<?php
/**
* 	@package Controllers
*/

namespace Controllers;
use Aws\S3\S3Client;
use Components\Enums;
use Models\Uploads;

/**
 * Manipulate Uploads to Facebook and Amazon S3
 * @version 2.0.0
  */
Class Upload extends \app\Controller
{
    /**
     * Intance of Model Uploads
     * @var Object
     */
    public $up;

    /**
     * Construct
     * Create instance of Model
     */
    public function __construct($app)
    {
        parent::__construct($app);
        $this->up = new Uploads($app);
    }

    /**
     * Upload photo to Facebook Graph
     * 
     * ### Reference
     * https://developers.facebook.com/docs/graph-api/reference/page/photos/
     *
     * ## Permissions
     * publish_actions permission is needed for this action
     * as of now there is no error message concerning the lack of this permission, instead Facebook only sends no 'success' property
     * 
     * @uses $_FILES
     *   ['file']       file    file (required)
     * @uses $_POST:
     *   ['callback']   string  callback function name (required)
     *   ['token']      string  access token (required)
     *   ['pageid']     int     fanpage id (required)
     *   ['message']    string  post content (required)
     * @return String
     */
    public function uploadPhotoFb()
    {

        try {
            $this->checkFile($_FILES);

            if (!isset($_POST['callback']) || !$_POST['callback'])
                throw new \Exception("callbackNotSent", Enums::callbackNotSent);

            if (!isset($_POST['token']) || !$_POST['token'])
                throw new \Exception("Ttoken not sent", Enums::tokenNotSent);

            if (!isset($_POST['pageId']) || !$_POST['pageId'])
                throw new \Exception("invalidParams", Enums::invalidParams);

            if (!isset($_POST['message']) || !$_POST['message'])
                throw new \Exception("Invalid message", Enums::invalidParams);

            $response = $this->up->uploadPhoto($_POST['pageId'], $_POST['token'], $_FILES['file'], $_POST['message'], $_POST['callback']);
            echo $response;

        } catch(\Exception $e) {
            if(isset($_POST['callback']))
                $_POST['callback'] = "ERROR";

            echo $this->up->error($e->getMessage(), $e->getCode(), $_POST['callback']);
        }

    }

    /**
     * Upload photo to ad account library on facebook.
     *
     * https://developers.facebook.com/docs/reference/ads-api/adimage/
     * 
     * @uses $_FILES
     *   ['file']       file    file (required)
     * @uses $_POST:
     *   ['callback']   string  callback function name (required)
     *   ['token']      string  access token (required)
     *   ['accountid']  int     ad account id (required)
     *   ['message']    string  post content (required)
     * @return String
     */
    public function uploadAlbumPhotoFb()
    {
        try {
            $this->checkFile($_FILES);

            if (!isset($_POST['callback']) || !$_POST['callback'])
                throw new \Exception("Callback not sent", Enums::callbackNotSent);

            if (!isset($_POST['token']) || !$_POST['token'])
                throw new \Exception("Token not sent", Enums::tokenNotSent);

            if (!isset($_POST['accountId']) || !$_POST['accountId'])
                throw new \Exception("Invalid accountId", Enums::invalidParams);

            $response = $this->up->uploadAlbum($_POST['accountId'], $_POST['token'], $_FILES['file'], $_POST['callback']);
            echo $response;

        }catch(\Exception $e)
        {
            if(isset($_POST['callback']))
                $_POST['callback'] = "ERROR";

            $response = $this->up->error($e->getMessage(), $e->getCode(), $_POST['callback']);
            echo $response;
        }
    }

    /**
     * $_FILES error check
     * @param  Array $file $_FILES
     */
    private function checkFile($file) {
        if (!isset($file['file']) || $file['file']['error']==4) throw new \Exception("No file uploaded", Enums::noFileSent);
        else switch ($file['file']['error']) {
            case 0:
                break;
            case 1:
            case 2:
                throw new \Exception("Maximum upload size exceeded", Enums::uploadMaxSizeExceeded);
                break;
            case 3:
                throw new \Exception("The file was only partially uploaded", Enums::uploadPartialUpload);
                break;
        }
    }


    /**
     * Upload video to Facebok Graph
     * @return String
     */
    public function uploadVidFb()
    {


        try{

            if((!isset($_POST['pageId']) && !$_POST['pageId']) || (!isset($_POST['token']) && !$_POST['token']) || (!isset($_POST['callback']) && !$_POST['callback']))
                throw new \Exception(Enums::invalidParams);

            if (!isset($file))
                throw new \Exception(Enums::noFileSent);

            $response = $this->up->uploadVideo($_POST['pageId'], $_POST['token'], $_FILES['file'], $_POST['message'], $_POST['callback']);

            echo $response;

        }catch(\Exception $e)
        {
            if(isset($_POST['callback']))
                $_POST['callback'] = "ERROR";

            echo $this->up->error($e->getMessage(), $e->getCode(), $_POST['callback']);
        }
    }

}
