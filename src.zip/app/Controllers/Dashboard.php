<?php
/**
 * @package Controllers
 */
namespace Controllers;
use Components\Canvas;
use Components\Facebook;
use Components\Rest;
use Guzzle\Http\Client;
 /**
  * Dashboard
  */
Class Dashboard extends \app\Controller
{
    public $options;
    public $graphUrl;
    public $client;
    protected $today;
    protected $app;


    public function __construct($app) {
        parent::__construct($app);
        $this->graphUrl = $this->app->config('fb.graphurl');
        $this->client = new Client();
        $this->options = http_build_query(array('wt' => "json",'omitHeader' => 'true'));
        $this->url = $this->app->config('solr_host');
    }

    public function dashboard()
    {
        $this->title = _('titleDashboard');
        $this->render('Dashboard/dashboard');
    }

    /**
     * Load Dashboard
     * @param  integer  $accountId
     * @param  integer  $startTime timestamp
     * @param  integer  $endTime   timestamp
     * @param  string  $status    enums
     * @param  integer $limit     qtd
     * @return json
     */
    public function load($accountId, $startTime, $endTime, $status = 'ACTIVE,PAUSED,CAMPAIGN_GROUP_PAUSED,ARCHIVED,DELETED', $limit = 4)
    {
        try {
            $pathAccount = '/act_'.$accountId;
            $token = $_SESSION['user']['token'];
            $status = "['".implode("','", explode(',', $status))."']";

            $getVars = $this->app->request->get();
            if(isset($_GET['nextPage'])) {
                $responseCampaigns = $this->client->get($_GET['nextPage']);
                $responseCampaigns = $responseCampaigns->send();
                $responseCampaigns = $responseCampaigns->json();

            } else {
                $path = $pathAccount . '/adcampaigns';
                $params = [
                    'access_token' => $token,
                    'campaign_status' => $status,
                    'start_time' => $startTime,
                    'end_time' => $endTime,
                    'limit' => $limit,
                    'fields' => 'id,account_id,name,lifetime_budget,daily_budget,budget_remaining,campaign_status,start_time,end_time,updated_time,created_time'
                ];
                $responseCampaigns = $this->client->get($this->graphUrl.$path.'?'.http_build_query($params));
                $responseCampaigns = $responseCampaigns->send();
                $responseCampaigns = $responseCampaigns->json();

            }

            // Erro Handling
            if(isset($responseCampaigns['error'])) {
                $this->log->error(print_r($responseCampaigns,true));
                throw new \Exception("Invalid Facebook Communication");
            }

            // No campaigns
            if(!$responseCampaigns['data']) {
                $this->renderJson(1,null);
                return;
            }

            // Next Page
            if(isset($responseCampaigns['paging']['next'])) {
                $nextPage = $responseCampaigns['paging']['next'];
            }
            $campaigns = $responseCampaigns['data'];
            $campaignIds = array();
            foreach ($campaigns as $campaign) $campaignIds[] = $campaign['id'];
            $campaignIdsQuery = '['.implode(',',$campaignIds).']';

            //NEW
            $query = 'campaignId:'.implode(' OR campaignId:',$campaignIds);
            $request = $this->client->get($this->url.'fb_campaigns/select?q='.$query."&".$this->options);
            $response = $request->send();
            $result = $response->json();

            $campaignTypes = array();

            foreach ($result['response']['docs'] as $campaign) {
                $campaignTypes[(string)$campaign['campaignId']] = $campaign['objective'];
            }

            // Get Stats
            $path = $pathAccount . '/adcampaignstats';
            $params = [
                'access_token' => $token,
                'campaign_ids' => $campaignIdsQuery,
            ];


            $responseStats = $this->client->get($this->graphUrl.$path.'?'.http_build_query($params));
            $response = $responseStats->send();
            $responseStats = $response->json();

            $campaignStats = array();

            foreach ($responseStats['data'] as $campaign) {
                $actions = 0;
                if($campaign['actions']) {
                    foreach ($campaign['actions'] as $type => $value) {
                        //TODO DEFINE ACTIONS (USING ALL)
                        $actions += $value;
                    }
                } else {
                    $actions = 0;
                }

                $campaignStats[(string)$campaign['campaign_id']]['actions'] = $actions;
                $campaignStats[(string)$campaign['campaign_id']]['spent'] = $campaign['spent'];
                // $campaignStats[$campaign['campaign_id']]['inline_actions'] = $campaign['inline_actions'];
            }

            // Merge type and stats on Campaigns
            foreach ($campaigns as &$campaign) {
                if(isset($campaignTypes[$campaign['id']]))
                    $campaign['objective'] = $campaignTypes[$campaign['id']];
                if(isset($campaignStats[$campaign['id']]))
                    $campaign = array_merge($campaign, $campaignStats[$campaign['id']]);
                else
                    $campaign = array_merge($campaign, ['actions'=>0,'spent'=>0]);
            }

            if(isset($nextPage)) $this->renderJson(1, $campaigns, $nextPage);
            else $this->renderJson(1, $campaigns);
            return;

        } catch (\Exception $e) {
            return $this->renderJson($e->getCode(), null, $e->getMessage(),  false, false);
        }
    }
}
