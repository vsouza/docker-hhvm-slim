<?php
/**
 * @package Controllers
 */
namespace Controllers;
use Components\Rest; 

 /**
  * Controls User Operations
  */

Class Notifications extends \app\Controller
{
	public function __construct($app)
	{
		parent::__construct($app);
	}
	/**
	 * Lista todas as notificações
	 * @param  int $qtd   Quantidade de solicitações que serão retornadas
	 * @param  int $start Indíce para paginação
	 * @return JSON
	 */
	public function listAll($qtd, $start)
	{
		$params = "?fbId=".$_SESSION['user']['fbId']."&start=".$start."&qtd=".$qtd;
        $value = (new Rest($this->config('data_base_url')))->get("/user/notifications/listAll",$params);

		foreach ($value['data'] as $key) {
			$key['createdDate'] = strtotime($key['createdDate']);
			$value['createdDate'] = $key['createdDate'];
			if( isset( $key['readDate'] ) ){
   				$key['readDate'] = strtotime($key['readDate']);
   				$value['readDate'] = $key['readDate'];
			}
		}
		$this->renderJson(null, $value['data'], $value['message']);
	}

	/**
	 * Lista todas as notificações e marcar como lida
	 * @param  int $qtd   Quantidade de solicitações que serão retornadas
	 * @param  int $start Indíce para paginação
	 * @return JSON
	 */
	public function listAndRead($qtd, $start)
	{
		$params = "?fbId=".$_SESSION['user']['fbId']."&start=".$start."&qtd=".$qtd;
        $value = (new Rest($this->config('data_base_url')))->get("/user/notifications/listAndRead",$params);

		foreach ($value['data'] as $key) {
			$key['createdDate'] = strtotime($key['createdDate']);
			$value['createdDate'] = $key['createdDate'];
			if( isset( $key['readDate'] ) ){
   				$key['readDate'] = strtotime($key['readDate']);
   				$value['readDate'] = $key['readDate'];
			}
			
			switch ($key['category']) {
				case 1:
					//Campanha
					$message = "Sua Campanha <a href='/'>".$key['param1']."</a>".$key['message'];
					break;
				case 2:
					$message = "Seu anúncio <a href='/".$key['param1']."'>".$key['param1']."</a> da campanha <a href=".$key['param2'].">".$key['param2']."</a>".$key['message'];
					break;
				case 3:
					$message = "Sua conta".$key['message'];
					break;
			}

			$key['message'] = $message;
			unset($key['userId'], $key['accountId'], $key['param1'], $key['param2'], $key['param3'], $key['adId'], $key['campaignId']);
		}
		
		$this->renderJson(null, $value['data']);
	}

	/**
	 * Marcar notificações
	 * @param  String $id   Id da notificação
	 * @return JSON
	 */
	public function checkAsRead($id)
	{
		$params = "?id=".$id;
        $value = (new Rest($this->config('data_base_url')))->get("/user/notifications/read",$params);
		$this->renderJson($value['code']);
	}

	/**
	 * Crirar notificações
	 * @param  String $id   Id da notificação
	 * @return JSON
	 * create?userId=556320929&campaignId=556320929&adId=556320929&message=foi%20finalizada&category=2&param1=startou&param2=adajdisj&param3=kasjdjdia
	 */
	public function create($fbId, $campaignId, $adId, $category, $message, $param1, $param2, $param3)
	{
		
        $params = array(
        	'fbId' => $fbId,
        	'campaignId' => $campaignId,
        	'adId' => $adId,
        	'message' => $message,
        	'category' => $category,
        	'param1' => $param1,
        	'param2' => $param2,
        	'param3' => $param3
        	);
        $params = http_build_query($params);      
        $params = htmlentities($params);        
        $value = (new Rest($this->config('data_base_url')))->get("/user/notifications/create?",$params);        
		$this->renderJson($value['code']);
	}

}