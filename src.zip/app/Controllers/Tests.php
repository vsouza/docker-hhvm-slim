<?php
/**
 * @package Controllers
 */
namespace Controllers;

use Components\Mailer;

 /**
  * Class for testing and debugging purposes
  */
Class Tests extends \app\Controller
{
    /**
     * Ads API Experiments
     */
    public function test() {
        $this->render("Tests/test",['appid'=>$this->config('fb.appid')],'test');
    }

    /**
     * Visual Elements
     */
	public function elements()
	{
        $this->render("Tests/elements",[],'test');
	}
}
