<?php
/**
 * @package Controllers
 */
namespace Controllers;

use \Components\Mailer;
use \Components\MySQL;
use \Components\Enums;
use Models\Plan;
 /**
  * Website Controller
  */
Class Website extends \app\Controller
{

    /**
     * Landing Page
     */
    public function index()
    {
        if(!$this->getCookie('cachecleared')) {
            header("Cache-Control: no-cache, must-revalidate");
            header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
            $this->setCookie('cachecleared',1);
        }
        $plans = (new Plan($this->app))->listPlans();
        $this->title = 'Tamboreen | '._('siteHomeTitle');
        $this->render('Website/index',['appid'=>$this->config('fb.appid'), 'scope'=>$this->config('fb.scope'), 'plans'=>$plans],'website');
    }

    /**
     * Contact form
     */
    public function sendContact()
    {
        try {
            if((new Mailer())->contact($this->request->post())) $this->renderJson(1);
            else $this->renderJson(501, null, 'Error sending transactional mail', false);
        } catch(Mandrill_Error $e) {
            $this->renderJson(500, null, get_class($e).' - '.$e->getMessage(), false);
        }
    }

    /**
     * Contact form
     */
    public function signUp()
    {
        try {

            $data = $this->request->post();

            if(!isset($data['email']) || !filter_var($data['email'],FILTER_VALIDATE_EMAIL))
                throw new \Exception("invalidParams", Enums::invalidParams);

            $conn = MySQL::connect($this->app);

            if(!is_object($conn))
                throw new \Exception("mysqlAdapterError", Enums::mysqlAdapterError);

            $stmt = $conn->prepare("INSERT INTO preorder (email, createdAt) VALUES (:email, :createdAt)");
            $stmt->bindParam(':email', $data['email']);
            $stmt->bindParam(':createdAt', date('Y-m-d\TH:i:s\Z'));
            $stmt->execute();

            return $this->renderJson(1, $this->request->post());

        } catch(Mandrill_Error $e) {

            $this->renderJson(500, null, get_class($e).' - '.$e->getMessage(), false);

        } catch(\Exception $e)
        {
            $this->renderJson($e->getCode(), null, $e->getMessage(), false);
        }
    }
}
