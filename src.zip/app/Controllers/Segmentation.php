<?php
/**
 * @package Controllers
 */
namespace Controllers;
use Components\Enums;

use Guzzle\Http\Client;

 /**
  * Controls User Operations
  */

Class Segmentation extends \app\Controller
{
	private $client;
	private $token;
	public $app;
	public $qtd = 4;

	public function __construct($app)
	{
		$this->app = $app;
		$this->token = $_SESSION['user']['token'];
		$this->client = new Client();
	}

	/**
	 * Get interests for page post
	 * @return [array] interests list
	 */
	public function goalPages()
	{
		try{
			$keywords = $this->getPageKeywords();
			
			if(is_null($keywords))
				throw new \Exception('noKeywordsFound', Enums::noKeywordsFound);

			$category = $this->validCategories($keywords);
			
			if(!$category)
				throw new \Exception('noCategoriesFound', Enums::noCategoriesFound);

			
			$interests = $this->hotTopic($category);
			
			if(is_null($interests))
				throw new \Exception('noInterestsFound', Enums::noInterestsFound);

			
			$code = Enums::noInterestsFound;
			$interests = array_slice($interests, 0, $this->qtd);
			return $this->renderJson($code, $interests, null, true);

		}catch(\Exception $e)
		{
			return $this->renderJson($e->getCode(), null, $e->getMessage(),  false, false);
		}

	}

	/**
	 * Get interests for website goal
	 * @return [array] interests list
	 */
	public function goalWebsite()
	{
		try{
			$keywords = $this->getUrlKeywords();
			
			if(is_null($keywords))
				throw new \Exception('noKeywordsFound', Enums::noKeywordsFound);

			$category = $this->validCategories($keywords);

			if(!$category)
				throw new \Exception('noCategoriesFound', Enums::noCategoriesFound);

			$interests = $this->hotTopic($category);
			
			if(is_null($interests))
				throw new \Exception('noInterestsFound', Enums::noInterestsFound);

			$code = Enums::noInterestsFound;
			return $this->renderJson($code, $interests, null, true);

		}catch(\Exception $e)
		{
			return $this->renderJson($e->getCode(), null, $e->getMessage(),  false, false);
		}
	}

	/**
	 * Get Url from facebook page, in 'website' section or traversing 'about' section searching for links.
	 * @return [string]      keywords separate by comma
	 */
	public function getPageKeywords()
	{
		$pageId = $this->request->post("pageId");

		$params = array(
			"access_token" => $this->token,
			"id" => $pageId,
			"locale" => $_SESSION['user']['lang']
		);

		$params = http_build_query($params);
		$url = $this->app->config('fb.graphurl') . "/?" . $params;

		$request = $this->client->get($url);
		$response = $request->send();
		$response = $response->json();

		if(!isset($response['website']))
		{
			
			preg_match_all('{\b(?:http://)?(www\.)?([^\s]+)(\.com|\.org|\.net)\b}mi', $response['about'], $match);
			if(count($match[0]) && $this->validUrl($match[0][0]) )
			{
				$response['website'] = $match[0][0];
			}
			else{
				$keywords = explode("/", $response['category']);
				$keywords = implode(",", $keywords);
				return $keywords;
			}
		}
		
		$keywords = $this->getUrlKeywords($response['website']);
		

		if(is_null($keywords))
		{
			$keywords = explode("/", $response['category']);
			$keywords = implode(",", $keywords);

		}

		return $keywords;
	}

	/**
	 * Extract keyword from html 
	 * @param  [string] $url url for parsing
	 * @return [string]      keywords separate by comma
	 */
	public function getUrlKeywords($url = null)
	{
		if(is_null($url))
			$url = $this->request->post('url');
		
		if (!preg_match("~^(?:f|ht)tps?://~i", $url))
                $url = "http://" . $url;

		$doc = file_get_contents($url);
		$html = new \DOMDocument();
		@$html->loadHTML($doc);	

		$elements = $html->getElementsByTagName('meta');
		
		foreach($elements as $node)
			if($node->getAttribute('name')=='keywords')
			    $keywords = $node->getAttribute('content');
 
 		if(!isset($keywords))
 			return;
 		else
 			return $keywords;

	}


	/**
	* Get list of interests and check if valid on facebook
	* @param $list (String (values separate by comma))
	* @version 1.0
	* @author Vinicius Souza
	* @return String
	*/
	public function validCategories($list)
	{
		$keywords = explode(",", $list);
		$val = array();
		foreach ($keywords as $key => $value) {
			
			
			$value = "'".trim($value)."'";
			array_push($val, $value);
		}
		$keywords = implode(",", $val);	
		$list = '['.$keywords.']';

		$params = array(
			"type" => "adinterestvalid",
			"interest_list" => $list,
			"access_token" => $this->token,
			"locale" => $_SESSION['user']['lang']
			);

		$params = http_build_query($params);
		$url = $this->app->config('fb.graphurl') . "/search?" . $params;
		
		$request = $this->client->get($url);
		$response = $request->send();		
		$response = $response->json();

		$result = array();
 
		foreach ($response as $key)
			foreach ($key as $value) 
				if($value['valid'])
					if(!in_array(strtolower($value['name']), $result))
						$result[$value['audience_size']] = strtolower($this->clean($value['name']));	

			
		krsort($result);
		
		$data = reset($result);
		
		return $data;
	}
	
	/**
	 * Remove special chars from string
	 * @param  [string] $str text for clean
	 * @return [string]      text cleaned
	 */
	private function clean($str) {
	   	$invalid = array('Š'=>'S', 'š'=>'s', 'Đ'=>'Dj', 'đ'=>'dj', 'Ž'=>'Z', 'ž'=>'z',
			'Č'=>'C', 'č'=>'c', 'Ć'=>'C', 'ć'=>'c', 'À'=>'A', 'Á'=>'A', 'Â'=>'A', 'Ã'=>'A',
			'Ä'=>'A', 'Å'=>'A', 'Æ'=>'A', 'Ç'=>'C', 'È'=>'E', 'É'=>'E', 'Ê'=>'E', 'Ë'=>'E',
			'Ì'=>'I', 'Í'=>'I', 'Î'=>'I', 'Ï'=>'I', 'Ñ'=>'N', 'Ò'=>'O', 'Ó'=>'O', 'Ô'=>'O',
			'Õ'=>'O', 'Ö'=>'O', 'Ø'=>'O', 'Ù'=>'U', 'Ú'=>'U', 'Û'=>'U', 'Ü'=>'U', 'Ý'=>'Y',
			'Þ'=>'B', 'ß'=>'Ss', 'à'=>'a', 'á'=>'a', 'â'=>'a', 'ã'=>'a', 'ä'=>'a', 'å'=>'a',
			'æ'=>'a', 'ç'=>'c', 'è'=>'e', 'é'=>'e', 'ê'=>'e',  'ë'=>'e', 'ì'=>'i', 'í'=>'i',
			'î'=>'i', 'ï'=>'i', 'ð'=>'o', 'ñ'=>'n', 'ò'=>'o', 'ó'=>'o', 'ô'=>'o', 'õ'=>'o',
			'ö'=>'o', 'ø'=>'o', 'ù'=>'u', 'ú'=>'u', 'û'=>'u', 'ý'=>'y',  'ý'=>'y', 'þ'=>'b',
			'ÿ'=>'y', 'Ŕ'=>'R', 'ŕ'=>'r', "`" => "'", "´" => "'", "„" => ",", "`" => "'",
			"´" => "'", "“" => "\"", "”" => "\"", "´" => "'", "&acirc;€™" => "'", "{" => "",
			"~" => "", "–" => "-", "’" => "'");
	 
		$str = str_replace(array_keys($invalid), array_values($invalid), $str);
	 
		return $str;
	}

	/**
	 * Check if url is valid
	 * @param  [string] $url url for validate
	 * @return string      string of url if true.
	 */
	private function validUrl($url)
	{
		if (!preg_match("~^(?:f|ht)tps?://~i", $url))
                $url = "http://" . $url;

        $url = filter_var($url, FILTER_VALIDATE_URL);

		if(empty($url))
			return false;
		
		return	$url;
	}

	

	/**
	 * Receive one keyword and returns a maximum of 3 keywords Facebook HotTopic 
	 * @return array adinterest
	 */
	public function hotTopic($keywords)
	{
		
		$params = array(
			'type' => "adinterest",
			'q' => $keywords,
			'access_token' => $this->token,
			"locale" => $_SESSION['user']['lang']
			);
		$url = $this->app->config('fb.graphurl') . "/search?" . http_build_query($params);
		$request = $this->client->get($url);
		$response = $request->send();
		
		$response = $response->json();


		$data = array();
		
		foreach ($response as $key) 
			foreach ($key as $value)
				$data[$value['audience_size']] = ['name' => $value['name'], 'id' => $value['id']];

		krsort($data);
		
		return $data;
	}

}	