<?php
/**
 * @package Controllers
 */
namespace Controllers;
use Components\Rest;
use Components\Mailer;
use Components\Facebook;
 /**
  * Controls User Operations
  */
Class Ads extends \app\Controller
{

    /////////////////
    // Ad Creation //
    /////////////////

    /**
    * Goal selection
    */
    public function goals()
    {
        if(isset($_GET['refresh'])) {
            $Facebook = new Facebook($this->app);
            $adAccounts = $Facebook->getAdAccounts($_SESSION['user']['token']);
            $_SESSION['user']['adaccounts'] = $Facebook->prettifyAccounts($adAccounts);
        }
        $this->title = _('titleGoalSelect');
        $this->render("Ads/goals");
    }

    /**
    * Objective #1: Promover um post
    */
    public function goal1($accountId)
    {
        $this->title = _('titleGoal1');
        $this->app->customGA = true;
        $this->render("Ads/goal1",['accountId'=>$accountId,'appid'=>$this->config('fb.appid')]);

    }

    /**
    * Objective #2: Conquistar fans, likes
    */
    public function goal2($accountId)
    {
        $this->title = _('titleGoal2');
        $this->app->customGA = true;
        $this->render("Ads/goal2",['accountId'=>$accountId]);
    }

    /**
    * Objective #3: Conquistar fans, likes
    */
    public function goal3($accountId)
    {
        $this->title = _('titleGoal3');
        $this->app->customGA = true;
        $this->render("Ads/goal3",['accountId'=>$accountId]);
    }

    ////////////////
    // Ad Details //
    ////////////////

    /**
     * Ad Details
     * @param  int $accountId
     * @param  int $campaignId
     * @param  int $objective
     *  POST_ENGAGEMENT => 1
     *  PAGE_LIKES => 2
     *  WEBSITE_CLICKS || WEBSITE_CONVERSIONS => 3
     *  UNSPECIFIED => 0
     */
    public function adDetails($accountId, $campaignId, $objective)
    {
        $this->title = _('titleAdDetails');
        $this->app->customGA = true;
        $this->render("Ads/addetails", ['campaign'=>[
            'accountId' => $accountId,
            'campaignId' => $campaignId,
            'objective' => $objective
        ]]);
    }

    public function sendPixel()
    {

        $data = $this->request->post();
        $pixel =  new Mailer();
        if($pixel->sendPixel($data))
            $this->renderJson(1);
        else
            $this->renderJson(2, null, null, false);
    }
}
