<?php
/**
 * @package Controllers
 */
namespace Controllers;
use Models\User;
use Components\Facebook;
use Components\Enums;
use Components\Mixpanel;
use Models\Plan;
use Models\Subscription;

 /**
  * Settings Controller
  */
Class Settings extends \app\Controller
{
    /**
     * My Account
     */
    public function myAccount()
    {

        $data = $this->request->post();

        if(!empty($data)) {
            try {
                $fbId = $_SESSION['user']['fbId'];
                $timezone = $data['timezone'];
                $lang = $data['lang'];

                $response = (new User($this->app))->setUser($fbId, $timezone, $lang);

                if(is_null($response))
                    throw new \Exception('Enums:userNotFound', Enums::userNotFound);
                $_SESSION['user']['timezone'] = $data['timezone'];
                $_SESSION['user']['lang'] = $data['lang'];
                setupi18n($data['lang']);
            } catch(\Exception $e) {
              return $this->renderJson(1, null, $e->getMessage());
            }
        }

        $user = (new User($this->app))->getUser($_SESSION['user']['fbId']);

        $this->title = _('titleMyAccount');
        $this->render("Settings/myaccount", ['data'=>$user,'update'=>!empty($data)]);

    }

    /**
     * Subscription
     */
    public function subscription()
    {

        $plans = (new Plan())->listPlans();

        $subscription = (new Subscription())->getSubscription($_SESSION['user']['mysqlId']);

        foreach ($plans as &$key)
        {
          if($key['plan'] == $subscription['plan'])
            $key['user'] = $subscription;
        }

        $this->title = _('subscription'); // TODO TRANSLATE
        $this->render("Settings/subscription",['plans'=>$plans]);
    }

    /**
     * Payments
     */
    public function payments()
    {
        $this->title = _('titlePayments'); // TODO TRANSLATE
        $this->render("Settings/payments");
    }

    /**
     * Notifications
     */
    public function notifications()
    {
        $this->title = _('titleNotications');
        $this->render("Settings/notifications");
    }

    /**
     * Extensions
     */
    public function extensions()
    {
        $this->title = _('titleExtensions');
        $this->render("Settings/extensions");
    }

    /**
     * Revoke Permissinons
     */
    public function revoke()
    {
        $this->title = _('revokeTitle');
        $this->render("Settings/revoke");
    }
}
