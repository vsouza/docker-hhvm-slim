<?php
/**
 * @package Controllers
 */
namespace Controllers;

use Models\User;
use Models\Subscription;
use Components\Facebook;
use Components\Mailer;
use Components\Rest;
use Components\Mixpanel;
use \Guzzle\Http\Client;

/**
* Controls User Operations
*/
Class Users extends \app\Controller
{
    /* Chronos Trait */
    use \Components\Chronos;

    /**
     * Login Facebook Process (JS)
     * @return JSON:
     * code: adAccountStatus()
     *
     * Errors: checkPermissions()
     */
    public function login()
    {
        try {
            $data = $this->request->post();
            if(!isset($data['token'])) $this->renderJson(400, null, 'No data token', false);
            $Facebook = new Facebook($this->app);

            $user = $Facebook->getUser($data['token']);
            $dbUser = $this->joinUser($user); //Database Login/Registration

            $adAccounts = $Facebook->getAdAccounts($user['token']);
            $this->setUserSession($user, $dbUser, $adAccounts, $Facebook);

            $pages = $Facebook->getPages($_SESSION['user']['token']);
            $numPages = count($pages);

            /** RESPONSE DATA **/

            $data = [
                'registration' => $dbUser['registration'],
                'fbId'=>$user['fbId'],
                'numAdAccounts' => count($adAccounts),
                'numPaymentMethods' => $Facebook->countPaymentMethods($adAccounts),
                'hasAds' => $Facebook->hasAds($user['token'], $adAccounts),
            ];

            // Mixpanel
            if($this->config('mixpanel.token')) {
                $mixpanelProfile = (new Mixpanel())->mixpanelProfile($user, $dbUser['data']);
                $adAccountsProfile = [
                    'Ad Accounts' => $data['numAdAccounts'],
                    'Payment Methods' => $data['numPaymentMethods'],
                    'Has Published Ads?' => $data['hasAds'],
                    'Fanpages' => $numPages
                ];
                $data['mixpanelProfile'] = array_merge($mixpanelProfile, $adAccountsProfile);
                $data['loginData'] = $adAccountsProfile;
            }

            /** MESSAGE **/

            // Redirect url
            $url = null;
            if(isset($_SESSION['urlRedirect'])) { $url = $_SESSION['urlRedirect']; unset($_SESSION['urlRedirect']); };

            return $this->renderJson(1, $data, $url);
        } catch (\Exception $e) {
            return  $this->renderJson($e->getCode(), null, $e->getMessage() . ' ['.$e->getFile().':'.$e->getLine().']', false);
        }
    }

    /**
     * Join user in Solr
     * Receive from rest params and decide what do with user
     * @return Enum Code
     * @author vinicius Souza
     * @version 0.0.1
     * @access public
     */
    public function joinUser($data)
    {
        $data['id'] = number_format($data['id'], 0, '.', '');
        $registration = false;

        $response = (new User($this->app))->login($data['id']);

        if(!is_null($response))
        {

            if(strcmp($data['token'], $response['token']) != 0)
                $this->updateToken($data['id'], $data['token']);

            return ['data'=>$response, 'registration'=>$registration];
        }

        if(!is_null($response = (new User($this->app))->signupSolr($data)))
        {
            $registration = true;
            return ['data'=>$response, 'registration'=>$registration];
        }

        return null;

    }

    private function setUserSession($userData, $dbUser, $adAccounts, $Facebook)
    {
        $userData['mysqlId'] = $dbUser['data']['mysqlId'];
        $userData['expiresTrial'] = $dbUser['data']['expiresTrial'];
        $userData['statusAccount'] = $dbUser['data']['statusAccount'];
        if(isset($dbUser['data']['timezone'])) $userData['timezone'] = $dbUser['data']['timezone'];
        $userData['lang'] = isset($dbUser['data']['lang']) ? $dbUser['data']['lang'] : $userData['locale'];

        $fUserData = array_intersect_key($userData, array_flip(['token', 'email', 'fbId', 'firstName', 'surname', 'gender', 'website', 'birthday', 'mysqlId', 'timezone', 'lang', 'statusAccount', 'expiresTrial']));

        $Subscription = new Subscription();

        // Subscription
        if($fUserData['statusAccount'] == 1) {
            $fUserData['subscription'] = $Subscription->getSubscription($fUserData['mysqlId']);
            // Check Subscription Deadline
            if($fUserData['subscription']['nextDue'] <= $this->getIsoDate()) {
                $Subscription->changeStatus(0, $fUserData['mysqlId'], 'subscriptions', 'status');
                $fUserData['subscription']['status'] = 0;
            }
        }

        $fUserData['adaccounts'] = $Facebook->prettifyAccounts($adAccounts);

        $_SESSION['user'] = $fUserData;
    }

    /**
     * Log user out of the system
     */
    public function logout()
    {
        $redirect = '/';
        if(isset($_SESSION['user'])) {
            $lang = $_SESSION['user']['lang'];
            if($lang!=$this->config('lang.default'))
                $redirect = '/'.substr($lang, 0, 2);
        }
        $_SESSION = [];
        session_unset();
        session_destroy();
        $this->redirect($redirect);
    }

    /**
     * Revoke Facebook permissions and logout
     */
    public function revoke()
    {
        $postData = $this->request->post();
        if(!isset($postData['revoke'])) $this->redirectTo('dashboard');
        $params = ['access_token' => $_SESSION['user']['token']];
        $Guzzle = new Client($this->app->config('fb.graphurl'));
        $request = $Guzzle->delete("/me/permissions?".http_build_query($params));
        $response = $request->send();
        $this->logout();
    }

    /**
     * Set data in Session
     * @return data
     */
    public function setSessionData($key = null, $value = null)
    {
        $postData = $this->request->post();
        if(!empty($postData)) {
            $_SESSION['user'] = array_merge($_SESSION['user'], $postData);
        } elseif (!empty($key) && !empty($value)) {
           return $_SESSION['user'][$key] = $value;
        }
        return false;
    }

    /**
     * Unset data in Session
     * @return data
     */
    public function unsetSessionData($key, $value)
    {
       if(!empty($key) && !empty($value))
       {
           unset($_SESSION['user'][$key]);
           return true;
       }
        return false;
    }

    /**
     * Set data in Session
     * @return data
     */
    public function getSessionData($key)
    {
       if(!empty($key))
       {
         $data = array($key => $_SESSION['user'][$key]);
         return json_encode($data);
       }
        return false;
    }

    /**
     * Get user data
     * @param  int $fbId
     * @return array
     */
    public function getUser($fbId)
    {
        //TODO validate data
        return ['data'=>(new User($this->app))->getUser($fbId)];
    }

    /**
     * Set user data
     * @param int $fbId
     * @param int $timezone
     * @param string $lang
     * @return array
     */
    public function setUser($fbId, $timezone, $lang)
    {
        //TODO validate data

        return ['data'=>(new User($this->app))->setUser($fbId, $timezone, $lang)];
    }

    /**
     * Update facebook token in db
     * @param  int $fbId  [description]
     * @param  string $token [description]
     * @return boolean
     */
    public function updateToken($fbId, $token)
    {
        //TODO validate data
        return (new User($this->app))->updateToken($fbId, $token);
    }

    //////////
    // JSON //
    //////////

    /**
     * Refresh Ad Accounts
     */
    public function updateAdAccounts() {
        $Facebook = new Facebook($this->app);
        $adAccounts = $Facebook->getAdAccounts($_SESSION['user']['token']);
        try {
          $prettyAccounts = $Facebook->prettifyAccounts($adAccounts);
          $_SESSION['user']['adaccounts'] = $prettyAccounts;
          $this->renderJson(1, ['adaccounts'=>$prettyAccounts]);
        } catch (\Exception $e) {
        $this->renderJson(0,null,$e->getMessage(),false);
        }
    }


}
