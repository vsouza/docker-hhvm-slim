<?php
/**
 * @package Controllers
 */

namespace Controllers;
use Models\Campaigns as Model;
use Components\Enums;

 /**
  * Class for Campaigns and Ads Variations
  */
Class Campaigns extends \app\Controller
{
    public $model;

    public function __construct()
    {
        $this->model = new Model();
    }

    /**
     * Get Master Ad of Campaign
     * @param  long $campaignId id for reference in Solr
     * @author Vinicius Souza <vinicius@ezlike.com.br>
     * @return json
     */
    public function getMasterAd($campaignId)
    {
        try{

            $masterAd = $this->model->getMasterAd($campaignId);

            if(is_null($masterAd))
                 throw new \Exception("getMasterAdError", Enums::getMasterAdError);

            $code = Enums::getMasterAdSuccess;

            return $this->renderJson($code,  $masterAd);
        }
        catch(\Exception $e)
        {
           return $this->renderJson($e->getCode(), $e->getMessage(),  null, false);
        }
    }

    /**
     * Save campaign in DB
     * @author Vinicius Souza <vinicius@ezlike.com.br>
     * @param Int  campaignId
     * @param Int accountId
     * @param String name
     * @param String adVariations
     * @param  String objective
     * @return json
     */
    public function goal()
    {
        try{

            $data = $_POST;

            if(!isset($data['campaignId']) || !isset($data['accountId']) || !isset($data['primaryAdId']))
                throw new \Exception("invalidParams", Enums::invalidParams);

            if(!isset($data['callback']))
                throw new \Exception("callbackNotSent", Enums::callbackNotSent);

            $goal = $this->model->save($data);

            if(is_null($goal))
                throw new \Exception("saveAdVariationsError", Enums::saveAdVariationsError);

            $callback = $data['callback'];
            $code = Enums::campaignSaved;
            $retorno = "
                      /**/
                      $callback({data: {
                         success: true,
                         code: $code
                      }});
                    ";

            echo $retorno;

        }
        catch(\Exception $e)
        {
            $callback = (!isset($data['callback'])) ? 'error' : $data['callback'];
            $code = $e->getCode();
            $message = $e->getMessage();
            $retorno = "
                      /**/
                      $callback({data: {
                         success: true,
                         code: $code,
                         message: $message
                      }});
                    ";

            echo $retorno;
        }

    }

    /**
     * Clear Documents before output. Remove unnecessary keys
     * @param  array $doc document with keys
     * @author Vinicius Souza <vinicius@ezlike.com.br>
     * @return array     cleaned properly document
     */
    public function clearDoc($doc)
    {
        foreach ($doc as $doc) {

            if(array_key_exists("_version_", $doc))
                unset($doc['_version_']);

            if(array_key_exists("nameStr", $doc))
                unset($doc['nameStr']);

            if(array_key_exists("solrHash", $doc))
                unset($doc['solrHash']);

        }
        return $doc;
    }

}
