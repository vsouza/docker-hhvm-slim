<?php
/**
 * @package Controllers
 */

namespace Controllers;
use Models\Subscription;
use Models\Plan;
use Components\Paypal;
use Components\Enums;
use Components\Mailer;

/**
 * Manipulate Subscriptions
 */
Class Subscriptions extends \app\Controller
{
    use \Components\Log;
    use \Components\Chronos;
    /**
     * Slim Instance
     * @var Object
     */
    public $app;

    /**
     * Model Subscription instance
     * @var Object
     */
    public $model;

    /**
     * mysqlId
     * @var int
     */
    public $user;

    /**
     * Payer data
     * @var array
     */
    public $payer;



    public $mailer;


    public function __construct($app)
    {
        $this->app = $app;

        $this->model = new Subscription();

        $this->paypal = new Paypal();

        $this->mailer = new Mailer();
    }

    /**
     * Set data for payer
     * @param array $payer
     */
    public function setPayer($payer)
    {
        $this->payer = $payer;
    }

    /**
     * Return payer data
     * @param  index $param
     * @return array or index
     */
    public function getPayer($param = null)
    {
        if(is_null($param))
            return $this->payer;

        return $this->payer[$param];
    }

    /**
     * Create subscription
     * @param $_POST['description']
     * @param $_POST['period']
     * @param $_POST['frequency']
     * @param $_POST['amount']
     * @param $_POST['name']
     * @param $_POST['plan']
     * @return JSON array
     */
    public function create()
    {
        try{

            $data = $this->app->request->post();

            if(!isset($data) || empty($data))
                throw new \Exception("invalidParams", Enums::invalidParams);

            $data['mysqlId'] = $_SESSION['user']['mysqlId'];
            $data['email'] = $_SESSION['user']['email'];
            $data['firstName'] = $_SESSION['user']['firstName'];
            $data['surname'] = $_SESSION['user']['surname'];
            $data['lang'] = $_SESSION['user']['lang'];

            if(isset($_SESSION['user']['expiresTrial']) || !empty($_SESSION['user']['expiresTrial']))
            {
                $expiresTrial = $_SESSION['user']['expiresTrial'];

            }else{
                $expiresTrial = $this->getIsoDate();
            }

            $data['startDate'] = $this->model->getStartDate($_SESSION['user']['mysqlId'], $expiresTrial);

            //Check if user is subscriber
            $subscriber = $this->model->getSubscription($data['mysqlId']);
            if(!is_null($subscriber))
            {
                $data['profileId'] = $subscriber['profileId'];
                $this->paypal->cancelProfile($data);
                $data['startDate'] = $subscriber['nextDue'];

            }

            $this->paypal->createSubscription($data);

            return true;

        }catch(\Exception $e)
        {
            $this->renderJson(Enums::getPlansError, $e->getMessage().$e->getLine().$e->getFile(), null);
        }

    }

    /**
     * Cancel subscription
     * @param  string $profileId
     * @return 301 Redirect
     */
    public function cancel()
    {
        try{

            $data = $this->app->request->post();

            setupi18n($_SESSION['user']['lang']);

            if(!isset($data['profileId']) || empty($data['profileId']))
            {
                $subscription = $this->model->getSubscription($_SESSION['user']['mysqlId']);
                $data['profileId'] = $subscription['profileId'];
            }

            $data['email'] = $_SESSION['user']['email'];
            $data['mysqlId'] = $_SESSION['user']['mysqlId'];
            $data['startDate'] = null;

            $fullName = $_SESSION['user']['firstName']." ".$_SESSION['user']['surname'];
            //TODO arrancar startDate;
            //
            $cancel = $this->paypal->cancelProfile($data);

            $cancelDb = $this->model->cancel($data['profileId'], $_SESSION['user']['mysqlId']);

            if($cancelDb)
            {
                $this->mailer->canceling($data['email'], $fullName);
                $this->app->redirect('/subscription?cancel=true');
            }

            $this->app->redirect('/subscription');

        }catch(\Exception $e)
        {
            $this->renderJson(Enums::getPlansError, $e->getMessage().$e->getLine(), null);
        }
    }

    /**
     * Receive response from paypal
     * @param  $data['PAYERID'] string
     * @param  $data['subscriber'] string
     * @param  $data['startDate'] string
     * @param  $data['mysqlId'] string
     * @param  $data['email'] string
     * @param  $data['firstName'] string
     * @param  $data['surname'] string
     * @param  $data['CUSTOM'] string hash of base_64 serialized
     * @return View
     */
    public function receiveReturn()
    {

        try{

            $token = $_GET['token'];

            if(!$token)
                return false;

            $expressCheckoutDetails = $this->paypal->getCheckoutDetails($token);

            $plan = unserialize(base64_decode($expressCheckoutDetails['CUSTOM']));

            setupi18n($plan['lang']);

            $mplan = new Plan();

            $values = $mplan->getPlan($plan['plan']);

            $data = $this->paypal->doPayment($expressCheckoutDetails, $token);

            $fullName = $plan['name'];

            if(!is_null($data))
            {
                $this->mailer->paymentAproval($plan['email'], $fullName, $this->formatDate($plan['lang']), $values['name'], $values['amount']);
            }

            $data['startDate'] = $plan['startDate'];
            $data['mysqlId'] = $plan['mysqlId'];
            $data['fullname'] = $plan['name'];
            $data['email'] = $plan['email'];
            $data['PAYERID'] = $expressCheckoutDetails['PAYERID'];
            $data['description'] = $values['description'];
            $data['period'] = $values['period'];
            $data['frequency'] = $values['frequency'];
            $data['amount'] = $values['amount'];
            $data['name'] = $values['name'];
            $data['plan'] = $plan['plan'];
            $data['profileId'] = $plan['plan'];
            $data['subscriber'] = $plan['name'];

            $profile = $this->paypal->createRecurringProfile($token, $data);

            if($profile['ACK'] != "Success")
                throw new \Exception("subscriptionCreateError", Enums::subscriptionCreateError);

            $data['profileId'] = $profile['PROFILEID'];

            $subs = $this->model->create($data);

            if(!is_null($subs))
            {
                $this->mailer->thankYou($plan['email'], $fullName);
            }

            $log = array(
                'mysqlId' => $plan['mysqlId'],
                'profileId' => $profile['PROFILEID']
            );

            $this->logger($log, "createPaypalRecurringProfile", "payments");

            $this->app->redirect('/subscription');

        }catch(\Exception $e)
        {
            $this->renderJson(Enums::getPlansError, $e->getMessage().$e->getLine(), null);
        }

    }

}
