<?php
/**
* @package app
*/
namespace app;

use DebugBar;
use Components\Canvas;
use Components\Chronos;
use Models\User;

 /**
 * Application (extended Slim)
 */
Class Shark extends \Slim\Slim
{
    /** @var PHPDebugBar */
    public $debugbar;

    public function __construct()
    {
        parent::__construct(['mode'=>'production']);
        require(ROOTPATH.'/config/config.php');
        $this->hook('slim.before.dispatch', array($this, 'accessGate'));
        require(ROOTPATH.'/config/routes.php');
    }

    /**
     * Acccess Gate
     */
    public function accessGate()
    {
        $this->checkAuth();
        if(isset($_SESSION['user']))
            $this->checkPayment();
    }

    /**
     * Authentication Gate
     */
    public function checkAuth()
    {
        $currentPath = $this->request()->getPathInfo();
        if($this->isAllowedRoute($currentPath, $this->config('allowed_routes'))) return;
        if(empty($_SESSION['user']['token'])) {
            if($currentPath != $this->urlFor('home'))
                $_SESSION['urlRedirect'] = $this->request()->getPathInfo();
            $this->redirect('/');
        }
    }

    /**
     * Checks for Allowed Route (Access withour login)
     * @param  string   $path
     * @param  array    $allowed    Array of allowed routes
     * @return bool
     */
    public function isAllowedRoute($currentPath, $allowed)
    {
        $search = array("/", "*");
        $replace   = array("\/", "(.*)");

        foreach ($allowed as $route) {
            $route = str_replace($search, $replace, $route);
            if(preg_match('/^'.$route.'$/', $currentPath)) return true;
        }
        return false;
    }

    /**
     * Payment Gate
     *
     * Status de Usuários:
     * 1 - Assinante
     * 2 - Trial
     *
     * Status de Assinaturas:
     * 0 - Cancelado
     * 1 - Assinante em dia
     * 2 - Assinante com pagamento vencido
     * 3 - Em cancelamento (esperar o vencimento para alterar para cancelado)
     */
    public function checkPayment()
    {
        if($this->getMode()=='development') return;

        $currentPath = $this->request()->getPathInfo();

        if($_SESSION['user']['statusAccount'] == 1) {
            // Subscriber
            if($this->isAllowedSubscriber($_SESSION['user']['subscription'], $currentPath)) return;
        } else {
            // Trial
            $trialDaysLeft = (new User($this))->remainingDays($_SESSION['user']['mysqlId']);
            $this->view()->appendData(['trialDaysLeft' => $trialDaysLeft > 0 ? $trialDaysLeft : 0]);
            if($this->isAllowedTrial($trialDaysLeft, $currentPath)) return;
        }
        $this->redirect('/dashboard');
    }

    /**
     * Checks if a subscriber can access a route
     * @param  Array    $subscription User Subscription plan
     * @param  string   $currentPath  Current accessed path
     * @return boolean
     */
    function isAllowedSubscriber($subscription, $currentPath) {
        // Payment is up to date
        if($subscription['status'] == 1) return true;

        $this->view()->appendData(['subscriptionExpired' => true]);

        // Allowed route
        if($this->isAllowedRoute($currentPath, $this->config('payment_pending_routes'))) return true;

        // Inside tolerance
        $tolerance = (new \DateTime($subscription['nextDue']))->modify('+'.$this->config('billing.tolerance_days').' days');
        $now = new \DateTime($this->getIsoDate());
        if($tolerance < $now) return true;

        return false;
    }

    /**
     * Checks if a trial user can access a route
     * @param  int      $trialDaysLeft  Days left in trial
     * @param  string   $currentPath    Current accessed path
     * @return boolean
     */
    function isAllowedTrial($trialDaysLeft, $currentPath) {
        if($trialDaysLeft < 1)
            $this->view()->appendData(['trialExpired' => true]);

        // Has trial days
        if($trialDaysLeft > -$this->config('billing.tolerance_days')) return true;

        // Allowed route
        if($this->isAllowedRoute($currentPath, $this->config('payment_pending_routes'))) return true;

        return false;
    }
}
