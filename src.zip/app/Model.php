<?php
/**
* @package app
*/
namespace app;

use Valitron\Validator;
 
 /**
 * Parent Model class 
 */
Class Model
{
    /** @var Model Data */
    protected $data;

    /** @var Slim Logger */
    protected $log;

    public function __construct()
    {
        //$this->log = \Slim\Slim::getInstance()->log;
    }

    /**
     * Instantiate Valitron Validator
     * @param array     $data   Data for validation
     * @param array     $fields Filtering of allowed field names 
     * @return  Validator
     */
    public function validator($data, $fields = array(), $lang = 'pt-br') {
        return new Validator($data, $fields, $lang);
    }
    /**
     * Wrapper for $this->log->info(), coverts array to string
     * @param   mixed   $data       Log data
     * @param   string  $wrapper    Wrapper
     * @return void
     */
    public function log($data, $wrapper = null) {
        if(is_array($data)) $data = print_r($data, true);
        if($wrapper) $this->log->info("--------- $wrapper ---------");
        $this->log->info($data);
        if($wrapper) $this->log->info("--------- $wrapper ---------");
    }
}
