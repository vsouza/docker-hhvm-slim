<?php
/**
 * @package Models
 */

namespace Models;
use Components\Solr;
use Components\Enums;

/**
* Model for Campaigns
*/
Class Campaigns extends \app\Model
{
	use \Components\Chronos;
	

	/**
	 * Solr Component Instance
	 * @var $solr
	 */
	public $solr;


	/**
	 * Construct
	 * @param Object $app
	 */
	public function __construct()
	{
		$this->solr = new Solr();
	}

	/**
	 * Save Campaign in db
	 * @param  Int $data['campaignGroupId']
	 * @param  String $data['name']
	 * @param  String $data['objective']
	 * @param  String (list separate by comma) $data['adVariations']
	 * @param  Int $data['accountId']
	 * @param  Int $data['campaignGroupId']
	 * @param  Int $data['campaignId']
	 * @param  Int $data['primaryAdId']
	 * @return Boolean
	 */
	public function save($data)
	{

        // if(!isset($data['adVariations']))
        // 	if(!$this->saveAdVariations($data['adVariations'], $data['accountId'], $data['campaignId']))
        // 		return;

        $document = [
        	'accountId' => $data['accountId'],
        	'campaignId' => $data['campaignId'],
        	'primaryAdId' => $data['primaryAdId'],
        	'campaignGroupId' => (!isset($data['campaignGroupId'])) ? 0 : $data['campaignGroupId'],
        	'objective' => $data['objective'],
        	'name' => $data['name'],
        	'createdTime' => $this->getIsoDate()
        ];
    	$this->solr->setCore('fb_campaigns');
    	if(!is_null($this->solr->addDocument($document)))
    		return true;
	}

	/**
	 * Save Ad Varations in fb_ads collection
	 * @param  String $adIds      A lista separate by comma
	 * @param  Int $accountId
	 * @param  Int $campaignId
	 * @return [type]
	 */
	public function saveAdVariations($adIds, $accountId, $campaignId)
	{

		$ad = explode(",", $adIds);
		$docs = array();

		foreach ($ad as $var)
		{
			$document = [
				'accountId' => $accountId,
				'campaignId' => $campaignId,
				'adId' => trim($var),
				'createdTime' => $this->getIsoDate()
			];

			array_push($docs, $document);
		}

		$this->solr->setCore('fb_ads');

        if(!is_null($this->solr->addDocuments($docs)))
    		return true;

    	return false;
	}

	/**
	 * Get master Ad of campaign
	 * @param  Int $campaignId
	 * @return Array
	 */
	public function getMasterAd($campaignId)
	{
		if(!is_numeric($campaignId))
			throw new \Exception(Enums::invalidParams);

		$this->solr->setCore('fb_campaigns');
		$this->solr->setOption('wt', 'json');

		$master = $this->solr->findByKey('campaignId', $campaignId);
		$master = array_shift($master['response']['docs']);

		if(!$this->solr->getNumFound())
			throw new \Exception(Enums::masterAdNotFound);

        return $master;
	}

}
