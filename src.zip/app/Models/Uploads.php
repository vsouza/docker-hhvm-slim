<?php
/**
 * @package Models
 */
namespace Models;

use Components\Rest;
use Components\Enums;
use \Guzzle\Http\Client;
/**
* Model for Users
*/
Class Uploads extends \app\Model
{
    /**
    * Graph url for video posts
    * @var string
    */
	const URL_VIDEO = "https://graph-video.facebook.com/v2.2/";

    /**
    * Graph url for Image posts
    * @var string
    */
    const URL_GRAPH = "https://graph.facebook.com/v2.2/";

    /**
    * Timeout for cUrl Request
    * @var Tnteger
    */
	const TIMEOUT = 180;

    /**
    * Slim Instance
    * @var object
    */
	public $app;
	
    /**
     * Construct
     * @param Object $app Slim Instance
     */
	public function __construct($app)
	{
		$this->app = $app;
	}

    /**
     * Upload photo to Facebook
     * @param  Integer $pageId  
     * @param  String $token    
     * @param  String $message  
     * @param  String $callback 
     * @return String
     */
    public function uploadPhoto($pageId, $token, $file, $message, $callback)
    {

        $postData = array(
            'file' => '@'.$file['tmp_name'].';filename='.basename($file['name']),
            'message' => $message,
            'access_token' => $token
        );
        
        $url = self::URL_GRAPH.$pageId."/photos";
        
        $response = $this->makeResquest($url, $postData);
        if($this->app->getMode()!='production') {
            echo "<!-- ";
            echo('$postData: '); print_r($postData); echo "\n";
            echo('$url: '); print_r($url); echo "\n";
            echo('$response: '); print_r($response); echo "\n";
            echo "-->";
        }

        if(isset($response['error']) && $response['error'])
            return $this->error($response['error']['message'], Enums::uploadError, $callback);

        if(!isset($response['post_id']) || empty($response['post_id']))
            return $this->error("publish_action permission needed", Enums::permissionError, $callback);      

        return $this->success(Enums::uploadSuccess, $callback, "postId", ''.$response['post_id']);
    }

    /**
     * Upload image to facebook account library
     * @param  Integer $accountId 
     * @param  String $token   
     * @param  file $file      
     * @param  String $callback 
     * @return String
     */
    public function uploadAlbum($accountId, $token, $file, $callback)
    {
       
        $postData = array(
            'file' => '@'.$file['tmp_name'].';filename='.basename($file['name']),
        );
        $url = self::URL_GRAPH."act_".$accountId."/adimages?access_token=".$token;
        
        $response = $this->makeResquest($url, $postData);
        
        if(isset($response['error']))
            return $this->error($response['error']['message'], Enums::uploadError, $callback);

        if(!isset($response['images'][basename($file['name'])]['hash']) || !isset($response['images'][basename($file['name'])]['url']))
            return $this->error("invalidIdResponse", Enums::uploadError, $callback);

        return $this->success(Enums::uploadSuccess, $callback, "hash", (string)$response['images'][basename($file['name'])]['hash'], "url", (string)$response['images'][basename($file['name'])]['url']);

    }


    /**
     * Upload video to facebook
     * @param  Integer $pageId   
     * @param  String $token   
     * @param  File $file     
     * @param  String $message  
     * @param  String $callback 
     * @return String
     */
	public function uploadVideo($pageId, $token, $file, $message, $callback)
	{

		//TODO Fazer o config funcionar        
        // $formato = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        // if(!in_array($formato, $this->config('allowed.video')))
        //     throw new \Exception(Enums::invalidFormatFile);
        
        $url = self::URL_VIDEO.$pageId."/videos?access_token=".$token;
        
        $postData = array(
            'source' => '@'.$file['tmp_name'].';filename='.basename($file['name']),
            'description' => $message
        );
         
        $response = $this->makeResquest($url, $postData);

        if(isset($response['error']) && $response['error'])
        	return $this->error($response['error']['message'], Enums::uploadError, $callback);

        if(!isset($response['post_id']) || empty($response['post_id']))
            return $this->error("publish_action permission needed", Enums::permissionError, $callback); 
        
        return $this->success(Enums::uploadSuccess,  $callback, "id", $response['post_id']);

	}

    /**
     * Success Response
     * @param  Integer $code   
     * @param  String $key     
     * @param  Mixed $value    
     * @param  String $key2    
     * @param  Mixed $value2   
     * @param  String $callback 
     * @return String
    */
	private function success($code, $callback, $key, $value, $key2 = null, $value2 = null)
	{

		if(!is_null($key2) &&  !is_null($value2))
		{
            $key2 = "$key2";
            $value2 = "$value2";
			$success = "
                <script>
                /**/
        	    $callback({data: {
            		    success: true, 
                 		code: ".$code.",
                 		$key: '$value', 
                 		$key2: '$value2' 
                }});
                </script>
                "; 

            return $success;    
        }

		$success = "
                <script>
                /**/
        	    $callback({data: {
            		    success: true, 
                 		code: ".$code.",
                 		".$key.": '".$value."'
                }});
                </script>
                "; 

        return $success;        
	}

    /**
     * Error response
     * @param  String $message 
     * @param  Integer $code   
     * @param  String $callback
     * @return String
     */
	public function error($message, $code, $callback)
	{

		$error = "
                <script>
                /**/
        	    ".$callback."({data: {
            		    success: false, 
                 		code: ".$code.",
                 		message: \"".(string)$message."\", 
                }});
                </script>
                "; 

		return $error;
	}

    /**
     * Make Curl Request
     * @param  String $url 
     * @param  Array $data 
     * @return Json Array
     */
	private function makeResquest($url, $data)
	{
		$post = curl_init($url);

        curl_setopt($post, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($post, CURLOPT_POST, true);
        curl_setopt($post, CURLOPT_SSL_VERIFYPEER, false); 
        curl_setopt($post, CURLOPT_POSTFIELDS, $data);
        curl_setopt($post, CURLOPT_FOLLOWLOCATION, false);
        set_time_limit(self::TIMEOUT);
        curl_setopt($post, CURLOPT_TIMEOUT, self::TIMEOUT);
        $response = curl_exec($post);
        curl_close($post);

        $response = json_decode($response, true);

        return $response;
	}


}