<?php
/**
 * @package Models
 */

namespace Models;
use \Components\Solr;
use \Components\Enums;
use \Components\Paypal;
/**
* Model for Campaigns
*/


Class Subscription extends \app\Model
{

	use \Components\Chronos;
	use \Components\Log;

	/**
	 * Solr component Instance
	 * @var Object
	 */
	public $solr;

	/**
	 * Date of creation account
	 * @var String
	 */
	public $startDate;

	/**
	 * User subscription details
	 * @var array
	 */
	public $subscription;

	/**
	 * Set instance for solr component
	 */
	public function __construct()
	{
		$this->solr = new Solr();
	}


	/**
	 * Get Details of subscription
	 * @return array
	 */
	public function getSubscription($mysqlId)
	{
		$this->solr->setCore('subscriptions');
        $this->solr->setOption('wt', 'json');
		$response = $this->solr->findByKey('mysqlId', (string)$mysqlId);

		$this->subscription = array_shift($response['response']['docs']);

		//Clear array
		unset($this->subscription['frequency'], 
			$this->subscription['period'], 
			$this->subscription['email'], 
			$this->subscription['amount'], 
			$this->subscription['createdAt'], 
			$this->subscription['_version_']);

		return $this->subscription;
	}

	/**
	 * Set start date value
	 * @param String $endTrial 
	 */
	public function getStartDate($mysqlId, $endTrial)
	{
		if($endTrial > $this->getIsoDate())
			return $endTrial;

		return $this->getIsoDate();
	}

	/**
	 * Date of next payment
	 * @param  int $period
	 * @return string isoDate
	 */
	public function nextDue($startDate, $frequency)
	{

		$datetime = new \DateTime(date( "Y-m-d", strtotime($startDate) ));

		if($frequency > 1)
		{
			$datetime->modify("+ $frequency months");
		
		}else{
			
			$datetime->modify("+1 month");
		}					

		return (string)$datetime->format('Y-m-d\TH:i:s\Z');
	}

	/**
	 * Create subscriptions method
	 * @param  string or Int $mysqlId
	 * @param  string $email
	 * @param  int $plan
	 * @param  float $value
	 * @param  string $createdAt
	 * @param  int $status
	 * @return int
	 */
	public function create($data)
	{
		
		$val = array(
			'mysqlId' => $data['mysqlId'],
			'email' => $data['email'],
			'plan' => (int)$data['plan'],
			'amount' => (float)$data['amount'],
			'frequency' => (int)$data['frequency'],
			'description' => $data['description'],
			'period' => $data['period'],
			'name' => $data['name'],
			'status' => 1,
			'createdAt' => $this->getIsoDate(),
			'profileId' => $data['profileId'],
			'startDate' => $data['startDate'],
			'nextDue' => $this->nextDue($data['startDate'], $data['frequency'])
			);

		$this->solr->setCore('subscriptions');

		$response = $this->solr->addDocument($val);

		//TODO remove expiresTrial
		//

		if(is_null($response))
			throw new \Exception("subscriptionCreateError", Enums::subscriptionCreateError);

		$this->changeStatus(1, $_SESSION['user']['mysqlId'], 'users', 'statusAccount');		

		return $val;
	}

	/**
	 * Cancel subscritpion
	 * @param  string $profileId 
	 * @param  string $mysqlId 
	 * @return boolean
	 */
	public function cancel($profileId, $mysqlId)
	{
		
		$this->solr->setCore('subscriptions');
		$this->solr->setOption('wt', 'json');
		$response = $this->solr->findByKey('profileId', $profileId);

		if(!(boolean)$this->solr->getNumFound())
			return false;

		$response = array_shift($response['response']['docs']);

		if($response['nextDue'] <= $this->getIsoDate())
		{
			return $this->changeStatus(0, $mysqlId, 'subscriptions', 'status');			
		}

		return $this->changeStatus(3, $mysqlId, 'subscriptions', 'status');

	}

	/**
	 * Set status in user account
	 * @param int $mysqlId
	 */
	public function changeStatus($status, $mysqlId, $collection, $field, $remove = false)
	{

		$this->solr->setCore((string)$collection);
		$this->solr->setOption('wt', 'json');

		$user = $this->solr->findByKey('mysqlId', (string)$mysqlId);
		$user = array_shift($user['response']['docs']);

		if(!$this->solr->getNumFound())
			throw new \Exception(Enums::userNotFound);

		$user[$field] = $status;

		unset($user['_version_']);

		if($collection == "users" && isset($user['expiresTrial']))
			unset($user['expiresTrial']);

		$fields = array($field);

		$response = $this->solr->update($user, $fields);

		return $response != null;
	}

}
