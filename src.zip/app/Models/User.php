<?php
/**
 * @package Models
 */
namespace Models;

use Components\Rest;
use Components\Mailer;
use \Components\MySQL;
use Components\Enums;
use \Guzzle\Http\Client;
use \Components\Solr;
/**
* Model for Users
*/
Class User extends \app\Model
{

    use \Components\Chronos;

    /**
     * Solr component Instance
     * @var $solr
     */
    public $solr;

    /**
     * Slim instance
     * @var $app
     */
    public $app;

    /**
     * Constructor
     * @param Object $app Slim Instance
     */
    public function __construct($app)
    {

        $this->app =  $app;

        $this->solr = new Solr();

    }

    /**
     * Login user in db
     * @param  int $fbId
     * @return array
     */
    public function login($fbId)
    {
        return $this->getUser($fbId);
    }

    /**
     * Signup Tamboreen user in Solr
     * @param  array $data
     * @return array
     */
    public function signupSolr($data)
    {
        $mysqlId = $this->signupMysql($data);

        if(!$mysqlId)
            throw new \Exception("Invalid Mysql");

        $document = [
            'firstName' => $data['first_name'],
            'surname' => $data['last_name'],
            'email' => $data['email'],
            'statusAccount' => 2,
            'expiresTrial' => $this->getIsoDate("+30 days"),
            'createdAt' => $this->getIsoDate(),
            'mysqlId' => (string)$mysqlId,
            'fbId' => $data['id'],
            'token' => $data['token'],
            'timezone' => (!isset($data['timezone'])) ? '' : $data['timezone'],
            'birthday' => (!isset($data['birthday'])) ? '' : $data['birthday'],
            'gender' => (!isset($data['gender'])) ? '' : $data['gender'],
            'website' =>  (!isset($data['website'])) ? '' : $data['website'],
            'lang' => (!isset($data['locale'])) ? '' : $data['locale']
           ];


        $this->solr->setCore("users");
        $this->solr->addDocument($document);

        setupi18n($data['locale']);
        if(!empty($data['email'])) (new Mailer())->welcome($data['email'],$data['first_name'].' '.$data['last_name']);

        return $document;


    }

    public function signupMysql($data)
    {
        $pdo = MySQL::connect($this->app);

        $date = $this->getIsoDate();

        $consulta = $pdo->prepare("SELECT id, fbId FROM users WHERE fbId = :fbId");
        $consulta->bindValue(':fbId', $data['id'], \PDO::PARAM_INT);
        $consulta->execute();
        $line = $consulta->fetch(\PDO::FETCH_ASSOC);

        if($line)
            return (int)$line['id'];

        $stmt = $pdo->prepare("INSERT INTO users (firstName, surname, email, fbId, timezone, lang,  createdAt) VALUES (:firstName, :surname, :email, :fbId, :timezone, :lang, :createdAt)");
        $stmt->bindValue(':firstName', $data['first_name']);
        $stmt->bindValue(':surname', $data['last_name']);
        $stmt->bindValue(':email', $data['email']);
        $stmt->bindValue(':fbId', $data['id']);
        $stmt->bindValue(':timezone', $data['timezone']);
        $stmt->bindValue(':lang', $data['locale']);
        $stmt->bindParam(':createdAt', $date);
        $stmt->execute();

        return $pdo->lastInsertId();
    }

    /**
     * Update user Facebook Token
     * @param  array $data
     * @return boolean
     */
    public function updateToken($fbId, $token)
    {

        $user = $this->getUser($fbId);

        $document = [
            'email' => $user['email'],
            'firstName' => $user['firstName'],
            'surname' => $user['surname'],
            'statusAccount' => $user['statusAccount'],
            'lang' => $user['lang'],
            'timezone' => $user['timezone'],
            'gender' => $user['gender'],
            'website' => $user['website'],
            'birthday' => $user['birthday'],
            'fbId' => number_format($fbId, 0, '.', ''),
            'token' => array('set'=> $token),
            'mysqlId' => (string)$user['mysqlId']
            ];

        $this->solr->setCore("users");
        if(!is_null($this->solr->addDocument($document)))
            return true;

        return false;
    }

    /**
     * Get user data from db
     * @param  int $fbId
     * @return array
     */
    public function getUser($fbId)
    {
        $this->solr->setOption('wt', 'json');
        $this->solr->setCore('users');
        $response = $this->solr->findByKey('fbId', number_format($fbId, 0, '.', ''));

        if(!(boolean)$this->solr->getNumFound())
            return;

        return array_shift($response['response']['docs']);
    }

    /**
     * Set user data in db
     * @param int $fbId
     * @param string $timezone
     * @param string $lang
     */
    public function setUser($fbId, $timezone, $lang)
    {
        $this->solr->setOption('wt', 'json');
        $this->solr->setCore('users');
        $response = $this->solr->findByKey('fbId', number_format($fbId, 0, '.', ''));

        if(!(boolean)$this->solr->getNumFound())
            return;

        $user = array_shift($response['response']['docs']);

        $document = [
            'firstName' => $user['firstName'],
            'surname' => $user['surname'],
            'email' => $user['email'],
            'statusAccount' => $user['statusAccount'],
            'createdAt' => $user['createdAt'],
            'mysqlId' => (string)$_SESSION['user']['mysqlId'],
            'fbId' => number_format($fbId, 0, '.', ''),
            'token' => $_SESSION['user']['token'],
            'timezone' => $timezone,
            'birthday' => $user['birthday'],
            'gender' => $user['gender'],
            'website' => $user['website'],
            'lang' =>  $lang
            ];

        $this->solr->update($document, array('lang', 'timezone'));

        unset($document['timezone'], $document['lang']);
        $document['timezone'] = $timezone;
        $document['lang'] = $lang;

        return $document;
    }

    /**
     * Remaining Trial Days
     * @return int
     */
    public function remainingDays($mysqlId)
    {
        $this->solr->setCore('users');
        $this->solr->setOption('wt', 'json');
        $user = $this->solr->findByKey('mysqlId', $mysqlId);
        $user = array_shift($user['response']['docs']);

        if(!$this->solr->getNumFound())
            throw new \Exception(Enums::userNotFound);

        if($user['statusAccount'] == 1)
            return null;
        $today = $this->getIsoDate();
        $timeDiff = strtotime($user['expiresTrial']) - strtotime($today);
        $remainingDays = floor($timeDiff / (24 * (60 * 60)));

        return $remainingDays;
    }

    /**
     * Set status in user account
     * @param int $mysqlId
     */
    public function changeStatus($status, $mysqlId)
    {

        $this->solr->setCore('users');
        $this->solr->setOption('wt', 'json');

        $user = $this->solr->findByKey('mysqlId', (string)$mysqlId);
        $user = array_shift($user['response']['docs']);

        if(!$this->solr->getNumFound())
            throw new \Exception(Enums::userNotFound);

        $user[$field] = $status;

        unset($user['_version_']);
        $fields = array('statusAccount');

        $response = $this->solr->update($user, $fields);

        return $response != null;
    }


}
