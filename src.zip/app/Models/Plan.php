<?php
/**
 * @package Models
 */

namespace Models;
use \Components\Solr;
use \Components\Enums;


/**
* Model for Plans
*/
Class Plan extends \app\Model
{
	public $Solr;

	public function __construct()
	{
		$this->Solr = new Solr();
	}

	/**
	 * List all plans and detect if user have a subscription
	 * @return array
	 */
	public function listPlans()
	{
        $this->Solr->setCore('plans');
        $this->Solr->setOption('wt', 'json');
        $this->Solr->setOption('sort', 'plan asc');

        $response = $this->Solr->findAll();

        $docs = $response['response']['docs'];
        return $docs;
	}

	/**
	 * Return data of plan
	 * @param  int $plan 
	 * @return array
	 */
	public function getPlan($plan)
	{
		$this->Solr->setCore('plans');
        $this->Solr->setOption('wt', 'json');

        $response = $this->Solr->findByKey('plan', (int)$plan);

        $docs = array_shift($response['response']['docs']);

        return $docs;
	}

}
