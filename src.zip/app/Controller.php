<?php
/**
* @package app
*/
namespace app;

use Helpers\ViewHelper;

 /**
 * Parent Controller class
 */
Class Controller
{
    /** @var Slim Application */
    protected $app;
    /** @var Title for View */
    public $title = "Tamboreen";

    /**
     * Set application to $this->app
     * @param Slim $app Application
     */
    public function __construct($app)
    {
        $this->app = $app;
        $this->setLang();
    }

    /**
     * Set Language
     */
    protected function setLang() {
        if(isset($_SESSION['user'])) {
            setupi18n($_SESSION['user']['lang']);
            $this->app->view()->appendData(['lang' => $_SESSION['user']['lang']]);
        }
    }

    ////////////////////////
    // Slim Magic Methods //
    ////////////////////////

    /**
     * Return inaccessible methods from Slim app
     */
    public function __call($name, $arguments)
    {
        return call_user_func_array(array($this->app,$name),$arguments);
    }

    /**
     * Return inaccessible properties from Slim app
     */
    public function __get($name)
    {
        return $this->app->{$name};
    }

    ////////////////////
    // View Rendering //
    ////////////////////

    /**
     * Renders Layouts
     * Enables PHPDebugBar Renderer, simple layout (header and footer), and appending '.php' to template
     *
     * @param  string $path     The path of the template directory
     * @param  array  $data     Associative array of data made available to the view
     * @param  int    $status   The HTTP response status code to use (optional)
     */
    public function render($path, $data = array(), $layout = 'layout', $status = null)
    {
        $app = $this->app;

        // View Helper
        $viewHelper = new ViewHelper($app);
        $viewHelper->title = $this->title;
        $viewHelper->setViewData($path, $data);
        $app->view()->appendData(['V' => $viewHelper]);

        $this->debugbar('time','startMeasure','render', 'Render');
        $app->render("Layouts/$layout.php", $data, $status);
    }

    /**
     * Wrapper for Slim::render
     * @param  string $template The name of the template passed into the view's render() method
     * @param  array  $data     Associative array of data made available to the view
     * @param  int    $status   The HTTP response status code to use (optional)
     */
    public function classicRender($template, $data = array(), $status = null)
    {
        $app->render($template, $data, $status);
    }

    /**
     * Render JSON response
     * @param  int          $code       Response code
     * @param  array        $data       Response data
     * @param  string       $message    Debug message
     * @param  bool         $success    Response status
     * @param  bool|string  $log        Log response (true, 'plain' or false)
     * @return void
     */
    public function renderJson($code, $data = null, $message = null, $success = true, $log = null) {
        $this->response->headers->set('Content-Type', 'application/json');
        $response = ['success' => $success];
        $response['code'] = $code;
        if($data) $response['data'] = $data;
        if($message) $response['message'] = $message;
        $response_json = json_encode($response);
        if($log) {
            if($log == 'plain') $this->log($response);
            else $this->log($response_json);
        }
        $this->app->render('json.php', ['response' => $response_json]);
        return $response;
    }

    ////////////////////
    // Helper Methods //
    ////////////////////

    /**
     * Redirect to named route
     * @param  string               $name       The route name
     * @param  array                $params     Associative array of URL parameters and replacement values
     * @param  int      $status     The HTTP redirect status code (optional)
     */
    public function redirectTo($name, $params = array(), $status = 302)
    {
        $this->redirect($this->urlFor($name, $params), $status);
    }

    /**
     * Handle errors
     * @param  int      $code       Response code
     * @param  string   $message    Debug message
     * @return array                Response
     */
    public function error($code, $message = null)
    {
        $this->log->error($message);
        $this->halt(500);
    }

    /**
     * Handle errors (JSON)
     * @param  int      $code       Response code
     * @param  string   $message    Debug message
     * @return array                Response
     */
    public function errorJson($code, $message = null)
    {
        $this->log->error($message);
        return $this->renderJson($code, null, $message, false);
    }

    ///////////
    // Debug //
    ///////////

    /**
     * Wrapper for $this->log->info(), coverts array to string
     * @param  mixed $data Log data
     * @return void
     */
    public function log($data) {
        if(is_array($data)) $data = print_r($data, true);
        $this->log->info($data);
    }

    /**
     * PHPDebugBar helper
     * @param  string       $collector  Debug Collector
     * @param  string       $method     Method to be called
     * @param  array|string $data       Initial parameter
     * @param  array|string $extra      Optional parameter
     */
    public function debugbar($collector,$method, $data, $extra = null) {
        if ($this->debugbar) $this->debugbar[$collector]->{$method}($data, $extra);
    }
}
