<?php
/**
 * Enums Component
 * @package Components
 */
namespace Components;

abstract Class Enums
 {
    //General Errors
    const __default = self::invalidParams;

    const generalError = 0;
	const invalidParams = 1;
    const databaseError = 2;
    const facebookError = 3;
    const internalError = 4;
    const enviromentError = 5;
    const solrRequestError = 6;
    const mysqlAdapterError = 7;
    const badResponse = 8;
    const invalidRequest = 9;

    //POST Errors
    const callbackNotSent = 20;
    const tokenNotSent = 21;
    const permissionError = 22;

    //Upload
    const noFileSent = 50;
    const invalidFormatFile = 51;
    const uploadError = 52;
    const uploadSuccess = 53;
    const uploadMaxSizeExceeded = 54;
    const uploadPartialUpload = 55;
    const uploadTempFolderMissing = 55;


    //Consistency
    const campaignNotFound = 100;
    const masterAdNotFound = 101;
    const getMasterAdSuccess = 102;
    const getMasterAdError = 103;
    const campaignSaved = 104;
    const campaignSaveError = 105;
    const saveAdVariationsError = 106;

	//Segmentation
    const noInterestsFound = 200;
    const interestsFound = 201;
    const noKeywordsFound = 203;
    const noCategoriesFound = 204;

    //Subscriptions
    const subscriptionCreated = 300;
    const subscriptionCreateError = 301;

    //Users
    const userNotFound = 400;

    //Billing 
    const getPlansSuccess = 500;
    const getPlansError = 501;
    const paypalRequestError = 502;
    const paypalInvalidToken = 503;
    const profileUpdateError = 504;
    const userUpdateError = 505;
    const canceledByUser = 506;
    const notSubscriber = 507;

}

