<?php
/**
 * Facebook Component
 * @package Components
 */
namespace Components;
use Components\Rest;

class Facebook
{
    protected $app;

    public function __construct($app = null) {
        $this->app = $app;
    }

    //////////
    // USER //
    //////////

    /**
     * Get Facebook User
     */
    public function getUser($token)
    {
        $this->checkPermissions($token);
        $extendedToken = $this->getExtendedToken($token);
        $userData = $this->getFbUserData($extendedToken);
        $userData['token'] = $extendedToken;
        return $userData;
    }

    /**
     * Check for necessary permissions
     * @throws Exception if permissions are not granted:
     * 403: Management Permissions
     * 403: Management Permissions
     * 500: Facebook Communication Error
     * 402: Publish Stream (DEPRECATED)
     */
    public function checkPermissions($token) {
        $permissions = $this->getPermissions($token);

        $scopeCheck = explode(',', $this->app->config('fb.scope.check'));

        foreach ($scopeCheck as $permission) {
            if(!in_array($permission, $permissions)) {
                $this->app->log->error(print_r($permissions,true));
                // $code = ($permission=='publish_stream') ? 402 : 403;
                $code = 403; //
                throw new \Exception('missing: ' . $permission . ' | granted: ' . implode(',', $permissions) , $code);
            }
        }
    }

    /**
     * Get User's permissions for App on Facebook
     * @param  string $token Access Token
     * @return bool
     */
    public function getPermissions($token) {
        $params = ["access_token"=>$token];
        $permissionsData = (new Rest($this->app->config('fb.graphurl')))->get("/me/permissions",$params, true);

        if(isset($permissionsData['error'])) throw new \Exception("Communication error", 500);

        if(!isset($permissionsData['data'])) {
            $this->app->log->error(print_r($permissionsData,true));
            throw new \Exception("Permission Error", 500);
        }

        $permissions = [];
        for ($i=0; $i < count($permissionsData['data']); $i++) { 
            array_push($permissions, $permissionsData['data'][$i]['permission']);
        }

        return $permissions;
    }

    /**
     * Get extended token
     * @param  String $code Code for generate token
     * @return  int Login code
     */
    public function getExtendedToken($token)
    {
        $params = array(
            "client_id" => $this->app->config('fb.appid'),
            "client_secret" => $this->app->config('fb.appsecret'),
            "grant_type" => "fb_exchange_token",
            "fb_exchange_token" => $token
            );
        //TODO Make with guzzle
        //
        $url = $this->app->config('fb.graphurl') . '/oauth/access_token?'.http_build_query($params);
        $cURL = curl_init($url);
        curl_setopt($cURL, CURLOPT_RETURNTRANSFER, true);

        $isLocal = !isset($_SERVER['SERVER_ADDR']) || in_array($_SERVER['SERVER_ADDR'], ['::1', '127.0.0.1', '192.168.121.114', '192.168.121.107']);
        if($isLocal) 
            curl_setopt($cURL, CURLOPT_SSL_VERIFYPEER, false);
        $content = curl_exec($cURL);
        curl_close($cURL);

        if(isset($content['error'])) throw new \Exception("Communication error", 500);

        if(preg_match('/access_token/', $content)== false) {
            $this->app->log->error(print_r($content,true));
            throw new \Exception('Error retrieving token', 500);
        }

        $params = explode("&", $content);
        foreach ($params as $value) {
            if(strpos($value, "access_token")===false) continue;
            $token = explode("=", $value);
            $token = $token[1];
        }
        if(empty($token)) {
            $this->app->log->error(print_r($content,true));
            throw new \Exception('Error retrieving token', 500);
        }
        return $token;
    }

    /**
     * Get user data from Graph API and set them in object
     */
    public function getFbUserData($token)
    {
        $params = array('access_token' => $token,'fields'=> 'id,email,first_name,last_name,gender,currency,timezone,locale,birthday,education,website');

        $userData = (new Rest($this->app->config('fb.graphurl')))->get("/me",$params, true);

        if(isset($userData['error'])) throw new \Exception("Communication error", 500);

        $userData['fbId'] = $userData['id'];
        if(!isset($userData['email'])) $userData['email'] = '';
        if(!isset($userData['gender'])) $userData['gender'] = '';
        if(!isset($userData['website'])) $userData['website'] = '';
        if(!isset($userData['birthday'])) $userData['birthday'] = '';

        $userData['firstName'] = !empty($userData['first_name']) ? $userData['first_name'] : $userData['id'];
        $userData['surname'] = isset($userData['last_name']) ? $userData['last_name'] : '';

        return $userData;
    }

    /////////////////
    // AD ACCOUNTS //
    /////////////////

    /**
     * Get user's Ad Accounts
     * @return array Ad Accounts
     */
    public function getAdAccounts($token) {
        $params = [
            'fields' => 'name,currency,timezone_name,business_name' ,
            'access_token' => $token
        ];

        /* TODO (remove) Temporary capabilities check */
        $params['fields'] .= ',capabilities';

        $Rest = new Rest($this->app->config('fb.graphurl'));
        $urlGraph = "/me/adaccounts";
        $result = $Rest->get($urlGraph, $params, true);


        if(isset($result['error'])) throw new \Exception("Communication error", 500);
        $accounts = array_reverse($result['data']);

        return $accounts;
    }

    /**
     * Checks User's Accounts for Ads
     * @param  string $token    Facebook token
     * @param  array  $accounts Ad Accounts
     * @return bool
     */
    public function hasAds($token, $accounts)
    {
        foreach ($accounts as $account) {
            $adAccountId = $account['account_id'];

            $urlGraph = "/act_".$adAccountId."/adcampaigns";
            $params = ["access_token"=>$token,"limit"=>1];
            $Rest = new Rest($this->app->config('fb.graphurl'));
            $campanhas = $Rest->get($urlGraph,$params,true);

            if(isset($campanhas['error']))
                throw new \Exception("Communication error", 500);
            if(isset($campanhas['data'])&&count($campanhas['data']) > 0)
                return true;
        }
        return false;
    }

    ///////////
    // PAGES //
    ///////////


    /**
     * Get Facebook pages of which the current user is an admin.
     * @return array Pages
     */
    public function getPages($token) {
        $params = [
            'fields' => 'id' ,
            'access_token' => $token
        ];

        $Rest = new Rest($this->app->config('fb.graphurl'));
        $urlGraph = "/me/accounts";
        $result = $Rest->get($urlGraph, $params, true);


        if(isset($result['error'])) throw new \Exception("Communication error", 500);
        $accounts = $result['data'];

        return $accounts;
    }

    ////////////////////
    // HELPER METHODS //
    ////////////////////

    /**
     * Return prettified Ad Accounts
     * @param  array $accounts Ad Accounts
     * @return array
     */
    function prettifyAccounts($accounts) {
        $prettyAccounts = [];
        foreach ($accounts as $account) {
            $account['prettyName'] = $this->prettyName($account);
            $account['hasPaymentMethod'] = in_array('HAS_AVAILABLE_PAYMENT_METHODS', $account['capabilities']);
            $prettyAccounts[$account['account_id']] = $account;
        }
        return $prettyAccounts;
    }

    /**
     * Return prettified Ad Account name
     * @param  array $account Ad Account data
     * @return string
     */
    function prettyName($account) {
        if(isset($account['business_name']) && $account['business_name']) return $account['business_name'];
        if(isset($account['name']) && $account['name']) return $account['name'];
        return $account['account_id'];
    }

    /**
     * Counts how many Ad Accounts have Payment Methods
     * @param  array $accounts Ad Accounts
     * @return int
     */
    function countPaymentMethods($accounts) {
        $i = 0;
        foreach ($accounts as $account) {
            if(in_array('HAS_AVAILABLE_PAYMENT_METHODS', $account['capabilities']))
                $i++;
        }
        return $i;
    }
}
