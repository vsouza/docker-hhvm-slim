<?php
/**
 * Paypal Component
 * @package Components
 */
namespace Components;

use \Guzzle\Http\Client;
use \Components\Enums;

Class Paypal
{
	/**
	 * Slim instance
	 * @var Object
	 */
	public $app;

	/**
	 * Paypal Token
	 * @var string
	 */
	public $token;

	/**
	 * Params for request
	 * @var Array
	 */
	public $params;


	public function __construct()
	{
		$this->app = \Slim\Slim::getInstance();
	}

	/** 
	 * Set token of paypal
	 * @param string $token 
	 */
	public function setToken($token)
	{
		$this->token = $token;
	}

	/**
	 * Return paypal token
	 * @return string
	 */
	public function getToken()
	{
		return $this->token;
	}

	/**
	 * Return params of paypal item
	 * @return array
	 */
	public function getParams()
	{
		return $this->params;
	}

	/** 
	 * Create paypal subscription
	 * @param  array $data 
	 * @param $data['description']
	 * @param $data['period']
	 * @param $data['frequency']
	 * @param $data['amount']
	 * @param $data['name']
	 * @param $data['startDate']
	 * @return HTTP REDIRECT 301 // Paypal.com
	 */
	public function createSubscription($data) 
   	{
	 	if(!$this->setParams($data))
	 		throw new \Exception("invalidParams", Enums::invalidParams);
	 	
	 	$values = array(
	 		'plan' => $data['plan'],
	 		'mysqlId' => $data['mysqlId'],
	 		'email' => $data['email'],
	 		'name' => $data['firstName'].$data['surname'],
	 		'startDate' => $data['startDate'],
	 		'lang' => $data['lang']
	 		);


	 	
   		$this->auth(base64_encode(serialize($values))); 
   		
		$this->app->redirect($this->app->config('billing.paypal.checkout.url') . '&token=' . urlencode($this->getToken()));

	}

	/**
	 * Set params for paypal request
	 * @param array $data 
	 */
	public function setParams($data)
	{
		
		if(!isset($data) || empty($data))
			return false;

		$this->params = array(
			'RETURNURL' => $this->app->config('billing.return.url'),
			'CANCELURL' => $this->app->config('billing.cancel.url'),
			'NOSHIPPING' => 1,
			'BRANDNAME' => "Tamboreen",
			'LOGOIMG' => $this->app->config('billing.paypal.logo.img'),
			'LOCALECODE' => 'BR',
			'PAYMENTREQUEST_0_CURRENCYCODE' => $this->app->config('billing.paypal.currency.code'),
			'HDRIMG' => $this->app->config('billing.paypal.header.img'),
			'L_BILLINGTYPE0' => 'RecurringPayments',
			'L_BILLINGAGREEMENTDESCRIPTION0' => $data['description'],
			'L_PAYMENTREQUEST_0_ITEMCATEGORY0' => 'Digital',
			'L_PAYMENTREQUEST_0_QTY0' => 1,
			'L_PAYMENTREQUEST_0_NAME0' => $data['name'],
			'L_PAYMENTREQUEST_0_CURRENCYCODE' => "BRL",
			'BILLINGPERIOD' => $data['period'],
			'BILLINGFREQUENCY' => $data['frequency'],
			'CURRENCYCODE' => "BRL",
			'AMT' => str_replace(',', '.', $data['amount']),
			'MAXFAILEDPAYMENTS' =>  $this->app->config('billing.paypal.max.failed'),
			'COUNTRYCODE' => 'BR',
			'EMAIL' => $data['email'],
			'DESC' => $data['description'],
			'PROFILESTARTDATE' => $data['startDate']
		);
			

		return true;
	}

	/**
	 * Configure paypal cURL request
	 * @param  array $params 
	 * @return array
	 */
	public function auth($custom) 
	{
		
		$params = array(
			'METHOD' => "SetExpressCheckout",
			'VERSION' => $this->app->config('billing.paypal.version'),
			'PWD' => $this->app->config('billing.paypal.pwd'),
			'USER' => $this->app->config('billing.paypal.user'),
			'SIGNATURE' => $this->app->config('billing.paypal.signature'),
			'CUSTOM' => (string)$custom
		);

		$params = $params + $this->getParams();

		$response = $this->makeRequest($params);
		
		$this->setToken($response['TOKEN']);

		return $response;
	}

	/**
	 * Receive paypal notification of payment, if user not cancel
	 * @return boolean
	 */
	public function getCheckoutDetails($token)
	{

		$params = array(
			'METHOD' => "GetExpressCheckoutDetails",
			'VERSION' => $this->app->config('billing.paypal.version'),
			'PWD' => $this->app->config('billing.paypal.pwd'),
			'USER' => $this->app->config('billing.paypal.user'),
			'SIGNATURE' => $this->app->config('billing.paypal.signature'),
			'TOKEN' => $token
		);

		$response = $this->makeRequest($params);

		return $response;
	}

	/**
	 * Do first Paypal Payment
	 * @param  array $data  
	 * @param  string $token 
	 * @return array
	 */
	public function doPayment($data, $token)
	{
		
		$params = array(
			'AMT' => str_replace(',', '.', $data['AMT']),
			'CUSTOM' => $data['CUSTOM'],
			'PAYERID' => $data['PAYERID'],
			'PAYMENTACTION' => "Sale",
			'TOKEN' => $token,
			'CURRENCYCODE' => "BRL",
			'METHOD' => "DoExpressCheckoutPayment",
			'VERSION' => $this->app->config('billing.paypal.version'),
			'PWD' => $this->app->config('billing.paypal.pwd'),
			'USER' => $this->app->config('billing.paypal.user'),
			'SIGNATURE' => $this->app->config('billing.paypal.signature'),
		);
		
		$response = $this->makeRequest($params);
		
		return $response;
	}

	/**
	 * Create recurring profile in Paypal
	 * @param  $data['PAYERID'] string 
	 * @param  $data['subscriber'] string 
	 * @param  $data['startDate'] string 
	 * @param  $data['mysqlId'] string 
	 * @param  $data['description'] string 
	 * @param  $data['period'] string 
	 * @param  $data['frequency'] string 
	 * @param  $data['amount'] string 
	 * @param  $data['email'] string 
	 * @param  $data['fullname'] string  fullname user
	 * @param  $data['description'] string Product description
	 * @param  $data['CUSTOM'] string 
	 * @return array
	 */
	public function createRecurringProfile($token, $data)
	{

		$params = array(

			'SUBSCRIBERNAME' => $data['fullname'],
			'PROFILESTARTDATE' => $data['startDate'],
			'MAXFAILEDPAYMENTS' => 10,
			'AUTOBILLOUTAMT' => 'NoAutoBill',
			'BILLINGPERIOD' => $data['period'],
			'L_BILLINGAGREEMENTDESCRIPTION0' => $data['description'],
			'BILLINGFREQUENCY' => $data['frequency'],
			'AMT' => str_replace(',', '.', $data['amount']),
			'EMAIL' => $data['email'],
			'DESC' => $data['description'],
			'L_BILLINGTYPE0' => "RecurringPayments",
			'L_PAYMENTREQUEST_0_ITEMCATEGORY0' => 'Digital',
			'L_PAYMENTREQUEST_0_AMT0' => str_replace(',', '.', $data['amount']),
			'L_PAYMENTREQUEST_0_QTY0' => 1,
			'L_PAYMENTREQUEST_0_DESC0' => "Plano Mensal",
			'TOKEN' => $token,
			'CURRENCYCODE' => "BRL",
			'METHOD' => "CreateRecurringPaymentsProfile",
			'VERSION' => $this->app->config('billing.paypal.version'),
			'PWD' => $this->app->config('billing.paypal.pwd'),
			'USER' => $this->app->config('billing.paypal.user'),
			'SIGNATURE' => $this->app->config('billing.paypal.signature')
		);
		
		
		$response = $this->makeRequest($params);
		
		return $response;
	}

	/**
	 * Cancel Profile on Paypal
	 * @return Array
	 */
	public function cancelProfile($data)
	{	
		$params = array(
			'METHOD' => "SetExpressCheckout",
			'VERSION' => $this->app->config('billing.paypal.version'),
			'PWD' => $this->app->config('billing.paypal.pwd'),
			'USER' => $this->app->config('billing.paypal.user'),
			'SIGNATURE' => $this->app->config('billing.paypal.signature'),
			
		);

		$this->setParams($data);
		unset($data['startDate']);

		$params = $params + $this->getParams();

		$response = $this->makeRequest($params);

		$this->setToken($response['TOKEN']);

		$params = array(
			'PROFILEID' => $data['profileId'],
			'ACTION' => "Cancel",
			'TOKEN' => $this->getToken(),
			'METHOD' => "ManageRecurringPaymentsProfileStatus",
			'VERSION' => $this->app->config('billing.paypal.version'),
			'PWD' => $this->app->config('billing.paypal.pwd'),
			'USER' => $this->app->config('billing.paypal.user'),
			'SIGNATURE' => $this->app->config('billing.paypal.signature'),
		);
		
		$response = $this->makeRequest($params);
		
		return $response;
		
	}

	/**
	 * Suspend profile on Paypal
	 * @return Array
	 */
	public function suspendProfile($profile, $data)
	{
		$params = array(
			'METHOD' => "SetExpressCheckout",
			'VERSION' => $this->app->config('billing.paypal.version'),
			'PWD' => $this->app->config('billing.paypal.pwd'),
			'USER' => $this->app->config('billing.paypal.user'),
			'SIGNATURE' => $this->app->config('billing.paypal.signature'),
			
		);

		$this->setParams($data);

		$params = $params + $this->getParams();

		$response = $this->makeRequest($params);

		$this->setToken($response['TOKEN']);

		$params = array(
			'PROFILEID' => $profile,
			'ACTION' => "Suspend",
			'TOKEN' => $this->getToken(),
			'METHOD' => "ManageRecurringPaymentsProfileStatus",
			'VERSION' => $this->app->config('billing.paypal.version'),
			'PWD' => $this->app->config('billing.paypal.pwd'),
			'USER' => $this->app->config('billing.paypal.user'),
			'SIGNATURE' => $this->app->config('billing.paypal.signature'),
		);
		
		$response = $this->makeRequest($params);
		
		return $response;
	}

	/**
	 * Make Paypal Requests
	 * @param  array $params 
	 * @return array
	 */
	private function makeRequest($params)
	{
		$curlOptions = array(
			CURLOPT_URL => (string)$this->app->config('billing.paypal.nvp.url'),
			CURLOPT_VERBOSE => 1,
			CURLOPT_RETURNTRANSFER => 1,
			CURLOPT_SSL_VERIFYPEER => false,
			CURLOPT_POST => 1,
			CURLOPT_POSTFIELDS => http_build_query($params)
		);

		$ch = curl_init();
		curl_setopt_array($ch,$curlOptions);

		$request = curl_exec($ch);	
		curl_close($ch);

		$response = array();
		parse_str($request,$response);
		
		return $response;
	}

}	