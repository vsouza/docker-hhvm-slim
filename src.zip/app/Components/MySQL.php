<?php
/**
 * MySQL Component
 * @package Components
 */
namespace Components;

/**
 * 
 * @version 0.0.1
 * @package Components
 * @author Vinicius Souza <vinicius@ezlike.com.br> 
 * @description Class for PDO connection
 */
Class MySQL 
{

	public static $app;
    public static $host; 
    public static $user; 
    public static $pass; 
    public static $conn;
    public static $dns;

    /**
     * Set params for MySQL Connection
     * @param  string $db select database
     * @return string     string with connection params
     */
    public static function initialize($app)
    {
        self::$app = $app;    
        self::$host = self::$app->config('mysql_host');
        self::$user = self::$app->config('mysql_user');
        self::$pass = self::$app->config('mysql_pass');
        self::$dns = 'mysql:dbname=tamboreen;host='.self::$host; 
                    
        return true;
    }

    /**
     * Do connection with mysql db
     * @param  string $db  select database
     * @param  object $app slim instance
     * @return object      connection object
     */

    public static  function connect($app) 
    {
        if(!self::initialize($app))
            throw new \Exception(Enums::internalError);
        
        self::$conn = new \PDO(self::$dns, self::$user, self::$pass); 
        self::$conn->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION); 
        
        return self::$conn;
    } 

    /**
     * Destroy connection object
     * @return boolean true if object destroyed
     */
    public static function disconnect()
    {
        if(!isset(self::$conn))
            return false;

        unset( self::$conn);
        return true;
    }
}    
