<?php
/**
 * Chronos Component - Manipulate isodate and timestamp
 * @package Components
 */
namespace Components;

Trait Log
{

	public function logger($data, $action, $core = "payments")
	{

		$dateTime = new \DateTime;	
		
		$data['action'] = $action;
		$data['id'] = (string)sha1(time() + $_SESSION['user']['mysqlId']);
		$data['createdAt'] = $dateTime->format('Y-m-d\TH:i:s\Z');
		
		$solr = new Solr(\Slim\Slim::getInstance());
		
		$solr->setCore((string)$core);

		if($solr->addDocument($data))
			return true;

		return false;	

	}

}