<?php
/**
 * Chronos Component - Manipulate isodate and timestamp
 * @package Components
 */
namespace Components;

Trait Chronos
{
	/**
	 * Get isoDate
	 * @param  string $time [description]
	 * @return String
	 */
	public function getIsoDate($time = "now")
	{
		$dateTime = new \DateTime;
		if($time != "now")
			$dateTime->modify($time);

		return (string)$dateTime->format('Y-m-d\TH:i:s\Z');
	}

	/**
	 * Convert any data format to more readable string or setting custom format
	 * @param  string $locale Language
	 * @param  string $time   default: now
	 * @return string
	 */
	public function formatDate($locale, $time = "now")
	{
		$dateTime = new \DateTime();

		switch ($locale) {
			case 'pt_BR':
				$format = "d/m/Y";
				break;
			case 'en_US':
				$format = "m/d/Y";
				break;
			default:
				$format = "d/m/Y";
				break;
		}
		return (string)$dateTime->format($format);
	}
	/**
	 * Get timestamp
	 * @param  string $time
	 * @return Int
	 */
	public function getTimeStamp($time = "now")
	{
		return (new \DateTime())->getTimestamp();
	}

}
