<?php
/**
*   @package Components
*/

namespace Components;
use Aws\S3\S3Client;
use Components\Enums;


/**
 * Manipulate Uploads to Facebook and Amazon S3
 * @version 2.0.0
  */
Class AWS extends \app\Controller
{


    /**
     * Upload images to S3 in creatives folder of tamboreen bucket
     * Documentation on Upload.md
     * @author Vinicius Souza
     * @since 05/12/2013
     * @return Json
     */
    public function s3Upload()
    {

        try
        {
            if (!isset($_FILES['file']))
                throw new \Exception("noFileSent", Enums::noFileSent);       
            
            $s3 = S3Client::factory(array(
                'key'    => "AKIAIAV4LMYM4IS3T7FA",
                'secret' => "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"
            ));
        
            $finfo = new \finfo(FILEINFO_MIME_TYPE);
            $type = $finfo->file($_FILES['file']['tmp_name']);
        
            $params = array(
             'Bucket' => "tamboreen/terms",
             'Key' => $_FILES['file']['name'],
             'SourceFile' => $_FILES['file']['tmp_name'],
             'ContentType' => $type,
             'ACL' => 'public-read',
             'CacheControl' => "max-age=315360000",
             'StorageClass' => 'REDUCED_REDUNDANCY'
            );

            $response = $s3->putObject($params);        
            $message = $response['ObjectURL'];
        
            if(isset($response['error']))
                throw new \Exception("uploadError", Enums::uploadError);
        
            $data = array(
                'success' => true,
                'code' => Enums::uploadSucess,
                'url' => $message
                );

            echo json_encode($data);

        }catch(\Exception $e)
        {
            $data = array(
                'success' => false,
                'code' => $e->getCode(),
                'message' => $e->getMessage()
                );
            
            echo json_encode($data);
        }
    }
}    