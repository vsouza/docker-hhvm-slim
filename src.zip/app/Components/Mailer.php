<?php
/**
 * Mailer Component
 * @package Components
 */
namespace Components;

use Mandrill;

class Mailer
{
	protected $templatePath;
	protected $Mandrill;
    protected $apiKey = '0p5jinb61JdbgpPGOs9LNg';
    protected $testApiKey = '9sbXTqMn9CJK3XK8I55J3w';
	protected $from = 'contato@tamboreen.com.br';
	protected $fromName = 'Tamboreen';
    protected $contactMail = 'contato@tamboreen.com.br';
	protected $defautMessage;
    protected $url = 'http://www.tamboreen.com.br';

    public function __construct()
    {
    	$this->Mandrill = new Mandrill($this->apiKey);
    	$this->defautMessage = [
            'from_email' => $this->from,
            'from_name' => $this->fromName,
            'headers' => array('Reply-To' => $this->from),
            'track_opens' => true,
            'auto_text' => true,
            'inline_css' => true
        ];
    }

    /* ------------ PLAIN MAIL ------------ */

    /**
     * Madrill Default Sender
     * @param  array $message   Message data
     * @return bool             Success
     */
    protected function send($message) {
        $result = $this->Mandrill->messages->send($message);
        return $result[0]['status']=='sent';
    }

    /**
     * Contact Form sender
     * @param  array $data  Form data
     * @return bool         Success
     */
    public function contact($data) {
        $message = [
            'from_email' => 'tickets@tamboreen.uservoice.com',
            'from_name' => $data['name'],
            'to' => array(
                array(
                    'email' => $this->contactMail,
                )
            ),
            'headers' => array('Reply-To' => $data['email']),
            'subject' => 'Contato via Site - '.$data['name'],
            'text' => $data['message'],
            'track_opens' => false,
            'tags' => array('contactform'),
        ];
        return $this->send($message);
    }

    /* ------------ MANDRILL TEMPLATES ------------ */

    /**
     * Madrill Template Sender
     * @param  array $message   Message data
     * @return bool             Success
     */
    protected function sendTemplate($toEmail, $toName, $subject, $template_name, $content) {
        $message = [
            'to' => [
                ['email' => $toEmail, 'name' => $toName,]
            ],
            'subject' => $subject,
        ];
        $message = array_merge($message, $this->defautMessage);

        $template_content = [];
        foreach ($content as $key => $value) {
            $template_content[] = [
                'name' => $key,
                'content' => $value
            ];
        }

        $result = $this->Mandrill->messages->sendTemplate($template_name, $template_content, $message);
        return $result[0]['status']=='sent';
    }

    /**
     * Welcome mail
     * @param  string $toEmail  Recepient address
     * @param  string $toName   Recepient Name
     * @return bool                 Success
     */
    public function welcome($toEmail, $toName)
    {
        $template_name = 'tamboreen-standard';
        $subject = _('emailWelcomeEmailSubject');
        $content = [
            'preheader_content' => _('emailWelcomePreheaderContent'),
            'header1' => _('emailWelcomeHeader1'),
            'body_content' => _('emailWelcomeBodyContent'),
            'footer_content' => _('emailWelcomeFooterContent'),
            'img_icon' => '<img align="center" alt="" src="http://gallery.mailchimp.com/bc19dcd44387703a1e9868755/images/5ef345d3-80e8-49c4-9baa-20760dacfb9e.png" width="64" style="max-width:64px, padding-bottom: 0, display: inline !important, vertical-align: bottom," class="mcnImage">',
            'link_to_tb' => _('emailLinkToTb'),
        ];
        return $this->sendTemplate($toEmail, $toName, $subject, $template_name, $content);
    }

    /**
     * Thank you mail
     * @param  string $toEmail  Recepient address
     * @param  string $toName   Recepient Name
     * @return bool                 Success
     */
    public function thankYou($toEmail, $toName)
    {
        $template_name = 'tamboreen-standard';
        $subject = _('emailThankYouEmailSubject');
        $content = [
            'preheader_content' => _('emailThankYouPreheaderContent'),
            'header1' => _('emailThankYouHeader1'),
            'body_content' => _('emailThankYouBodyContent'),
            'footer_content' => _('emailThankYouFooterContent'),
            'img_icon' => '<img align="center" alt="" src="http://gallery.mailchimp.com/bc19dcd44387703a1e9868755/images/5ef345d3-80e8-49c4-9baa-20760dacfb9e.png" width="64" style="max-width:64px, padding-bottom: 0, display: inline !important, vertical-align: bottom," class="mcnImage">',
            'link_to_tb' => _('emailLinkToTb'),
        ];
        return $this->sendTemplate($toEmail, $toName, $subject, $template_name, $content);
    }

    /**
     * We missed you mail
     * @param  string $toEmail  Recepient address
     * @param  string $toName   Recepient Name
     * @return bool                 Success
     */
    public function weMissedYou($toEmail, $toName)
    {
        $template_name = 'tamboreen-standard';
        $subject = _('emailWeMissedYouEmailSubject');
        $content = [
            'preheader_content' => _('emailWeMissedYouPreheaderContent'),
            'header1' => _('emailWeMissedYouHeader1'),
            'body_content' => _('emailWeMissedYouBodyContent'),
            'footer_content' => _('emailWeMissedYouFooterContent'),
            'img_icon' => '<img align="center" alt="" src="http://gallery.mailchimp.com/bc19dcd44387703a1e9868755/images/5ef345d3-80e8-49c4-9baa-20760dacfb9e.png" width="64" style="max-width:64px, padding-bottom: 0, display: inline !important, vertical-align: bottom," class="mcnImage">',
            'link_to_tb' => _('emailLinkToTb'),
        ];
        return $this->sendTemplate($toEmail, $toName, $subject, $template_name, $content);
    }

    /**
     * Payment Evaluation mail
     * @param  string $toEmail      Recepient address
     * @param  string $toName       Recepient Name
     * @param  string $startDate    Plan Start Date
     * @param  string $planName     Name of the Plan
     * @param  string $price        Price of the Plan
     * @return bool                 Success
     */
    public function paymentEvaluation($toEmail, $toName, $startDate, $planName, $price)
    {
        $template_name = 'tamboreen-standard';
        $subject = _('emailPaymentEvaluationEmailSubject');
        $content = [
            'preheader_content' => _('emailPaymentEvaluationPreheaderContent'),
            'header1' => '<span style="color: #ffa200">'._('emailPaymentEvaluationHeader1').'</span>',
            'body_content' => _('emailPaymentEvaluationBodyContent').'<br><br>'.$startDate.'<br>'.$planName.'<br>'.$price,
            'footer_content' => _('emailPaymentEvaluationFooterContent'),
            'img_icon' => '<img align="none" height="55" src="http://gallery.mailchimp.com/bc19dcd44387703a1e9868755/images/0e0817c4-1ddb-45fe-98d5-831e5a090bae.png" style="width: 68px; height: 55px; margin: 0px;" width="68">',
            'link_to_tb' => _('emailLinkToTb'),
        ];
        return $this->sendTemplate($toEmail, $toName, $subject, $template_name, $content);
    }

    /**
     * Payment Reproval mail
     * @param  string $toEmail      Recepient address
     * @param  string $toName       Recepient Name
     * @param  string $link         Call to action URL
     * @param  string $startDate    Plan Start Date
     * @param  string $planName     Name of the Plan
     * @param  string $price        Price of the Plan
     * @return bool                 Success
     */
    public function paymentReproval($toEmail, $toName, $link, $startDate, $planName, $price)
    {
        $template_name = 'tamboreen-calltoaction-btn';
        $subject = _('emailPaymentReprovalEmailSubject');
        $content = [
            'preheader_content' => _('emailPaymentReprovalPreheaderContent'),
            'header1' => '<span style="color: #ff5400">'._('emailPaymentReprovalHeader1').'</span>',
            'body_content' => _('emailPaymentReprovalBodyContent').'<br><br>'.$startDate.'<br>'.$planName.'<br>'.$price,
            'footer_content' => _('emailPaymentReprovalFooterContent'),
            'call_to_action_button' => '<a href="'.$link.'" style="padding: 10px 15px; color: #fff !important; text-decoration: none;" target="_blank">'._('emailPaymentReprovalCallToActionButton').'</a>',
            'img_icon' => '<img align="none" height="56" src="http://gallery.mailchimp.com/bc19dcd44387703a1e9868755/images/eb62bf6c-8683-4cee-9e53-9d4c99d41a93.png" style="width: 59px; height: 56px; margin: 0px;" width="59">',
        ];
        return $this->sendTemplate($toEmail, $toName, $subject, $template_name, $content);
    }

    /**
     * Payment Aproval mail
     * @param  string $toEmail      Recepient address
     * @param  string $toName       Recepient Name
     * @param  string $startDate    Plan Start Date
     * @param  string $planName     Name of the Plan
     * @param  string $price        Price of the Plan
     * @return bool                 Success
     */
    public function paymentAproval($toEmail, $toName, $startDate, $planName, $price)
    {
        $template_name = 'tamboreen-standard';
        $subject = _('emailPaymentAprovalEmailSubject');
        $content = [
            'preheader_content' => _('emailPaymentAprovalPreheaderContent'),
            'header1' => '<span style="color: #03b003">'._('emailPaymentAprovalHeader1').'</span>',
            'body_content' => _('emailPaymentAprovalBodyContent').'<br><br>'.$startDate.'<br>'.$planName.'<br>'.$price,
            'footer_content' => _('emailPaymentAprovalFooterContent'),
            'img_icon' => '<img align="none" height="57" src="http://gallery.mailchimp.com/bc19dcd44387703a1e9868755/images/7aa44a61-e71f-4f39-af8e-e78f431a3ac5.png" style="width: 67px; height: 57px; margin: 0px;" width="67">',
            'link_to_tb' => _('emailLinkToTb'),
        ];
        return $this->sendTemplate($toEmail, $toName, $subject, $template_name, $content);
    }

    /**
     * End trial mail
     * @param  string $toEmail      Recepient address
     * @param  string $toName       Recepient Name
     * @param  string $link         Call to action URL
     * @return bool                 Success
     */
    public function trialExpired($toEmail, $toName, $link)
    {
        $template_name = 'tamboreen-calltoaction-btn';
        $subject = _('emailTrialExpiredEmailSubject');
        $content = [
            'preheader_content' => _('emailTrialExpiredPreheaderContent'),
            'header1' => '<span style="color: #ffa200">'._('emailTrialExpiredHeader1').'</span>',
            'body_content' => _('emailTrialExpiredBodyContent'),
            'footer_content' => _('emailTrialExpiredFooterContent'),
            'call_to_action_button' => '<a href="'.$link.'" style="padding: 10px 15px; color: #fff !important; text-decoration: none;" target="_blank">'._('emailTrialExpiredCallToActionButton').'</a>',
            'img_icon' => '<img align="none" height="53" src="http://gallery.mailchimp.com/bc19dcd44387703a1e9868755/images/cf2a5d48-97dc-4891-9687-29e26b4b17a5.png" style="width: 53px; height: 53px; margin: 0px;" width="53">',
        ];
        return $this->sendTemplate($toEmail, $toName, $subject, $template_name, $content);
    }

    /**
     * Trial expiring mail
     * @param  string $toEmail      Recepient address
     * @param  string $toName       Recepient Name
     * @param  string $link         Call to action URL
     * @return bool                 Success
     */
    public function expiringTrial($toEmail, $toName, $link)
    {
        $template_name = 'tamboreen-calltoaction-btn';
        $subject = _('emailExpiringTrialEmailSubject');
        $content = [
            'preheader_content' => _('emailExpiringTrialPreheaderContent'),
            'header1' => '<span style="color: #ffa200">'._('emailExpiringTrialHeader1').'</span>',
            'body_content' => _('emailExpiringTrialBodyContent'),
            'footer_content' => _('emailExpiringTrialFooterContent'),
            'call_to_action_button' => '<a href="'.$link.'" style="padding: 10px 15px; color: #fff !important; text-decoration: none;" target="_blank">'._('emailExpiringTrialCallToActionButton').'</a>',
            'img_icon' => '<img align="none" height="53" src="http://gallery.mailchimp.com/bc19dcd44387703a1e9868755/images/cf2a5d48-97dc-4891-9687-29e26b4b17a5.png" style="width: 53px; height: 53px; margin: 0px;" width="53">',
        ];
        return $this->sendTemplate($toEmail, $toName, $subject, $template_name, $content);
    }

    /**
     * Canceling mail
     * @param  string $toEmail      Recepient address
     * @param  string $toName       Recepient Name
     * @return bool                 Success
     */
    public function canceling($toEmail, $toName)
    {
        $template_name = 'tamboreen-standard';
        $subject = _('emailCancelingEmailSubject');
        $content = [
            'preheader_content' => _('emailCancelingPreheaderContent'),
            'header1' => '<span style="color: #ffa200">'._('emailCancelingHeader1').'</span>',
            'body_content' => _('emailCancelingBodyContent'),
            'footer_content' => _('emailCancelingFooterContent'),
            'img_icon' => '<img align="none" height="53" src="http://gallery.mailchimp.com/bc19dcd44387703a1e9868755/images/cf2a5d48-97dc-4891-9687-29e26b4b17a5.png" style="width: 53px; height: 53px; margin: 0px;" width="53">',
            'link_to_tb' => _('emailLinkToTb'),
        ];
        return $this->sendTemplate($toEmail, $toName, $subject, $template_name, $content);
    }

    /**
     * Conversion Pixel Mail
     * @param  array $data Message Data:
     * - name: Recepient Name
     * - to: Recepient Address
     * - from: Sender Name
     * - script: Conversion Pixel code
     * @return bool Success
     */
    public function sendPixel($data)
    {
        $template_name = 'Tamboreen_Wide';
        $message = [
            'from_email' => $_SESSION['user']['email'],
            'from_name' => $_SESSION['user']['firstName'].' '.$_SESSION['user']['surname'],
            'headers' => array('Reply-To' => $_SESSION['user']['email']),
            'track_opens' => true,
            'auto_text' => true,
            'inline_css' => true,
            'to' => [
                ['email' => $data['to'], 'name' => $data['name'],]
            ],
            'subject' => sprintf(_('mailPixelSubject'), $data['from']),
        ];
        $template_content = [
            [
                'name' => 'preheader_content',
                'content' => _('mailPixelTeaser')
            ],
            [
                'name' => 'body_content',
                'content' => '<h1>'._('mailPixelHeader').'</h1><p>'.sprintf(_('mailPixelContent'), $data['name'], $data['from']).'</p><multiline><small><pre style="
    background: #eee; padding: 10px; color: #555;">'.htmlentities($data['script']).'</pre></small>
    </multiline>'
            ],
        ];
        $result = $this->Mandrill->messages->sendTemplate($template_name, $template_content, $message);
        return $result[0]['status']=='sent';
    }
}
