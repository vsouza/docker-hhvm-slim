<?php
/**
 * Solr Component
 * @package Components
 */
namespace Components;
use Guzzle\Http\Client;

class Solr
{
	/**
	 * Slim Instance
	 * @var Object
	 */
	public $app;

	/**
	 * Guzzle Instance for cURL requests
	 * @var Object
	 */
	private $client;

	/**
	 * Collection for query
	 * @var String
	 */
	public $core;

	/**
	 * Request options
	 * @var String
	 */
	public $options;
	
	/**
	 * Requst Handler
	 * @var String
	 */
	public $handler;

	/**
	 * Number of results found in query
	 * @var Int
	 */
	public $numFound = null;


	public function __construct()
	{
		$this->app = \Slim\Slim::getInstance();
		
		$this->client = new Client($this->app->config('solr_host'));
	}

	/**
	 * Set Core property
	 * @param string $core name of Solr core
	 */
	public function setCore($core)
	{
		$this->core = $core;
	}

	/**
	 * Get Solr Core
	 * @return string name of the core that was set for the object
	 */
	public function getCore()
	{
		return $this->core;
	}

	/**
	 * Set options for request
	 * @param string $key
	 * @param mixed $value
	 * @return boolean
	 */
	public function setOption($key, $value)
	{
		$this->options[(string)$key] = (string)$value;
		return true;
	}

	/**
	 * Get especific option
	 * @param  string $key
	 * @return mixed 	index of array
	 */
	public function getOption($key)
	{
        if(empty($this->options) || isset($this->options))
		      return null;

        return $this->options[(string)$key];
	}

	/**
	 * Get options for request
	 * @return string query string of options
	 */
	public function getOptions($update = false)
	{

		if(!empty($this->options))
			if(!$update)
				return "&".http_build_query($this->options);

		return http_build_query($this->options);
	}

	/**
	 * Set handler of request
	 * @param string $name
	 */
	public function setHandler($name)
	{
		$this->handler = (string)$name;
		return true;
	}

	/**
	 * Get handler for request
	 * @return string name of handler for request
	 */
	public function getHandler()
	{
		return $this->handler."?";
	}

	/**
	 * Set number found for search request
	 * @param array $response
	 */
	public function setNumFound($response)
	{

		$this->numFound = $response['response']['numFound'];
	}

	/**
	 * Get number of results found
	 * @return Integer
	 */
	public function getNumFound()
	{
		return $this->numFound;
	}
	/**
	 * Find document by Id
	 * @param  string $id
	 * @return array
	 */
	public function findById($id)
	{

		$this->setHandler("select");

		$query = "id:".$id;
		$request = $this->client->get($this->getCore()."/".$this->getHandler().$query.$this->getOptions());
		$response = $request->send();
		$doc = $response->json();


		$this->setNumFound($doc);

		return $doc;
	}

	/**
	 * Find document by Key
	 * @param  string $key  name of the key for search
	 * @param  string $value value of the key for search
	 * @return array       document
	 */
	public function findByKey($key, $value)
	{
		$this->setHandler("select");
		$query = $key.":".$value;
        
		$request = $this->client->get($this->getCore()."/".$this->getHandler()."q=".$query.$this->getOptions());

		$response = $request->send();
		$doc = $response->json();

		$this->setNumFound($doc);

		return $doc;
	}

	/**
	 * Find document by keys, using "AND" clause
	 * @param  string $key
	 * @param  mixed $value
	 * @param  string $key2
	 * @param  mixed $value2
	 * @return array
	 */
	public function findByKeys($key, $value, $key2, $value2)
	{
		$this->setHandler("select");
		$query = $key.":".$value." AND ".$key2.":".$value2;
		$request = $this->client->get($this->getCore()."/".$this->getHandler().$query.$this->getOptions());
		$response = $request->send();
		$doc = $response->json();

		$this->setNumFound($doc);

		return $doc;
	}

	/**
	 * Find document by key, if not found find by second key using "OR" clause
	 * @param  string $key
	 * @param  mixed $value
	 * @param  string $key2
	 * @param  mixed $value2
	 * @return array
	 */
	public function findByKeyOrKey($key, $value, $key2, $value2)
	{
		$this->setHandler("select");
		$query = $key.":".$value." OR ".$key2.":".$value2;
		$request = $this->client->get($this->getCore()."/".$this->getHandler().$query.$this->getOptions());
		$response = $request->send();
		$doc = $response->json();

		$this->setNumFound($doc);

		return $doc;
	}

	/**
	 * List all data stored in collection
	 * @return array
	 */
	public function findAll()
	{
		$this->setHandler("select");
		$query = "*:*";
		$request = $this->client->get($this->getCore()."/".$this->getHandler()."q=".$query.$this->getOptions());
		$response = $request->send();
		$doc = $response->json();

		$this->setNumFound($doc);

		return $doc;
	}

	/**
	 * Add document do Solr
	 * @param array $document
	 */
	public function addDocument($document)
	{
		$this->setHandler("update");
		$this->setOption('commit', 'true');
		$doc = "[".json_encode($document)."]";
		$request = $this->client->post($this->getCore()."/".$this->getHandler().$this->getOptions(true));
		$request->setBody($doc, 'application/json');
		$response = $request->send();
		$response = $response->json();
		return $response;
	}

	/**
	 * Add multiple documents to Solr
	 * @param array $documents
	 */
	public function addDocuments($documents)
	{
		$this->setHandler("update");
		$this->setOption('commit', 'true');
		$doc = json_encode($documents);
		$request = $this->client->post($this->getCore()."/".$this->getHandler().$this->getOptions(true));
		$request->setBody($doc, 'application/json');
		$response = $request->send();
		$response = $response->json();
		return $response;
	}

	/**
	 * Update document
	 * @param  array $document
	 * @param  array $fields   Array with fields and values to update
	 * @return Integer
	 */
	public function update($document, $fields)
	{

		$this->setHandler("update");
		$this->setOption('commit', 'true');

		foreach ($document as $key => $value)
		{
			if(in_array($key, $fields))
				 $document[$key] = array('set' => $value);
		}

		$doc = "[".json_encode($document)."]";
		$request = $this->client->post($this->getCore()."/".$this->getHandler().$this->getOptions());
		$request->setBody($doc, 'application/json');
		$response = $request->send();
		$response = $response->json();
		return $response;
	}

	/**
	 * Delete document by Id
	 * @param  mixed $id
	 * @return Integer status
	 */
	public function deleteById($id)
	{

		$this->setHandler("update");
		$this->setOption('commit', 'true');
		$query = "<delete><query>id:".$id."</query></delete>";
		$request = $this->client->get($this->getCore()."/".$this->getHandler()."/?stream.body=".$query.$this->getOptions());
		$response = $request->send();
		return $response;
	}

	/**
	 * Delete document searching by key
	 * @param  string $key
	 * @param  mixed $value
	 * @return Integer
	 */
	public function deleteByKey($key, $value)
	{

		$this->setHandler("update");
		$this->setOption('commit', 'true');
		$query = "<delete><query>".$key.":".$value."</query></delete>";
		$request = $this->client->get($this->getCore()."/".$this->getHandler()."stream.body=".$query.$this->getOptions());
		$response = $request->send();
		return $response;
	}

	/**
	 * Delete document matching multiple keys
	 * @param  string $key
	 * @param  mixed $value
	 * @param  string $key2
	 * @param  mixed $value2
	 * @return Integer
	 */
	public function deleteByKeys($key, $value, $key2, $value2)
	{
		$this->setHandler("update");
		$this->setOption('commit', 'true');
		$query = "<delete><query>".$key.":".$value." AND ".$key2.":".$value2."</query></delete>";
		$request = $this->client->get($this->getCore()."/".$this->getHandler()."stream.body=".$query.$this->getOptions());
		$response = $request->send();
		return $response;
	}

	/**
	 * Delete document matching key, if not match matching second key
	 * @param  string $key
	 * @param  mixed $value
	 * @param  string $key2
	 * @param  mixed $value2
	 * @return Integer
	 */
	public function deleteByKeyOrKey($key, $value, $key2, $value2)
	{
		$this->setHandler("update");
		$this->setOption('commit', 'true');
		$query = "<delete><query>".$key.":".$value." OR ".$key2.":".$value2."</query></delete>";
		$request = $this->client->get($this->getCore()."/".$this->getHandler()."/?stream.body=".$query.$this->getOptions());
		$response = $request->send();
		return $response;
	}

	/**
	 * Remove _version_ and SolrHash field of documents
	 * @param  array $document
	 * @return array
	 */
	public function cleanDocument($document)
	{
		foreach ($document as &$value)
		{
			unset($value['_version_']);
			unset($value['solrHash']);
		}

		return $document;
	}

}
