<?php
/**
* 	@package Components
*/

namespace Components;
use \Guzzle\Http\Client;

/**
 * Rest component
 * TODO Remover baseUrl na criação do objeto
 * TODO Inserir http_build_query dentro do component
 * @version 1.2
 * @access public
 * @package  Components
 * 
 */
Class Rest
{
	public $baseUrl;
	public $client;
	public $opt;

	public function __construct($baseUrl)
	{
		$this->baseUrl = $baseUrl;
		$this->client = new Client();
		
	}

	/**
	 * Make post Request
	 * @param  array $data   params to post
	 * @param  string $path   path of url
	 * @param  string $format json or raw
	 * @return array          response in json format
	 */
	public function post($path, $data, $format)
	{
		try{
			
			$request = $this->client->post($this->baseUrl.$path);

			if(isset($format) && $format == "json")
				$request->setBody($data, 'application/json');      

			$response = $request->send();
			return $response->json();

		}catch(\Exception $e)
        {
           return Enums::invalidRequest;
        }
	}
    
	/**
	 * Make Get Request
	 * @param  string $data   params in query string format
	 * @param  string $path   path of url
	 * @return array          response in json format
	 */
    public function get($path, $data, $json = null)
    {
    	
		try{
			

			if(count($data))
				$url = $this->baseUrl.$path."?".http_build_query($data);
			else
				$url = $this->baseUrl.$path;

    						
			$request = $this->client->get($url);
			$response = $request->send();
			
			if($json)
				return $response->json();

			
			return $response->__toString();


		}catch(\Exception $e)
        {
        	// echo $e->getMessage();die();
           return Enums::invalidRequest;
        }
    }

   

    /**
	 * Make Delete Request
	 * @param  string $data   params in query string format
	 * @param  string $path   path of url
	 * @return array          response in json format
	 */
    public function delete($path, $data)
    {
    	
		try{
			
			if(count($data))
				$url = $this->baseUrl.$path."?".$data;
			else
				$url = $this->baseUrl.$path;
    						
			$request = $this->client->delete($url, $this->setOptions('xml', $data));
			$response = $request->send();
			return $response->json();

		}catch(\Exception $e)
        {
           return Enums::invalidRequest;
        }
    }

    private function setOptions($request, $data)
    {

    	switch ($request) 
    	{
    		case "xml":
    			$contentType = "application/json";

    			break;
    		case "json":
    			$contentType = "text/xml";
    			break;

    		default:
    			
    			break;
    	}
    	$this->opt = array(
			'allow_redirects' => false,
			'timeout' => 10,
			'connect_timeout' => 3,
			'verify' => false,
			'debug' => false,
			'Content-Type' => $contentType,
			'Content-Length' => strlen($data)
			);
    	return $this->opt;
    }
   
}