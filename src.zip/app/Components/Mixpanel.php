<?php
/**
*   @package Components
*/

namespace Components;
use \Mixpanel as MixpanelVendor;

/**
 *
  */
Class Mixpanel
{

    /**
     * Prepare Mixpanel profile
     * @param string $token     Mixpanel token
     * @param array  $fbUser    User data from Facebook
     * @param array  $dbUser    User data from Database
     */
    function mixpanelProfile($fbUser, $dbUser) {
        $properties = array(
            '$email' => $dbUser['email'],
            '$first_name' => $dbUser['firstName'],
            '$last_name' => $dbUser['surname'],
            '$name' => $dbUser['firstName'].' '.$dbUser['surname'],
            '$created' => $dbUser['createdAt'],
            'Facebook Id' => $fbUser['id'],
            'Gender' => $fbUser['gender'],
            'Locale' => $fbUser['locale'],
            'Locale (FB)' => $dbUser['lang'],
            'Timezone' => $fbUser['timezone'],
            'Timezone (FB)' => $dbUser['timezone'],
        );
        if(array_key_exists('education',$fbUser)) {
            $properties['Education'] = count($fbUser['education']) ? array_pop($fbUser['education'])['type'] : null;
        }
        if(array_key_exists('currency',$fbUser)&&array_key_exists('user_currency',$fbUser['currency']))
            $properties['Currency'] = $fbUser['currency']['user_currency'];

        return $properties;
    }
}
