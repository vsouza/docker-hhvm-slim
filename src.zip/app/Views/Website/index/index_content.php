<section class="main" id="panel">
    <div class="main-content <?=$lang?>">
        <div class="wrapper clearfix">
            <div class="main-c1">
                <h1 class="title"><?=_('siteHomeHeadline')?></h1>
                <div class="row-fluid">
                    <p><?=_('siteHomeDescription')?></p>

                    <div class="buttons ">
                        <div class="access-button bigbutton">
                            <button class="btn fullgreen" rel="fb-login" location="panel"><?=strtoupper(_('siteHomeLoginButton'))?>
                            <span class="f">
                                <img src="/assets/img/website/f.png">
                            </span>
                            </button>
                        </div>
                        <!-- <p class="terms"><?=sprintf(_('siteHomeTerms'),'https://s3.amazonaws.com/tamboreen%2Fterms/terms.html')?></p> -->
                    </div>
                </div>
            </div>
            <div class="main-c2"></div>
        </div>
    </div>
</section>
<div class="content-wrap" id="howitworks">
    <section class="features">
        <div class="wrapper">
            <div class="row-fluid ">
                <div class="span12">
                    <h1 class="hBlue"><?=_('siteH1HowItWorks')?></span></h1>
                    <p><?=_('siteH2HowItWorks')?></p>
                    <span class="connector"></span>
                    <div class="row-fluid small ">
                        <!--###   Feature 1 ###-->
                        <div class="span3 featu">
                            <div class="featu-box">
                                <div class="icon">
                                    <img src="/assets/img/website/howto-1.png" class="ft1" alt=""/>
                                </div>
                                <h4><?=_('siteHowItWorksStep1H')?></h4>
                                <p><?=_('siteHowItWorksStep1p')?></p>
                            </div>
                        </div>


                        <!--###   Feature 2 ###-->
                        <div class="span3 featu">
                            <div class="featu-box">
                                <div class="icon">
                                    <img src="/assets/img/website/howto-2.png" class="ft1" alt=""/>
                                </div>
                                <h4><?=_('siteHowItWorksStep2H')?></h4>
                                <p><?=_('siteHowItWorksStep2p')?></p>
                            </div>
                        </div>

                        <!--###   Feature 3 ###-->
                        <div class="span3 featu">
                            <div class="featu-box">
                                <div class="icon">
                                    <img src="/assets/img/website/howto-3.png" class="ft1" alt=""/>
                                </div>
                                <h4><?=_('siteHowItWorksStep3H')?></h4>
                                <p><?=_('siteHowItWorksStep3p')?></p>
                            </div>
                        </div>

                        <!--###   Feature 4 ###-->
                        <div class="span3 featu">
                            <div class="featu-box">
                                <div class="icon">
                                    <img src="/assets/img/website/howto-4.png" class="ft1" alt=""/>
                                </div>
                                <h4><?=_('siteHowItWorksStep4H')?></h4>
                                <p><?=_('siteHowItWorksStep4p')?></p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <section class="content-wrap" id="about">
        <div class="main-features">
            <div class="wrapper">
                <h1 class="main-feat-title hBlue" id="features">
                    <?=_('siteH1Tool')?>
                </h1>
                <p class="main-feat-p"><?=_('siteH2Tool')?></p>

                <div class="box first">
                    <div class="row-fluid">
                        <div class="span4">
                            <h4><?=_('siteH4Screenshot1')?></h4>
                            <p><?=_('sitepScreenshot1')?></p>

                            <div class="linkmore">
                                <a href="#" class="btn white" rel="fb-login" location="screenshots"><?=_('siteHomeLoginButton')?></a>
                            </div>
                        </div>

                        <div class="span8">
                            <img src="/assets/img/website/screen-1.jpg" alt="">
                        </div>
                    </div>

                </div>
            </div>
            <div class="whitebg">
                <div class="wrapper">
                    <div class="box second">
                        <div class="row-fluid">
                            <div class="span4 rightside">
                                <h4><?=_('siteH4Screenshot2')?></h4>
                                <p><?=_('sitepScreenshot2')?></p>

                                <div class="linkmore">
                                    <a href="#" class="btn white" rel="fb-login" location="screenshots"><?=_('siteHomeLoginButton')?></a>
                                </div>

                                </div>

                                <div class="span8 leftside">
                                <img src="/assets/img/website/screen-2.jpg" alt="">
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="wrapper">
                <div class="box third">
                    <div class="row-fluid">
                        <div class="span4  ">
                            <h4><?=_('siteH4Screenshot3')?></h4>
                            <p><?=_('sitepScreenshot3')?></p>

                            <div class="linkmore">
                                <a href="#" class="btn white" rel="fb-login" location="screenshots"><?=_('siteHomeLoginButton')?></a>
                            </div>
                        </div>

                        <div class="span8  ">
                            <img src="/assets/img/website/screen-3.jpg" alt="">
                        </div>

                    </div>
                </div>
            </div>


            <div class="whitebg last">
                <div class="wrapper">
                    <div class="box second">
                        <div class="row-fluid">
                            <div class="span4 rightside">
                                <h4><?=_('siteH4Screenshot4')?></h4>
                                <p><?=_('sitepScreenshot4')?></p>

                                <div class="linkmore">
                                    <a href="#" class="btn white" rel="fb-login" location="screenshots"><?=_('siteHomeLoginButton')?></a>
                                </div>

                                </div>

                                <div class="span8 leftside">
                                <img src="/assets/img/website/screen-4.jpg" alt="">
                            </div>

                        </div>
                    </div>
            </div>
            </div>

        </div>
    </section>

     <section id="pricing">
        <div class="wrapper">
            <h1 class="hBlue"><?=_('siteH1pricing')?></h1>
            <p><?=_('sitePricingIntro')?></p>

            <!-- SUBSCRIPTION PLANS -->
            <div class="subscription-plans website-plans">

                <?php foreach ($plans as $key => $plan) : ?>
                <div class="plan">
                    <div class="frame">
                        <header><?=_n('hPlanMonths',$plan['frequency'])?></header>
                        <div class="content">
                            <div class="price">
                                R$<b><?php echo number_format($plan['amount'], 2, ',', '.'); ?></b>
                            </div>
                            <div class="paymenttype">
                                <?=_('autoDebit')?><br>
                                <b><?=_('monthly'.$plan['frequency'])?></b>
                            </div>
                        </div>
                        <?php if(!$plan['save']): ?>
                        <div class="discount empty"></div>
                        <?php else: ?>
                        <div class="discount">
                            <?=_('discount')?><br>
                            <b>R$<?php echo number_format($plan['save'], 2, ',', '.'); ?></b>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
            </div>
            <div class="clearfix"></div>
            <p><?=_('sitePricingIntro2')?></p>
            <div class="infos clearfix">
                <div class="info">
                    <h4><?=_('siteH4onTB')?></h4>
                    <p><?=_('siteH4onTBinfo')?></p>
                </div>
                <div class="infopic <?=$lang?>">
                </div>
                <div class="info right">
                    <h4><?=_('siteH4onFB')?></h4>
                    <p><?=_('siteH4onFBinfo')?></p>
                </div>
            </div>
        </div>
    </section>

    <section class="calltoaction">
        <div class="noodlebar grey"></div>
        <div class="wrapper">
            <h1><?=_('siteH130days')?></h1>
            <p><?=_('sitep30days')?></p>
            <div class="buttons">
                <div class="access-button bigbutton">
                    <button class="btn fullgreen" rel="fb-login" location="calltoactionsection"><?=strtoupper(_('siteHomeLoginButton'))?>
                    <span class="f">
                        <img src="/assets/img/website/f.png">
                    </span>
                    </button>
                </div>
            </div>
            <p class="fineprint"><?=_('sitep30daysfine')?></p>
        </div>
        <div class="noodlebar white bottom"></div>
    </section>

    <section class="contact-form" id="contact">
        <div class="wrapper">
            <h1><?=_('siteHomeContact')?></h1>
            <p><?=_('siteHomeContactSubtitle')?></p>
            <div class="row-fluid">
                <div class="span4">
                    <address>
                        <div class="map">
                            <h4><?=_('siteHomeAddress')?></h4>
                            <p>
                                Rua Guaicuí, 20 - Sala 802, Luxemburgo<br>
                                Belo Horizonte - MG | Brasil
                            </p>
                            <a href="https://www.google.com.br/maps/place/Rua+Guaicui,+20+-+Coracao+de+Jesus/@-19.9457229,-43.9496317,17z/data=!3m1!4b1!4m2!3m1!1s0xa697826b6e9d83:0x8f46afb12057f7ff" target="_blank"><?=_('siteHomeMap')?></a>
                        </div>

                        <?php if(false): ?>
                        <div class="phone">
                            <h4><?=_('siteHomePhone')?></h4>
                            <p>+55 31 2514-2062</p>
                        </div>
                        <?php endif; ?>

                        <div class="email">
                            <h4><?=_('siteHomeEmail')?></h4>
                            <p>
                                <a href="mailto:contato@tamboreen.com.br">contato@tamboreen.com.br</a>
                            </p>
                        </div>
                    </address>
                </div>

                <div class="span4">
                    <form name="contact" method="POST" action="" id="contact-form">

                        <div class="name">
                            <input name="name" type="text" placeholder="<?=_('lPixelSendYourName')?>..." id="namefield"/>
                        </div>

                        <div class="email">
                            <input name="email" type="text" placeholder="email@email.com" id="emailfield" />
                        </div>

                        <div class="message">
                            <textarea name="message" placeholder="<?=_('contactTypeYourMessage')?>..." id="messagefield"></textarea>
                        </div>

                        <div class="submit">
                            <button class="btn medium fullgreen" type="submit" name="submit" id="submitbtn"><?=_('siteHomeSendContactButton')?></button>
                        </div>
                    </form>
                    <p class="response success" id="reponsesuccess">
                        <?=_('siteHomeContactSuccess')?>
                    </p>
                    <p class="response error" id="reponseerror">
                        <?=_('siteHomeContactError')?>
                    </p>
                </div>

                <div class="span4 ">
                    <div class="likebox">
                        <div class="fb-like-box" data-href="http://www.facebook.com/tamboreenoficial" data-width="286" data-height="230" data-colorscheme="light" data-show-faces="true" data-header="false" data-stream="false" data-show-border="false"></div>
                    </div>
                </div>

            </div>
        </div>
    </section>
</div>
<footer class="footer">
    <div class="whitenoodles"></div>
    <div class="wrapper">
        <div class="row-fluid">

            <div class="span6 copy">
                <p>
                    <span class="langs">
                    <?php if($lang!='pt_BR') { ?>
                        <a href="<?php $V->urlFor('home'); ?>">
                            <img src="/assets/img/website/flag_br.png"> Em português
                        </a>
                    <?php } ?>
                    <?php if($lang!='en_US') { ?><a href="<?php $V->urlFor('home'); ?>en"><img src="/assets/img/website/flag_en.png"> In english</a><?php } ?>
                    </span> |  <a href="http://www.sanpedrovalley.org/" target="_blank">We <b class="heart">❤</b> San Pedro Valley</a><br>
                    © 2014 Tamboreen
                </p>
            </div>

            <div class="span6 copy right">
                <p><a href="https://mixpanel.com/f/partner"><img src="//cdn.mxpnl.com/site_media/images/partner/badge_light.png" alt="Mobile Analytics" /></a></p>
            </div>
            <p class="terms"><?=sprintf(_('siteHomeTerms'),'https://s3.amazonaws.com/tamboreen%2Fterms/terms.html')?></p>

        </div>
    </div>
</footer>

<!-- Modal -->
<div id="modalPermissions" class="modal hide fade permissions" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    </div>
    <div class="modal-body">
      <h4><?=_('siteHomePermissionsHead')?></h4>
      <p><?=_('siteHomePermissionsDescription')?></p>
      <img src="/assets/img/website/permissions.png">
      <div class="description">
        <span>
            <?=_('spanPermissionsAccessProfile')?>
        </span>
        <span class="fr">
            <?=_('spanPermissionsManage')?>
        </span>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn fullgreen" data-dismiss="modal" aria-hidden="true" id="authorize"><?=_('siteHomePermissionsButton')?></button>
    </div>
</div>
