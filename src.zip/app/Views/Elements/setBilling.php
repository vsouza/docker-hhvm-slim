<div class="lef perCent100">
    <div class="lef perCent50">
        <div class="rig w373 m0_18">
            <div id="byValue" class="radiusBox10 height282 ">
                <div class="r-body sel">
                    <div class="r-bg height216">
                        <span></span>
                    </div>
                    <div class="r-content">
                        <div class="fbFlag1">
                            <span>
                                <?=_('byValue')?>
                            </span>
                        </div>
                        <div class="fbFlag1Sh"></div>
                    </div>
                    <div class="r-inner-footer"></div>
                </div>
                <div class="r-body form">
                    <div class="r-content in260 p70_0_0_0">
                        <label for="budget" class="aLef">
                            <?=_('labInvestment')?>
                        </label>
                        <input type="text" id="budget" name="budget" class="money">
                    </div>
                    <div class="r-inner-footer aRig in260">
                        <button type="button" onclick="initSimulate('byValue');" class="btn-modal-white">
                            <?=_('btnCalculate')?>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="lef perCent50">
        <div class="lef w373 m0_18">
            <div id="byPeriod" class="radiusBox10 height282 ">
                <div class="r-body sel">
                    <div class="r-bg height216">
                        <span></span>
                    </div>
                    <div class="r-content">
                        <div class="fbFlag1">
                            <span>
                                <?=_('byPeriod')?>
                            </span>
                        </div>
                        <div class="fbFlag1Sh"></div>
                    </div>
                    <div class="r-inner-footer"></div>
                </div>
                <div class="r-body form">
                    <div class="r-content in260 p35_15_0_0">
                        <label for="top_beginDate" class="aLef">
                            <?=_('labInitialDate')?>
                        </label>
                        <div id="top_beginDate" class="input-append date"><!--
                            --><input type="text" id="top_beginDateI" name="top_beginDateI"></input><!--
                            --><span class="add-on"><i data-time-icon="icon-time" data-date-icon="icon-calendar"></i></span><!--
                        --></div>
                        <label for="top_endDate" class="aLef"><?=_('labEndDate')?></label>
                        <div id="top_endDate" class="input-append date"><!--
                            --><input type="text" id="top_endDateI" name="top_endDateI"></input><!--
                            --><span class="add-on"><i data-time-icon="icon-time" data-date-icon="icon-calendar"></i></span><!--
                        --></div>
                        <div class="r-inner-footer aRig in260">
                            <button type="button" onclick="initSimulate('byPeriod');" class="btn-modal-white">
                                <?=_('btnCalculate')?>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="hr35"></div>
<div class="block">
    <div class="in782">
        <div class="simulate byValue">
            <div class="simulateArrow"></div>
            <div class="simuBody">
                <div>
                    <span class="info">
                        <?=_('labYoullAnnounceby')?>
                    </span>
                    <div class="calendar">
                        <span class="aux">
                            <?=_n( 'day',30)?>
                        </span>
                        <span class="value">30</span>
                    </div>
                </div>
                <div>
                    <span class="info">
                        <?=_('msgYourCampaignCanAchieve')?>
                    </span>
                    <!-- 
                    <div class="percenter">
                        <div class="percentLimiter">
                            <div class="percentCircle"></div>
                            <div class="percentIndicator">
                                <span>50
                                    <font>%</font>
                                </span>
                            </div>
                        </div>
                        <div class="fbFlag2">
                            <span class="aCenter">
                                < ?=_('labOfTotal')?>
                            </span>
                        </div>
                    </div> 
                    -->
                    <div class="display">
                        <div>
                            <span class="label">
                                <?=_('labViews')?>
                            </span>
                            <span class="tagBlue reachedEstimateSpan"></span>
                        </div>
                        <div>
                            <span class="label">
                                <?=_('labTotalOfPeople')?>
                            </span>
                            <span class="tagGold reachEstimateSpan"></span>
                        </div>
                    </div>
                    <!-- <div class="percenterWarning">< ?=_('msgUnableToReach100')?></div> -->
                </div>
            </div>
            <div class="simuFooter">
                <span class="info">
                    <?=_('setDateForYourCampaign')?>
                </span>
                <div class="lef perCent50 p20_100_0_0">
                    <label for="sub_beginDateI" class="aLef"><?=_('labInitialDate')?></label>
                    <div id="sub_beginDate" class="input-append date"><!--
                        --><input type="text" id="sub_beginDateI" name="sub_beginDateI"></input><!--
                        --><span class="add-on"><i data-time-icon="icon-time" data-date-icon="icon-calendar"></i></span><!--
                    --></div>
                </div>
                <div class="lef perCent50 p20_100_0_0">
                    <label for="sub_endDate" class="aLef"><?=_('labEndDate')?></label>
                    <div id="sub_endDate" class="input-append date"><!--
                        --><input type="text" id="sub_endDateI" name="sub_endDateI"></input><!--
                        --><span class="add-on"><i data-time-icon="icon-time" data-date-icon="icon-calendar"></i></span><!--
                    --></div>
                </div>
            </div>
        </div>
        <div class="cb"></div>
        <div class="simulate byPeriod">
            <div class="simulateArrow"></div>
            <div class="simuBody">
                <div>
                    <span class="info">
                        <?=_s('idealInvestDuringXdaysIs',2)?>
                    </span>
                    <div class="currentBudget">
                        <font></font>
                        <font></font>
                    </div>
                    <span class="currentBudgetCoins"></span>
                </div>
                <div>
                    <span class="info">
                        <?=_('msgYourCampaignCanAchieve')?>
                    </span>
                    <!-- 
                    <div class="percenter">
                        <div class="percentLimiter">
                            <div class="percentCircle"></div>
                            <div class="percentIndicator">
                                <span>50<font>%</font></span>
                            </div>
                        </div>
                        <div class="fbFlag2">
                            <span class="aCenter">
                                < ?=_('labOfTotal')?>
                            </span>
                        </div>
                    </div> 
                    -->
                    <div class="display">
                        <div>
                            <span class="label">
                                <?=_('labViews')?>
                            </span>
                            <span class="tagBlue reachedEstimateSpan"></span>
                        </div>
                        <div>
                            <span class="label">
                                <?=_('labTotalOfPeople')?>
                            </span>
                            <span class="tagGold reachEstimateSpan"></span>
                        </div>
                    </div>
                    <!-- <div class="percenterWarning">< ?=_('msgUnableToReach100')?></div> -->
                </div>
            </div>
            <div class="simuFooter">
                <span class="info aCenter">
                    <?=_('defineYourInvestmentOption')?>
                </span>
                <div class="block aCenter p25_0_0_0">
                    <select id="investmentOption" name="investmentOption" class="select-yellow-xl"></select>
                </div>
            </div>
        </div>
        <div class="cb"></div>
    </div>
</div>