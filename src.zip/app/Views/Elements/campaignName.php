<div class="fullField">
    <label for="campaignName"><?=_('labCampaignName')?></label>
    <input type="text" id="campaignName" name="campaignName" maxlength="100">
</div>