<div class="wizard" id="fbPixel-wizard" data-title="<?=_('labMyPixel')?>" labRetry="<?=_('btnRetry')?>">
    <div class="wizard-card" data-cardname="creating">
        <h3><?=_('labCreating')?></h3>

        <div class="wizard-input-section">
            <div class="row-fluid">
                <div class="span12"><p><?=_('msgCreatingPixel')?></p></div>
            </div>
            <div class="height20"></div>
            <div class="row-fluid">
                <div class="span6 form-group">
                    <label for="pixelName"><?=_('labNameYourPixel')?></label>
                    <input id="pixelName" name="pixelName" type="text" class="form-control" data-validate="validatePixelName">
                </div>
                <div class="span6">
                    <label for="pixelType"><?=_('labChoosePixelType')?></label>
                    <select id="pixelType" name="pixelType" class="selectpicker">
                        <option value="CHECKOUT"><?=_('labPixelType0')?></option>
                        <option value="REGISTRATION"><?=_('labPixelType1')?></option>
                        <option value="LEAD"><?=_('labPixelType2')?></option>
                        <option value="KEY_PAGE_VIEW"><?=_('labPixelType3')?></option>
                        <option value="ADD_TO_CART"><?=_('labPixelType4')?></option>                    
                        <option value="OTHER"><?=_('labPixelType5')?></option>
                    </select>
                </div>
            </div>
            <div class="height20"></div>
            <div class="row-fluid">
                <div class="span6">
                    <label for="trackMode"><?=_('labTrackingMode')?></label>
                    <select id="trackMode" name="trackMode" class="selectpicker">
                        <option value="0"><?=_n('xDaysAfterViewingAd',1)?></option>
                        <option value="1"><?=_n('xDaysAfterViewingAd',7)?></option>
                        <option value="2"><?=_n('xDaysAfterViewingAd',28)?></option>
                        <option value="3" selected="selected"><?=_n('xDaysAfterClickingAd',1)?></option>
                        <option value="4"><?=_n('xDaysAfterClickingAd',7)?></option>
                        <option value="5"><?=_n('xDaysAfterClickingAd',28)?></option>
                    </select>
                    <div class="cb"></div>
                    <span class="suggestion"><?=_('labTrackingSuggestion')?></span>
                </div>
                <div class="span6">
                    <label><?=_('labWhoCodeYourWebSite')?></label>
                    <div class="tbRadioSmll" id="tbRadioSmll01">
                        <div id="radio0" class="radio"><i></i><span><?=_('labMyself')?></span></div>
                        <div id="radio1" class="radio"><i></i><span><?=_('labSomebodyElse')?></span></div>                    
                    </div>    
                </div>
            </div>
            <div class="height20"></div>
            <div class="height10"></div>
            <div class="row-fluid">
                <div class="span12 form-group">
                    <div class="tbRadioSmll form-control" id="tbRadioSmll02">
                        <div id="radio0" class="radio"><i></i><span><?=_s('msgAcceptTermsOfUse', '')?></span></div>
                    </div>                    
                </div>
            </div>
        </div>
    </div>
    <div class="wizard-card" data-cardname="sending">
        <h3><?=_('labSending')?></h3>
        
        <div class="wizard-input-section">
            <div class="row-fluid">
                <div class="span12">
                    <p><?=_('msgPixelCreated')?></p>
                </div>
            </div>
            <div class="height20 senderEmail" style="display: none;"></div>
            <div class="row-fluid senderEmail" style="display: none;">
                <div class="span6">
                    <div class="block form-group">
                        <label for="emailSender"><?=_('labSenderEmail')?></label>
                        <input id="emailSender" name="emailSender" type="text">
                    </div>
                    <div class="block m20_0_0_0 form-group">
                        <label for="emailReceiver"><?=_('labRecipientEmail')?></label>
                        <input id="emailReceiver" name="emailReceiver" type="text">
                        <span class="suggestion"><?=_('msgSeparateEmailAddressesWithCommas')?></span>
                    </div>    
                </div>
                <div class="span6 form-group">
                    <label for="msgReceiver"><?=_('labPersonalMessage')?></label>
                    <textarea id="msgReceiver" name="msgReceiver"></textarea>
                    <span class="suggestion"><?=_('msgToYourCodeManager')?></span>    
                </div>
            </div>
            <div class="height20"></div>
            <div class="row-fluid">
                <div class="span6">
                    <h6><?=_('labCodeAndInstructionsPixel')?></h6>
                    <p><?=_('msgCopyPastePixelCodeGuide')?></p>
                    <p><a href="%s" class="grayLinkStrong"><?=_('labUnderstandMoreAboutThis')?></a></p>
                </div>
                <div class="span6">
                    <textarea id="textScript" name="textScript" readonly="readonly"></textarea>
                </div>
            </div>
        </div>
    </div>
</div>