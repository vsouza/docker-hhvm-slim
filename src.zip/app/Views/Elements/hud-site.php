<div id="hud"><!-- absolute -->
    <ul id="topLine">
        <li></li>
        <li></li>
        <li></li>
    </ul>
    <header class="wrapper">
        <div class="logo">
            <a href="#panel" class="topLogoLink">
                <img src="/assets/img/topLogo.png">
            </a>
        </div>
        <nav class="top-nav">
            <ul class="mainmenu">
                <li><a href="#howitworks"><?=_('siteMenuHowItWorks')?></a></li>
                <li><a href="#about"><?=_('siteMenuTool')?></a></li>
                <li><a href="#contact"><?=_('siteMenuContact')?></a></li>
                <li><a href="#pricing"><?=_('siteMenuPricing')?></a></li>
            </ul>
        </nav>
        <div class="buttons">
            <div class="access-button">
                <button class="btn fullgreen" rel="fb-login" location="hud"><?=_('siteHomeLoginButton')?>
                    <span class="f">
                        <img src="/assets/img/website/f.png">
                    </span>
                </button>
            </div>

        </div>
    </header>
</div>
