<?php if($V->app->getMode()=='production'): ?>
<!-- Facebook Conversion Code for Start-Create-Campaing -->
<script type="text/javascript">
var fb_param = {};
fb_param.pixel_id = '6014953934872';
fb_param.value = '0.00';
fb_param.currency = 'BRL';
(function(){
  var fpw = document.createElement('script');
  fpw.async = true;
  fpw.src = '//connect.facebook.net/en_US/fp.js';
  var ref = document.getElementsByTagName('script')[0];
  ref.parentNode.insertBefore(fpw, ref);
})();
</script>
<noscript><img height="1" width="1" alt="" style="display:none" src="https://www.facebook.com/offsite_event.php?id=6014953934872&amp;value=0&amp;currency=BRL" /></noscript>

<!-- Facebook Conversion Code for Finish-Create-Campaing -->
<img height="1" width="1" alt="" style="display:none" id="finishCampaignPixel" data-src="https://www.facebook.com/offsite_event.php?id=6014953949472&amp;value=0&amp;currency=BRL" />
<?php else: ?>
<!-- CAMPAIGN PIXELS -->
<img height="1" width="1" alt="" style="display:none" id="finishCampaignPixel" data-src="http://placehold.it/1x1" />
<?php endif; ?>


