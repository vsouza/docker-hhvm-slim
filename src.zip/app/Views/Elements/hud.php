<div id="hud"><!-- absolute -->
    <ul id="topLine">
        <li></li>
        <li></li>
        <li></li>
    </ul>
    <div id="topWrapper">
        <div id="wraplogo">
            <a href="<?php $V->urlFor('dashboard'); ?>" title="<?=_('titleLogo')?>" class="topLogoLink">
                <img src="/assets/img/topLogo.png">
            </a>
            <nav>
                <a href="<?php $V->urlFor('dashboard'); ?>" class="btn medium"><?=_('navDashboard')?></a>
                <?php if(isset($trialDaysLeft)): ?>
                <a href="<?php $V->urlFor('subscription'); ?>" class="btn medium green"><?=_('aSubscribeNow')?></a>
                <?php endif; ?>
            </nav>
        </div>
        <div id="userNav">
            <?php if(isset($trialDaysLeft)): ?>
            <div  id="trialdays">
                <a href="<?php $V->urlFor('subscription'); ?>" class="<?php if($trialDaysLeft<=10) echo 'red' ?>">
                    <b><?=$trialDaysLeft?></b><br>
                    <?=_('aTrialDays')?>
                </a>
            </div>
            <?php endif ?>
            <div class="btn-group pull-right" id="wrapconfig">
                <a class="btn dropdown-toggle tb-dropdown" data-toggle="dropdown" href="#">
                    <span class="tb-dropdown-desc"><?=$_SESSION['user']['firstName']?></span>
                    <span class="caret"></span>
                </a>
                <ul class="dropdown-menu tb-dropdown-menu">
                    <li><a href="<?php $V->urlFor('dashboard'); ?>" title="<?=_('navDashboard')?>"><?=_('navDashboard')?></a></li>
                    <li><a href="<?php $V->urlFor('myaccount'); ?>" title="<?=_('navMyAccount')?>"><?=_('navMyAccount')?></a></li>
                    <li><a href="http://tamboreen.uservoice.com/" title="<?=_('navHelp')?>" target="_blank"><?=_('navHelp')?></a></li>
                    <li><a href="<?php $V->urlFor('logout'); ?>" title="<?=_('navLogout')?>"><?=_('navLogout')?></a></li>
                </ul>
            </div>
            <div class="btn-group pull-right">
                <button class="btn dropdown-toggle tb-dropdown-alert" data-toggle="dropdown">
                    <span class="tb-dropdown-radius-desc" id="global-unread">0</span>
                    <span class="tb-dropdown-desc"  id="wrapwarninglabel"><?=_('labWarnings')?></span>
                </button>
                <ul class="dropdown-menu tb-dropdown-menu-alert">
                    <li>
                        <article>
                            <p style="margin-bottom: 0;"><?=_('msgNoNotifications')?></p>
                        </article>
                    </li>
                    <script id="tpl_wrapnotifications" type="text/x-handlebars-template">
                        {{#if data}}
                        {{#each data}}
                            <li>
                                <article>
                                    <p>
                                        {{{message}}} <br>
                                        <div class="timestamp">{{Timezone createdDate}}</div>
                                    </p>
                                 </article>                                        how to export psd linux
                            </li>
                            <li class="divider"></li>
                        {{/each}}
                        <li>
                            <a href="<?php $V->urlFor('notifications') ?>" id="wrapviewallnotices">
                                <strong><?=_('aAllNotifications')?></strong>
                            </a>
                        </li>
                        {{else}}
                            <li>
                                <article>
                                    <p style="margin-bottom: 0;"><?=_('msgNoNotifications')?></p>
                                </article>
                            </li>
                        {{/if}}
                    </script>
                    <span id="wrapnotifications">
                    </span>
                </ul>
            </div>
        </div>
    </div>
</div>
