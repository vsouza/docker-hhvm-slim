<div class="block aCenter">
    <div class="fbFlag0 m0_0_0_100">
        <span><?=_('informationFromYourFacebook')?></span>
    </div>
    <div class="w100 rig m12_0_0_0">
        <i class="tb-icon-18x-info rig"></i>
        <font class="rig m0_6_0_0 fbInfoYellow14"><a href="javascript:startGuideTabStp03();void(0);" title="<?=_('viewTab')?>"><?=_('viewTab')?></a></font>
    </div>                                        
</div>
<div class="cb"></div>
<div>
    <div class="in300">
        <div id="segAge" 
            class="radiusBox10 height250 bootstro" 
            data-bootstro-step="0"
            data-bootstro-placement="right"
            data-bootstro-width="300px"
            data-bootstro-html="true"
            data-bootstro-content='<?=_('helpFindTheAge')?>'
            data-bootstro-prevButton = '<a href="#" class="bootstro-prev-btn"><?=_('labPrev')?></a>'
            data-bootstro-nextButton = '<a href="#" class="bootstro-next-btn"><?=_('labNext')?></a>'
            data-bootstro-finishButton = '<a href="#" class="bootstro-finish-btn"><?=_('labFinish')?></a>'>
            <div class="r-body">
                <div class="r-bg height137">
                    <span></span>
                </div>
                <div class="r-content">
                    <div class="fbFlag1">
                        <span><?=_('labAge')?></span>
                    </div>
                    <div class="fbFlag1Sh"></div>
                    <span id="madeRange">
                        <script id="tpl_madeRange" type="text/x-handlebars-template">
                            {{madeRange this.age this.ageTerms}}
                        </script>
                    </span>
                </div>
                <div class="r-inner-footer"></div>
            </div>
            <div class="r-footer aRig">
                <button type="button" class="btn-modal-white m0_10_0_0" onclick="showModal('#modalManageAge',{ backdrop: 'static', keyboard: false});"><?=_('btnChange')?></button>
            </div>
        </div>
        <div class="hr20"></div>
        <div id="segSex" 
            class="radiusBox10 height250 bootstro"
            data-bootstro-step="1"
            data-bootstro-placement="right"
            data-bootstro-width="300px"
            data-bootstro-html="true"
            data-bootstro-content='<?=_('helpSetCustomers')?>'
            data-bootstro-prevButton = '<a href="#" class="bootstro-prev-btn"><?=_('labPrev')?></a>'
            data-bootstro-nextButton = '<a href="#" class="bootstro-next-btn"><?=_('labNext')?></a>'
            data-bootstro-finishButton = '<a href="#" class="bootstro-finish-btn"><?=_('labFinish')?></a>'>
            <div class="r-body">
                <div class="r-bg height137" id="genderShowClass">
                    <script id="tpl_genderShowClass" type="text/x-handlebars-template">
                        <span class="{{genderShowClass this}}"></span>
                    </script>
                </div>
                <div class="r-content">
                    <div class="fbFlag1">
                        <span><?=_('labGender')?></span>
                    </div>
                    <div class="fbFlag1Sh"></div>
                    <span id="genderShow">
                        <script id="tpl_genderShow" type="text/x-handlebars-template">
                            {{genderShow this.gender this.genderTerms}}
                        </script>
                    </span>
                </div>
                <div class="r-inner-footer"></div>
            </div>
            <div class="r-footer aRig">
                <button type="button" class="btn-modal-white m0_10_0_0" onclick="showModal('#modalManageGenre',{ backdrop: 'static', keyboard: false});"><?=_('btnChange')?></button>
            </div>
        </div>
    </div>
</div>
<div>
    <div class="in300">
        <div id="segPlace" 
            class="radiusBox10 height435 bootstro"
            data-bootstro-step="2"
            data-bootstro-placement="right"
            data-bootstro-width="300px"
            data-bootstro-html="true"
            data-bootstro-content='<?=_('helpFindPlace')?>'
            data-bootstro-prevButton = '<a href="#" class="bootstro-prev-btn"><?=_('labPrev')?></a>'
            data-bootstro-nextButton = '<a href="#" class="bootstro-next-btn"><?=_('labNext')?></a>'
            data-bootstro-finishButton = '<a href="#" class="bootstro-finish-btn"><?=_('labFinish')?></a>'>
            <div class="r-body">
                <div class="r-bg height187">
                    <span></span>
                </div>
                <div class="r-content">
                    <div class="fbFlag1">
                        <span><?=_('labLocated')?></span>
                    </div>
                    <div class="fbFlag1Sh"></div>
                    <div class="r-content-overflow">
                        ascpuoas
                    </div>
                </div>
                <div class="r-inner-footer"></div>
            </div>
            <div class="r-footer aRig">
                <button type="button" onclick="showModal('#modalManagePlace',{ backdrop: 'static', keyboard: false});" class="btn-modal-white m0_10_0_0"><?=_('btnChange')?></button>
            </div>
        </div>
    </div>
</div>
<div>
    <div class="in300">
        <div id="segInterest" class="radiusBox10 height435 bootstro"
            data-bootstro-step="3"
            data-bootstro-placement="left"
            data-bootstro-width="300px"
            data-bootstro-html="true"
            data-bootstro-content='<?=_('helpFindInterest')?>'
            data-bootstro-prevButton = '<a href="#" class="bootstro-prev-btn"><?=_('labPrev')?></a>'
            data-bootstro-nextButton = '<a href="#" class="bootstro-next-btn"><?=_('labNext')?></a>'
            data-bootstro-finishButton = '<a href="#" class="bootstro-finish-btn"><?=_('labFinish')?></a>'>
            <div class="r-body">
                <div class="r-bg height187">
                    <span></span>
                </div>
                <div class="r-content">
                    <div class="fbFlag1">
                        <span><?=_('labInterested')?></span>
                    </div>
                    <div class="fbFlag1Sh"></div>
                    <div class="r-content-overflow"></div> 
                </div>
                <div class="r-inner-footer"></div>
            </div>
            <div class="r-footer aRig">
                <button type="button" onclick="showModal('#modalManageInterest',{ backdrop: 'static', keyboard: false});" class="btn-modal-white m0_10_0_0"><?=_('btnChange')?></button>
            </div>
        </div>
    </div>
</div>
<div>
    <div><?=_('seenByApproximately')?></div>
    <div>
        <span class="int reachEstimateSpan">0</span>
        <span><?=_('labPeople')?></span>
    </div>
</div>