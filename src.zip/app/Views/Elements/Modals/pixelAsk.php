<div id="modalPixelAsk" class="modal hide fade in" tabindex="-1" role="dialog" aria-labelledby="headerLabel" aria-hidden="false" style="display: none;">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="modalPixelAskLabel">&nbsp;</h3>
    </div>
    <div class="modal-body">
        <h4><?=_('hello')?> <?=$_SESSION['user']['firstName']?></h4>
        <div class="hr10"></div>
        <p><?=_s('msgPixelConversionDescription',_('msgPixelConversionToolTip'))?></p>

        <p class="noob"><?=_('msgPixelConversionAsk')?></p>
        <p class="veteran"><b><?=_('msgYouHavePixelCreated')?></b></p>

        <div class="hr10"></div>
        <div class="row-fluid veteran">
            <label for="pixelList"><?=_('labChoosePixel')?></label>
            <select id="pixelList" name="pixelList" class="selectpicker"></select>
        </div>

        <div class="row-fluid veteran">
            <label for="trackMode"><?=_('labTrackingMode')?></label>
            <select id="trackMode" name="trackMode" class="selectpicker">
                <option value="0"><?=_n('xDaysAfterViewingAd',1)?></option>
                <option value="1"><?=_n('xDaysAfterViewingAd',7)?></option>
                <option value="2"><?=_n('xDaysAfterViewingAd',28)?></option>
                <option value="3" selected="selected"><?=_n('xDaysAfterClickingAd',1)?></option>
                <option value="4"><?=_n('xDaysAfterClickingAd',7)?></option>
                <option value="5"><?=_n('xDaysAfterClickingAd',28)?></option>
            </select>
            <div class="cb"></div>
            <span class="suggestion"><?=_('labTrackingSuggestion')?></span>
        </div>
    </div>
    <div class="modal-footer">
        <button id="btnNo" class="btn-cancel noob"><?=_('labNo')?></button>
        <button id="btnYes" class="btn-modal-solildWhite noob"><?=_('labYes')?></button>

        <a id="aCreate" class="lef linkAsBtnGray13 veteran" href="javascript:void(0);" title="<?=_('labCreatePixel')?>"><?=_('labCreatePixel')?></a>
        <button id="btnCancel" class="btn-cancel veteran"><?=_('btnCancel')?></button>
        <button id="btnContinue" class="btn-green veteran"><?=_('btnContinue')?></button>
    </div>
</div>
