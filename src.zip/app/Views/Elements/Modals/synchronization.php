<div id="modalSynchronization" class="modal hide fade in" tabindex="-1" role="dialog" aria-labelledby="headerLabel" aria-hidden="false" style="display: none;">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="modalSynchronizationLabel">&nbsp;</h3>
    </div>
    <div class="modal-body">
        <h4><?=_('hello')?> <?=$_SESSION['user']['firstName']?></h4>
        <div class="hr10"></div>
        <p><?=_('msgSyncModal')?></p>
        
        <div class="syncContainer">
            <div></div>
            <div>
                <ul>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                </ul>
                <span><?=_('labSynchronizing')?></span>
            </div>
            <div></div>
        </div>

    </div>
    <div class="modal-footer">
        <a href="#" target="_blank" class="linkAsBtnGray13 lef"><?=_('labNeedHelp')?></a>
        <button class="btn-modal-disabled"><?=_('btnUpdateAccounts')?></button>
    </div>
</div>