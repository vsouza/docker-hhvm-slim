<div id="modalManageInterest" class="modal hide fade in" tabindex="-1" role="dialog" aria-labelledby="headerLabel" aria-hidden="false" style="display: none;">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="modalManageInterestLabel">&nbsp;</h3>
    </div>
    <div class="modal-body">
        <h4><?=_('whatTheyLike')?></h4>
        <div class="hr10"></div>
        <p><?=_('helpFindInterest')?></p>
        <div class="clearfix"></div>
        <input type="hidden" id="interestDefiner" name="interestDefiner">
    </div>
    <div class="modal-footer aCenter">
        <button class="btn-green"><?=_('btnSaveChanges')?></button>
        <input type="hidden" 
            id="langPkg" 
            data-noResultsText="<?=_('labNoRecordsFound')?>"
            data-searchingText="<?=_('labSearching')?>"
            data-placeholder="<?=_('postAnInterest')?>">
    </div>
</div>