<div id="modalCreateCreativeSimilar" class="modal hide fade in" tabindex="-1" role="dialog" aria-labelledby="headerLabel" aria-hidden="false" style="display: none;">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="modalCreateCreativeSimilarLabel">&nbsp;</h3>
    </div>
    <div class="modal-body">
        <h4 class="aCenter"><?=_('createSimilarContent')?></h4>
        <div class="hr25"></div>
        <form id="frmModalCreateCreativeSimilar" name="frmModalCreateCreativeSimilar">
            <div class="row-fluid">
                <div class="span7">
                    <textarea id="txtText" name="txtText" placeholder="<?=_('textOfYourAd')?>"></textarea>
                    <div class="hr25"></div>
                    <span class="curvedArrow1"></span>
                    <input type="file" 
                        id="addMedia"
                        class="filestyle" 
                        data-buttonText="<?=_('btnAddImageOrVideo')?>" 
                        data-titleButton="<?=_('percentOfText')?>" 
                        data-input="false" 
                        data-icon="false" 
                        data-classButton="btn-modal-white" 
                        data-idButton="addMediaBtn"
                        data-targeting="form#postForm :file">
                    <span class="curvedArrow2"></span>
                </div>
                <div class="span5 m0">
                    <div class="fbCreative">
                        <div><span class="pag-thumb"></span></div>
                        <article>
                            <h5 class="pag-name"></h5>
                            <p hasMedia="0">
                                <span class="text"></span>
                                <span class="targetSquareSample140"></span>
                            </p>
                            <footer>
                                <i class="tb-icon-13x-sponsor"></i>
                                <font class="fbInfoGray12"><?=_('sponsored')?></font>
                            </footer>
                        </article>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <div class="modal-footer aCenter">
        <button type="button" id="btnGo_modalCreateCreativeSimilar" class="btn-green"><?=_('btnContinue')?></button>
    </div>    
</div>