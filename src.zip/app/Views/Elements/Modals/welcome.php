<!-- Modal -->
<div id="modalWelcome" class="modal hide fade" tabindex="-1" role="dialog" style="width: 800px; margin-left: -400px;">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    </div>
    <div class="modal-body">
        <h4><?=_('modalWelcomeToTBTitle')?></h4>
        <p><?=_('modalWelcomeToTBDescription')?></p>
        <img src="/assets/img/modal_welcome.jpg">
        <div class="description three">
            <span><?=_('modalWelcomeToTBCaption1')?></span>
            <span><?=_('modalWelcomeToTBCAption2')?></span>
            <span><?=_('modalWelcomeToTBCAption3')?></span>
        </div>
    </div>
    <div class="modal-footer center">
      <button id="welcomeStart" data-dismiss="modal" class="btn fullgreen"><?=_('modalWelcomeToTBCTA')?><img src="/assets/img/wizardWhiteArrow.png"></button>
    </div>
</div>
