<div id="modalChooseAccount" class="modal hide fade in" tabindex="-1" role="dialog" aria-labelledby="headerLabel" aria-hidden="false" style="display: none;">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="headerLabel">&nbsp;</h3>
    </div>
    <div class="modal-body">
        <h4><?=_('modalMyAdAccountsTBTitle')?></h4>
        <div class="hr10"></div>
        <p class="white-tooltip"><?=_('modalMyAdAccountsTBDescription')?> <a href="#" class="tip" data-toggle="tooltip" data-placement="bottom" data-original-title="<?=_('modalMyAdAccountsTBTooltip')?>"><img src="/assets/img/question.gif" ></a></p>
        <div class="hr10"></div>
        <div class="lef"><?=_('modalMyAdAccountsTBQuestion')?></div>
        <div class="lef btn-group" style="margin:-4px 0 0 10px">
            <select id="selectAccountId" name="selectAccountId"></select>
        </div>
        <div class="cb"></div>

        <div class="warning hide">
            <?=_('modalMyAdAccountsTBWarning')?>
            <div style="text-align: right"><a href="http://www.facebook.com"><?=_('btnAccessFacebook')?></a></div>
        </div>
    </div>
    <div class="modal-footer" style="text-align: center;">
        <a class="btn red whitebg" data-dismiss="modal"><?=_('btnCancel')?></a>
        <a class="btn fullgreen hide" id="btnContinueModalChooseAccount"><?=_('btnContinue')?></a>
    </div>
</div>
