<div id="modalPublishActions" class="modal" tabindex="-1" role="dialog" aria-labelledby="headerLabel" aria-hidden="false" style="display: none;">
    <div class="modal-header">
        <h3 id="modalPublishActionsLabel">&nbsp;</h3>
    </div>
    <div class="modal-body">
        <h4 class="aCenter"><?=_('hPermissionsRequired')?></h4>
        <div class="hr25"></div>
        <p><?=_('pPublishActions')?></p>
    </div>
    <div class="modal-footer aCenter">
        <button type="button" id="btnPublishActions" class="btn fullgreen big"><?=_('btnAuthorize')?></button>
    </div>
</div>