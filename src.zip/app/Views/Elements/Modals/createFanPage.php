<div id="modalCreateFanPage" class="modal hide fade in" tabindex="-1" role="dialog" aria-labelledby="headerLabel" aria-hidden="false" style="display: none;">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="modalCreateFanPageLabel">&nbsp;</h3>
    </div>
    <div class="modal-body">
        <h4><?=_('hello')?> <?=$_SESSION['user']['firstName']?></h4>
        <div class="hr10"></div>
        <p labContinue="<?=_('msgAfterFacebookPageCreation')?>"><?=_('msgCreatingFanPageProcess')?></p>
    </div>
    <div class="modal-footer">
        <button class="btn-green create" labContinue="<?=_('btnContinue')?>"><?=_('btnCreateMyFacebookPage')?></button>
    </div>
</div>