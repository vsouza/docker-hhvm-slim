<div id="modalManagePlace" class="modal hide fade in" tabindex="-1" role="dialog" aria-labelledby="headerLabel" aria-hidden="false" style="display: none;">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="modalManagePlaceLabel">&nbsp;</h3>
    </div>
    <div class="modal-body">
        <h4><?=_('whereAreAsk')?></h4>
        <div class="hr10"></div>
        <p><?=_('helpFindPlace')?></p>
        <div class="clearfix"></div>
        <input type="hidden" id="placeDefiner" name="placeDefiner">
    </div>
    <div class="modal-footer aCenter">
        <button class="btn-green"><?=_('btnSaveChanges')?></button>
        <input type="hidden" 
            id="langPkg" 
            data-noResultsText="<?=_('labNoRecordsFound')?>"
            data-searchingText="<?=_('labSearching')?>"
            data-placeholder="<?=_('postALocale')?>">
    </div>
</div>