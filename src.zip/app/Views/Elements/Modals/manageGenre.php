<div id="modalManageGenre" class="modal hide fade in" tabindex="-1" role="dialog" aria-labelledby="headerLabel" aria-hidden="false" style="display: none;">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="modalManageGenreLabel">&nbsp;</h3>
    </div>
    <div class="modal-body">
        <h4><?=_('genreAsk')?></h4>
        <div class="hr10"></div>
        <p><?=_('helpSetCustomers')?></p>
        <div class="tbRadio">
            <div id="radio0" class="radio">
                <i></i>
                <span><?=_('men')?></span>
            </div>
            <div id="radio1" class="radio">
                <i></i>
                <span><?=_('women')?></span>
            </div>
            <div id="radio2" class="radio selected">
                <i></i>
                <span><?=_('bothGenres')?></span>
            </div>
        </div>
    </div>
    <div class="modal-footer aCenter">
        <button class="btn-green"><?=_('btnSaveChanges')?></button>
    </div>
</div>