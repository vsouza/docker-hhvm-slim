<div id="modalLinkFanPage" class="modal hide fade in" tabindex="-1" role="dialog" aria-labelledby="headerLabel" aria-hidden="false" style="display: none;">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="modalLinkFanPageLabel">&nbsp;</h3>
    </div>
    <div class="modal-body">
        <h4><?=_('hello')?> <?=$_SESSION['user']['firstName']?></h4>
        <div class="hr10"></div>
        <p><?=_('msgHavePagesInYourAccount')?></p>
        <p><?=_('msgThesePagesRefersToTheWebsite')?></p>
    </div>
    <div class="modal-footer aCenter">
        <button class="btn-cancel"><?=_('labNo')?></button>
        <button class="btn-modal-solildWhite"><?=_('labYes')?></button>
    </div>
</div>