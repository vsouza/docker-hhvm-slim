<div id="modalChangeCreativeDomain" class="modal hide fade in" tabindex="-1" role="dialog" aria-labelledby="headerLabel" aria-hidden="false" style="display: none;">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="modalChangeCreativeDomainLabel">&nbsp;</h3>
    </div>
    <div class="modal-body">
        <h4 class="aCenter"><?=_('labEditYourAd')?></h4>
        <div class="hr25"></div>
        <form id="frmModalChangeCreativeDomain" name="frmModalChangeCreativeDomain">
            <div class="row-fluid">
                <div class="span7">
                    <input type="text" id="titAd" name="titAd" placeholder="<?=_('titOfYourAd')?>" maxlength="25">
                    <textarea id="txtText" name="txtText" placeholder="<?=_('textOfYourAd')?>"></textarea>
                    <div class="hr25"></div>
                    <span class="curvedArrow1"></span>
                    <input type="file" 
                        id="addMedia"
                        data-buttonText="<?=_('btnAddImage')?>" 
                        data-titleButton="<?=_('percentOfText')?>" 
                        data-input="false" 
                        data-icon="false" 
                        data-classButton="btn-modal-white" 
                        data-idButton="addMediaBtn"
                        data-targeting="form#postForm :file">
                    <span class="curvedArrow2"></span>
                </div>
                <div class="span5 m0">
                    <div class="pageLikeAd">
                        <div class="">
                            <h5 class="fanPageTitle pag-name">&nbsp;</h5>
                            <h6 class="pageLikeAdTitle"></h6>
                        </div>
                        <div class="pageLikeAdMedia pag-thumb"></div>
                        <div class="pageLikeAdMessage"></div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <div class="modal-footer aCenter">
        <button type="button" id="btnGo_modalChangeCreativeDomain" class="btn-modal-disabled"><?=_('labEditYourAd')?></button>
    </div>
</div>