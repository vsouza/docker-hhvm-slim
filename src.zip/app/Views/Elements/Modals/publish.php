<div id="modalPublish" class="modal hide fade in" tabindex="-1" role="dialog" aria-labelledby="headerLabel" aria-hidden="false" style="display: none;">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="modalPublishLabel">&nbsp;</h3>
    </div>
    <div class="modal-body">
        <h4><?=_('labProcessing')?></h4>
        <div class="hr10"></div>
        <p class="currentStatus"></p>
        <div class="clearfix"></div>
    </div>
    <div class="modal-footer aRig">
        <button class="btn-modal-disabled" id="btnPublishRetry" style="visibility: hidden"><?=_('btnBack')?></button>
        <button class="btn-modal-disabled" id="btnPublishCancel" style="visibility: hidden"><?=_('labCancel')?></button>
        <button class="btn-modal-disabled" id="btnPublishFinish" style="visibility: hidden"><?=_('labFinish')?></button>
    </div>    
</div>