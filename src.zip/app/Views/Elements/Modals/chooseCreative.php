<div id="modalChooseCreative" class="modal hide fade in" tabindex="-1" role="dialog" aria-labelledby="headerLabel" aria-hidden="false" style="display: none;">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="modalChooseCreativeLabel">&nbsp;</h3>
    </div>
    <div class="modal-body">
        <h4 class="aCenter"><?=_('chooseYourContent')?></h4>
        <div class="hr25"></div>
        <ul>
            <li>
                <div class="fbCreative">
                    <div><span class="pag-thumb"></span></div>
                    <article>
                        <h5 class="pag-name"></h5>
                        <p class="pag-info"></p>
                        <footer>
                            <i class="tb-icon-13x-sponsor"></i>
                            <font class="fbInfoGray12"><?=_('sponsored')?></font>
                        </footer>
                    </article>
                </div>
                <span></span>
            </li>
        </ul>
        <div class="cb"></div>
    </div>
    <div class="modal-footer aCenter">
        <button type="button" id="btnGo_modalChooseCreative" class="btn-modal-disabled"><?=_('btnContinue')?></button>
    </div>
</div>    