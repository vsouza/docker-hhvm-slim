<div id="modalManageAge" class="modal hide fade in" tabindex="-1" role="dialog" aria-labelledby="headerLabel" aria-hidden="false" style="display: none;">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h3 id="modalManageAgeLabel">&nbsp;</h3>
        </div>
        <div class="modal-body">
            <h4><?=_('hHowOldAsk')?></h4>
            <div class="hr10"></div>
            <p><?=_('helpFindTheAge')?></p>
            <div class="clearfix"></div>
            <ul class="between1in2">
                <li>
                    <select id="beginAge" class="selectpicker">
                        <script id="tpl_beginAge" type="text/x-handlebars-template">
                            {{{iterateTpl 13 65 this.targeting.age.begin '<option value="%0" %1>%0 &nbsp;&nbsp;</option>'}}}
                        </script>
                    </select>
                </li>
                <li><span class="color-select"><?=_('labTo')?></span></li>
                <li>
                    <select id="endAge" class="selectpicker">
                        <script id="tpl_endAge" type="text/x-handlebars-template">
                            {{{iterateTpl 13 65 this.targeting.age.end '<option value="%0" %1>%0 &nbsp;&nbsp;</option>'}}}
                        </script>
                    </select>
                </li>
            </ul>           

        </div>
        <div class="modal-footer aCenter">
            <button class="btn-green"><?=_('btnSaveChanges')?></button>
        </div>
</div>