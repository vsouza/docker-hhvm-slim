<div>
    <div class="createNewPage" id="createNewPage">
        <a href="javascript:showModal('#modalCreateFanPage',{ backdrop: 'static', keyboard: false});void(0);" title="<?=_('createNewPage')?>">
            <div class="ico"></div>
            <div class="label"><?=_('createNewPage')?></div>
        </a>                                
    </div>
</div>
<div>
    <div id="carouselChooseYourPage" class="carousel slide carouselGoal">
        <script id="tpl_carouselChooseYourPage" type="text/x-handlebars-template">
            <ol class="carousel-indicators">
                {{{carouselChooseYourPageIndicators this}}}
            </ol>
            <div class="carousel-inner pageList">
                {{{carouselChooseYourPageInner this}}}
            </div>
            <div class="carousel-control left">
                <a href="#carouselChooseYourPage" data-slide="prev"></a>
            </div>
            <div class="carousel-control right">
                <a href="#carouselChooseYourPage" data-slide="next"></a>
            </div>
        </script>
        <div id="noPages">
            <p>
                <?=_('noPagesFound');?>
            </p>
        </div>
    </div>
</div>