<?php 
if(/*true||*/$V->app->getMode()=='production'):

	if(!isset($lang))
		$lang = isset($_SESSION['user']['lang']) ? substr($_SESSION['user']['lang'],0,2) : 'pt';
?>

<script>
// https://www.uservoice.com/o/javascript-sdk
UserVoice=window.UserVoice||[];(function(){var uv=document.createElement('script');uv.type='text/javascript';uv.async=true;uv.src='//widget.uservoice.com/55zsg5KW9kgaF3cyTS0cCw.js';var s=document.getElementsByTagName('script')[0];s.parentNode.insertBefore(uv,s)})();

UserVoice.push(['set', {
  accent_color: '#2e4981',
  trigger_background_color: '#03b003',
  locale: '<?=$lang?>',
  trigger_style: 'tab',
  tab_label: '<?=strtoupper(_('navHelp'))?>'
}]);

<?php if(isset($_SESSION['user'])): ?>
UserVoice.push(['identify', {
  email:      '<?=$_SESSION['user']['email']?>', // User’s email address
  name:       '<?=$_SESSION['user']['firstName']?> <?=$_SESSION['user']['surname']?>', // User’s real name
  id:         <?=$_SESSION['user']['fbId']?>, // Optional: Unique id of the user (if set, this should not change)
}]);
<?php endif; ?>

UserVoice.push(['addTrigger', { mode: 'contact', trigger_position: 'bottom-right' }]);
UserVoice.push(['autoprompt', {}]);
</script>

<?php endif; // production ?>