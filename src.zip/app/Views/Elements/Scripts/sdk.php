<!-- build:js(.) /js/sdk.js -->
<script src="/js/app/utils/fb.js"></script>

<script src="/js/tb/errors.js"></script>
<script src="/js/tb/prelude.js"></script>
<script src="/js/tb/validate.js"></script>
<script src="/js/tb/objects/token.js"></script>
<script src="/js/tb/objects/permissions.js"></script>
<script src="/js/tb/objects/user.js"></script>
<script src="/js/tb/objects/page.js"></script>
<script src="/js/tb/objects/adaccount.js"></script>
<script src="/js/tb/objects/adcampaign.js"></script>
<script src="/js/tb/objects/adset.js"></script>
<script src="/js/tb/objects/adgroup.js"></script>
<script src="/js/tb/objects/adcreative.js"></script>
<script src="/js/tb/objects/targeting.js"></script>
<script src="/js/tb/objects/adpreview.js"></script>
<script src="/js/tb/objects/adstatistics.js"></script>

<script src="/js/lib/promise/promise-6.1.0.min.js"></script>
<script src="/js/facebook-js-ads-sdk/src/utils/browser-prepend.js"></script>
<script src="/js/facebook-js-ads-sdk/src/http/fb-error.js"></script>
<script src="/js/facebook-js-ads-sdk/src/http/xml-http-request.js"></script>
<script src="/js/facebook-js-ads-sdk/src/http/graph.js"></script>
<script src="/js/facebook-js-ads-sdk/src/objects/core/data-object.js"></script>
<script src="/js/facebook-js-ads-sdk/src/objects/core/collection.js"></script>
<script src="/js/facebook-js-ads-sdk/src/objects/core/crud-object.js"></script>
<script src="/js/facebook-js-ads-sdk/src/objects/mixins/cannot-create.js"></script>
<script src="/js/facebook-js-ads-sdk/src/objects/mixins/cannot-update.js"></script>
<script src="/js/facebook-js-ads-sdk/src/objects/mixins/cannot-delete.js"></script>
<script src="/js/facebook-js-ads-sdk/src/objects/mixins/object-validation.js"></script>
<script src="/js/facebook-js-ads-sdk/src/objects/mixins/archivable.js"></script>
<script src="/js/facebook-js-ads-sdk/src/objects/ad-user.js"></script>
<script src="/js/facebook-js-ads-sdk/src/objects/ad-account.js"></script>
<script src="/js/facebook-js-ads-sdk/src/objects/ad-campaign.js"></script>
<script src="/js/facebook-js-ads-sdk/src/objects/ad-set.js"></script>
<script src="/js/facebook-js-ads-sdk/src/objects/ad-image.js"></script>
<script src="/js/facebook-js-ads-sdk/src/objects/ad-creative.js"></script>
<script src="/js/facebook-js-ads-sdk/src/objects/ad-group.js"></script>
<script src="/js/facebook-js-ads-sdk/src/objects/ad-preview.js"></script>
<script src="/js/facebook-js-ads-sdk/src/objects/ad-statistics.js"></script>
<script src="/js/facebook-js-ads-sdk/src/objects/ad-conversion-pixel.js"></script>
<script src="/js/facebook-js-ads-sdk/src/objects/connection-object.js"></script>
<script src="/js/facebook-js-ads-sdk/src/objects/reach-estimate.js"></script>
<script src="/js/facebook-js-ads-sdk/src/objects/objects.js"></script>
<script src="/js/facebook-js-ads-sdk/src/api.js"></script>
<!-- endbuild -->