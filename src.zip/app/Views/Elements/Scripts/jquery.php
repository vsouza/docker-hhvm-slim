<!-- build:js(.) /js/jquery.js -->
<script src="/js/bower/jquery/dist/jquery.js"></script>
<script src="/js/bower/spin.js/spin.js"></script>
<script src="/js/app/utils/jquery-plugins.js"></script>
<!-- endbuild -->