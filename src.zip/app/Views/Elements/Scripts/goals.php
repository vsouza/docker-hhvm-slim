<!-- build:js(.) /js/goals.js -->
<script src="/js/bower/jcarousel/dist/jquery.jcarousel.min.js"></script> 
<script src="/js/bower/bootstro/bootstro.min.js"></script> 
<script src="/js/lib/jquery.tokeninput/jquery.tokeninput.min.js"></script>
<script src="/js/app/goals/goals.js"></script>
<!-- endbuild -->