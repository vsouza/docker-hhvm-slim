<!-- build:js(.) /js/main.js -->
	<!-- Plugins -->
	<script src="/js/bower/bootstrap/docs/assets/js/bootstrap-affix.js"></script>
	<script src="/js/bower/bootstrap/docs/assets/js/bootstrap-alert.js"></script>
	<script src="/js/bower/bootstrap/docs/assets/js/bootstrap-dropdown.js"></script>
	<script src="/js/bower/bootstrap/docs/assets/js/bootstrap-tooltip.js"></script>
	<script src="/js/bower/bootstrap/docs/assets/js/bootstrap-modal.js"></script>
	<script src="/js/bower/bootstrap/docs/assets/js/bootstrap-transition.js"></script>
	<script src="/js/bower/bootstrap/docs/assets/js/bootstrap-button.js"></script>
	<script src="/js/bower/bootstrap/docs/assets/js/bootstrap-popover.js"></script>
	<script src="/js/bower/bootstrap/docs/assets/js/bootstrap-typeahead.js"></script>
	<script src="/js/bower/bootstrap/docs/assets/js/bootstrap-carousel.js"></script>
	<script src="/js/bower/bootstrap/docs/assets/js/bootstrap-scrollspy.js"></script>
	<script src="/js/bower/bootstrap/docs/assets/js/bootstrap-collapse.js"></script>
	<script src="/js/bower/bootstrap/docs/assets/js/bootstrap-tab.js"></script>
	<script src="/js/bower/jQuery-Mask-Plugin/jquery.mask.min.js"></script>
	<script src="/js/bower/handlebars/handlebars.js"></script>
	<script src="/js/bower/bootbox/bootbox.js"></script>
	<script src="/js/lib/bootstrap-datetimepicker/bootstrap-datetimepicker.min.js"></script>
	<script src="/js/lib/bootstrap-select/bootstrap-select.min.js"></script>
	<script src="/js/lib/jquery.currency/jquery.currency.min.js"></script>
	<script src="/js/lib/jquery.number/jquery.number.min.js"></script>

	<!-- Utilities -->
	<script src="/js/app/utils/create-class.js"></script>
	<script src="/js/app/utils/functions.js"></script>
	<script src="/js/app/utils/cookies.js"></script>
	<script src="/js/app/utils/ui-helpers.js"></script>
	<script src="/js/app/utils/currency.js"></script>
	<script src="/js/app/utils/i18n.js"></script>
	<script src="/js/app/utils/handlebars.js"></script>
	<script src="/js/app/utils/keyboard.js"></script>

	<!-- Configurations -->
	<script src="/js/app/config.js"></script>
<!-- endbuild -->
<!-- <script src="/js/app/utils/notifications.js"></script> -->