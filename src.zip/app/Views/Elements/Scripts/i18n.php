<!-- build:js(.) /js/i18n.js -->
	<script src="/js/lib/gettext/gettext.js"></script>
	<script src="/js/bower/sprintf/src/sprintf.min.js"></script>
	<script src="/js/bower/momentjs/min/moment-with-langs.min.js"></script>
	<script src="/js/bower/moment-timezone/min/moment-timezone.min.js"></script>
	<script src="/js/lib/moment.timezones/moment.timezones.js"></script>
<!-- endbuild -->