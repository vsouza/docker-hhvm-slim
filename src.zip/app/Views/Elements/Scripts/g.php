<script>
  	var g = {
  		token: '<?=$_SESSION['user']['token']?>',
  		<?php if(isset($_SESSION['user']['adaccounts']) && count($_SESSION['user']['adaccounts'])): ?>adaccounts: <?=json_encode($_SESSION['user']['adaccounts'])?>, <?php endif; ?>
	};
	setLanguage('<?=$_SESSION['user']['lang']?>');
	TB.init({token:'<?=$_SESSION['user']['token']?>', locale: '<?=$_SESSION['user']['lang']?>'});
	var api = new FacebookAdsApi('<?=$_SESSION['user']['token']?>');

  	<?php if(isset($csrf_key)): ?>var GUARD = {csrf_key:'<?=$csrf_key?>', csrf_token:'<?=$csrf_token?>'};<?php endif; ?>
</script>
