<header>
	<a class="btn medium sprite-back" type="button" id="btnBack"  href="<?=$V->urlFor('dashboard')?>"><?=_('btnBack')?></a>
    <h2><?=_('hSettings')?></h2>
</header>
<?php if(!isset($active)) $active = '';?>
<div id="config-menu">
	<nav>
	    <ul id="config-nav">
	        <li><a href="<?php $V->urlFor('myaccount'); ?>" class="<?=$V->equals('myaccount', $active, 'active'); ?>"><?=_('navMyAccount')?></a></li>
	        <li><a href="<?php $V->urlFor('subscription'); ?>" class="<?=$V->equals('subscription', $active, 'active'); ?>"><?=_('subscription')?></a></li>
	        <!-- <li><a href="<?php $V->urlFor('payments'); ?>" class="<?=$V->equals('payments', $active, 'active'); ?>"><?=_('aPayments')?></a></li> -->
	        <li><a href="<?php $V->urlFor('notifications'); ?>" class="<?=$V->equals('notifications', $active, 'active'); ?>"><?=_('navNotifications')?></a></li>
	        <li><a href="<?php $V->urlFor('extensions'); ?>" class="<?=$V->equals('extensions', $active, 'active'); ?>"><?=_('navExtensions')?></a></li>
	        <li><a href="http://tamboreen.uservoice.com/" target="_blank"><?=_('navHelp')?></a></li>
			<li><a href="<?php $V->urlFor('revoke'); ?>" class="<?=$V->equals('revoke', $active, 'active'); ?>"><?=_('labRevokePermissions')?></a></li>
	    </ul>
	</nav>
</div>
