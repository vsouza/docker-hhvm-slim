<?php
/**
 * View Helper
 *
 */
namespace Helpers;

class ViewHelper
{
    public $app;
    protected $templatesPath;
    public $path; // View Directory Path
    public $templateDir; // View Path on Template Folder
    public $data; // View Data
    public $title; // View Title
    public $debugrenderer; // Debug Bar Renderer

    public function __construct($app)
    {
        $this->app = $app;
        $this->templatesPath = $app->config('templates.path');
        if($app->debugbar) $this->debugrenderer = $app->debugbar->getJavascriptRenderer();
    }

    /**
     * Sets View Data for Layout rendering
     * @param string $path Path to template's directory
     * @param array $data View Data
     */
    public function setViewData($path, $data)
    {
        $this->path = $path;
        $pathArray = (explode('/', $path));
        $this->name = $pathArray[1];
        $this->templateDir = $this->path.'/'.$pathArray[1];
        $this->data = $data;
    }

    /**
     * Layout "content" helper
     */
    public function content()
    {
        $file = $this->templateDir.'_content.php';
        $filepath = $this->templatesPath.'/'.$file;
        if(file_exists($filepath)) $this->app->render($file, $this->data);
    }

    /**
     * Layout "head" helper
     */
    public function head()
    {
        // Analytics
        $this->element('Scripts/ga',[
            'isProduction' => ($this->app->getMode()=='production'),
            'customGA' => isset($this->app->customGA)
        ]);

        // Retargeting
        $this->element('Pixels/retargeting');

        // MixPanel
        $this->element('Scripts/mixpanel',[
            'isProduction' => ($this->app->getMode()=='production'),
        ]);

        $V = $this;
        $file = $this->templateDir.'_head.php';
        $filepath = $this->templatesPath.'/'.$file;
        if(file_exists($filepath)) $this->app->render($file, $this->data);
    }

    /**
     * Layout "footer" helper
     */
    public function footer()
    {
        $V = $this;
        $file = $this->templateDir.'_footer.php';
        $filepath = $this->templatesPath.'/'.$file;
        if(file_exists($filepath)) $this->app->render($file, $this->data);
    }

    /**
     * Layout "tail" helper
     */
    public function tail()
    {
        $V = $this;
        $file = $this->templateDir.'_tail.php';
        $filepath = $this->templatesPath.'/'.$file;
        if(file_exists($filepath)) $this->app->render($file, $this->data);
        if($this->debugrenderer) $this->debugRender();
    }

    /**
     * Layout "element" helper
     */
    public function element($path, $data = [])
    {
        extract($data);
        $V = $this;
        require($this->templatesPath.'/Elements/'.$path.'.php');
    }

    /**
     * Document Title Helper
     * @param  string $suffix    Suffix
     * @param  string $separator Separator
     */
    public function title($suffix = null, $separator = " | ")
    {
        $title = $this->title;
        if($suffix) $title .= $separator . $suffix;
        echo $title;
    }

    /**
     * Returns CSS class if $a == $b
     * @param  string $a     First operand
     * @param  string $b     Second operand
     * @param  string $class CSS class
     * @return mixed         CSS class or NULL
     */
    public function equals($a, $b, $class)
    {
        if($a==$b) return $class;
    }

    /**
     * Debugbar Head
     */
    public function debugHead()
    {
        if($this->debugrenderer) echo $this->debugrenderer->renderHead();
    }

    /**
     * URL for named route helper
     * @return Clousure
     */
    public function urlFor($path, $params = array())
    {
        echo $this->app->urlFor($path,$params);
    }

    /**
     * Prints JS Locales for different Languages
     * @param  string $locale Language String
     */
    public function jsLocale($locale)
    {
        echo "<script src=\"/js/locale/{$_SESSION['user']['lang']}/{$locale}.js\"></script>";
        echo "<script>var gt = new Gettext({ domain : '{$_SESSION['user']['lang']}', locale_data : {$locale}Locale});</script>";
    }

    /**
     * Debugbar Renderer
     */
    public function debugRender()
    {
        $this->debugrenderer->setIncludeVendors(false); // No Jquery/Font Awesome
        echo "\n<!-- START DEBUGBAR  -->\n";
        echo $this->debugrenderer->renderHead();
        echo $this->debugrenderer->render();
        echo "<!-- END DEBUGBAR  -->\n";
    }
}
