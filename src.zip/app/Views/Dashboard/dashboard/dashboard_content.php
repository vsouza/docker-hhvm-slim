<div id="wrapper" class="dashboard">
    <!-- CAMPAIGNS -->
    <div id="campaigns">
        <div class="campaignheader">
            <span class="statusfilter btn-group">
                <select id="statusfilter" class="selectpicker">
                    <option value="ACTIVE,PAUSED,CAMPAIGN_GROUP_PAUSED,ARCHIVED"><?=_('optAll')?></option>
                    <option value="ACTIVE"><?=_('optActive')?></option>
                    <option value="PAUSED,CAMPAIGN_GROUP_PAUSED"><?=_('optPaused')?></option>
                    <option value="ARCHIVED"><?=_('optArchived')?></option>
                    <option value="DELETED"><?=_('optDeleted')?></option>
                    <?php if(false): ?>
                        <option value="FINALIZED"><?=_('optFinished')?></option>
                        <option value="SCHEDULED"><?=_('optScheduled')?></option>
                        <option value="PENDING"><?=_('optPending')?></option>
                    <?php endif; ?>
                </select>
            </span>
            <span id="searchfield" class="input-append">
                <?php if(false): ?>
                    <input id="searchinput" type="search" placeholder="<?=_('plcFindCampaign')?>">
                    <button class="btn uneditable-input sprite-search" type="button" id="gosearch"></button>
                <?php endif; ?>
            </span>
            <span id="visualizations">
                <a href="#" class="tiles on" ref="tiles"><b class="sprite-vis_tiles"></b></a>
                <a href="#" class="list"  ref="list"><b class="sprite-vis_list"></b></a>
            </span>
        </div>

        <div class="separator"></div>

        <script id="tpl_tplcampaigns" type="text/x-handlebars-template">
        {{#each this}}
        <li class="campaign" id="{{id}}">
            <div class="headerbg"></div>
            <div class="content">
                <div class="statuswrapper">
                    {{{campaignStatus campaign_status}}}
                </div>
                {{{campaignType objective}}}
                <div class="data">
                    <h2 class="campaigntitle">{{name}}</h2>
                    <div class="stats results">
                        <h4><?=_('fbActions')?> </h4>
                        <span>{{int actions}}</span>
                    </div>
                    <span class="stats spent">
                        <h4><?=_('fbSpent')?> </h4>
                        <span>{{accountmoney spent}}</span>
                    </span>
                </div>
            </div>
            <div class="actions">
                {{{campaignActions campaign_status}}}
                {{{adUrl this}}}
            </div>
        </li>
        {{/each}}
        </script>
        <ul id="tplcampaigns" class="campaignslist"></ul>
        <div id="empty">
            <p><?=_('msgNoCampaings')?></p>
        </div>

        <div id="loader">
            <span id="spinner"></span>
            <p id="fetching"><?=_('mgsSearching')?></p>
            <div id="broken">
                <p><?=_('msgCampaignLoadError')?></p>
                <p><a href="#" id="retrybutton"><?=_('aTryAgain')?></a></p>
            </div>
        </div>

        <div id="loadmore">
            <span class="separator">
                <a id="loadmorebutton">
                    <b class="sprite-loadmorearrow"></b>
                    <b class="sprite-loadmorearrow"></b>
                    <?=_('aLoadMoreCampigns')?>
                </a>
            </span>
        </div>
    </div>

    <!-- MENU -->
    <aside id="dashboard-menu">
        <h1><?=_('hDashboard');?></h1>

        <span class="btn-group accountselect">
            <select id="accountid" class="selectpicker">
            </select>
        </span>

        <span class="btn-group periodwrap">
            <select id="period" class="selectpicker">
                <option value="1"><?=_('optTodays')?></option>
                <option value="2"><?=_('optYesterday')?></option>
                <option value="3"><?=_('opt7Days')?></option>
                <option value="4"><?=_('opt28Days')?></option>
                <option value="0"><?=_('optEver')?></option>
            </select>
        </span>

        <div>
            <script id="tpl_stats" type="text/x-handlebars-template">
                {{#if impressions}}
                    <?=_('hYourCampaignReach') ?>
                    <div class="figures int" id="uniqueimpressions">
                        {{int impressions}} <?=_('labViews') ?>
                    </div>
                {{else}}
                    <?=_('hNoImpressions') ?>
                {{/if}}
                <div class="spent">
                    {{#if spent}}
                        <?=_('hYouHaveSpent') ?>
                        <div class="figures" id="spent">{{accountmoney spent}}</div>
                    {{else}}
                        <?=_('hNoSpendings') ?>
                    {{/if}}
                </div>
            </script>
            <div class="stats" id="stats">
            </div>
            <div class="separator"></div>
            <a href="<?php $V->urlFor('goals')?>" class="btn fullgreen newcampaign">
                <?=_('btnCreateCampaign')?>
                <b class="sprite-plus"></b>
            </a>
        </div>
    </aside>
</div>

<?php $V->element('Modals/welcome'); ?>

<!-- Modal -->
<div id="modalPayGate" class="modal hide fade" tabindex="-1" role="dialog" style="width: 700px;">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    </div>
    <div class="modal-body">
        <h4 class="orange"><?=_('paygateH4')?></h4>
        <div class="canceled hide">
            <p><?=_('paygateCanceledP1')?></p>
            <p><?=_('paygateCanceledP2')?></p>
        </div>
        <div class="trialended hide">
            <p><?=_('paygateExpiredP1')?></b></p>
            <p><?=_('paygateExpiredP2')?></p>
        </div>
        <img src="/assets/img/paygate.jpg">
        <div class="description">
            <span><?=_('paygateSpan1')?></span>
            <span class="fr"><?=_('paygateSpan2')?></span>
        </div>
    </div>
    <div class="modal-footer center">
      <a href="<?php $V->urlFor('subscription')?>" class="btn fullgreen"><?=_('paygateCTA')?><img src="/assets/img/wizardWhiteArrow.png"></a>
    </div>
</div>

<!-- Modal -->
<div id="modalYouHaveAds" class="modal hide fade" tabindex="-1" role="dialog" style="width: 700px;  margin-left: -350px;">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    </div>
    <div class="modal-body">
        <h4><?=_('modalYouHaveAdsTitle')?></h4>
        <p><?=_('modalYouHaveAdsDescription')?></p>
        <img src="/assets/img/modal_youhaveads.jpg">
        <div class="description">
            <span><?=_('modalYouHaveAdsCaption1')?></span>
            <span class="fr"><?=_('modalYouHaveAdsCAption2')?></span>
        </div>
    </div>
    <div class="modal-footer center">
      <button data-dismiss="modal" class="btn fullgreen"><?=_('modalYouHaveAdsCTA')?><img src="/assets/img/wizardWhiteArrow.png"></button>
    </div>
</div>
