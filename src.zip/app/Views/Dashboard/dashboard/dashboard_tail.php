<?php $V->jsLocale('dashboard'); ?>
<!-- build:js(.) /js/dashboard.js -->
<script src="/js/app/dashboard.js"></script>
<!-- endbuild -->

<script>
    $(document).ready(function() {
        <?php if(isset($_GET['registration'])): ?>
        $('#modalWelcome').modal('show');

        $('#modalWelcome').on('hidden', function () {
          $('#modalYouHaveAds').modal('show');
        });
        <?php endif; ?>

        <?php if(isset($subscriptionExpired)||isset($trialExpired)): ?>

            <?php if(isset($trialExpired)): ?>
            $('#modalPayGate .trialended').show();
            mixpanel.track("Payment Gate",{'Type':'Trial Ended'});
            <?php else: ?>
            $('#modalPayGate .canceled').show();
            mixpanel.track("Payment Gate",{'Type':'Canceled'});
            <?php endif; ?>

            $('#modalPayGate').modal('show');
        <?php endif; ?>

    });
</script>
