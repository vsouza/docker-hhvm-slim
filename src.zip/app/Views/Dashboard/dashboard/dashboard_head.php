<?php $V->element('Pixels/registration'); ?>
<style>
    .accountselect .filter-option:before {content: "<?=_('beforeAccount')?>: ";} .periodwrap .filter-option:before {content: "<?=_('beforePeriod')?>: ";} .statusfilter .filter-option:before {content: "<?=_('beforeShowing')?>: ";}
</style>