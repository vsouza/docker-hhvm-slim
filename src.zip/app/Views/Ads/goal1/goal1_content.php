<div id="mainQuestion"><?=_('hMainQuestion')?></div><!-- absolute -->
<div id="wrapper" class="goal1">
    <div id="goalContent">
        <div class="fullCarousel">
            <ul>
                <li>
                    <div id="stp01" class="selectFanPage">
                        <?php $V->element('selectFanPage'); ?>
                    </div>
                </li>
                <li>
                    <div id="stp02">
                        <div>
                            <div class="mainBox">
                               <div>
                                   <span class="pag-thumb"></span>
                               </div>
                               <div>
                                <article>
                                    <h2 class="pag-name"></h2>
                                    <p class="pag-info"></p>
                                    <footer>
                                        <i class="tb-icon-13x-sponsor"></i>
                                        <font class="fbInfoGray12"><?=_('sponsored')?></font>
                                    </footer>
                                </article>
                               </div>
                            </div>
                            <span class="mainBoxMedal"></span>
                            <span class="mainBoxCurvedArrow"></span>
                        </div>
                        <div>
                            <h3 class="height65"><?=_('contentVariations4betterResult')?></h3>
                            <div id="carouselPost" class="carousel slide carouselPostVariation">
                                <ol class="carousel-indicators">
                                    <li data-target="#carouselPost" data-slide-to="0" class="active"></li>
                                    <li data-target="#carouselPost" data-slide-to="1"></li>
                                    <li data-target="#carouselPost" data-slide-to="2"></li>
                                </ol>
                                <div class="carousel-inner">
                                    <div class="active item">
                                        <div class="model">
                                            <div><span></span></div>
                                            <div>
                                                <div class="modelHead">
                                                    <h4><strong><?=$_SESSION['user']['firstName']?></strong> <?=_('likes')?> <strong class="pag-name"></strong></h4>
                                                </div>
                                                <div class="modelBody">
                                                    <div><span class="pag-thumb"></span></div>
                                                    <article>
                                                        <h5 class="pag-name"></h5>
                                                        <p class="pag-info"></p>
                                                        <footer>
                                                            <i class="tb-icon-13x-sponsor"></i>
                                                            <font class="fbInfoGray12"><?=_('sponsored')?></font>
                                                        </footer>
                                                    </article>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="model">
                                            <div><span></span></div>
                                            <div>
                                                <div class="modelHead">
                                                    <h4><strong><?=$_SESSION['user']['firstName']?></strong> <?=_('shared')?> <strong class="pag-name"></strong></h4>
                                                </div>
                                                <div class="modelBody">
                                                    <div><span class="pag-thumb"></span></div>
                                                    <article>
                                                        <h5 class="pag-name"></h5>
                                                        <p class="pag-info"></p>
                                                        <footer>
                                                            <i class="tb-icon-13x-sponsor"></i>
                                                            <font class="fbInfoGray12"><?=_('sponsored')?></font>
                                                        </footer>
                                                    </article>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="model">
                                            <div><span></span></div>
                                            <div>
                                                <div class="modelHead">
                                                    <h4><strong><?=$_SESSION['user']['firstName']?></strong> <?=_('commented')?> <strong class="pag-name"></strong></h4>
                                                </div>
                                                <div class="modelBody">
                                                    <div><span class="pag-thumb"></span></div>
                                                    <article>
                                                        <h5 class="pag-name"></h5>
                                                        <p class="pag-info"></p>
                                                        <footer>
                                                            <i class="tb-icon-13x-sponsor"></i>
                                                            <font class="fbInfoGray12"><?=_('sponsored')?></font>
                                                        </footer>
                                                    </article>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="carousel-control left">
                                    <a href="#carouselPost" data-slide="prev"></a>
                                </div>
                                <div class="carousel-control right">
                                    <a href="#carouselPost" data-slide="next"></a>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="block aCenter m50_0">
                            <select id="contentDecision" name="contentDecision" class="select-yellow-xl">
                                <option data-icon="sIco" value="0" selected="selected"><?=_('keepThisAd')?></option>
                                <option data-icon="sIco" value="1"><?=_('chooseAnotherCreative')?></option>
                                <option data-icon="sIco" value="2"><?=_('createNewCreative')?></option>
                                <option data-icon="sIco" value="3"><?=_('createCreativeAs')?></option>
                            </select>
                        </div>
                    </div>
                </li>
                <li>
                    <div id="stp03">
                        <?php $V->element('segmentation'); ?>
                    </div>
                </li>
                <li>
                    <div id="stp04" class="p0_0_10_0">
                        <?php $V->element('setBilling'); ?>
                    </div>
                </li>
                <li>
                    <div id="stp05">
                        <?php $V->element('campaignName'); ?>
                    </div>                                
                </li>
                <li>
                    <div id="stp06" class="stpPublish">
                        <div>
                            <div>
                                <h2><?=_('labAdChosen')?></h2>
                                <div class="yellow3center"></div>
                                <div class="hr25"></div>
                                <div class="fbCreative">
                                    <div><span class="pag-thumb"></span></div>
                                    <article>
                                        <h5 class="pag-name"></h5>
                                        <p><span class="text"></span></p>
                                        <footer>
                                            <i class="tb-icon-13x-sponsor"></i>
                                            <font class="fbInfoGray12"><?=_('sponsored')?></font>
                                        </footer>
                                    </article>
                                </div>
                                <span class="pageLikeAdMedal"></span>
                                <div class="fbCreativeSh"></div>

                                <div class="hr10"></div>
                                <h3><?=_('adToImproveYourCampaign')?></h3>
                                <div class="hr20"></div>
                                <ul class="miniPost">
                                    <li>
                                        <div class="model">
                                            <div><span></span></div>
                                            <div>
                                                <div class="modelHead">
                                                    <h4>
                                                        <strong><?=$_SESSION['user']['firstName']?></strong> <?=_('likes')?> <strong class="pag-name"></strong>
                                                    </h4>
                                                </div>
                                                <div class="modelBody">
                                                    <div><span class="pag-thumb"></span></div>
                                                    <article>
                                                        <h5 class="pag-name"></h5>
                                                        <p class="pag-info"></p>
                                                        <footer>
                                                            <i class="tb-icon-13x-sponsor"></i>
                                                            <font class="fbInfoGray12"><?=_('sponsored')?></font>
                                                        </footer>
                                                    </article>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="model">
                                            <div><span></span></div>
                                            <div>
                                                <div class="modelHead">
                                                    <h4><strong><?=$_SESSION['user']['firstName']?></strong> <?=_('shared')?> <strong class="pag-name"></strong></h4>
                                                </div>
                                                <div class="modelBody">
                                                    <div><span class="pag-thumb"></span></div>
                                                    <article>
                                                        <h5 class="pag-name"></h5>
                                                        <p class="pag-info"></p>
                                                        <footer>
                                                            <i class="tb-icon-13x-sponsor"></i>
                                                            <font class="fbInfoGray12"><?=_('sponsored')?></font>
                                                        </footer>
                                                    </article>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="model">
                                            <div><span></span></div>
                                            <div>
                                                <div class="modelHead">
                                                    <h4>
                                                        <strong><?=$_SESSION['user']['firstName']?></strong> <?=_('commented')?> <strong class="pag-name"></strong>
                                                    </h4>
                                                </div>
                                                <div class="modelBody">
                                                    <div><span class="pag-thumb"></span></div>
                                                    <article>
                                                        <h5 class="pag-name"></h5>
                                                        <p class="pag-info"></p>
                                                        <footer>
                                                            <i class="tb-icon-13x-sponsor"></i>
                                                            <font class="fbInfoGray12"><?=_('sponsored')?></font>
                                                        </footer>
                                                    </article>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                                <div class="hr25"></div>
                                <div class="hr25"></div>
                            </div>
                            <div>
                                <div>
                                    <h2><?=_('labPublic')?></h2>
                                    <div class="yellow3center"></div>
                                    <div class="hr20"></div>
                                    <div class="block">
                                        <div class="lef perCent50">
                                            <span class="label"><?=_('genderColon')?></span>
                                            <span class="info" id="reviewGenderStr"></span>
                                        </div>
                                        <div class="lef perCent50">
                                            <span class="label"><?=_('ageColon')?></span>
                                            <span class="info" id="reviewAgeStr"></span>
                                        </div>
                                    </div>
                                    <div class="block">
                                        <span class="label block"><?=_('locatedColon')?></span>
                                        <span class="info" id="reviewLocatedStr"></span>
                                    </div>
                                    <div class="block">
                                        <span class="label block"><?=_('interestedColon')?></span>
                                        <span class="info" id="reviewInterestedStr"></span>
                                    </div>
                                </div>
                                <div>
                                    <h2><?=_('labCampaign')?></h2>
                                    <div class="yellow3center"></div>
                                    <div class="hr20"></div>
                                    <div class="block">
                                        <span class="label"><?=_('nameColon')?></span>
                                        <span class="info" id="reviewCampaignName"></span>
                                    </div>
                                    <div class="block">
                                        <div class="lef perCent50">
                                            <span class="label"><?=_('startColon')?></span>
                                            <span class="info" id="reviewBeginDate"></span>
                                        </div>
                                        <div class="lef perCent50">
                                            <span class="label"><?=_('endColon')?></span>
                                            <span class="info" id="reviewEndDate"></span>
                                        </div>
                                    </div>  
                                    <div class="block">
                                        <span class="label"><?=_('investmentColon')?></span>
                                        <span class="info" id="reviewInvestment"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
        <div class="clearfix"></div> 
    </div>
</div>
<div id="footerPush"></div>