<?php $V->jsLocale('goal'); ?>
<script>
	g.accountId = "<?=$accountId?>";
	g.appId = "<?=$appid?>";
</script>

<?php $V->element('Scripts/goals'); ?>

<!-- build:js(.) /js/goal1.js -->
<script src="/js/app/goals/goal1.js"></script>
<!-- endbuild -->

<div id="fb-root"></div>
<script>(function(d, s, id){
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/<?=$_SESSION['user']['lang']?>/all.js";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

