<!-- build:js(.) /js/goalSelection.js -->
<script src="/js/app/goals/goalSelection.js"></script>
<!-- endbuild -->

<script>
    $(document).ready(function() {
        <?php if(isset($_GET['registration'])): ?>
        setUpNewUser();
        <?php else: ?>
        checkAdAccounts('<?=isset($_GET['refresh']) ? $_GET['refresh'] : '';?>');
        <?php endif; ?>
    });
</script>
