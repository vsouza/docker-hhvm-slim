<?php $V->element('Pixels/registration'); ?>
<!-- build:css(.) /assets/css/goals.css -->
<link rel="stylesheet" type="text/css" href="/assets/css/goals.css">
<!-- endbuild -->