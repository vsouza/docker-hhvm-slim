<div id="mainQuestion"><!-- absolute -->
    <?=_('hMainQuestion')?>
</div>
<div id="wrapper">
    <ul id="goalSelection">
        <li>
            <div class="choice"><a href="#" goal="1"></a></div>
            <div class="choiceDesc"><?=_('hReceiveCommentsAndLikes')?></div>
        </li>
        <li>
            <div class="choice"><a href="#" goal="2"></a></div>
            <div class="choiceDesc"><?=_('hGainMoreFans')?></div>
            <a href="<?php $V->urlFor('dashboard'); ?>" id="fPrev" class="back" ><?=_('aBackGoalSelection')?></a>
        </li>
        <li>
            <div class="choice"><a href="#" goal="3"></a></div>
            <div class="choiceDesc"><?=_('hBringPeopleRegistrationsAndSalesForMySite')?></div>
        </li>
    </ul>
</div>
