<?php $V->element('Modals/chooseAccount'); ?>
<?php $V->element('Modals/welcome'); ?>

<!-- Modal -->
<div id="modalAccounts1" class="modal accounts hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header">
    </div>
    <div class="modal-body <?=$lang?>">
        <div class="steps"><?=_('Passo 1 de 2')?></div>
        <h4><?=_('modalAccounts1Title')?></h4>
        <h5 class="white-tooltip"><?=_('modalAccounts1Sub')?> <a href="#" class="tip" data-toggle="tooltip" data-placement="bottom" data-original-title="<?=_('modalAccounts1Tooltip')?>"><img src="/assets/img/question.gif" ></a></h4>
        <p><?=_('modalAccounts1Description')?></p>
        <div class="caption"><?=_('modalAccounts1Caption')?></div>
        <img src="/assets/img/locale/pt_BR/create_account.jpg" class="has-caption lang pt_BR">
        <img src="/assets/img/locale/en_US/create_account.jpg" class="has-caption lang en_US">
        <p><?=_('modalAccounts1Description2')?></p>
        <div class="warning hide"><?=_('modalAccounts1Warning')?></div>
    </div>
    <div class="modal-footer center">
        <a href="https://www.facebook.com/advertising/" target="_blank" class="btn fullgreen" id="btnAdAccountAccessFacebook"><?=_('btnAccessFacebook')?> <img src="/assets/img/wizardWhiteArrow.png"></a>

        <a id="btnAdAccountContinue" href="<?=$V->urlFor('goals')?>?refresh=adaccount" class="btn fullgreen hide"><?=_('modalAccounts1Continue')?><img src="/assets/img/wizardWhiteArrow.png"></a>
    </div>
</div>

<!-- Modal -->
<div id="modalAccounts2" class="modal accounts hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header">
    </div>
    <div class="modal-body <?=$lang?>">
        <div class="steps hide"><?=_('Passo 2 de 2')?></div>
        <h4><?=_('modalAccounts2Title')?></h4>
        <h5 class="white-tooltip"><?=_('modalAccounts2Sub')?> <a href="#" class="tip" data-toggle="tooltip" data-placement="bottom" data-original-title="<?=_('modalAccounts2Tooltip')?>"><img src="/assets/img/question.gif" ></a></h4>
        <p><?=_('modalAccounts2Description')?></p>
        <div class="caption"><?=_('modalAccounts2Caption')?></div>
        <img src="/assets/img/locale/pt_BR/add_payment.jpg" class="lang pt_BR">
        <img src="/assets/img/locale/en_US/add_payment.jpg" class="lang en_US">
        <p><?=_('modalAccounts2Description2')?></p>
        <div class="warning hide"><?=_('modalAccounts2Warning')?></div>
    </div>
    <div class="modal-footer center">
        <a href="" target="_blank" id="btnPaymentAccessFacebook" class="btn fullgreen"><?=_('btnAccessFacebook')?><img src="/assets/img/wizardWhiteArrow.png"></a>

        <a id="btnPaymentContinue" href="<?=$V->urlFor('goals')?>?refresh=payment" class="btn fullgreen hide"><?=_('modalAccounts1Continue')?><img src="/assets/img/wizardWhiteArrow.png"></a>
    </div>
</div>
