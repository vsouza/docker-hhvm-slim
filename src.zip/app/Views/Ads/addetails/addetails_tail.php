<script>
	if (window['g'] == undefined) var g = {}; // criando o objeto global g caso não haja
	window.g.accountId = "<?=$campaign['accountId']?>";
	window.g.campaignId = "<?=$campaign['campaignId']?>";
	window.g.campaignType = "<?=$campaign['objective']?>";
    ga('send', 'pageview', '/ad');
</script>

<?php $V->jsLocale('addetails'); ?>

<!-- build:js(.) /js/addetails.js -->
<script src="/js/app/addetails.js"></script>
<!-- endbuild -->
