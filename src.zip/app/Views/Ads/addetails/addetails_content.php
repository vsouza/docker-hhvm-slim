<div id="wrapper" class="addetailsbox">
	<div id="addetailsbox" class="clearfix">
	  	<header>
			<script id="tpl_header" type="text/x-handlebars-template">
				<div id="status">
					{{{campaignStatus this.campaign_status}}}
		  		</div>
				<div id="actions">
					{{{campaignActions this.campaign_status}}}
					<button id="btnExclude" data-interaction="campaign" class="btn medium red exclude"><?=_('btnExcludeA')?></button>				
				</div>			
		  	</script>
		  	<div id="header"></div>

			<a class="btn medium sprite-back" type="button" id="btnBack"  href="<?=$V->urlFor('dashboard')?>"><?=_('btnBack')?></a>
		</header>
		<div id="content">
			<header class="sprite-status<?=$campaign['objective']?>">
				<h2 id="type"><?=_('hCampaignType'.$campaign['objective']);?></h2>
				<div id="title">
					<button data-interaction="campaign" id="btnEditCampaignName" class="btn tiny pencil sprite-btn_edit"></button>
					<input id="campaignName" type="text" value="" readonly>
				</div>
			</header>
			<div id="campaigndata" class="clearfix">
				<span>
					<h3><?=_('hBudget');?></h3>
					<button data-interaction="campaign" id="btnBudget" class="btn tiny pencil sprite-btn_edit" for="budget"></button>
					<font class="currencySymbol"></font>
					<input id="budget" class="money" type="text" readonly>
	  			</span>
				<span>
					<h3><?=_('hInvestment');?></h3>
					<input id="investment" type="text" readonly>
				</span>
	  			<span>
	  				<h3><?=_('hStartDate');?></h3>
	  				<div id="startDatePicker" class="input-append date">
		                <button data-interaction="campaign" class="add-on btn tiny pencil sprite-btn_edit"></button>
					    <input id="startdate" type="text" readonly></input>
					</div>
	                <button data-interaction="campaign" data-objective="openStartDate" class="add-on btn tiny pencil sprite-btn_edit save" style="margin-top:-11px; visibility:hidden"></button>    
	  			</span>
	  			<span>
	  				<h3><?=_('hEndDate');?></h3>
	  				<div id="endDatePicker" class="input-append date">
		                <button data-interaction="campaign" class="add-on btn tiny pencil sprite-btn_edit"></button>
					    <input id="enddate" type="text" readonly></input>				    
					</div>
	                <button data-interaction="campaign" data-objective="openEndDate" class="add-on btn tiny pencil sprite-btn_edit save" style="margin-top:-11px; visibility:hidden"></button>    
	  			</span>
	  		</div>
			<script id="tpl_results" type="text/x-handlebars-template">
				<div id="resultdata">
					<div id="views" class="resultrow">
						<span id="reach">
						{{#hIf this.unique_impressions '==' 0}}
							<?=_('msgUnseenAds')?>
						{{else}}
							<?=_('hYourAdViews')?> <b>{{{_n 'numPeople' this.unique_impressions}}}</b>
						{{/hIf}}
						</span>
					</div>
					{{#each this.rows}}
						<div class="resultrow">
							<span id="conversion">
								{{label}} <b>{{int value}}</b>
							</span>
							<span id="cost">
								{{unique_label}} <b>{{accountmoney unique_cost true}}</b>
							</span>
						</div>
					{{/each}}
				</div>
			</script>
			<div id="results"></div>
			<div id="ads"></div>
			<script id="tpl_ads" type="text/x-handlebars-template">
				{{#if ads}}
					<!--<h2 class="variations"><?=_('labAdVariation')?></h2>-->
					<table width="100%" border="0" cellpadding="0" cellspacing="0" id="campaignvariations">
						<thead>
							<tr>
							    <th colspan="2"><?=_('thAds')?></th>
							    <th><?=_('thInvestment')?></th>
							    <th><?=_('thGoal')?></th>
							    <th><?=_('thUnitCost')?></th>
							    <th><?=_('thStatus')?></th>
							    <th>&nbsp;</th>
							    <th>&nbsp;</th>
							</tr>
						</thead>
						<tbody>
							{{#each ads}}
								<tr data-ref="{{id}}">
									<td><span class="sprite-campaign_preview preview"></span></td>
									<td><span class="name">{{name}}</span class="name"></td>
									<td><b>{{accountmoney spent true}}</b></td>
									<td><?=_('convType'.$campaign['objective']);?> <b>{{int goal}}</b></td>
									<td><b>{{accountmoney cost true}}</b></td>
									<td class="statuscell" id="{{id}}">{{{adStatus adgroup_status}}}</td>
									<td>
										<button data-interaction="ad" data-ad-action="edit" style="visibility: hidden;" class="btn tiny"><?=_('btnEdit')?></button>
									</td>
									<td>
										<button data-interaction="ad" data-ad-action="delete" class="btn tiny red exclude"><?=_('btnExclude')?></button>
									</td>
								</tr>
							{{/each}}
						</tbody>
					</table>
				{{/if}}
			</script>
  		</div>
	</div>
</div>

<!-- formulário que enviará os arquivos de media para o backend -->
<form id="postForm" name="postForm" action="#" target="ifrmPostForm" method="POST" enctype="multipart/form-data">
    <input type="hidden" id="token" name="token">
    <input type="hidden" id="accountId" name="accountId">
    <input type="hidden" id="callback" name="callback">
    <input type="hidden" id="pageId" name="pageId">
    <input type="file" id="file" name="file">
	<iframe src="javascript:void(0);" id="ifrmPostForm" name="ifrmPostForm" width="0" height="0" frameborder="0"></iframe>
</form>

<div class="addetails">
	<?php $V->element('Modals/chooseCreative'); ?>
	<?php $V->element('Modals/changeCreative'); ?>
	<?php $V->element('Modals/changeCreativeDomain'); ?>
</div>