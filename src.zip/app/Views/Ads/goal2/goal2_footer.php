<div class="clearfix"></div>
<div id="footer" class="goal2">
    <a type="button" class="btn-goal-normal cancel" href="<?php $V->urlFor('goals')?>"><?=_('btnCancel')?></a>
    <div id="fWrapper">
        <div class="row-fluid" style="height: 80px;line-height: 80px;">
            <div class="span6 aRig">
                <button type="button" id="fPrev" class="btn-goal-disabled"><?=_('btnReturn')?></button>
            </div>
            <div class="span6 aLef">
                <button type="button" id="fNext" class="btn-goal-disabled"><?=_('btnContinue')?></button>
            </div>
        </div>
        <div class="row-fluid" style="height: 61px; width: 664px;margin: 0 auto;">
            <div class="stepper7">
                <div class="stepperFIll" style="width:0%;"></div>
            </div>
            <div class="stepper7-indicators">
                <ul>
                    <li class="done"><a href="#1" id="nav-0">1</a></li>
                    <li><a href="#2" id="nav-1">2</a></li>
                    <li><a href="#3" id="nav-2">3</a></li>
                    <li><a href="#4" id="nav-3">4</a></li>
                    <li><a href="#5" id="nav-4">5</a></li>
                    <li><a href="#6" id="nav-5">6</a></li>
                    <li><a href="#7" id="nav-6">7</a></li>
                </ul>
            </div>
        </div>
        <div class="stepper7-indicators-labels">
            <div class="done"><?=_('labStepper01')?></div>
            <div><?=_('labStepper02')?></div>
            <div><?=_('labStepper032')?></div>
            <div><?=_('labStepper03')?></div>
            <div><?=_('labStepper04')?></div>
            <div><?=_('labStepper05')?></div>
            <div><?=_('labStepper06')?></div>
        </div>
    </div>
</div>

<!-- formulário que enviará os arquivos de media para o backend -->
<form id="postForm" name="postForm" action="#" target="ifrmPostForm" method="POST" enctype="multipart/form-data">
    <input type="hidden" id="accountId" name="accountId">
    <input type="hidden" id="token" name="token">
    <input type="hidden" id="callback" name="callback">
    <input type="hidden" id="type" name="type">
    <input type="file" id="file" name="file">
    <iframe src="javascript:void(0);" id="ifrmPostForm" name="ifrmPostForm" width="0" height="0" frameborder="0"></iframe>
</form>

<?php $V->element('Modals/createFanPage'); ?>
<?php $V->element('Modals/manageAge'); ?>
<?php $V->element('Modals/manageGenre'); ?>
<?php $V->element('Modals/managePlace'); ?>
<?php $V->element('Modals/manageInterest'); ?>
<?php $V->element('Modals/publish'); 