<?php $V->jsLocale('goal'); ?>
<script>
	g.accountId = "<?=$accountId?>";
</script>

<?php $V->element('Scripts/goals'); ?>
<!-- build:js(.) /js/goal2.js -->
<script src="/js/app/goals/goal2.js"></script>
<!-- endbuild -->