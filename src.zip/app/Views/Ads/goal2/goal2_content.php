<div id="mainQuestion"><?=_('hMainQuestion')?></div><!-- absolute -->
<div id="wrapper" class="goal2">
    <div id="goalContent">
        <div class="fullCarousel">
            <ul>
                <li>
                    <div id="stp01" class="selectFanPage">
                        <?php $V->element('selectFanPage'); ?>
                    </div>                    
                </li>
                <li>
                    <div id="stp02">
                        <div class="row-fluid">
                            <div class="span7">
                                <input type="text" id="titAd" name="titAd" placeholder="<?=_('titOfYourAd')?>" maxlength="25">
                                <textarea id="txtText" name="txtText" placeholder="<?=_('textOfYourAd')?>" maxlength="90"></textarea>
                                <div class="hr25"></div>
                                <input type="file" 
                                    id="addMedia"
                                    data-buttonText="<?=_('btnAddImage')?>" 
                                    data-titleButton="<?=_('percentOfText')?>" 
                                    data-input="false" 
                                    data-icon="false" 
                                    data-classButton="btn-modal-white" 
                                    data-idButton="addMediaBtn"
                                    data-targeting="form#postForm :file">
                                <span class="curvedArrow2"></span>
                                <span class="curvedArrow3"></span>
                                <span class="curvedArrow4"></span>
                            </div>
                            <div class="span5 m0">
                                <div class="pageLikeAd">
                                    <div class="">
                                        <h5 class="fanPageTitle pag-name"></h5>
                                        <h6 class="pageLikeAdTitle"></h6>
                                    </div>
                                    <div class="pageLikeAdMedia pag-thumb"></div>
                                    <div class="pageLikeAdMessage"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div id="stp03">
                        <div>
                            <div class="pageLikeAdWhiteLarge">
                                <div class="">
                                    <h5 class="fanPageTitle pag-name"></h5>
                                    <h6 class="pageLikeAdTitle"></h6>
                                </div>
                                <div class="pageLikeAdMedia pag-thumb">s</div>
                                <div class="pageLikeAdMessage"></div>
                            </div>
                            <span class="pageLikeAdWhiteLargeMedal"></span>
                            <span class="pageLikeAdWhiteLargeCurvedArrow"></span>
                        </div>
                        <div>
                            <h3 class="height65"><?=_('contentVariations4betterResult')?></h3>
                            <div class="pageLikeAdModel">
                                <div><span></span></div>
                                <div>
                                    <div>
                                        <h6><strong><?=$_SESSION['user']['firstName']?></strong> <?=_('likes')?> <strong class="pag-name"></strong></h6>
                                    </div>
                                    <div>
                                        <div class="pag-thumb"></div>
                                    </div>
                                    <div>
                                        <h5 class="fanPageTitle pag-name"></h5>
                                        <!-- <h6 class="pageLikeAdTitle"></h6> -->
                                        <span class="fbInfoGray12"><i class="tb-icon-15x-like p2_0_0_0"></i> <?=_('like')?></span>
                                    </div>
                                </div>
                            </div>                           
                            <div class="cb"></div>
                            <div class="pageLikeAdModelSh"></div>
                            <div class="modelObs p0_35_0_0 aRig"><?=_('msgSimulationAd')?></div>
                        </div>
                    </div>
                </li>
                <li>
                    <div id="stp04">
                        <?php $V->element('segmentation'); ?>
                    </div>
                </li>
                <li>
                    <div id="stp05" class="p0_0_10_0">
                        <?php $V->element('setBilling'); ?>
                    </div>
                </li>
                <li>
                    <div id="stp06">
                        <?php $V->element('campaignName'); ?>
                    </div>
                </li>
                <li>
                    <div id="stp07" class="stpPublish">
                        <div>
                            <div>
                                <h2><?=_('labAdChosen')?></h2>
                                <div class="yellow3center"></div>
                                <div class="hr25"></div>

                                <div class="pageLikeAd">
                                    <div class="">
                                        <h5 class="fanPageTitle pag-name"></h5>
                                        <h6 class="pageLikeAdTitle"></h6>
                                    </div>
                                    <div class="pageLikeAdMedia pag-thumb"></div>
                                    <div class="pageLikeAdMessage"></div>
                                </div>
                                <span class="pageLikeAdMedal"></span>
                                <div class="fbCreativeSh"></div>

                                <div class="hr10"></div>
                                <h3><?=_('adToImproveYourCampaign')?></h3>
                                <div class="hr20"></div>
                                
                                <div class="pageLikeAdModel">
                                    <div><span></span></div>
                                    <div>
                                        <div>
                                            <h6><strong><?=$_SESSION['user']['firstName']?></strong> <?=_('likes')?> <strong class="pag-name"></strong></h6>
                                        </div>
                                        <div>
                                            <div class="pag-thumb"></div>
                                        </div>
                                        <div>
                                            <h5 class="fanPageTitle pag-name"></h5>
                                            <!-- <h6 class="pageLikeAdTitle"></h6> -->
                                            <span class="fbInfoGray12"><i class="tb-icon-15x-like p2_0_0_0"></i> <?=_('like')?></span>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="hr25"></div>
                                <div class="hr25"></div>
                            </div>
                            <div>
                                <div>
                                    <h2><?=_('labPublic')?></h2>
                                    <div class="yellow3center"></div>
                                    <div class="hr20"></div>
                                    <div class="block">
                                        <div class="lef perCent50">
                                            <span class="label"><?=_('genderColon')?></span>
                                            <span class="info" id="reviewGenderStr"></span>
                                        </div>
                                        <div class="lef perCent50">
                                            <span class="label"><?=_('ageColon')?></span>
                                            <span class="info" id="reviewAgeStr"></span>
                                        </div>
                                    </div>
                                    <div class="block">
                                        <span class="label block"><?=_('locatedColon')?></span>
                                        <span class="info" id="reviewLocatedStr"></span>
                                    </div>
                                    <div class="block">
                                        <span class="label block"><?=_('interestedColon')?></span>
                                        <span class="info" id="reviewInterestedStr"></span>
                                    </div>
                                </div>
                                <div>
                                    <h2><?=_('labCampaign')?></h2>
                                    <div class="yellow3center"></div>
                                    <div class="hr20"></div>
                                    <div class="block">
                                        <span class="label"><?=_('nameColon')?></span>
                                        <span class="info" id="reviewCampaignName"></span>
                                    </div>
                                    <div class="block">
                                        <div class="lef perCent50">
                                            <span class="label"><?=_('startColon')?></span>
                                            <span class="info" id="reviewBeginDate"></span>
                                        </div>
                                        <div class="lef perCent50">
                                            <span class="label"><?=_('endColon')?></span>
                                            <span class="info" id="reviewEndDate"></span>
                                        </div>
                                    </div>  
                                    <div class="block">
                                        <span class="label"><?=_('investmentColon')?></span>
                                        <span class="info" id="reviewInvestment"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
        <div class="clearfix"></div> 
    </div>
</div>
<div id="footerPush"></div>