<?php $V->jsLocale('goal'); ?>
<script>
	g.accountId = "<?=$accountId?>";
</script>

<?php $V->element('Scripts/goals'); ?>
<!-- build:js(.) /js/goal3.js -->
<script src="/js/lib/bootstrap-wizard/bootstrap-wizard.min.js"></script>
<script src="/js/app/goals/goal3.js"></script>
<!-- endbuild -->