<div id="wrapper" class="layout wrapper">
	<?php $boxes = ['whitebox','bluebox']; for($i=0; $i<2; $i++): ?>
	<div class="area clearfix <?=$boxes[$i]?>">
		<h2>Buttons</h2>
		<button class="btn">Default</button>
		<a class="btn">Link</a>
		<button class="btn white">White</button>
		<button class="btn green">Green</button>
		<button class="btn red">Red</button>
		<button class="btn fullgreen">Fullgreen</button>

		<hr>

		<button class="btn medium">Medium</button>
		<a class="btn medium">Link</a>
		<button class="btn medium white">White</button>
		<button class="btn medium green">Green</button>
		<button class="btn medium red">Red</button>
		<button class="btn medium fullgreen">Fullgreen</button>

		<hr>

		<button class="btn small">Small</button>
		<a class="btn small">Link</a>
		<button class="btn small white">White</button>
		<button class="btn small green">Green</button>
		<button class="btn small red">Red</button>
		<button class="btn small fullgreen">Fullgreen</button>

		<hr>

		<button class="btn tiny">tiny</button>
		<a class="btn tiny">link</a>
		<button class="btn tiny white">white</button>
		<button class="btn tiny green">green</button>
		<button class="btn tiny red">red</button>
		<button class="btn tiny fullgreen">fullgreen</button>
	</div>
	<?php endfor; ?>
</div>