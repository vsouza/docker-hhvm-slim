<div id="wrapper" class="wrapper">
	<div class="area whitebox clearfix">
		<h2>Token</h2>
		<div class="clearfix">
			<p class="ellipsis"><?=$_SESSION['user']['token']?></p>
			<h4>Permissions</h4>
			<p id="permissions"></p>
			<button id="publishPermsButton" class="hide">Get publish_actions</button>
		</div>

		<h2>Accounts</h2>
		<div class="clearfix">
			<script id="tpl_accounts" type="text/x-handlebars-template">
			{{#each this}}
	            <input type="radio" name="account" value="{{account_id}}" id="{{account_id}}"> 
	            <label for="{{account_id}}">{{business_name}}</label>
	        {{/each}}
			</script>
			<div id="accounts" class="radio">
			</div>
		</div>

		<h2>Pages</h2>
		<div class="clearfix">
			<script id="tpl_pages" type="text/x-handlebars-template">
			{{#each this}}
	            <input type="radio" name="page" value="{{id}}" id="{{id}}"> 
	            <label for="{{id}}">{{name}}</label>
	        {{/each}}
			</script>
			<div id="pages" class="radio">
			</div>
		</div>

		<!-- -------------------------------------------------------------------------------- -->

		<h2>Previews</h2>
		<div class="clearfix">
			<div class="span3">
				<div class="radio">
					<input type="radio" name="placement" id='rcs' value="RIGHT_COLUMN_STANDARD" checked="checked"><label for="rcs">RIGHT_COLUMN_STANDARD</label><br>
					<input type="radio" name="placement" id='dfs' value="DESKTOP_FEED_STANDARD"><label for="dfs">DESKTOP_FEED_STANDARD</label><br>
					<input type="radio" name="placement" id='mfs' value="MOBILE_FEED_STANDARD"><label for="mfs">MOBILE_FEED_STANDARD</label><br>
					<input type="radio" name="placement" id='mb' value="MOBILE_BANNER"><label for="mb">MOBILE_BANNER</label><br>
				</div>
				<br>
				<div class="radio">
					<input type="radio" name="creative" id='Cdomain_ad' value="domain_ad" checked="checked"><label for="Cdomain_ad">domain_ad</label><br>
					<input type="radio" name="creative" id='Cpage_like_ad' value="page_like_ad"><label for="Cpage_like_ad">page_like_ad</label><br>
					<input type="radio" name="creative" id='Clink_page_post' value="link_page_post"><label for="Clink_page_post">link_page_post</label><br>
				</div>
				<br>
				Call to action:
				<select id="call_to_action" name="call_to_action">
				    <option value="">Nenhum botão</option>
				    <option value="SHOP_NOW">Comprar agora</option>
				    <option value="LEARN_MORE">Saiba mais</option>
				    <option value="BOOK_TRAVEL">Reservar agora</option>
				    <option value="SIGN_UP">Cadastre-se</option>
				    <option value="DOWNLOAD">Baixar</option>
				</select>
				<br><button id="previewButton" type="button" disabled="disabled" rel="accountSubmit">Generate!</button>
			</div>
			<div class="span6" id="previewResult" style="min-height: 300px; text-align: center;"></div>
		</div>

		<!-- -------------------------------------------------------------------------------- -->

		<h2>Creative</h2>
		<div class="clearfix">
			<h3>Domain Ad</h3>
			<div class="span4">
	            Hash: <input type="text" name="hash" id="domainadCreativeHash" value="6077c25c6552527a1fccbd2c1883877e" class="dontclean">
				<button id="domainadCreativeButton" type="button" disabled="disabled" rel="accountSubmit">Create</button> 
			</div>
			<div class="span5">
				<textarea class="code" id="domainadCreativeResult" readonly="readonly"></textarea>
			</div>
		</div>

		<!-- -------------------------------------------------------------------------------- -->

		<h2>Campaign</h2>
		<h3>Campaign (/adcampaign_groups)</h3>
		<div class="clearfix">
			<div class="span4">
				<input type="text" id="campaignName" value="<?=uniqid('testName');?>" rel="accountSubmit" disabled="disabled" class="dontclean">
				<button id="campaignButton" type="button" rel="accountSubmit" disabled="disabled">Create</button> 
			</div>
			<div class="span5">
				<textarea class="code" id="campaignResult" readonly="readonly"></textarea>
			</div>
		</div>

		<h3>Ad Set (/adcampaigns)</h3>
		<div class="clearfix">
			<div class="span4">
				Campaign Id: <input type="text" id="adsetCampaignId" placeholder="CampaignId" rel="campaignId">
				<input type="text" id="adsetName" value=""  placeholder="Ad Set Name">
				<button id="adsetButton" type="button" disabled="disabled">Create</button> 
			</div>
			<div class="span5">
				<textarea class="code" id="adsetResult" readonly="readonly"></textarea>
			</div>
		</div>

		<h3>Ad Group (/adgroups)</h3>
		<div class="clearfix">
			<div class="span4">
				AdSet Id: <input type="text" id="adGroupAdsetId" placeholder="CampaignId">
				<input type="text" id="adGroupName" value=""  placeholder="Ad Group Name">
				<button id="adGroupButton" type="button" disabled="disabled">Create</button> 
			</div>
			<div class="span5">
				<textarea class="code" id="adGroupResult" readonly="readonly"></textarea>
				<a id="adGroupLink" href="" target="_blank"></a>
			</div>
		</div>

		<!-- -------------------------------------------------------------------------------- -->

		<h2>Uploads</h2>
		<div class="clearfix">
			<h3>Timeline Upload (publish_actions permissions needed)</h3>
			<div class="span4">
				<form id="timelineUpload" name="timelineUpload" action="/upload/fb/photo" target="timelineUploadForm" method="POST" enctype="multipart/form-data">
				    <input type="hidden" name="pageId" rel="pageId">
				    <input type="hidden" name="token" rel="pageToken" value="">
				    <input type="hidden" id="uploadCallback" name="callback" value="window.parent.handleTimelineUpload">
				    <input type="hidden" id="uploadMessage" name="message" value="This is the message value">
				    <input type="file" id="uploadFile" name="file">
				    <input type="submit" rel="pageSubmit" disabled="disabled" value="Upload">
				    <iframe src="javascript:void(0);" id="timelineUploadForm" name="timelineUploadForm" width="0" height="0" frameborder="0"></iframe>
				</form>
			</div>
			<div class="span5">
				<textarea class="code" id="timelineUploadResult" readonly="readonly"></textarea>
				<a id="timelineUploadLink" href="" target="_blank"></a>
			</div>
		</div>
		
		<div class="clearfix">
			<h3>Ad Account Library (album) Upload</h3>
			<div class="span4">
				<form id="albumUpload" name="albumUpload" action="/upload/fb/album/photo" target="albumUploadForm" method="POST" enctype="multipart/form-data">
				    <input type="hidden" name="accountId" rel="accountId">
				    <input type="hidden" name="token" value="<?=$_SESSION['user']['token']?>">
				    <input type="hidden" id="uploadCallback" name="callback" value="window.parent.handleAlbumUpload">
				    <input type="file" id="uploadFile" name="file">
				    <input type="submit" rel="accountSubmit" disabled="disabled" value="Upload">
				    <iframe src="javascript:void(0);" id="albumUploadForm" name="albumUploadForm" width="0" height="0" frameborder="0"></iframe>
				</form>
			</div>
			<div class="span5">
				<textarea class="code" id="albumUploadResult" readonly="readonly"></textarea>
				<a id="albumUploadLink" href="" target="_blank"></a>
			</div>
		</div>
	</div>
</div>