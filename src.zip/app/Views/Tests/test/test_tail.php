<script src="/js/bower/handlebars/handlebars.js"></script>
<script src="/js/app/utils/create-class.js"></script>
<script src="/js/app/utils/functions.js"></script>
<script src="/js/app/utils/cookies.js"></script>
<script src="/js/app/utils/ui-helpers.js"></script>
<script src="/js/app/utils/currency.js"></script>
<script src="/js/app/utils/i18n.js"></script>
<script src="/js/app/utils/handlebars.js"></script>
<script src="/js/app/utils/keyboard.js"></script>
<script src="/js/tests/tests.js"></script>

<script>
	g.appId = "<?=$appid?>";
</script>

<div id="fb-root"></div>
<script>(function(d, s, id){
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) {return;}
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/<?=$_SESSION['user']['lang']?>/all.js";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>