  <div id="fb-root"></div>
  <script src="js/fbinit.js"></script>

  <!-- Modal -->
  <div id="modal-terms" class="modal fade">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title">Termos e Políticas de Uso</h4>
        </div>
        <div class="modal-body">
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae, unde error quo fugiat repellendus quod dolorem nemo neque maiores sed iusto nobis asperiores assumenda cupiditate vero eius tempore dolor similique!</p>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore, veritatis, nemo minima odit minus voluptatum rem est cupiditate sit explicabo nobis aut ad sapiente ipsam incidunt itaque veniam quisquam ex.</p>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magnam quibusdam corporis ratione. Quidem, quia, praesentium, consequatur, voluptates omnis ex eius laudantium nobis ipsum nam harum similique suscipit eveniet repellat in.</p>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Suscipit, ipsum inventore modi dolorum accusamus cum a ut aliquid recusandae laudantium ad quaerat natus quam voluptates rerum fuga mollitia. Quos, minima!</p>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Distinctio, illum, at, architecto corporis saepe delectus quo earum doloremque eos sapiente assumenda neque sequi explicabo molestiae accusamus quisquam cum aperiam vitae!</p>
        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal -->

  <!-- Modal sync -->
    <div id="modal-fbsync" class="modal fade">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">            
            <h4 class="modal-title">Para utilizar a nossa plataforma e gerenciar suas campanhas <br><strong>você precisa conectar uma conta do Facebook.</strong></h4>
          </div>
          <div class="modal-body">

            <div class="col-xs-12 col-lg-12 text-center">
              <a href="#" title="Vincular sua conta ao Facebook" class="btn btn-primary btn-login-fb">
                Vincular sua conta ao Facebook
              </a>

              <h3 class="text-center">ou</h3>

              <h4>Ainda não tenho uma conta no Facebook.</h4>
              <a href="http://www.facebook.com" target="_blank" class="btn btn-link btn-fb-vinculate" title="Quero criar uma conta agora">
                Quero criar uma conta agora
              </a>              
            </div>
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->

  <!-- Wrap all page content here -->
  <div id="wrap">

    <!-- Begin page content -->
    <div class="container">
        <div class="jumbotron">
          <h1>Cadastre-se</h1>
          <h2>A maneira fácil de anunciar.</h2>
        </div>

        <div id="container-register">
          <div class="row">
            <div class="col-xs-12 hidden-sm hidden-md hidden-lg">
              <a href="javascript:;" title="Entrar com o facebook" class="btn-login row-btn-fb">
                Entrar com o facebook
              </a>

              <h3 class="text-center">ou</h3>
            </div>

            <form id="register" class="form-horizontal" role="form" action="<?php $urlFor('registration') ?>" method="post" >
              <fieldset>
                <div class="col-xs-12 col-sm-6 col-lg-6 form-data">
                  <div class="col-lg-11">
                    <div class="form-group">
                      <label for="name">Nome</label>
                      <input type="text" id="name" name="name" class="form-control" placeholder="Nome">
                    </div>
                    <div class="form-group">
                      <label for="surname">Sobrenome</label>
                      <input type="text" id="surname" name="surname" class="form-control" placeholder="Nome">
                    </div>
                    <div class="form-group">
                      <label for="email">E-mail</label>
                      <input type="text" id="email" name="email" class="form-control" placeholder="E-mail">
                    </div>
                    <div class="form-group">
                      <label for="pass">Senha</label>
                      <input type="password" id="pass" name="pass" class="form-control" placeholder="Senha">
                    </div>
                    <div class="form-group">
                      <label for="repeat_pass">Repita a senha</label>
                      <input type="password" id="repeat_pass" name="repeat_pass" class="form-control" placeholder="Repita a senha">
                    </div>
                  </div>
                </div>

                <div class="col-sm-6 col-lg-6 col-btn-fb hidden-xs">
                  <a href="objetivo.html" title="Entrar com o facebook" class="btn-login">
                    Entrar com o facebook
                  </a>
                </div>

                <div class="col-xs-12 col-sm-6 col-lg-12 form-data">
                  <div class="col-lg-11">
                    <div class="checkbox">
                      <label for="terms">
                        <input type="checkbox" name="terms" id="terms"> Ao clicar em Cadastrar, você confirma que leu e concorda com nossos <a href="javascript:;" class="link-terms">Termos e Políticas de Uso</a>.
                      </label>
                    </div>
                    
                    <div class="form-group">                    
                      <input type="button" class="btn btn-primary btn-form-register" title="Cadastrar" value="Cadastrar">
                    </div>                  
                  </div>
                </div>
              </fieldset>
            </form>

          </div>
        </div>
    </div>
  </div>

  <script src="js/libs/jquery.validate.min.js" defer></script>
  <script src="js/cadastro.js" defer></script>
  <!--<script src="js/login.js" defer></script>-->