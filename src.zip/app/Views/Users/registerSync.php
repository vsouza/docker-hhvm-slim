  <div id="fb-root"></div>
  <script src="js/fbinit.js"></script>

  <!-- Wrap all page content here -->
  <div id="wrap">

    <!-- Begin page content -->
    <div class="container register-continue">
          <h1>Falta pouco para completar o seu cadastro.</h1>
          <h2>Para utilizar a nossa plataforma e gerenciar suas campanhas <strong>você precisa conectar uma conta do Facebook.</strong></h2>

          <div class="row">
            <div class="col-xs-12 col-lg-12 text-center">
              <a href="#" title="Vincular sua conta ao Facebook" class="btn btn-primary btn-login-fb">
                Vincular sua conta ao Facebook
              </a>

              <h3 class="text-center">ou</h3>

              <h4>Ainda não tenho uma conta no Facebook.</h4>
              <a href="http://www.facebook.com" target="_blank" class="btn btn-link btn-fb-vinculate" title="Quero criar uma conta agora">
                Quero criar uma conta agora
              </a>              
            </div>
          </div>          
      </div>
    </div>
  </div>
  <script src="js/cadastro.js" async="true"></script>