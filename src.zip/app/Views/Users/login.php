<div id="fb-root"></div>
<?php $html->js('old/fbinit.js'); ?>

<!-- Modal -->
<div id="modal-fbsync" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Para utilizar a nossa plataforma e gerenciar suas campanhas<br>
                    <strong>você precisa conectar uma conta do Facebook.</strong>
                </h4>
            </div>
            <div class="modal-body">
                <div class="col-xs-12 col-lg-12 text-center"><a href="#" title="Vincular sua conta ao Facebook" class="btn btn-primary btn-login-fb">Vincular sua conta ao Facebook</a>
                    <h3 class="text-center">ou</h3>
                    <h4>Ainda não tenho uma conta no Facebook.</h4>
                    <a href="http://www.facebook.com" target="_blank" class="btn btn-link btn-fb-vinculate" title="Quero criar uma conta agora">Quero criar uma conta agora</a>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<!-- Wrap all page content here -->
<div id="wrap">
    <!-- Begin page content -->
    <div class="container">
        <div class="jumbotron">
            <h1>Faça o login.</h1>
            <h2>A maneira fácil de anunciar.</h2>
        </div>
        <div class="row">
            <div id="container-login">
                <div class="col-xs-12 hidden-sm hidden-md hidden-lg">
                    <a href="#" title="Entrar com o facebook" class="btn-login row-btn-fb">Entrar com o facebook</a>
                    <h3 class="text-center">ou</h3>
                </div>
                <div class="col-xs-12 col-sm-6 col-lg-6">
                    <div class="col-lg-11">
                        <form id="login" class="form-horizontal" role="form" action="<?php $urlFor('login') ?>" method="post">
                            <fieldset>
                                <div class="form-group">
                                    <label for="email">E-mail</label>
                                    <input type="text" id="email" name="email" class="form-control" placeholder="E-mail">
                                </div>
                                <div class="form-group">
                                    <label for="pass">Senha</label>
                                    <input type="password" id="pass" name="pass" class="form-control" placeholder="Senha">
                                </div>

                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-5 col-md-5 col-xs-5">
                                            <input type="button" class="btn btn-primary btn-form-login" title="Entrar" value="Entrar">
                                        </div>

                                        <div class="col-lg-7 col-md-7 col-xs-7 text-right pull-right">
                                            <a class="forgot-link" href="#" title="Esqueci minha senha">Esqueci minha senha</a>
                                            <br>
                                            <a class="registration-link" href="<?php $urlFor('registration') ?>" title="Cadastrar nova conta">Cadastrar nova conta</a>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                        </form>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-6 col-btn-fb hidden-xs">
                    <a href="objetivo.html" title="Entrar com o facebook" class="btn-login">
                  Entrar com o facebook
                </a>
                </div>
            </div>

            <div id="container-forgot" class="col-xs-12 col-sm-6 col-lg-6 hide">
                <form id="resetpass" class="form-horizontal" role="form" action="<?php $urlFor('passwordreset') ?>">
                    <fieldset>
                        <div class="form-group">
                            <label for="resetpass-email">E-mail</label>
                            <input type="text" id="resetpass-email" name="resetpass-email" class="form-control" placeholder="E-mail">
                        </div>

                        <div class="form-group">
                            <input type="submit" class="btn btn-primary" title="Redefinir senha" value="Redefinir senha">
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $html->js('old/libs/jquery.validate.min.js'); ?>
<?php $html->js('old/login.js'); ?>