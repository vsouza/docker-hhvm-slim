    <!-- Wrap all page content here -->
    <div id="wrap">

      <!-- Begin page content -->
      <div class="container">
          <div class="jumbotron">
            <h1>Nova senha.</h1>
            <h2>Defina sua nova senha.</h2>
          </div>

          <div class="row">
            <div id="container-login">              
              <div class="col-xs-12 col-sm-6 col-lg-6">
                <div class="col-lg-11">
                  <form id="forgot" class="form-horizontal" role="form" action="<?php $urlFor('setpassword', ['token' => $token ]) ?>">
                    <fieldset>
                      <div class="form-group">
                        <label for="pass">Senha</label>
                        <input type="password" id="pass" name="pass" class="form-control" placeholder="Senha">
                      </div>
                      <div class="form-group">
                        <label for="repeat_pass">Repita a senha</label>
                        <input type="password" id="repeat_pass" name="repeat_pass" class="form-control" placeholder="Repita a Senha">
                      </div>                   
                      
                      <div class="form-group">
                        <div class="row">
                          <div class="col-lg-5 col-md-5 col-xs-5">
                            <input type="submit" class="btn btn-primary" title="Definir" value="Definir">
                          </div>
                        </div>
                      </div>                    
                    </fieldset>
                  </form>
                </div>
              </div>
            </div>
          </div>         
      </div>
    </div>

    <script src="/js/libs/jquery.validate.min.js" defer></script>
    <script src="/js/setPassword.js" defer></script>