<?php $hasPlan = false; ?>
<script>var hasPlan = false;</script>

<div id="wrapper" class="config-box">
    <div id="config-box" class="clearfix">
        <?php $V->element('settingsMenu',['active'=>'revoke']) ?>
        <div id="config-content">
            <h2><?=_('revokeTitle')?></h2>
            <p><?=_('revokeDescription')?></p>
            <p><b><?=_('revokeDescription2')?></b></p>
            <br>
            <button class="btn white big"  href="#modalConfirmRevoke" data-toggle="modal"><?=_('revokeCTA')?></button>

            <form action="<?php $V->urlFor('revokeconfirm'); ?>" method="post" id="revokeForm">
            <input type="hidden" name="revoke" value="true">
            </form>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="modalConfirmRevoke" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    </div>
    <div class="modal-body">
        <h4 class="orange"><?=_('revokeModalTitle')?></h4>
        <p><?=_('revokeModalDescription')?></p>
    </div>
    <div class="modal-footer center">
        <button data-dismiss="modal" aria-hidden="true" class="btn white whitebg"><?=_('btnCancel')?></button>
      <button id="payIt" class="btn red whitebg" onclick="document.getElementById('revokeForm').submit(); mixpanel.track('Revoke Permissions');"><?=_('revokeCTA')?></button>
    </div>
</div>
