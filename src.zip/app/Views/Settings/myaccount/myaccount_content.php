<div id="wrapper" class="config-box">
  <div id="config-box" class="clearfix">
      <?php $V->element('settingsMenu', ["active" => "myaccount"]) ?>
      <div id="config-content">
          <ul class="nav nav-tabs" id="myTab">
            <li class="active"><a href="#myaccount" data-toggle="tab"><?=_('navMyAccount')?></a></li>
            <li><a href="#fbaccounts" data-toggle="tab"><?=_('navFbAccounts')?></a></li>
            <?php if(false): ?>
            <li><a href="#passwordtab" data-toggle="tab">Alterar Senha</a></li>
            <?php endif; ?>
          </ul>
          <div class="tab-content">
            <div class="tab-pane active" id="myaccount">
            <!-- Start "My Account" Form -->
              <p><?=_('pMyAccountIntro')?></p>
              <form class="" action="<?php $V->urlFor('myaccount') ?>" method="post">
                <div class="span8 controls-row">
                  <div class="control-group span4" style="margin-left: 0;">
                    <label class="control-label" for="name"><?=_('labFullName')?></label>
                    <div class="controls">
                      <input class="span4" type="text" id="name" value="<?=$data['firstName'].' '.$data['surname']?>" readonly>
                    </div>
                  </div>
                  <div class="control-group span4">
                    <label class="control-label" for="name"><?=_('labEmail')?></label>
                    <div class="controls">
                      <input class="span4" type="text" id="email" value="<?=$data['email']?>" readonly>

                    </div>
                  </div>
                </div>
                <div class="span8 controls-row">
                  <div class="control-group span4" style="margin-left: 0;">
                    <label class="control-label" for="DropDownTimezone"><?=_('labTimezone')?></label>
                    <div class="controls">
                      <select name="timezone" id="dropDownTimezone" class="span4 selectpicker">
                        <?=_('optionsTimezones')?>
                      </select>
                    </div>
                  </div>
                  <div class="control-group span4">
                    <div class="controls">
                      <label class="control-label" for="DropDownLanguage"><?=_('labLang')?></label>
                      <select name="lang" id="dropDownLanguage" class="span4 selectpicker">
                        <option value="pt_BR"><?=_('langpt_BR')?></option>
                        <option value="en_US"><?=_('langen_US')?></option>
                      </select>
                    </div>
                  </div>
              </div>
              <div class="control-group span8">
                <div class="controls">
                  <button type="submit" id="submitMyAccount" class="btn fullgreen"><?=_n('btnSave',1)?></button>
                </div>
              </div>
              </form>
              <!-- End "My Account" Form -->
            </div>
            <!-- Facebook Accounts -->
            <div class="tab-pane" id="fbaccounts">
              <p><?=_('pFbAccountsIntro')?></p>
              <table class="table" id="accountstable">
                <thead>
                  <tr>
                    <th><?=_('thID')?></th>
                    <th><?=_('thDailySpent')?></th>
                    <!-- <th><?=_('thAcessStatus')?></th> -->
                    <th><?=_('thAccountStatus')?></th>
                  </tr>
                </thead>
                <tbody id="fbaccounts_rows">
                    <script id="tpl_fbaccounts_rows" type="text/x-handlebars-template">
                    {{#each this}}
                      <tr>
                        <td>
                          <div class="id">{{account_id}}</div>
                        </td>
                        <td class="money">{{daily_spend_limit}}</td>
                        `<!--<td>?</td>-->
                        <td>{{fbAccountStatus account_status}}</td>
                      </tr>
                    {{/each}}
                    </script>
                </tbody>
              </table>
                <div id="loader">
                        <span id="spinner">&nbsp</span>
                </div>
              <button class="btn" type="button" id="btn-uptfbadacc"><?=_('btnUpdateAccounts')?></button>
            </div>
            <!-- Facebook Accounts -->
          </div>

      </div>
  </div>
</div>
