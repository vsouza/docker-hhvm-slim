<?php $V->jsLocale('myaccount'); ?>

<script>
	g.useri18n = {
		timezone: '<?=$_SESSION['user']['timezone']?>',
		lang: '<?=$_SESSION['user']['lang']?>'
	}
</script>

<!-- build:js(.) /js/myaccount.js -->
<script src="/js/app/myaccount.js"></script>
<!-- endbuild -->

<?php if($update):?>
<script>
    $(document).ready(function() {
        mixpanel.people.set({
            'Timezone': g.useri18n.timezone,
            'Locale': g.useri18n.lang
        });
    });
</script>
<?php endif; ?>
