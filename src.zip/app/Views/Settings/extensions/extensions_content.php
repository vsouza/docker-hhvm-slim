<div id="wrapper" class="config-box">
<div id="config-box" class="clearfix extensions">
    <?php $V->element('settingsMenu',['active'=>'extensions']) ?>
    <div id="config-content">
        <span class="btn-group accountselect">
          <select id="accountid" class="selectpicker">
        </select>
        </span>
        <p><?=_('pPixelsIntro')?></p>

        <div id="spinner"></div>
        <!-- Start "Pixels" Table -->
        <script id="tpl_pixeldata" type="text/x-handlebars-template">
        {{#if terms}}
        <div class="contentInfo" style="margin: 5px 0 10px;">
            <div class="content">
                <i class="tb-icon-16x-alert lef"></i>
                <span><?=_('pixelTermsIntro')?></span>
            </div>
        </div>
        <a href="https://www.facebook.com/ads/manage/convtrack/tosapi.php?act={{accountid}}" target="_blank"><?=_('pixelTermsLinks')?>.
        {{else}}
            {{#if data}}
            <table id="pixels-table" class="table">
                <thead>
                      <tr>
                            <th><?=_('thPixel')?></th>
                            <th><?=_('thCategory')?></th>
                            <th><?=_('thPixelStatus')?></th>
                            <th><?=_('thActions')?></th>
                      </tr>
                </thead>
                <tbody>
                    {{#each data}}
                    <tr>
                        <td>{{name}}</td>
                        <td>{{Tags tag}}</td>
                        <td>{{Statuses status}}</td>
                        <td>
                            <button class="btn tiny" href="#modalSendCode" data-toggle="modal" data-interaction="send" data-pixel-id="{{id}}" data-code="{{js_pixel}}"><?=_('hPixelSendCode')?></button>
                            <button class="btn tiny" href="#modalCopyCode" data-toggle="modal" data-interaction="copy" data-code="{{js_pixel}}"><?=_('btnCopyCode')?></button>
                            <button class="btn tiny red" href="#modalDeletePixel" data-toggle="modal" data-interaction="delete" data-pixel-id="{{id}}"><?=_('aDelete')?></button>
                        </td>
                    </tr>
                    {{/each}}
                </tbody>
            </table>
            <button class="btn" type="button" id="createPixel" href="#modalPixelCreation" data-toggle="modal"><?=_('labCreatePixel')?></button>
            {{else}}
            <p><?=_('pixelNoPixels')?></p>
            <button class="btn" type="button" id="createPixel" href="#modalPixelCreation" data-toggle="modal"><?=_('labCreatePixel')?></button>
            {{/if}}
        {{/if}}
        </script>
        <div id="pixeldata"></div>
        <!-- End "Pixels" Table -->
      </div>
  </div>
</div>

<div class="extensions">

  <!-- Modal -->
  <div id="modalPixelCreation" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    </div>
    <div class="modal-body">
      <h4><?=_('hPixelCreation')?></h4>
      <form id="createpixelform">
        <fieldset>
          <div class="control-group">
              <label><?=_('PixelsName')?></label>
              <input type="text" id="pixelname">
          </div>
          
          <div class="control-group">
              <label for="pixelType"><?=_('labChoosePixelType')?></label>
              <select id="pixelType" name="pixelType" class="selectpicker">
                  <option value="CHECKOUT"><?=_('labPixelType0')?></option>
                  <option value="REGISTRATION"><?=_('labPixelType1')?></option>
                  <option value="LEAD"><?=_('labPixelType2')?></option>
                  <option value="KEY_PAGE_VIEW"><?=_('labPixelType3')?></option>
                  <option value="ADD_TO_CART"><?=_('labPixelType4')?></option>                    
                  <option value="OTHER"><?=_('labPixelType5')?></option>
              </select>
          </div>
        </fieldset>
      </form>
    </div>
    <div class="modal-footer">
      <button id="createpixelbutton" class="btn fullgreen"><?=_('labCreatePixel')?></button>
    </div>
  </div>


  <!-- Modal -->
  <div id="modalSendCode" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    </div>
    <div class="modal-body">
      <h4><?=_('hPixelSendCode')?></h4>
      <form id="sendcodeform">
          <p><?=_('pPixelSendToAdmin')?></p>
          <fieldset>
              <div class="control-group">
              <?php 
                if(!is_numeric($_SESSION['user']['firstName'])) $namevalue = $_SESSION['user']['firstName'].' '.$_SESSION['user']['surname'] ;
                else $namevalue = '';
               ?>
                  <label>Seu nome</label>
                  <input type="text" id="sendpixelmyname" value="<?=$namevalue?>">
              </div>
              <div class="control-group">
                  <label>Nome do Administrador</label>
                  <input type="text" id="sendpixeladmname">
              </div>
              <div class="control-group">
                  <label><?=_('hPixelAdminEmail')?></label>
                  <input type="text" id="sendpixeladmemail">
                  <input type="submit" style="visibility: hidden; height: 0; width: 0;">
              </div>
              <input type="hidden" id="sendpixelid" name="sendpixelid">
              <input type="hidden" id="sendpixelcode" name="sendpixelcode">
          </fieldset>
      </form>
      <div class="error" style="display:none">
        <p><?=_('pPixelSendError')?></p>
      </div>
      <div class="success" style="display:none">
        <p><?=_('pPixelMailSent')?></p>
      </div>
    </div>
    <div class="modal-footer">
      <button id="sendcodebutton" class="btn fullgreen"><?=_('btnSend');?></button>
      <button id="sendcodeclosebutton" data-dismiss="modal" class="btn white"  style="display:none"><?=_('btClose');?></button>
    </div>
  </div>


  <!-- Modal -->
  <div id="modalCopyCode" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    </div>
    <div class="modal-body">
      <h4><?=_('hPixelCopyCode')?></h4>
      <form id="copycodeform">
        <fieldset>
          <p><?=_('pPixelCopyToAdmin')?></p>
          <div class="control-group">
              <textarea id="codeArea" readonly="readonly"></textarea>
          </div>
        </fieldset>
      </form>
    </div>
    <div class="modal-footer">
      <!-- <button id="copycodebutton" class="btn" data-dismiss="modal" aria-hidden="true"><?=_('btnCopyCode')?></button> -->
      <button class="btn white" data-dismiss="modal" aria-hidden="true"><?=_('btClose')?></button>
    </div>
  </div>

</div>