<style>
    .accountselect .filter-option:before {content: "<?=_('beforeAccount')?>: ";}
</style>