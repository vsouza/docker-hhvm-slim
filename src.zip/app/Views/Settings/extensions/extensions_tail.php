<?php $V->jsLocale('extensions'); ?>

<!-- build:js(.) /js/extensions.js -->
<script src="/js/app/extensions.js"></script>
<!-- endbuild -->