<?php $hasPlan = false; ?>
<script>var hasPlan = false;</script>

<div id="wrapper" class="config-box">
    <div id="config-box" class="clearfix">
        <?php $V->element('settingsMenu',['active'=>'subscription']) ?>
        <div id="config-content" class="notifications">
            <h2><?=_('subscription')?></h2>
            <h3><?=_('shSubscription')?></h3>
            <div class="subscription-plans">
                <h4><?=_('h4PaymentPlans')?></h4>
                <div>
                    <?php
                        foreach ($plans as $plan) :
                        $planClass = '';
                        $isStandBy = false;
                        $isSelected = false;
                        if(isset($plan['user'])) {
                            switch ($plan['user']['status']) {
                                case 0:
                                    $planClass .= 'standby ';
                                    $isStandBy = true;
                                    break;
                                case 1:
                                    $planClass .= 'selected ';
                                    $hasPlan = true;
                                    $isSelected = true;
                                    break;
                            }
                        }
                    ?>

                    <div class="plan <?=$planClass?>">
                        <div class="frame">
                            <header><?=_n('hPlanMonths',$plan['frequency'])?></header>
                            <div class="content">
                                <div class="price">
                                    R$<b><?php echo number_format($plan['amount'], 2, ',', '.'); ?></b>
                                </div>
                                <div class="paymenttype">
                                    <?=_('autoDebit')?><br>
                                    <b><?=_('monthly'.$plan['frequency'])?></b>
                                </div>
                                <div class="action">

                                <?php if($isStandBy): ?>
                                    <p class="status"><?=_('pPayAnalysis')?>*</p>
                                <?php endif; ?>

                                <?php if($isSelected): ?>
                                    <p class="status"><?=_('pCurrentPlan')?>*</p>
                                    <form action="<?php $V->urlFor('cancelSubscription'); ?>" method="post" id="cancelPlan">
                                    <input type="hidden" name="description" value="<?=$plan['description']?>">
                                    <input type="hidden" name="period" value="<?=$plan['period']?>">
                                    <input type="hidden" name="frequency" value="<?=$plan['frequency']?>">
                                    <input type="hidden" name="amount" value="<?=$plan['amount']?>">
                                    <input type="hidden" name="name" value="<?=$plan['name']?>">
                                    <input type="hidden" name="plan" value="<?=$plan['plan']?>">
                                    <?php if(!empty($plan['user']['profileId'])): ?>
                                     <input type="hidden" name="profileId" value="<?=$plan['user']['profileId']?>">
                                    <?php endif; ?>
                                    </form>
                                    <button class="btn red" href="#modalConfirmCancel" data-toggle="modal"><?=_('btnCancel')?></button>
                                <?php endif; ?>

                                <?php if(!$isStandBy&&!$isSelected) : ?>
                                    <form action="<?php $V->urlFor('createSubscription'); ?>" method="post" id="formPlan<?=$plan['plan']?>">
                                    <input type="hidden" name="description" value="<?=$plan['description']?>">
                                    <input type="hidden" name="period" value="<?=$plan['period']?>">
                                    <input type="hidden" name="frequency" value="<?=$plan['frequency']?>">
                                    <input type="hidden" name="amount" value="<?=$plan['amount']?>">
                                    <input type="hidden" name="name" value="<?=$plan['name']?>">
                                    <input type="hidden" name="plan" value="<?=$plan['plan']?>">
                                    </form>
                                    <button class="btn fullgreen" rel="subscribeButton" plan="<?=$plan['plan']?>"  href="#modalPayPal" data-toggle="modal"><?=_('btnSubscribe')?></button>
                                <?php endif; ?>

                                </div>
                            </div>
                            <?php if(!$plan['save']): ?>
                            <div class="discount empty"></div>
                            <?php else: ?>
                            <div class="discount">
                                <?=_('discount')?><br>
                                <b>R$<?php echo number_format($plan['save'], 2, ',', '.'); ?></b>
                            </div>
                            <?php endif; ?>
                        </div>

                        <?php if($isStandBy): ?>
                        <div class="statusrel">* <?=_('pPayAnalysisDays')?></div>
                        <?php endif; ?>

                        <?php if($isSelected): ?>
                        <div class="statusrel">* <?=_('pDueOn')?>: <?=strftime($V->app->config('lang.strftime')[$_SESSION['user']['lang']],(int)strtotime($plan['user']['nextDue']))?></div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; if($hasPlan): ?>
                    <script>hasPlan = true;</script>
                    <?php endif; ?>
                </div>
            </div>
            <div class="clearfix"></div>

            <?php if(false): // TODO Pagamento reprovado ?>
            <div id="warning" class="warning"><?=_('subscriptionWarningPayReproved')?></div>
            <?php elseif(isset($trialDaysLeft)): ?>
            <div id="warning" class="warning <?php if($trialDaysLeft==0) echo 'zero'; ?>"><?=_n('subscriptionWarningTrialDays', $trialDaysLeft)?></div>
            <?php endif; ?>

            <div class="faq">
                <h4>
                    <span class="ribbon"><?=_('hFaq')?></span>
                </h4>
                <div>
                    <header>
                        <b>1</b> <?=_('subscriptionQuestion1')?>
                        <span class="clearfix"></span>
                    </header>
                    <p><?=_('subscriptionAnswer1')?></p>
                </div>
                <div class="right">
                    <header>
                        <b>2</b> <?=_('subscriptionQuestion2')?>
                        <span class="clearfix"></span>
                    </header>
                    <p><?=_('subscriptionAnswer2')?></p>
                </div>
                <div>
                    <header>
                        <b>3</b> <?=_('subscriptionQuestion3')?>
                        <span class="clearfix"></span>
                    </header>
                    <p><?=_('subscriptionAnswer3')?></p>
                </div>
                <div class="right">
                    <header>
                        <b>4</b> <?=_('subscriptionQuestion4')?>
                        <span class="clearfix"></span>
                    </header>
                    <p><?=_('subscriptionAnswer4')?></p>
                </div>
            </div>

        </div>
    </div>
</div>



<!-- Modal -->
<div id="modalPayPal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    </div>
    <div class="modal-body">
        <h4 class="orange"><?=_('subscriptionModalPayPalH4')?></h4>
        <p><?=_('subscriptionModalPayPalP')?></p>
        <img src="/assets/img/paypal.png">
    </div>
    <div class="modal-footer center">
      <button id="payIt" class="btn fullgreen"><?=_('subscriptionModalPayPalCTA')?></button>
    </div>
</div>

<!-- Modal -->
<div id="modalConfirmChange" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    </div>
    <div class="modal-body">
        <h4 class="orange"><?=_('subscriptionChangeH4')?></h4>
        <p><!-- <b>Você ainda possui 2 meses e 4 dias de assinatura</b> para utilizar o Tamboreen. --> <?=_('subscriptionChangeDialog')?></p>
        <p><?=_('subscriptionChangeDialog2')?></p>
    </div>
    <div class="modal-footer center">
      <button data-dismiss="modal" class="btn white whitebg"><?=_('subscriptionChangeKeep')?></button>
      <button id="reallyChangePlan" class="btn green whitebg"><?=_('subscriptionChangeConfirm')?></button>
    </div>
</div>


<!-- Modal -->
<div id="modalConfirmCancel" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    </div>
    <div class="modal-body">
        <h4 class="orange"><?=_('subscriptionCancelH4')?></h4>
        <p><?=_('subscriptionCancelDialog')?></p>
    </div>
    <div class="modal-footer center">
      <button data-dismiss="modal" class="btn white whitebg"><?=_('subscriptionCancelKeep')?></button>
      <button id="reallyCancelPlan" class="btn red whitebg"><?=_('subscriptionCancelConfirm')?></button>
    </div>
</div>

<!-- Modal -->
<div id="modalCancelConfirmed" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    </div>
    <div class="modal-body">
        <h4 class="orange"><?=_('subscriptionModalCancelledH4')?></h4>
        <p><?=_('subscriptionModalCancelledP1')?></p>
        <p><?=_('subscriptionModalCancelledP2')?></p>
    </div>
    <div class="modal-footer center">
      <button data-dismiss="modal" class="btn fullgreen"><?=_('subscriptionModalCancelledCTA')?></button>
    </div>
</div>
