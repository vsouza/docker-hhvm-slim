<!-- build:js(.) /js/subscription.js -->
<script src="/js/app/subscription.js"></script>
<!-- endbuild -->

<?php if(isset($_GET['cancel'])): ?>
<script>
	$(document).ready(function() {
		$('#modalCancelConfirmed').modal('show');
	});
</script>
<?php endif; ?>
