<div id="wrapper" class="config-box">
    <div id="config-box" class="clearfix">
        <?php $V->element('settingsMenu',['active'=>'notifications']) ?>
        <div id="config-content" class="notifications">
            <p><?=_('pNotificationsIntro')?></p>
            <table class="table table-striped">
                <tr>
                    <td>
                        <?=_('msgNoNotifications')?>
                    </td>
                </tr>
                <script id="tpl_notificationslist" type="text/x-handlebars-template">
                {{#if data}}
                {{#each data}}
                <tr>
                    <td>
                        {{{message}}} 
                        <div class="timestamp">{{Timezone createdDate}}</div>
                    </td>
                </tr>
                {{/each}}
                {{/if}}
                </script>
                <tbody id="notificationslist">
                </tbody>
                <tr id="loader">
                    <td style="background: none;">
                        <span id="spinner"></span>
                    </td>
                </tr>
            </table>
            <!--<a href="#" id="loadmore"><i class="icon-chevron-down"></i><?=_('aLoadMore')?></a>-->
        </div>
    </div>
</div>