<!-- build:js(.) /js/app.notifications.js -->
<script src="/js/app/notifications.js"></script>
<!-- endbuild -->