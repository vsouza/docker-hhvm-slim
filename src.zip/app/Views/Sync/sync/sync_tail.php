<?php $V->jsLocale('sync'); ?>
<!-- build:js(.) /js/app.sync.js -->
<script src="/js/app/sync.js"></script>
<!-- endbuild -->