<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title><?php $V->title(); ?></title>
		<meta name="description" content="<?=_('siteHomeMetaDescription')?>">
		<meta name="google-site-verification" content="RMOGmXlH-nRSnHhjZpOW0T5xnqKL3flV_6anMrtRxfw" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<link rel="shortcut icon" href="/favicon.ico">

		<!-- build:css(.) /assets/css/bootstrap.css -->
		<link rel="stylesheet" href="/js/bower/bootstrap/docs/assets/css/bootstrap.css">
		<!-- endbuild -->
		
		<!-- build:css(.) /assets/css/website.css -->
		<link rel="stylesheet" href="/js/bower/bootstrap/docs/assets/css/bootstrap-responsive.css">
		<link rel="stylesheet" href="/assets/css/website.css">
		<!-- endbuild -->
		<!-- javascript -->
		<?php $V->head(); ?>
	</head>
    <body class="website">
    	<div id="fullWrapper">
			<?php $V->element('hud-site'); ?>
		</div>

			<!-- BEGIN CONTENT -->
			<?php $V->content(); ?> 
			<!-- END CONTENT -->


		<?php $V->footer(); ?> 
		
		<div id="fb-root"></div>

	    <?php $V->element('Scripts/jquery'); ?>

		<!-- build:js(.) /js/website.js -->
		<script src="/js/bower/bootstrap/docs/assets/js/bootstrap-modal.js"></script>
		<script src="/js/bower/bootstrap/docs/assets/js/bootstrap-transition.js"></script>
		<script src="/js/app/website.js"></script>
		<!-- endbuild -->
		
		<?php $V->tail(); ?>

		<?php $V->element('Scripts/uservoice'); ?>
    </body>
</html>