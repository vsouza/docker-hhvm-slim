<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title><?php $V->title('Tamboreen'); ?></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<link rel="shortcut icon" href="/favicon.ico">

		<!-- build:css(.) /assets/css/bootstrap.css -->
		<link rel="stylesheet" href="/js/bower/bootstrap/docs/assets/css/bootstrap.css">
		<!-- endbuild -->

		<!-- build:css(.) /assets/css/main.css -->
		<link rel="stylesheet" href="/assets/css/main.css">
		<!-- endbuild -->

		<!-- javascript -->
		<?php $V->head(); ?>
	</head>
    <body>
    	<div id="fullWrapper" class="clearfix">
			<?php
                $hudData = ['session'=>$_SESSION];
                
                if(isset($trialDaysLeft)) $hudData['trialDaysLeft'] = $trialDaysLeft;
                $V->element('hud',$hudData);
            ?>

			<!-- BEGIN CONTENT -->

			<?php $V->content(); ?>

			<!-- END CONTENT -->
		</div>

		<?php $V->footer(); ?>

		<div id="fb-root"></div>

		<?php $V->element('Scripts/jquery'); ?>
		<?php $V->element('Scripts/main'); ?>
		<?php $V->element('Scripts/i18n'); ?>
		<?php $V->element('Scripts/sdk'); ?>
		<?php $V->element('Scripts/g'); ?>

		<?php $V->tail(); ?>

		<?php $V->element('Scripts/uservoice'); ?>
    </body>
</html>
