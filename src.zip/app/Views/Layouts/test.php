<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title><?php $V->title(); ?></title>
		<meta name="description" content="<?=_('siteHomeMetaDescription')?>">
		<meta name="google-site-verification" content="RMOGmXlH-nRSnHhjZpOW0T5xnqKL3flV_6anMrtRxfw" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<link rel="shortcut icon" href="/favicon.ico">

		<link rel="stylesheet" href="/js/bower/bootstrap/docs/assets/css/bootstrap.css">

		<link rel="stylesheet" href="/js/bower/bootstrap/docs/assets/css/bootstrap-responsive.css">
		<link rel="stylesheet" href="/assets/css/website.css">
		<link rel="stylesheet" href="/assets/css/tests.css">

		<!-- javascript -->
		<?php $V->head(); ?>
	</head>
    <body>
    	<?php $V->element('hud',['session'=>$_SESSION]); ?>

		<!-- BEGIN CONTENT -->
		<?php $V->content(); ?> 
		<!-- END CONTENT -->


		<?php $V->footer(); ?> 
		
		<div id="fb-root"></div>

	    <?php $V->element('Scripts/jquery'); ?>
	    <?php $V->element('Scripts/sdk'); ?>
		<script>function setLanguage(){}</script>
		<?php $V->element('Scripts/g'); ?>

		<!-- build:js(.) /js/website.js -->
		<script src="/js/bower/bootstrap/docs/assets/js/bootstrap-modal.js"></script>
		<script src="/js/bower/bootstrap/docs/assets/js/bootstrap-transition.js"></script>
		<script src="/js/app/website.js"></script>
		<!-- endbuild -->
		
		<?php $V->tail(); ?>
    </body>
</html>