<?php
require(dirname(__FILE__).'/config/bootstrap.php');
(new \app\Shark())->run();