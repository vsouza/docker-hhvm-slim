<?php
	$this->config(array(
		'mode' => 'development',
	    'data_base_url' => 'http://homologa.tamboreen.com.br:8080/com.tamboreen.rest/rest/v1',
	    'solr_host' => 'http://homologa.tamboreen.com.br:8983/solr/',
	    'mysql_host' => 'homologa.tamboreen.com.br',
	    'mysql_db' => 'tamboreen',
	    'mysql_user' => 'tzlike',
	    'mysql_pass' => '^p8$Nn*u4A1i'
	));
?>
