<?php
////////////
// ROUTES //
////////////

$app = $this;

/*
    Routes allowed without authentication
 */

$allowedRoutes = [
    // Website
    '/',
    '/sendcontact',
    '/signup',

    // Login/Logout
    '/login',
    '/logout',

    // Billing
    '/billing*',

    // Internals
    // '/test*',
    '/sys/*',
];

foreach ($app->config('lang.supported') as $short => $lang)
    $allowedRoutes[] = '/'.$short;

$app->config('allowed_routes' , $allowedRoutes);

$app->config('payment_pending_routes', array_merge($allowedRoutes, [
    '/dashboard',
    '/getcampaigns*',
    '/settings*',
    '/updateadaccounts'
]));

/////////////
// WEBSITE //
/////////////

// Home
$app->get('/', function () use($app) {
    if(isset($_SESSION['user']['lang']))
        $lang = $_SESSION['user']['lang'];
    else $lang = $app->config('lang.default');
    setupi18n($lang);
    $app->view()->appendData(['lang' => $lang]);
    (new \Controllers\Website($app))->index();
})->name('home');

// Home languages
foreach ($app->config('lang.supported') as $short => $lang) {
    if($lang==$app->config('lang.default')) continue;
    $app->get('/'.$short, function () use($app, $lang) {
        setupi18n($lang);
        $app->view()->appendData(['lang' => $lang]);
        (new \Controllers\Website($app))->index();
    });
}

// === JSON requests === //

// Send Contact Form
$app->post('/sendcontact', function () use($app) {
    (new \Controllers\Website($app))->sendContact();
});

// E-mail signup
$app->post('/signup', function () use($app) {
    (new \Controllers\Website($app))->signUp();
});

//////////////////
// LOGIN/LOGOUT //
//////////////////

// Login (JS)
$app->post('/login', function () use($app) {
    (new \Controllers\Users($app))->login();
})->name('login');

// Logout
$app->get('/logout', function () use($app) {
    (new \Controllers\Users($app))->logout();
})->name('logout');

// Revoke permissions
$app->post('/revokeconfirm', function () use($app) {
    (new \Controllers\Users($app))->revoke();
})->name('revokeconfirm');

///////////
// USERS //
///////////

// Update Ad Accounts
$app->get('/updateadaccounts', function () use($app) {
    (new \Controllers\Users($app))->updateAdAccounts();
})->name('updateadaccounts');

///////////////
// DASHBOARD //
///////////////

$app->any('/dashboard', function () use($app) {
    (new \Controllers\Dashboard($app))->dashboard();
})->name('dashboard');

// === JSON requests === //

// Get Campaigns //
$app->get('/getcampaigns/:accountId(/:startTime(/:endTime(/:status(/:limit))))', function ($accountId, $startTime = null, $endTime = null, $status = null, $limit = null) use($app) {
    (new \Controllers\Dashboard($app))->load($accountId, $startTime, $endTime, $status, $limit);
})->name('dashboardBack');

///////////
// GOALS //
///////////

// Goal selection
$app->get('/goals', function () use($app) {
    (new \Controllers\Ads($app))->goals();
})->name('goals');

$app->group('/goals', function () use ($app) {

  // Objective #1: Promote post
  $app->get('/post/:accountId', function ($accountId) use($app) {
      (new \Controllers\Ads($app))->goal1($accountId);
  })->name('goal1');

  // Objective #2: Get Likes
  $app->get('/fan/:accountId', function ($accountId) use($app) {
      (new \Controllers\Ads($app))->goal2($accountId);
  })->name('goal2');

  // Objective #3: Get conversions
  $app->get('/conv/:accountId', function ($accountId) use($app) {
      (new \Controllers\Ads($app))->goal3($accountId);
  })->name('goal3');

});

// === JSON requests === //

// Consistency
$app->post('/goal/consistency', function () use($app) {
    (new \Controllers\Campaigns($app))->goal();
})->name('consistency');

////////////////
// AD DETAILS //
////////////////

$app->get('/ad/:accountId/:campaignId/:type', function ($accountId, $campaignId, $type) use($app) {
    (new \Controllers\Ads($app))->adDetails($accountId, $campaignId, $type);
})->name('addetails');

// === JSON requests === //

// Get Master Ad
$app->get('/campaigns/details/getMasterAd(/:campaignId)', function ($campaignId) use($app) {
     (new \Controllers\Campaigns($app))->getMasterAd($campaignId);
});

//////////////
// SETTINGS //
//////////////

// My Account
$app->any('/settings/myaccount', function () use($app) {
    (new \Controllers\Settings($app))->myAccount();
})->name('myaccount');

// Subscription
$app->get('/settings/subscription', function () use($app) {
    (new \Controllers\Settings($app))->subscription();
})->name('subscription');

// Payments
$app->get('/settings/payments', function () use($app) {
    (new \Controllers\Settings($app))->payments();
})->name('payments');

// Notifications
$app->get('/settings/notifications', function () use($app) {
    (new \Controllers\Settings($app))->notifications();
})->name('notifications');

// Extensions
$app->get('/settings/extensions', function () use($app) {
    (new \Controllers\Settings($app))->extensions();
})->name('extensions');

// Revoke Permissions
$app->get('/settings/revoke', function () use($app) {
    (new \Controllers\Settings($app))->revoke();
})->name('revoke');

// === JSON requests === //

// Send conversion Pixel e-mail
$app->post('/settings/pixel/send', function () use($app) {
   (new \Controllers\Ads($app))->sendPixel();
})->name('sendPixel');

///////////////////
// NOTIFICATIONS //
///////////////////

$app->get('/notifications/:qtd/:start', function ($qtd, $start) use($app) {
    (new \Controllers\Notifications($app))->listAll($qtd, $start);
})->name('notificationsList');

$app->get('/notifications/read/:qtd/:start', function ($qtd, $start) use($app) {
    (new \Controllers\Notifications($app))->listAndRead($qtd, $start);
})->name('notificationsRead');

$app->get('/notifications/set/read/:id', function ($id) use($app) {
   (new \Controllers\Notifications($app))->checkAsRead($id);
})->name('notificationsSetRead');

$app->get('/notifications/create/:fbId/:campaignId/:adId/:category/:message/:param1/:param2/:param3', function ($fbId, $campaignId, $adId, $category, $message, $param1, $param2, $param3) use($app) {
   (new \Controllers\Notifications($app))->create($fbId, $campaignId, $adId, $category, $message, $param1, $param2, $param3);
})->name('notificationsCreate');

//////////////////
// SESSION DATA //
//////////////////

$app->any('/session/set(/:key/:value)', function ($key = null, $value = null) use($app) {
   (new \Controllers\Users($app))->setSessionData($key, $value);
})->name('setSessionData');

$app->get('/session/remove/:key', function ($key) use($app) {
   (new \Controllers\Users($app))->unsetSessionData($key);
})->name('unsetSessionData');

$app->get('/session/get/:key/', function ($key) use($app) {
   (new \Controllers\Users($app))->getSessionData($key);
})->name('getSessionData');

////////////
// UPLOAD //
////////////

$app->post('/upload/s3', function () use($app){
    (new \Controllers\Upload($app))->s3Upload();
})->name('s3Upload');

$app->post('/upload/fb/photo', function () use($app){
    (new \Controllers\Upload($app))->uploadPhotoFb();
})->name('uploadPhotoFb');

$app->post('/upload/fb/album/photo', function () use($app){
    (new \Controllers\Upload($app))->uploadAlbumPhotoFb();
})->name('uploadAlbumPhotoFb');

$app->post('/upload/fb/video', function () use($app){
    (new \Controllers\Upload($app))->uploadVidFb();
})->name('uploadVidFb');


/////////////
// BILLING //
/////////////


$app->post('/billing/profile/create', function () use($app){
    (new \Controllers\Subscriptions($app))->create();
})->name('createSubscription');

$app->post('/billing/subscription/cancel', function () use($app){
    (new \Controllers\Subscriptions($app))->cancel();
})->name('cancelSubscription');

$app->get('/billing', function () use($app){
    (new \Controllers\Plans($app))->plans();
})->name('getPlans');


$app->get('/billing/paypal/return', function () use($app){
    (new \Controllers\Subscriptions($app))->receiveReturn();
})->name('receiveReturn');

$app->get('/billing/paypal/cancel', function () use($app){
    (new \Controllers\Subscriptions($app))->receiveCancel();
})->name('receiveCancel');


//////////////////
// SEGMENTATION //
//////////////////

$app->post('/segmentation/url', function () use($app) {
   (new \Controllers\Segmentation($app))->goalWebsite(null);
})->name('getSiteData');

$app->post('/segmentation/fbpage', function () use($app) {
   (new \Controllers\Segmentation($app))->goalPages();
})->name('getSiteFbPage');


if($app->getMode()=='development') {

    ////////////////////
    // TESTING ROUTES //
    ////////////////////

    $app->get('/test', function () use($app) {
        (new \Controllers\Tests($app))->test();
    });

    $app->get('/test/elements', function () use($app) {
        (new \Controllers\Tests($app))->elements();
    });

}