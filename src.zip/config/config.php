<?php
////////////////////
// CONFIGURATIONS //
////////////////////

// Server (Environment and DB) 
require_once(ROOTPATH.'/config/server.php');

// Languages
$this->config(array(
    'lang.default'=> (strpos($_SERVER['SERVER_NAME'], '.br') === false) ? 'en_US' : 'pt_BR',
    'lang.supported'=> ['pt'=>'pt_BR','en'=>'en_US'],
    'lang.strftime'=> ['pt_BR'=>'%d/%m/%y','en_US'=>'%m/%d/%y'],
));

/**
 * Default configurations
 */

$this->config(array(

    // Views path
    'templates.path' => ROOTPATH . (defined('BUILD') ? '/build/Views' : '/app/Views'),

    // Facebook Auth
    'fb.scope' => 'email,ads_management,manage_pages,read_insights',
    'fb.scope.check' => 'public_profile,ads_management,manage_pages,read_insights',
    'fb.scope.future' => 'offline_access,user_videos',
    'fb.graphurl' => 'https://graph.facebook.com/v2.2',

    // Cookies
    'cookies.lifetime' => '1 month',
    'cookies.domain' => 'tamboreen.com.br',
    'cookies.name' => 'tamboreen_session',

    // Billing
    'billing.tolerance_days' => 3,

    // Video filetypes allowed
    'allowed.video' => ['3g2', '3gp', '3gpp', 'asf', 'avi', 'dat', 'divx','dv','f4v','flv','m2ts','m4v','mkv','mod','mov', 'mp4', 'mpe', 'mpeg', 'mpeg4', 'mpg', 'mts', 'nsv', 'ogm'],

));

/**
 * Environment configurations
 */

$appMode = $this->getMode();

/*
   'development' and 'homologation' mode 
 */

if( ($appMode=='development') || ($appMode=='homologation') ) {

    // Show errors
    error_reporting(E_ALL);
    ini_set('display_errors', 1);

    $this->config(array(

        // Development Facebook App
        'fb.appid' => '651148168276399',
        'fb.appsecret' => 'c75fc1ae520e63cbb8f0726b2f6a7873',

        // Paypal
        'billing.trial.duration' => 30,
        'billing.return.url' => "http://".$_SERVER["HTTP_HOST"]."/billing/paypal/return",
        'billing.cancel.url' => "http://".$_SERVER["HTTP_HOST"]."/subscription",
        'billing.paypal.currency.code' => "BRL",
        'billing.paypal.max.failed' => 3,
        'billing.paypal.logo.img' => "http://tamboreen.com.br/assets/img/6ce80b10.topLogo.png",
        'billing.paypal.header.img' => "http://tamboreen.com.br/assets/img/6ce80b10.topLogo.png",
        'billing.paypal.signature' => "AFcWxV21C7fd0v3bYYYRCpSSRl31AdOrTqOq97vvBchYOv5.w79X0VcA'",
        'billing.paypal.user' => "vinicius-facilitator_api1.codemakers.com.br",
        'billing.paypal.pwd' => "1396901459",
        'billing.paypal.version' => "65.1",
        'billing.paypal.checkout.url' => "https://www.sandbox.paypal.com/webscr?cmd=_express-checkout&useraction=commit",
        'billing.paypal.nvp.url' => "https://api-3t.sandbox.paypal.com/nvp",

        // Mixpanel
        'mixpanel.token' => 'a64386a3e6d14a8ff752bbc45bf99b79',

        // Log
        'log.writer' => new \Slim\Extras\Log\DateTimeFileWriter(array(
            'debug' => true,
            'log.enabled' => true,
            'path' => ROOTPATH.'/logs',
            'name_format' => 'Y-m-d',
            'message_format' => "%label% - %date%\n%message%\n---------------"
        )),

    ));

    // DebugBar
    if(isset($_GET['debugbar'])) {
        $this->debugbar = new DebugBar\StandardDebugBar();
        $this->debugbar['messages']->aggregate(new DebugBar\Bridge\SlimCollector($this));
    }

};

/*
    'production' mode
 */

$this->configureMode('production', function () {

    // Hide errors
    error_reporting(0);
    ini_set('display_errors', 0);

    $this->config(array(

        // Production Facebook App
        'fb.appid' => '643154229038051',
        'fb.appsecret' => 'bd7f5e1ccec6d03205caf68aa13168dc',

        // Paypal
        'billing.trial.duration' => 30,
        'billing.return.url' => "http://".$_SERVER["HTTP_HOST"]."/billing/paypal/return",
        'billing.cancel.url' => "http://".$_SERVER["HTTP_HOST"]."/subscription",
        'billing.paypal.currency.code' => "BRL",
        'billing.paypal.max.failed' => 3,
        'billing.paypal.logo.img' => "http://tamboreen.com.br/assets/img/6ce80b10.topLogo.png",
        'billing.paypal.header.img' => "http://tamboreen.com.br/assets/img/6ce80b10.topLogo.png",
        'billing.paypal.signature' => "AS.tufDLqaurxVzRMTVN7kHlJ7G9Akf1kOXSw0LgchTTEqxp1F2m6lac",
        'billing.paypal.user' => "contato_api1.tamboreen.com.br",
        'billing.paypal.pwd' => "EFN8CVR362EGC3WA",
        'billing.paypal.version' => "65.1",
        'billing.paypal.checkout.url' => "https://www.paypal.com/webscr?cmd=_express-checkout&useraction=commit",
        'billing.paypal.nvp.url' => "https://api-3t.paypal.com/nvp",

        // Mixpanel
        'mixpanel.token' => '7908078b22f476ec81f4959ad9b1f88c',

        // Disable debugging
        'debug' => false,
    ));
});

/*
    'test' mode
 */

$this->configureMode('test', function () {
    $this->config(array(
        'data_baseurl' => 'http://ec2-54-205-105-15.compute-1.amazonaws.com:8080/com.tamboreen.rest/rest/v1/',
        'solr_baseurl' => 'http://ec2-54-205-105-15.compute-1.amazonaws.com:8983/solr/',
    ));
});
