<?php
//////////////////////////
// INTERNATIONALIZATION //
//////////////////////////

/**
 * PHP Gettext
 */
if(!function_exists('_')) {
	require(ROOTPATH .'/vendor/php-gettext/gettext.inc');
	define('PHPGETTEXT', true);
}

// GetText helper functions

function _s($msgid, $n) {
    return sprintf(_($msgid), $n);
}

function _n($msgid, $n) {
    return sprintf(ngettext($msgid, $msgid."_p", $n), $n);
}

/**
 * Setup Internationalization
 */
function setupi18n($locale = 'pt_BR', $domain = 'messages') {

	if(!in_array($locale, \Slim\Slim::getInstance()->config('lang.supported')))
		$locale = "en_US";

	putenv("LANG=$locale");
	if(defined('PHPGETTEXT')) T_setlocale(LC_ALL, $locale);
	else setlocale(LC_ALL, $locale);
    setlocale(LC_TIME, $locale);
	bindtextdomain($domain, ROOTPATH .'/locale');
	bind_textdomain_codeset($domain, 'UTF-8');
	textdomain($domain);
}
?>