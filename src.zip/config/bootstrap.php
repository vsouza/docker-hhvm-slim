<?php
///////////////////////////
// APPLICATION BOOTSTRAP //
///////////////////////////

// Root path
define('ROOTPATH', dirname(dirname(__FILE__)));

// Session
session_cache_limiter(false);
session_start();

// Timezone
date_default_timezone_set("America/Sao_Paulo");

// Composer Autoload
require(ROOTPATH .'/vendor/autoload.php');

// Internationalization
require(ROOTPATH .'/config/i18n.php');