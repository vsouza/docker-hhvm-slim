////////////////////////////
// DEFAULT CONFIGURATIONS //
////////////////////////////

var DEF_CONFIG = (function() {
    var c = {
        LANGUAGE: 'pt_BR',
        REGIONAL: LANGUAGES.pt_BR,
        ASSETSPATH: 'assets'
    };
    return {
        get: function(name) {
            return c[name];
        }
    };
})();


/* ajax timeout config */
$.ajaxSetup({
    timeout: 10000 //Time in milliseconds
});
