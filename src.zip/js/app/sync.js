// ↓ Objeto global do sync
if (window['g'] == undefined) {
    var g = {};
}
g.syncFlag = false;
g.syncUri = '/sync/all/' + window.g.token;

// ↓ Função que starta os comportamentos Js do modal #modalSynchronization

function modalSynchronizationPrepare(opt) {
    try {
        var idModal = 'div#modalSynchronization';
        var updateBtn = $('div.modal-footer > button', idModal);

        //ação de salvar parametros do modal
        updateBtn.unbind('click').bind('click', function() {
            var cls = updateBtn.attr('class').split(' ');

            if (!inArray('btn-modal-disabled', cls))
                $(idModal).modal('hide');
        });

        // chama a sincronização 
        getSynchronization();

        //exibe o modal
        $(idModal).modal(opt);
    } catch (e) {
        console.log('modalSynchronizationPrepare() : ', e);
    }
}

// ↓ Função que efetua a sincronização de fato

function getSynchronization() {
    // setando default
    $('#modalSynchronization > div.modal-footer > button').attr('class', 'btn-modal-disabled');
    window.g.syncFlag = false;
    var li = $('#modalSynchronization ul > li');
    var liLen = $('#modalSynchronization ul > li').length;
    li.removeClass('done');

    // animação do sync
    var interval = setInterval(function() {
        var liDone = $('#modalSynchronization ul > li.done').length;

        for (i = 0; i < liLen; i++) {
            if (liDone == liLen) {
                li.removeClass('done');
                li.eq(0).addClass('done');
                break;
            }

            if (i <= liDone)
                li.eq(i).addClass('done');
        }

        if (window.g.syncFlag)
            clearInterval(interval);
    }, 500);

    window.setTimeout(function() {
        $.ajax({
            type: 'GET',
            url: window.g.syncUri,
            dataType: 'json',
            cache: false,
            crossDomain: true,
            success: function(retur) {
                try {
                    console.log('getSynchronization()', retur);
                    handleGetSynchronization(retur);
                } catch (e) {
                    console.log('getSynchronization().successError: ', e);
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.log('getSynchronization().error: ', jqXHR, textStatus, errorThrown);
            }
        });
    }, 2000);
}

// ↓ Função que lida com o resultado da sincronização

function handleGetSynchronization(data) {
    var syncContainer = $('#modalSynchronization > div.modal-body > div.syncContainer');
    var spanMsg = $('#modalSynchronization > div.modal-body > div.syncContainer > div:nth-child(2) > span');
    var syncBtn = $('#modalSynchronization > div.modal-footer > button');
    var out = '';

    try {
        if (!inObject('success', data)) throw 'invalid success response';
        if (!inObject('code', data)) throw 'invalid code response';
        if (!data.success) throw data.code;

        if (!isNaN(data.code)) {
            switch (data.code) {
                case 751:
                    out = _('msgSync751');
                    break;
                default:
                    out = 'success';
                    break;
            }
        }
        // troca dos loading para verde de finish
        $('#modalSynchronization > div.modal-body > div.syncContainer > div:nth-child(2) > ul > li').attr('class', 'finish');

        // evento click no caso de sucesso 
        syncBtn.text(_('labFinish')).attr('class', 'btn-green').unbind('click').bind('click', function() {
            window.location.href = window.location.origin;
        });

    } catch (e) {
        console.log('handleGetSynchronization():', e);
        syncContainer.addClass('error');
        out = _('msgSyncError');

        // evento click no caso de erro
        syncBtn.text(_('btnRetry')).attr('class', 'btn-green').unbind('click').bind('click', function() {
            getSynchronization();
        });
    } finally {
        spanMsg.text(out);
        window.g.syncFlag = true;
    }
}



$(document).ready(function() {
    try {

        showModal('#modalSynchronization', {
            backdrop: 'static',
            keyboard: false,
            closeButton: false
        });

        /* definição de parametros regionais da ferramenta + aplicação de máscara*/
        CreateClass.Regional().setMaskForAll('mask', null);
    } catch (e) {
        console.log('sync.php.js : ' + e);
    }
});