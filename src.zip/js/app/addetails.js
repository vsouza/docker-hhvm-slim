window.g.creative = {
	imgUrl: null,
	imgHash: null,
	imgWidth: null,
	imgHeight: null,
}; // objeto utilizado para auxílio com tratamento de constução do objeto Ad Creative
window.g.ppFields = 'name, message, story, type, timeline_visibility, link, picture, full_picture, created_time, is_published'; // campos escolhidos para efetuar busca de posts promovíveis
window.g.ppArr = null; // objeto que armazenará posts promovíveis
window.g.uriPostAccountLibrary = '/upload/fb/album/photo'; // url para fazer upload de imagens via backend
window.g.mustUploadImg = false; // flag para decisão de subir ou não uma imagem para alteração do anúncio
window.g.objEditAd = null; // objeto para guardar temporariamente um Ad Creative para alteração do anúncio
window.g.stpDateTimePickerSet = false; // flag de instância do datetimepicker

var timezoneName = ((window.g.accountId && !isNaN(window.g.accountId) && window.g.adaccounts instanceof Object) ? window.g.adaccounts[window.g.accountId].timezone_name : 'America/Sao_Paulo');

//////////////////////
// FACEBOOK OBJECTS //
//////////////////////
var adAccount = new api.AdAccount('act_' + window.g.accountId);
var adSet;
var adSetStats;
var adGroups = [];
var adGroupsStats;

// Action dictionary
var FB_AD_ACTIONS = {
	clicks: 'LabClick',
	comment: 'Comments',
	like: 'Likes',
	post_like: 'Likes',
	video_view: 'Video',
	video_play: 'Actions',
	post: 'Actions',
	link_click: 'Actions',
	follow: 'Actions',
	app_install: 'Actions',
	app_use: 'Actions',
	checkin: 'Actions',
	mention: 'Actions',
	mobile_app_install: 'Actions',
	offsite_ersion: 'Actions',
	photo_view: 'Actions',
	receive_offer: 'Actions',
	recommendation: 'Actions',
	rspv: 'Actions',
	tab_view: 'Actions',
	vote: 'Actions',
};

// Loadr Options
var spinnerOpts = {
	zIndex: 1,
	lines: 8,
	length: 2,
	width: 2,
	radius: 3,
	color: '#7b98d3'
};

///////////////
// DOM READY //
///////////////

$(document).ready(function() {
	fullLoader(null, null, 'fullLoaderBg', 0);
	adSet = new api.AdSet(window.g.campaignId, adAccount.id);
	setJqueryExtensions();
	getFbCampaignData();
	setAccountCurrency(window.g.adaccounts[window.g.accountId].currency);
	var adAccountCurrencySymbol = LANGUAGES[FB_LANGS[window.g.adaccounts[window.g.accountId].currency]].locale.currencySymbol;
    $('.currencySymbol').html(adAccountCurrencySymbol);
});

/**
 * JQuery extensions
 */
function setJqueryExtensions() {
	var popoverOnShow = $.fn.popover.Constructor.prototype.show;
	$.fn.popover.Constructor.prototype.show = function() {
		popoverOnShow.call(this);
		if (this.options.onShow) {
			this.options.onShow(this);
		}
	};

	var popoverOnClose = $.fn.popover.Constructor.prototype.hide;
	$.fn.popover.Constructor.prototype.hide = function() {
		popoverOnClose.call(this);
		if (this.options.onHide) {
			this.options.onHide(this);
		}
	};

	var datetimepickerOnShow = $.fn.datetimepicker.Constructor.prototype.show;
	$.fn.datetimepicker.Constructor.prototype.show = function() {
		datetimepickerOnShow.call(this);
		if (this.options.onShow) {
			this.options.onShow(this);
		}
	};

	var datetimepickerOnClose = $.fn.datetimepicker.Constructor.prototype.hide;
	$.fn.datetimepicker.Constructor.prototype.hide = function() {
		datetimepickerOnClose.call(this);
		if (this.options.onHide) {
			this.options.onHide(this);
		}
	};
}

/////////////////////////
// FACEBOOK OPERATIONS //
/////////////////////////

/**
 * Buscar dados da campanha
 */
function getFbCampaignData() {
	//validate model
	if (!window.g.hasOwnProperty('campaignId') || isNaN(window.g.campaignId)) {
		showError('invalidCampaignObject');
		return;
	}
	adSet.read(['name','lifetime_budget','daily_budget','campaign_status','start_time','end_time'])
		.then(parseFbCampaignData)
		.catch(showError);
}

/**
 * Aplica dados da campanha
 * @param  {Object} result  Resultado do request
 */
function parseFbCampaignData() {
	Campaign = adSet;
	renderHeader(adSet.campaign_status);
	initCampaignName(adSet.name);
	getFbCampaignStats();
	getFbCampaignAds();
}

/**
 * Busca estatísticas da campanha
 */
function getFbCampaignStats() {
	var params = {start_time: adSet.start_time};
	if(adSet.end_time)
		params.end_time = adSet.end_time;
	adSet.getAdStatistics(null, params).then(function(stats) {
		adSetStats = stats;
		initCampaignData();
		renderCampaignResults();
	}).catch(showError);
}

/**
 * Busca os anúncios da Campanha
 */
function getFbCampaignAds() {
	$('#ads').spin(spinnerOpts); // ads loader
	adSet.getAdGroups(['name','adgroup_status','creative_ids','bid_type','adgroup_review_feedback','bid_info','objective']).then(function(response) {
		adGroups = response;
		getFbAdsStats();
	}).catch(showError);
}


/**
 * Busca estatísticas dos anúncios
 */
function getFbAdsStats() { 
	//Get ad ids
	var adIds = [];
	for (var i = 0; i < adGroups.length; i++) {
		adIds.push(adGroups[i].id);
	};

	var params = {start_time: adSet.start_time};
	if(adSet.end_time)
		params.end_time = adSet.end_time;
	adAccount.getAdGroupStats(adIds, params).then(function(stats) {
		adGroupsStats = stats;
		renderAds();
	}).catch(showError);
}

/**
 * Altera Status da Campanha
 * @param {[type]} button) { console.log('setCampaignStatus' [description]
 */
function setCampaignStatus(button) {
	if (button.attr('lock')) return;

	button.attr('lock', 1);
	enableButtonLoader(button);

	// Lock all ads
	$('.statuscell').each(function() {
		enableAdLoader($(this));
	})

	adSet.campaign_status = button.attr("setStatus");;
	adSet.update()
		.then(function() {
			var campaign_status = $('#btnCampaignToogle').attr('setstatus');
			renderHeader();
			reloadAds();
		})
		.catch(function(response) {
			disableButtonLoader($('#btnCampaignToogle'));
			$('.statuscell').each(function() {
				disableAdLoader($(this));
			})
			showError(response);
		});
}

/**
 * Limpa anúncios e estatísticas e busca novos dados
 */
function reloadAds() {
	adGroups = [];
	adGroupsStats = {};
	$('#campaignvariations').remove();
	getFbCampaignAds();
}

/**
 * Altera status do anúncio
 * @param {DOMObject} button
 */
function setAdStatus(button) {
	var status = parseInt(button.val());
	var td = button.parent();
	var adGroupId = td.attr('id');

	enableAdLoader(td);

	if (status == 1) {
		//start
		button.selectpicker('setStyle', 'red', 'remove');
		status = "ACTIVE";
	} else {
		//Pause
		button.selectpicker('setStyle', 'red', 'add');
		status = "PAUSED";
	}

	var adGroup = new api.AdGroup(adGroupId);
	adGroup.adgroup_status = status;
	adGroup.update().then(function(result) {
		renderAdStatus(adGroupId, result);
	}).catch(showError);
}

/**
 * Renderiza status da campanha alterado
 * @param  {int} 	ad  	Id do ad
 * @param  {Object} result  Resultado do request
 */
function renderAdStatus(ad, result) {
	try {
		if (!ad || isNaN(ad)) {
			showError('errorChangingAdStatus', result.error.message);
			return;
		}

		var button = $('td.statuscell[id=' + ad + '] select');
		var status = parseInt(button.val());
		var td = button.parent();
		var id = td.attr('id');

		//Validate response
		if (result instanceof Object && !$.isEmptyObject(result) && result.hasOwnProperty('error') && result.error && result.error.hasOwnProperty('message')) {

			//Back last status on error
			if (status == 1) {
				//start
				button.selectpicker('setStyle', 'red', 'remove');
			} else {
				//Pause
				button.selectpicker('setStyle', 'red', 'add');
			}

			//remove loader
			disableButtonLoader(td);

			//throw exception
			showError('errorChangingAdStatus', result.error.message);
			return;
		}

		//Validate response
		if (!result) {
			//Back last status on error
			if (status == 1) {
				//start
				button.selectpicker('setStyle', 'red', 'remove');
			} else {
				//Pause
				button.selectpicker('setStyle', 'red', 'add');
			}

			//remove loader
			disableButtonLoader(td);

			//throw exception
			showError('errorChangingAdStatus');
			return;
		}

		if (status != 1)
			status = 9;

		// TODO check
		// if (status == 1 && adSet.hasOwnProperty('campaign_status') && adSet.campaign_status && !isNaN(adSet.campaign_status)) {
		// 	if (parseInt(adSet.campaign_status) == 2)
		// 		status = 8;
		// 	else if (parseInt(adSet.campaign_status) == 3)
		// 		status = 3;
		// }

		td.html(getAdStatus(status));
		if ($('select', $(td)).length > 0)
			setSelectPickers($('select', $(td)));

		checkAdStatus([{
			id: ad,
			status: status
        }])
	} catch (e) {
		pageError('errorChangingAdStatus');
		console.log('errorChangingAdStatus', e);
	}
}

/**
 * Exlui a campanha
 */
function excludeCampaign() {
	try {
		fullLoader(null, null, 'fullLoaderBg', 0);
		adSet.delete().then(parseFbCampaignDelete).catch(showError);
	} catch (e) {
		if ($('#fullLoader00').is(':visible'))
			fullLoaderStop();

		showError('errorDeletingCampaign');
		console.log('excludeCampaign: ' + e);
	}
}

/**
 * Atualiza elementos de status da campanha
 * @param  {Object} result  Resultado do request
 */
function parseFbCampaignDelete(result) {
	try {
		//Validate response
		if (result && result.hasOwnProperty('error') && result.error && result.error.hasOwnProperty('message')) {
			if ($('#fullLoader00').is(':visible'))
				fullLoaderStop();

			//throw exception
			showError('invalidFacebookResponseOnDeleteCampaign', result.error.message);
			return;
		}

		if (result != true) {
			if ($('#fullLoader00').is(':visible'))
				fullLoaderStop();
			showError('errorDeletingCampaign');
		}

		window.location.reload();
	} catch (e) {
		showError('errorDeletingCampaign');
		console.log('parseFbCampaignDelete: ' + e);
	}
}

/////////////////////
// UI INTERACTIONS //
/////////////////////

/**
 * Removes Ad Interactions if AdSet is DELETED
 * @return {[type]} [description]
 */
function checkCampaignStatus() {
	if(adSet.campaign_status === 'DELETED')
		$('[data-interaction=ad],[data-interaction=campaign]').remove();
}

function checkAdStatus(ads) {
	try {
		if (!ads || !$.isArray(ads) || ads.length <= 0)
			return;

		for (var ad in ads) {
			if (!ads[ad].hasOwnProperty('id') || isNaN(ads[ad]['id']) || !ads[ad].hasOwnProperty('status') || (typeof ads[ad]['status'] != 'string' && typeof ads[ad]['status'] != 'number'))
				continue;

			switch (ads[ad]['status']) {
				case "ACTIVE":
				case 1:
				case "PAUSED":
				case 9:
				case "CAMPAIGN_PAUSED":
				case 8:
				case "PENDING_REVIEW":
				case 4:
				case "ARCHIVED":
					break;
				case "DELETED":
				case 3:
				case "DISAPPROVED":
				case 5:
				case "PENDING_BILLING_INFO":
				case 7:
					if ($('tbody tr[data-ref=' + ads[ad]['id'] + ']').length > 0) {
						$('tbody tr[data-ref=' + ads[ad]['id'] + '] td button[data-ad-action=edit]').remove();
						$('tbody tr[data-ref=' + ads[ad]['id'] + '] td button[data-ad-action=delete]').remove();
					}

					break;
			}
		}
	} catch (e) {
		console.log('checkAdStatus', e);
	}
}

/**
 * Renderiza cabeçalho
 * @param  {string} campaign_status) Status da campanha
 */
function renderHeader() {
	CreateClass.MyHandlebars(Campaign, "header").simpleRender();

	$('#btnCampaignToogle').click(function() {
		setCampaignStatus($(this));
	});

	$('#btnExclude').click(function() {
		excludeCampaign();
	});

	checkCampaignStatus();
}

/**
 * Inicializa comportamento de edição do nome da campanha
 * @param  {string} name Nome da campanha
 */
function initCampaignName(name) {
	var input = $('input#campaignName');
	input.val(name);

	$('#btnEditCampaignName').click(function() {
		if (input.attr('readonly')) {
			input.addClass('edit').removeAttr('readonly').focus();
			$(this).addClass('save');
		} else {
			$(this).prop('disabled', true);
			$(input).prop('disabled', true);
			enableButtonLoader($(this)); // enable loader on button
			var newName = input.val();
			adSet.name = newName;
			adSet.update().then(renderCampaignName).catch(showError);
		}
	});
}

/**
 * Renderiza elementos do nome da campanha
 * @param  {Object} result  Resultado do request
 */
function renderCampaignName(result) {
	disableButtonLoader($('#btnEditCampaignName'));
	$('#btnEditCampaignName').prop('disabled', false);
	$('input#campaignName').prop('disabled', false);

	if (!result.success) {
		showError('errorChangingCampaignName');
		return;
	}

	//change input properties
	$('input#campaignName').removeClass('edit').attr('readonly', '');
	//change button label
	$('#btnEditCampaignName').removeClass('save');
}

/**
 * Inicializa comportamento do botão de edição de orçamento
 */
function setCampaignBudgetEditable() {
	try {
		if ($('#btnBudget').attr('lock'))
			return;

		$('#btnBudget').attr('lock', 1);

		$('#btnBudget').removeClass('save').unbind('click').click(function() {
			$(this).addClass('save').unbind('click').click(function() {
				setCampaignBudget();
				$(this).removeClass('save');
			});

			$('#budget').prop('readonly', 0).addClass('edit').focus();

			CreateClass.Regional().setMaskForAll('mask', null);
		});
	} catch (e) {
		console.log('setCampaignBudgetEditable', e);
	}
}

/**
 * Atualiza orçamento da campanha
 */
function setCampaignBudget() {
	enableButtonLoader($('#btnBudget'));
	$('#budget').prop('readonly', 1).removeClass('edit');
	var budget = tryParse($('#budget').val(), 'fbMoney', 0);

	if (adSet.hasOwnProperty('lifetime_budget') && adSet.lifetime_budget > 0)
		adSet.lifetime_budget = budget;
	if (adSet.hasOwnProperty('daily_budget') && adSet.daily_budget > 0)
		adSet.daily_budget = budget;

	adSet.update().then(renderCampaignBudget).catch(showError);
}

/**
 * Renderiza elementos de orçamento da campanha
 * @param  {Object} result  Resultado do request
 */
function renderCampaignBudget(result) {
	try {
		//backward buttons status
		disableButtonLoader($('#btnBudget'));
		$('#btnBudget').removeAttr('lock');
		setCampaignBudgetEditable();

		//Validate response
		if (result instanceof Object && !$.isEmptyObject(result) && result.hasOwnProperty('error') && result.error && result.error.hasOwnProperty('message')) {
			//throw exception
			showError('errorChangingCampaignBudget', result.error.message);
			return;
		}

		//Validate response
		if (!result) {
			//throw exception
			showError('errorChangingCampaignBudget');
			return;
		}
	} catch (e) {
		pageError('errorChangingCampaignBudget');
		console.log('renderCampaignBudget', e);
	}
}

/**
 * Inicializa dados da campanha
 */
function initCampaignData() {
	try {
		// Set budget values
		if (adSet.hasOwnProperty('lifetime_budget') && adSet.lifetime_budget > 0) {
			$('#campaigndata span:first h3').html(_('hBudget') + ' (' + _('fbLblBudgetTypeLifetime') + ')');
			$('#budget').val(adSet.lifetime_budget);
		} else if (adSet.hasOwnProperty('daily_budget') && adSet.daily_budget > 0) {
			$('#campaigndata span:first h3').html(_('hBudget') + ' (' + _('fbLblBudgetTypeDaily') + ')');
			$('#budget').val(adSet.daily_budget);
		} else {
			showError('invalidCampaignBudget');
			return;
		}

		setCampaignBudgetEditable();

		// Set spent values
		// Set budget and spent format
		// Current Ad Account Locale
		var locale = LANGUAGES[FB_LANGS[window.g.adaccounts[window.g.accountId].currency]].locale.currencySymbol;

		$('#investment').val(adSetStats.hasOwnProperty('spent') && !isNaN(adSetStats.spent) ? adSetStats.spent : 0).currency({
			region: locale.currency,
			thousands: locale.thousandSymbol,
			decimal: locale.decimalSymbol,
			decimals: locale.decimalCount,
			hidePrefix: false,
			hidePostfix: true,
		});

		initDatePickers();

	} catch (e) {
		console.log('initCampaignData', e);
	}
}

/**
 * Inicaliza elementos de seleção de datas
 */
function initDatePickers() {
	try {
		// instanciando elementos datetimepicker que serão usados no passo 4
		if (!window.g.stpDateTimePickerSet) {
			window.g.stpDateTimePickerSet = true;

			var currentAccountDate = moment().tz(timezoneName).format();
			var startCampaignDate = moment(adSet.hasOwnProperty('start_time') && adSet.start_time ? adSet.start_time : '').tz(timezoneName).format();
			var endCampaignDate = moment(adSet.hasOwnProperty('end_time') && adSet.end_time ? adSet.end_time : '').tz(timezoneName).format();

			var started = moment(startCampaignDate).isBefore(currentAccountDate);
			var ended = moment(endCampaignDate).isBefore(currentAccountDate);

			adSet.started = started;
			adSet.ended = ended;

			// TODO check
			// if ( (!started || ended) && (adSet.campaign_status != 'DELETED') && (adSet.campaign_status != 'ARCHIVED') ) { // TODO mudar pra número quando mudar no GET
			// 	adSet.campaign_status = ended ? 4 : 5;
			// 	renderHeader(adSet.campaign_status);
			// 	checkCampaignStatus();
			// }

			$('#startdate').val(moment(adSet.hasOwnProperty('start_time') && adSet.start_time ? adSet.start_time : '').tz(timezoneName).format(window.g.dateTime24)).attr({
				'data-format': window.g.componetSetup.datetimepicker.format,
			});
			if (!started) {
				$('[data-objective=openStartDate]').click(function() {
					$('[data-objective=openStartDate]').attr('close', 'false');
					changeCampaignStartDate();
				});

				$('#startDatePicker').datetimepicker({
					format: window.g.componetSetup.datetimepicker.format,
					language: window.g.componetSetup.datetimepicker.language,
					orientation: 'left',
					startDate: moment({
						hour: 0
					}).toDate(),
					onHide: function(e) {
						$('#startdate').val(moment(adSet.hasOwnProperty('start_time') && adSet.start_time ? adSet.start_time : '').tz(timezoneName).format(window.g.dateTime24));
						window.setTimeout(function() {
							if ($('[data-objective=openStartDate]').attr('close') != 'false') {
								$('[data-objective=openStartDate]').css({
									'visibility': 'hidden'
								});
							}
						}, 300)
					},
					onShow: function(e) {
						$('[data-objective=openStartDate]').css({
							'visibility': 'visible'
						});
					}
				}).on('changeDate', function(e) {
					startDateChange(e);
				});
			} else {
				$('#startDatePicker button').css({
					'display': 'none'
				});
			}

			if (adSet.hasOwnProperty('end_time')) {
				$('#enddate').val(moment(adSet.hasOwnProperty('end_time') && adSet.end_time ? adSet.end_time : '').tz(timezoneName).format(window.g.dateTime24)).attr({
					'data-format': window.g.componetSetup.datetimepicker.format,
				});

				$('[data-objective=openEndDate]').click(function() {
					$('[data-objective=openEndDate]').attr('close', 'false');
					changeCampaignEndDate();
				});

				$('#endDatePicker').datetimepicker({
					format: window.g.componetSetup.datetimepicker.format,
					language: window.g.componetSetup.datetimepicker.language,
					orientation: 'left',
					startDate: moment({
						hour: 0
					}).toDate(),
					onHide: function(e) {
						$('#enddate').val(moment(adSet.hasOwnProperty('end_time') && adSet.end_time ? adSet.end_time : '').tz(timezoneName).format(window.g.dateTime24));
						window.setTimeout(function() {
							if ($('[data-objective=openEndDate]').attr('close') != 'false') {
								$('[data-objective=openEndDate]').css({
									'visibility': 'hidden'
								});
							}
						}, 300)
					},
					onShow: function(e) {
						$('[data-objective=openEndDate]').css({
							'visibility': 'visible'
						});
					}
				}).on('changeDate', function(e) {
					endDateChange(e);
				});

			} else {
				$('#endDatePicker button').remove();
				$('#enddate').val(' - ');
			}
		}
	} catch (e) {
		console.log('initDatePickers', e);
	}
}

/**
 * Aplica mudança na data inicial da campanha no objeto
 * @param  {DOMObject} e
 */
function startDateChange(e) {
	try {
		var currentAccountDate = moment().tz(timezoneName).format();
		var startCampaignDate = moment.tz(moment(e.localDate).format('YYYY-MM-DDTHH:mm:ss'), timezoneName).format();

		if (moment(startCampaignDate).isBefore(currentAccountDate)) {
			$('#startDatePicker').datetimepicker('hide');
			$('#startdate').val(moment(adSet.hasOwnProperty('start_time') && adSet.start_time ? adSet.start_time : '').tz(timezoneName).format(window.g.dateTime24));
			showError('invalidStartCampaignDate');
			return;
		}

		$('#startdate').val(moment(adSet.hasOwnProperty('start_time') && adSet.start_time ? adSet.start_time : '').tz(timezoneName).format(window.g.dateTime24));
		adSet.start_time_to_change = startCampaignDate;
	} catch (e) {
		console.log('startDateChange', e);
	}
}

/**
 * Altera dada inicial da campanha
 */
function changeCampaignStartDate() {
	try {
		var currentAccountDate = moment().tz(timezoneName).format();
		var startCampaignDate = adSet.hasOwnProperty('start_time_to_change') ? adSet.start_time_to_change : null;

		if (startCampaignDate == null) {
			$('[data-objective=openStartDate]').attr('close', '').css({
				'visibility': 'hidden'
			});
			return;
		}

		if (moment(startCampaignDate).isBefore(currentAccountDate)) {
			showError('invalidStartCampaignDate');
			return;
		}

		enableButtonLoader($('[data-objective=openStartDate]'));
		adSet.start_time = startCampaignDate;
		adSet.update().then(renderCampaignStartDate).catch(function(response) {
			$('[data-objective=openStartDate]').attr('close', '').css({
				'visibility': 'hidden'
			});
			showError(response);
		});
	} catch (e) {
		console.log('changeCampaignStartDate', e);
	}
}

/**
 * Renderiza data inicial alterada
 * @param  {Object} result  Resultado do request
 */
function renderCampaignStartDate(result) {
	$('#startdate').val(moment(adSet.start_time_to_change).tz(timezoneName).format(window.g.dateTime24));
	adSet.start_time = adSet.start_time_to_change;
	delete adSet.start_time_to_change;
	disableButtonLoader($('[data-objective=openStartDate]'));
	$('[data-objective=openStartDate]').attr('close', '').css({
		'visibility': 'hidden'
	})
}


/**
 * Aplica mudança na data final da campanha no objeto
 * @param  {DOMObject} e
 */
function endDateChange(e) {
	console.log('e.localDate:', e.localDate);
	try {
		var currentAccountDate = moment().tz(timezoneName).format('YYYY-MM-DDTHH:mm:ss');
		var endCampaignDate = moment.tz(moment(e.localDate).format('YYYY-MM-DDTHH:mm:ss'), timezoneName).format();

		if (moment(endCampaignDate).isBefore(currentAccountDate)) {
			$('#endDatePicker').datetimepicker('hide');
			$('#enddate').val(moment(adSet.hasOwnProperty('end_time') && adSet.end_time ? adSet.end_time : '').tz(timezoneName).format(window.g.dateTime24));
			showError('invalidEndCampaignDate');
			return;
		}

		$('#enddate').val(moment(adSet.hasOwnProperty('end_time') && adSet.end_time ? adSet.end_time : '').tz(timezoneName).format(window.g.dateTime24));
		adSet.end_time_to_change = endCampaignDate;
	} catch (e) {
		console.log('endDateChange', e);
	}
}

/**
 * Altera dada final da campanha
 */
function changeCampaignEndDate() {
	try {
		var currentAccountDate = moment().tz(timezoneName).format();
		var endCampaignDate = adSet.hasOwnProperty('end_time_to_change') ? adSet.end_time_to_change : null;

		if (endCampaignDate == null) {
			$('[data-objective=openEndDate]').attr('close', '').css({
				'visibility': 'hidden'
			});
			return;
		}

		if (moment(endCampaignDate).isBefore(currentAccountDate)) {
			showError('invalidEndCampaignDate');
			return;
		}

		enableButtonLoader($('[data-objective=openEndDate]'));

		adSet.end_time = endCampaignDate;
		adSet.update().then(renderCampaignEndDate).catch(function(response) {
			disableButtonLoader($('[data-objective=openEndDate]'));
			$('[data-objective=openEndDate]').attr('close', '').css({
				'visibility': 'hidden'
			});
			showError(response);
		});

	} catch (e) {
		console.log('changeCampaignEndDate', e);
	}
}

/**
 * Renderiza data final alterada
 * @param  {Object} result  Resultado do request
 */
function renderCampaignEndDate(result) {
	$('#enddate').val(moment(adSet.end_time_to_change).tz(timezoneName).format(window.g.dateTime24));
	adSet.end_time = adSet.end_time_to_change;
	delete adSet.end_time_to_change;
	disableButtonLoader($('[data-objective=openEndDate]'));
	$('[data-objective=openEndDate]').attr('close', '').css({
		'visibility': 'hidden'
	})
}

/**
 * Renderiza resultados da campanha
 */
function renderCampaignResults() {
	try {
		var results = {};
		results.unique_impressions = adSetStats && adSetStats.hasOwnProperty('unique_impressions') ? adSetStats.unique_impressions : 0;
		results.rows = [];
		var addClickActions = true;
		switch (window.g.campaignType) {
			case 1:
				results.rows[0] = {
					// Action dictionary
					label: _('conv' + FB_AD_ACTIONS['post_like']),
					value: adSetStats && adSetStats.hasOwnProperty('actions') && adSetStats.actions && adSetStats.actions.hasOwnProperty('post_like') ? adSetStats.actions.post_like : 0,
					unique_label: _('cost' + FB_AD_ACTIONS['post_like'])
				}
				break;
			case 2:
				results.rows[0] = {
					label: _('conv' + FB_AD_ACTIONS['like']),
					value: adSetStats && adSetStats.hasOwnProperty('actions') && adSetStats.actions && adSetStats.actions.hasOwnProperty('like') ? adSetStats.actions.like : 0,
					unique_label: _('cost' + FB_AD_ACTIONS['like'])
				}
				break;
			case 3:
				results.rows[0] = {
					label: _('conv' + FB_AD_ACTIONS['link_click']),
					value: adSetStats && adSetStats.hasOwnProperty('actions') && adSetStats.actions && adSetStats.actions.hasOwnProperty('link_click') ? adSetStats.actions.link_click : 0,
					unique_label: _('cost' + FB_AD_ACTIONS['link_click'])
				}
				break;
			default:
				results.rows[0] = {
					label: _('conv' + FB_AD_ACTIONS['clicks']),
					value: adSetStats && adSetStats.hasOwnProperty('actions') && adSetStats.actions && adSetStats.hasOwnProperty('clicks') ? adSetStats.clicks : 0,
					unique_label: _('cost' + FB_AD_ACTIONS['clicks'])
				}
				addClickActions = false;
				break;
		}

		var spent = adSetStats && adSetStats.hasOwnProperty('spent') && !isNaN(adSetStats.spent) ? parseInt(adSetStats.spent) : 0;
		var actions = results.hasOwnProperty('rows') && $.isArray(results.rows) && results.rows.length > 0 && results.rows[0].hasOwnProperty('value') && !isNaN(results.rows[0].value) ? parseInt(results.rows[0].value) : 0;
		results.rows[0].unique_cost = (actions > 0 ? spent / actions : spent);

		if (addClickActions) {
			var clicks =
				adSetStats &&
				adSetStats.hasOwnProperty('actions') &&
				adSetStats.actions &&
				adSetStats.hasOwnProperty('clicks') ? adSetStats.clicks : 0;
			if (clicks > 0) {
				results.rows.push({
					label: _('conv' + FB_AD_ACTIONS['clicks']),
					value: clicks,
					unique_label: _('cost' + FB_AD_ACTIONS['clicks']),
					unique_cost: (clicks > 0 ? spent / clicks : spent)
				});
			}
		}


		if (adSetStats && adSetStats.hasOwnProperty('actions') && adSetStats.actions && adSetStats.actions != null) {
			if (!results)
				results = {};

			if (!results.hasOwnProperty('rows') || !$.isArray(results.rows))
				results.rows = [];

			for (var i in adSetStats.actions) {
				if (adSetStats.actions[i] && !isNaN(adSetStats.actions[i]) && parseInt(adSetStats.actions[i]) > 0) {
					var insert = true;

					if (results.rows.length > 0) {
						for (var e in results.rows) {
							if (!results.rows[e].hasOwnProperty('unique_label'))
								continue;

							if (results.rows[e].unique_label != _('cost' + FB_AD_ACTIONS[i]))
								continue;

							insert = false;
						}
					}

					if (!insert)
						continue;

					results.rows.push({
						label: _('conv' + FB_AD_ACTIONS[i]),
						value: adSetStats.actions[i],
						unique_label: _('cost' + FB_AD_ACTIONS[i]),
						unique_cost: (parseInt(adSetStats.actions[i]) > 0 ? spent / parseInt(adSetStats.actions[i]) : spent)
					});
				}
			}
		}

		CreateClass.MyHandlebars(results, "results").simpleRender();

		// Máscara na quantidade de pessoas, custo por acao e valor da conversão
		CreateClass.Regional().setMaskForAll('mask', null);

		//Hide loader
		if ($('#fullLoader00').is(':visible'))
			fullLoaderStop();
	} catch (e) {
		showError('invalidFacebookResponseOnCampaignStats');
		console.log('renderCampaignResults', e);
	}
}

/**
 * Renderiza anúncios
 */
function renderAds() {
	try {
		//check ads lenth
		if (adGroups && $.isArray(adGroups) && adGroups.length <= 0) {
			// showError('anyAdToParse');
			CreateClass.MyHandlebars({ads:[]}, "ads").simpleRender();
			return;
		}

		adsRender = {};
		adsRender.ads = [];
		adsMessages = [];
		adsStatuses = [];

		for (var i = 0; i < adGroups.length; i++) {
			var currentAd = adGroups[i];
			var currentAdStats = adGroupsStats[i];
			if(currentAd.id !== currentAdStats.adgroup_id)
				console.error('Statistics mismatch');

			// Review Feedback
			if (currentAd && currentAd.hasOwnProperty('adgroup_review_feedback')) {
				currentAd.adgroup_review_feedback = currentAd.adgroup_review_feedback.join('\n');
				adsMessages.push({
					id: currentAd.id,
					adgroup_review_feedback: currentAd.adgroup_review_feedback
				});
			}

			// Check
			adsStatuses.push({
				id: currentAd.id,
				status: currentAd.adgroup_status
			});

			var adResult = mountAdObject(currentAd, currentAdStats, window.g.campaignType);
			adsRender.ads.push(adResult);
		};

		CreateClass.MyHandlebars(adsRender, "ads").simpleRender();
		setSelectPickers($('.selectpicker'));

		var locale = LANGUAGES[FB_LANGS[window.g.adaccounts[window.g.accountId].currency]].locale.currencySymbol;
		if (adsRender && adsRender.hasOwnProperty('ads') && $.isArray(adsRender.ads) && adsRender.ads.length > 0) {
			$('#campaignvariations tbody tr td:nth-child(3) b,#campaignvariations tbody tr td:nth-child(5) b').currency({
				region: locale.currency,
				thousands: locale.thousandSymbol,
				decimal: locale.decimalSymbol,
				decimals: locale.decimalCount,
				hidePrefix: false,
				hidePostfix: true,
			});

			CreateClass.Regional().setMaskForAll('mask', null);
		}

		setAdButtonActions(adsRender);

		if (adsMessages && adsMessages.length > 0) {
			for (var ad in adsMessages) {
				if (
					adsMessages[ad].hasOwnProperty('id') && !isNaN(adsMessages[ad]['id']) &&
					$('tbody tr[data-ref=' + adsMessages[ad]['id'] + ']').length > 0 &&
					$('tbody tr[data-ref=' + adsMessages[ad]['id'] + '] td.statuscell').length > 0 &&
					$('tbody tr[data-ref=' + adsMessages[ad]['id'] + '] td.statuscell span.status').length > 0 &&
					adsMessages[ad].hasOwnProperty('disapprove_reason_descriptions') &&
					adsMessages[ad]['disapprove_reason_descriptions'].length > 0) {
					$('tbody tr[data-ref=' + adsMessages[ad]['id'] + '] td.statuscell span.status').attr('title', adsMessages[ad]['disapprove_reason_descriptions']).tooltip();

				}
			}
		}
		checkCampaignStatus();
		checkAdStatus(adsStatuses);

		$('tr[data-ref] td span.sprite-campaign_preview').click(function() {
			getAdPreview($(this));
		});
	} catch (e) {
		checkCampaignStatus();
		console.log('renderAds', e);
	}
}
var currentAdPreview;
function getAdPreview(obj) {
	if ($(obj) && $(obj).length > 0) {
		var adId = $(obj).closest('tr').attr('data-ref');

		if ($(obj).attr('previewLoaded') == 'true') {
			// posicionar a {arrow} no meio
			$('div.adPreviewLoad[previewAdId="' + adId + '"]').closest('.popover').find('.arrow').css('top', '50%');
			return;
		} else {
			if (isNaN(adId)) {
				showError('errorGettingAdId');
				return;
			}

			var objContainer = $('<div>').append($('<button>', {
				'class': 'close',
				'onclick': 'javascript:hidePopoverPreview(' + adId + ');void(0);',
				'text': '×',
			})).append($('<div>', {
				'class': 'adPreviewLoad',
				'previewAdId': adId,
				'data-section': 'facebookPreview'
			}).css({
				'min-width': '235px',
				'min-height': '30px',
			}));

			$(obj).popover({
				html: true,
				placement: 'right',
				trigger: 'click',
				title: null,
				content: objContainer,
				container: 'body',
				onShow: function(e) {
					objContainer.spin({
						zIndex: 1,
						lines: 8,
						length: 2,
						width: 2,
						radius: 3,
						color: '#7b98d3'
					});

                    currentAdPreview = adId;
                    var ad_format;
                    switch(g.campaignType) {
                        case '1':
                            ad_format = 'DESKTOP_FEED_STANDARD';
                            break;
                        case '2':
                        case '3': // TODO check
                        default:
                            ad_format = 'RIGHT_COLUMN_STANDARD';
                    }
                    var adGroup = new api.AdGroup(adId, window.g.accountId);
                    adGroup.getAdPreviews({ad_format: ad_format}).then(parseAdPreview).catch(showError);
				},
				onHide: function(e) {
					// objContainer.parent().html('');
				}
			});
			$(obj).popover('show');

			// posicionar a {arrow} no topo
			$('div.adPreviewLoad[previewAdId="' + adId + '"]').closest('.popover').find('.arrow').css('top', '32px');

		}
	} else {
		showError('errorGettingAdObject');
	}
}

function hidePopoverPreview(adId) {
	try {
		if (!adId || isNaN(adId)) throw 'invalid adId';

		$('tbody > tr[data-ref="' + adId + '"] > td > span').click();
	} catch (e) {
		console.log('hidePopoverPreview()', e);
	}
}

function parseAdPreview(result) {
	try {
		//Validate response
		if (!result[0].hasOwnProperty('body')) {
			showError('errorParsingAdPreview');
			return;
		}

		var content = result[0]['body'];
		var objContainer = $('div.adPreviewLoad[previewAdId=' + currentAdPreview + ']');
		objContainer.parent().spin(false);
		objContainer.html(content);
		$('tr[data-ref=' + currentAdPreview + '] td span.sprite-campaign_preview').attr('previewLoaded', 'true');

	} catch (e) {
		console.log('parseAdPreview', e);
	}
}

/**
 * Manta objeto de anúncio
 * @param  {Object} ad             	Anúncio
 * @param  {Object} adStats 		Estatística do Anúncio
 * @param  {Object} campaignType   	Tipo de Campanha
 * @return {Object}                	Anúncio montado
 */
function mountAdObject(ad, adStats, campaignType) {
	try {
		ad.spent = adStats.spent ? parseInt(adStats.spent) : 0;

		switch (campaignType) {
			case 1:
				ad.goal = adStats != null &&
					adStats.hasOwnProperty('actions') &&
					adStats.actions &&
					adStats.actions.hasOwnProperty('like') &&
					adStats.actions.like && !isNaN(adStats.actions.like) ? parseInt(adStats.actions.like) : 0;
				break;
			case 2:
				ad.goal = adStats != null &&
					adStats.hasOwnProperty('actions') &&
					adStats.actions &&
					adStats.actions.hasOwnProperty('post_like') &&
					adStats.actions.post_like && !isNaN(adStats.actions.post_like) ? parseInt(adStats.actions.post_like) : 0;
				break;
			case 3:
				ad.goal = adStats != null &&
					adStats.hasOwnProperty('actions') &&
					adStats.actions &&
					adStats.actions.hasOwnProperty('link_click') &&
					adStats.actions.link_click && !isNaN(adStats.actions.link_click) ? parseInt(adStats.actions.link_click) : 0;
				break;
			default:
				ad.goal = adStats != null &&
					adStats.hasOwnProperty('clicks') &&
					adStats.clicks && !isNaN(adStats.clicks) ? parseInt(adStats.clicks) : 0;
				break;
		}
		ad.cost = (ad.goal > 0 ? (ad.spent / ad.goal) : 0);
		ad.status = ad.adgroup_status;
		return ad;
	} catch (e) {
		console.log('mountAdObject', e);
		return null;
	}
}
/**
 * Aplica alterações de anúncio removido
 * @param  {int} 	ad  	Id do ad
 * @param  {Object} result  Resultado do request
 */
function parseFbAdDelete(ad, result) {
	$('tbody tr[data-ref=' + ad + '] td [data-ad-action=delete]').prop('disabled', false);
	disableButtonLoader($('tbody tr[data-ref=' + ad + '] td [data-ad-action=delete]'));

	if (result.success) {
		$('tbody tr[data-ref=' + ad + '] td [data-ad-action=edit]').remove();
		$('tbody tr[data-ref=' + ad + '] td [data-ad-action=delete]').remove();
		$('tbody tr[data-ref=' + ad + '] td.statuscell').html(getAdStatus('DELETED'));
	}
}

/**
 * Habilita loader em um ad
 * @param  {DOMObject} td
 */
function enableAdLoader(td) {
	try {
		td.children().css('visibility', 'hidden');
		td.spin(spinnerOpts);
	} catch (e) {
		console.log('enableAdLoader', e);
	}
}

/**
 * Desabilita loader em um ad
 * @param  {DOMObject} td
 */
function disableAdLoader(td) {
	try {
		td.data('spinner').stop();
		td.children().css('visibility', 'visible');
	} catch (e) {
		console.log('disableAdLoader', e);
	}
}

/**
 * Habilita loader de um botão
 * @param  {DOMObject} button
 */
function enableButtonLoader(button) {
	try {
		button.css({
			'background-image': 'none',
			'color': 'transparent'
		});
		spinner = button.spin(spinnerOpts);
	} catch (e) {
		console.log('enableButtonLoader', e);
	}
}

/**
 * Desabilita loader de um botão
 * @param  {DOMObject} button
 */
function disableButtonLoader(button) {
	try {
		button.css({
			'background-image': '',
			'color': ''
		});
		button.attr('lock', '');
		button.data('spinner').stop();
	} catch (e) {
		console.log('disableButtonLoader', e);
	}
}

/**
 * Comportamento dos botões editar e excluir
 * @param {Object} ads
 */
function setAdButtonActions(ads) {
	try {
		if (ads && adGroups && $.isArray(ads.ads) && ads.ads.length > 0) {
			for (var ad in ads.ads) {
				if ($('tbody tr[data-ref=' + ads.ads[ad].id + ']').length <= 0)
					continue;

				// ação de excluir anúncio
				$('tbody tr[data-ref=' + ads.ads[ad].id + '] td [data-ad-action=delete]').unbind('click').click(function() {
					var adId = $(this).closest('tr').attr('data-ref');
					if (isNaN(adId)) {
						showError('errorGettingAdId');
						return;
					}

					$(this).prop('disabled', true);
					enableButtonLoader($(this));

					var adGroup = new api.AdGroup(adId);
					adGroup.delete().then(function(response) {
						parseFbAdDelete(adId, response);
					}).catch(showError);
				});
			}
		}
	} catch (e) {
		console.log('setAdButtonActions', e);
	}
}

/**
 * Gera elemento de status de campanha
 * @param  {string} status
 * @return {string}         Elemento HTML
 */
function getAdStatus(status) {
	try {
		var output;
		switch (status) {
			case "ACTIVE":
			case 1:
				if (adSet.hasOwnProperty('started') && adSet.started == false) {
					output = '<span class="status scheduled">' + _('fbAdScheduled') + '</span>';
					break;
				}

				if (adSet.hasOwnProperty('ended') && adSet.ended == true) {
					output = '<span class="status finalized">' + _('fbAdFinalized') + '</span>';
					break;
				}

				output = '<select class="selectpicker" data-style="tb-dropdown"><option value="1" class="green" selected>' + _('fbAdActive') + '</option><option value="0" class="red">' + _('fbAdPaused') + '</option></select>';
				break;
			case "PAUSED":
			case 9:
				output = '<select class="selectpicker" data-style="tb-dropdown red"><option value="1" class="green">' + _('fbAdActive') + '</option><option value="0" class="red" selected>' + _('fbAdPaused') + '</option></select>';
				break;
			case "DELETED":
			case 3:
				output = '<span class="status excluded">' + _('fbAdDeleted') + '</span>'
				break;
			case "ARCHIVED":
				output = '<span class="status archived">' + _('fbAdArchived') + '</span>'
				break;
			case "PENDING_REVIEW":
			case 4:
				output = '<span class="status pending">' + _('fbAdPendigReview') + '</span>'
				break;
			case "DISAPPROVED":
			case 5:
				output = '<span class="status disapproved">' + _('fbAdDisapproved') + '</span>'
				break;
			case "PENDING_BILLING_INFO":
			case 7:
				output = '<span class="status pendingbilling">' + _('fbAdPedingBillling') + '</span>'
				break;
			case "CAMPAIGN_PAUSED":
			case 8:
				output = '<span class="status campaignpaused">' + _('fbAdCampaignPaused') + '</span>'
				break;
		}
		return output;
	} catch (e) {
		console.log('getAdStatus', e);
	}
}

/**
 * Aplica selepicker em um elemento
 * @param {DOMObject} el elemento
 */
function setSelectPickers(el) {
	try {
		el.selectpicker({
			dropupAuto: false,
			showSubtext: true,
		}).each(function() {
			$(this).change(function() {
				setAdStatus($(this));
			});
		});
	} catch (e) {
		console.log('setSelectPickers', e);
	}
}
////////////
// ERRORS //
////////////

/**
 * Exibe modal com mensagem de erro
 * @param  {string} error
 */
function showError(error) {
	var message;
	try {
		if(typeof error ==='object')
			message = (error.message) ? error.message : error.error.message;
		else
			message = _(error);
		bootbox.dialog({
			className: 'red',
			locale: window.g.languageMin,
			message: message,
			closeButton: false,
			buttons: {
				'close': {
					label: _('btClose'),
					callback: function() {}
				}
			}
		});
	} catch(e) {
		console.error(e);
	}
}

////////////////////////
// HANDLEBARS HELPERS //
////////////////////////

Handlebars.registerHelper('campaignActions', function(status) {
	// console.log('campaignActions', status);
	try {
		var toogleClass = null;
		var toogleLabel = null;

		if (typeof status == 'string') {
			switch (status.toLowerCase()) {
				case 'active':
					toogleClass = 'medium pause';
					toogleLabel = _('btnPause');
					setStatus = 'PAUSED';
					break;
				case 'paused':
					toogleClass = 'medium green activate';
					toogleLabel = _('btnActivate');
					setStatus = 'ACTIVE';
					break;
			}
		} else {
			switch (parseInt(status)) {
				case 1:
					toogleClass = 'pause';
					toogleLabel = _('btnPause');
					setStatus = 2;
					break;
				case 2:
					toogleClass = 'green activate';
					toogleLabel = _('btnActivate');
					setStatus = 1;
					break;
			}
		}

		var output = '';

		if (toogleLabel)
			output = '<button data-interaction="campaign" id="btnCampaignToogle" class="btn ' + toogleClass + '" setStatus="' + setStatus + '">' + toogleLabel + '</button> ';

		return output;
	} catch (e) {
		console.log('registerHelper', e);
	}
});

Handlebars.registerHelper('adStatus', function(status) {
	try {
		return getAdStatus(status);
	} catch (e) {
		console.log('registerHelper', e);
	}
});