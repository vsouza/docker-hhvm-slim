$(document).ready(function() {
	accounts = g.adaccounts;

	// Fill Accounts Select
	for (id in accounts) {
		var option = $("<option></option>").text(accounts[id].prettyName).val(id);
		if (tbCookie.has("currentAccountId")) {
			if (tbCookie.get("currentAccountId") == id) option.attr('selected', 'selected');
		}
		$('#accountid').append(option);
	}

	//	Bootstrap-select
	$('.selectpicker').selectpicker({
		style: 'tb-dropdown',
		dropupAuto: false,
		showSubtext: true,
	});

	// Get Pixels
	getPixels();

	// Account ID Selector
	$('#accountid').change(function() {
		getPixels();
	});

	// Pixel Creation Events
	$('#modalPixelCreation').on('hidden', function () {
	  	$('#createpixelform')[0].reset();
	  	$('#createpixelform input').css('border-color','');
	})
	$('#createpixelbutton').click(function(e) {
		e.preventDefault();
		createPixel();
	});
	$("#createpixelform").submit(function(e) {
		e.preventDefault();
		createPixel();
    });

	// Copy Code
	$('#modalCopyCode').on('hidden', function () {
	  	$('#copycodeform')[0].reset();
	})
	$('#modalCopyCode').click(function () {
	  	$('#codeArea').select();

	  	// Work around Chrome's little problem
	    $('#codeArea').mouseup(function() {
	        // Prevent further mouseup intervention
	        $('#codeArea').unbind("mouseup");
	        return false;
	    });
	});

	// Send Code
	$('#modalSendCode').on('hidden', function () {
	  	$('#sendcodeform')[0].reset();
	  	$('#sendcodeform input').css('border-color','');
	})
	$('#sendcodebutton').click(function(e) {
		e.preventDefault();
		sendCode();
	});
	$("#sendcodeform").submit(function(e) {
		e.preventDefault();
		sendCode();
    });

});

/**
 * Busca Pixels de Conversão
 */
function getPixels() {
	accountid = $('#accountid').val();
	startSpinner();
	var adAccount = new api.AdAccount('act_' + accountid);
	adAccount.getConversionPixels().then(fbHandleConversionPixels);
}
 
/**
 * Renderiza Pixels na tela
 * @param  {Object} response resposta do request
 */
function fbHandleConversionPixels(response) {
    try {
        // caso o retorno do facebook não seja um objeto válido
        if (!response instanceof Object || $.isEmptyObject(response))
            throw 'pixel not received';

        // erro encontrado
        if (inObject('error', response))
            if (inObject('message', response.error))
                throw response.error.message;

        if(response.length>0){
        	var accounts = {
        		data: response
        	};
	        CreateClass.MyHandlebars(accounts, "pixeldata").simpleRender();
			stopSpinner();
        }
	    else {
			var adAccount = new api.AdAccount('act_'+$('#accountid').val());
			adAccount.read(['offsite_pixels_tos_accepted']).then(fbHandlePixelTermsQuery);
	    }

    } catch (e) {
        console.log('fbHandleConversionPixels() :', e);
    }
}

/**
 * Verifica aceitação dos Termos de Uso de Pixels de Conversão
 * @param  {Object} response resposta do request
 */
function fbHandlePixelTermsQuery (response) {
	try {
        // caso o retorno do facebook não seja um objeto válido
        if (!response instanceof Object || $.isEmptyObject(response))
            throw 'not an object';

        // erro encontrado
        if (inObject('error', response))
            if (inObject('message', response.error))
                throw response.error.message;

		if (response.offsite_pixels_tos_accepted) {
			CreateClass.MyHandlebars({empty:0}, "pixeldata").simpleRender();
		} else {
			CreateClass.MyHandlebars({terms:true,accountid:$('#accountid').val()}, "pixeldata").simpleRender();
			$('#reload').click(function(e) {
				e.preventDefault();
				getPixels();
			});
		}
		stopSpinner();

	} catch (e) {
        console.log('fbHandlePixelTermsQuery() :', e);
    }
}

//////////////////////
// Criação do Pixel //
//////////////////////

/**
 * Cria pixel de conversão
 */
function createPixel() {
	var name = $('#pixelname').val();
	var tag = $('#pixelType').val();
	if(!name) {
		$('#pixelname').css('border-color','red');
	} else {
		$('#pixelname').css('border-color','');

        var pixelData = {
            name: name,
            tag: tag
        }
        var conversionPixel = new api.AdConversionPixel(pixelData, 'act_' + $('#accountid').val());
        conversionPixel.create().then(fbHandlePixelCreation);
		startSpinner();
		$('#modalPixelCreation').modal('hide');
	}
}

/**
 * Recebe a responsta da criação do Pixel e atualiza a tela
 * @param  {Object} response resposta do request
 */
function fbHandlePixelCreation(response) {
	try {
        // caso o retorno do facebook não seja um objeto válido
        if (!response instanceof Object || $.isEmptyObject(response))
            throw 'not an object';

        // erro encontrado
        if (inObject('error', response)) {
        	if (inObject('code', response.error)&&response.error.code==1487438) {
				bootbox.dialog({
					className: 'yellow',
					locale: window.g.languageMin,
					message: response.error.message,
					closeButton: false,
					buttons: {
						'ok': {
							label: _('ok'),
						},
					}
				});
        	} else {
	        	if (inObject('message', response.error))
	                throw response.error.message;
        	}

        }
	} catch (e) {
        console.log('fbHandlePixelCreation() :', e);
    } finally {
    	getPixels();
    }
}

////////////////////
// Envio do Pixel //
////////////////////

/**
 * Gatilho de envio
 */
function sendCode() {
	var myname = $('#sendpixelmyname').val();
	var admname = $('#sendpixeladmname').val();
	var admemail = $('#sendpixeladmemail').val();
	if(!validateEmail(admemail)) $('#sendpixeladmemail').css('border-color','red');
	else $('#sendpixeladmemail').css('border-color','');
	if(!myname) $('#sendpixelmyname').css('border-color','red');
	else $('#sendpixelmyname').css('border-color','');
	if(!admname) $('#sendpixeladmname').css('border-color','red');
	else $('#sendpixeladmname').css('border-color','');

	if(validateEmail(admemail)&&myname&&admname) {
		sendMail(myname, admname, admemail, $('#sendpixelid').val(), $('#sendpixelcode').val());
	}
}

/**
 * Validação do email
 * @param  {string} email
 */
function validateEmail(email) {
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}

/**
 * Envio do email
 */
function sendMail(myname, admname, admemail, pixelId, code) {
	var modalFooter = $('#modalSendCode .modal-footer');
	var modalHeight = modalFooter.height();
	$('#modalSendCode .modal-footer button').hide();
	modalFooter.css('height', modalHeight).spin(spinnerOpts);

    var objPost = {};
    objPost.from = myname;
    objPost.to = admemail;
    objPost.name = admname;
    objPost.script = code;

	$.ajax({
        type: 'POST',
        url: '/settings/pixel/send',
        data: objPost,
        dataType: 'json',
        cache: false,
        crossDomain: true,
        success: function(data) {
            try {
                if (!inObject('success', data))
                    throw 'invalid sendEmail response';

				modalFooter.data('spinner').stop();
                if (data.success) {
					$('#modalSendCode .success').show();
					$('#modalSendCode #sendcodeclosebutton').show();
                } else {
					modalFooter.data('spinner').stop();
					$('#modalSendCode .error').show();
					$('#modalSendCode #sendcodebutton').show();
                }
            } catch (e) {
                console.log('sendEmail(): ', e);
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log('sendEmail().error: ', jqXHR, textStatus, errorThrown);
        }
    });
}

/**
 * Eventos dos botões da tabela
 */
function setButtonEvents() {
	$('#pixels-table [data-interaction=copy]').click(function(e) {
		$('#codeArea').val($(this).attr('data-code'));
		setTimeout(function(){$('#codeArea').select();},500);
	});

	$('#pixels-table [data-interaction=send]').click(function(e) {
		$('#modalSendCode .success, #modalSendCode .error, #modalSendCode #sendcodeclosebutton').hide();
		$('#modalSendCode #sendcodebutton').show();
		$('#sendpixelid').val($(this).attr('data-pixel-id'));
		$('#sendpixelcode').val($(this).attr('data-code'));
		setTimeout(function(){$('#sendpixeladmemail').focus();},500);
	});

	$('#pixels-table [data-interaction=delete]').click(function(e) {
		pixelId = $(this).attr('data-pixel-id');
		if(confirm(_('hPixelDeleteConfirm')+pixelId)) {
			var conversionPixel = new api.AdConversionPixel(pixelId);
        	conversionPixel.delete().then(fbHandleDeletePixel);
			startSpinner();
		}
	});
}

/**
 * Recebe a responsta da remoção do Pixel e atualiza a tela
 * @param  {Object} response resposta do request
 */
function fbHandleDeletePixel(response) {
	console.log(response);
	try {
        // caso o retorno do facebook não seja um objeto válido
        if (!response instanceof Object || $.isEmptyObject(response))
            throw 'not an object';

        // erro encontrado
        if (inObject('error', response))
            if (inObject('message', response.error))
                throw response.error.message;

	} catch (e) {
        console.log('fbHandlePixelCreation() :', e);
    } finally {
    	getPixels();
    }
}

/////////////
// Spinner //
/////////////

var spinner = $("#spinner");
var spinnerOpts = {
    lines: 8,
    length: 2,
    width: 2,
    radius: 3,
    color: '#7b98d3'
};
function startSpinner() {
    $('#pixeldata').css("display", "none");
    spinner.css("display", "block");
    spinner.spin(spinnerOpts);
}
function stopSpinner() {
	spinner.data('spinner').stop();
    spinner.css("display", "none");
    $('#pixeldata').css("display", "block");
    setButtonEvents();
}

////////////////
// Handlebars //
////////////////

Handlebars.registerHelper('Tags', function(tag) {
	try{
		var tagsLang = {
			'checkout':_('labPixelType0'),
			'registration':_('labPixelType1'),
			'lead':_('labPixelType2'),
			'key_page_view':_('labPixelType3'),
			'add_to_cart':_('labPixelType4'),
			'other':_('labPixelType5')
		}

		if(!tag || typeof tag != 'string') throw 0;
		if(!tagsLang.hasOwnProperty(tag)) throw 0;
		return tagsLang[tag];

	}catch(e){
		console.log('Tags helper error: ',e);
	}
});

Handlebars.registerHelper('Statuses', function(status) {
	try{
		if(!status || typeof status != 'string') throw 0;
		return _('labPixelStatus'+status);
	}catch(e){
		console.log('Statuses helper error: ',e);
	}
});
