;(function() {

$(document).ready(function() {
	readCookieAndSetListOrColumn();
	setVisualizationToogle();
	setAccountsSelect();
	Campaigns.initialize();

	// Bootstrap-select
	$('.selectpicker').selectpicker({
		style: 'tb-dropdown transparent',
		dropupAuto: false,
		showSubtext: true,
	});
});

/**
 * Avalia a existência do cookie portador da definição de disposição das campanhas no dashboard
 */
function readCookieAndSetListOrColumn() {
	try {
		if (tbCookie.has("dashList")) {
			if (tbCookie.get("dashList") == 'l') {
				$("div#campaigns").addClass('list');
				$('span#visualizations > a.list').addClass('on').siblings().removeClass('on');
			} else {
				$("div#campaigns").removeClass('list');
				$('span#visualizations > a.tiles').addClass('on').siblings().removeClass('on');
			}
		}
	} catch (e) {
		console.log('readCookieAndSetListOrColumn():', e);
	}
}

/**
 * Monitora botão de troca do modo de visualização
 */
function setVisualizationToogle() {
	$("#visualizations a").click(function(e) {
		e.preventDefault();

		var type = $(this).attr("ref");
		$(this).addClass('on').siblings().removeClass('on');

		$('#tplcampaigns').addClass('transition');

		if (type == 'list') {
			$("div#campaigns").addClass('list');
			tbCookie.set("dashList", 'l');
		} else {
			$("div#campaigns").removeClass('list');
			tbCookie.remove("dashList");
		}

		setTimeout(function() {
			$('#tplcampaigns').removeClass('transition');
		}, 10);
	});
}

/**
 * Popula select de contas
 */
function setAccountsSelect() {
	accounts = window.g.adaccounts;
	// Fill Accounts Select
	for (id in accounts) {
		var option = $("<option></option>").text(accounts[id].prettyName).val(id);
		if (tbCookie.has("currentAccountId")) {
			if (tbCookie.get("currentAccountId") == id) option.attr('selected', 'selected');
		}
		$('#accountid').append(option);
	}
}

///////////////
// CAMPAIGNS //
///////////////

Campaigns = {
	accountid: null,
	pagination: 12,	// Pagination setting
	loaded: 0,	// Loaded Campaigns counter
	preventOnChange: false,
	nextPage: null,
	/**
	 * Inicializa campanhas do painel
	 */
	initialize: function() {
		this.getCampaigns();
		Loader.setEvents();
		this.getStats();
		var self = this;

		// Status Filter change event
		$('#statusfilter').add($("#period")).change(function() {
			self.nextPage = null;
			if (!self.preventOnChange) self.getCampaigns();
		});

		// Account id change event
		$("#accountid").change(function() {
			self.nextPage = null;
			$("#searchinput").val('');
			self.clearFilters();
			self.getCampaigns();
		});

		// Period change event
		$("#period").change(function() {
			self.nextPage = null;
			self.getStats();
		});

		// Search
		/*
		$('#gosearch').click(function() {
			self.search();
		});
		$("#searchinput").keypress(function(event) {
			if (event.which == 13) self.search();
		});
		*/
	},
	/**
	 * Busca campanhas no back-end
	 * @param  {bool} append Flag de anexação para paginação
	 */
	getCampaigns: function(append) {
		append = append || false;
		$('#empty').hide();
		$("#loadmore").show();
		if (!append) $("#tplcampaigns").empty();
		Loader.show();

		var accountid = $("#accountid").val();
		this.accountid = accountid;

		if (accountid) {
			// Set Account currency for formatting
			setAccountCurrency(window.g.adaccounts[accountid].currency);
			var timezone = window.g.adaccounts[accountid].timezone_name;
		} else
			var timezone = 'America/Sao_Paulo';

		var period = $("#period").val();
		var timestamps = this.getTimestamps(period, timezone);

		var startTime = timestamps.start;
		var endTime = timestamps.end;

		if (tbCookie.has("currentAccountId"))
			tbCookie.remove("currentAccountId");

		tbCookie.set("currentAccountId", accountid);

		// url de pesquisa
		var url = '/getcampaigns';
		url += '/' + accountid;
		url += '/' + startTime;
		url += '/' + endTime;

		// Status
		if ($("#statusfilter").val().length == 0) {
			url += '/ACTIVE,PAUSED,CAMPAIGN_GROUP_PAUSED'
		} else {
			url += '/' + $("#statusfilter").val();
		}

		// Paginação
		url += '/' + this.pagination;

		// Paginação facebook
		if (this.nextPage != null) {
			this.nextPage.replace(/"/g, "");
			url += '?nextPage=' + encodeURIComponent(this.nextPage);
		}

		// Search
		/*if ($("#searchinput").val()) {
			data.s = $("#searchinput").val();
		}*/

		var self = this;
		$.ajax({
			type: 'get',
			url: url,
			success: function(campaigndata) {
				try {

					if (campaigndata.success) {
						if (!campaigndata.hasOwnProperty('data')) {
							Loader.hide();
							$('#empty').show();
							$("#loadmorebutton").hide();
							return;
						}

						var campaigns = self.parseStatus(campaigndata.data,timezone);
						self.loaded += campaigns.length;
						self.nextPage = campaigndata.message;
						if (self.nextPage == null)
							$("#loadmore").hide();
						Loader.hide();

						if (append) self.append(campaigns);
						else self.render(campaigns);

						$('#tplcampaigns .ad-action').unbind().click(function() {
							self.changeStatus($(this));
						});
					} else {
						Loader.error();
					}
				} catch (e) {
					Loader.error();
					console.log('getCampaigns:' + e);
				}
			},
			error: function() {
				Loader.error();
				console.log('error loading campaigns');
			},
		});
	},
	/**
	 * Interpreta o status de cada campanha
	 * @param  {array} 	campaigns
	 * @param  {string} timezone
	 * @return {array}           	conjunto de campanhas processadas
	 */
	parseStatus: function(campaigns,timezone) {
		var currentAccountDate = moment().tz(timezone).format();

		for (key in campaigns) {
			var Campaign = campaigns[key];
			var startCampaignDate = moment(Campaign.hasOwnProperty('start_time') && Campaign.start_time ? Campaign.start_time : '').tz(timezone).format();
			var endCampaignDate = moment(Campaign.hasOwnProperty('end_time') && Campaign.end_time ? Campaign.end_time : '').tz(timezone).format();

			var started = moment(startCampaignDate).isBefore(currentAccountDate);
			var ended = moment(endCampaignDate).isBefore(currentAccountDate);

			if ( (!started || ended) && (Campaign.campaign_status != 'DELETED')&& (Campaign.campaign_status != 'ARCHIVED') ) { // TODO mudar pra número quando mudar no GET
				Campaign.campaign_status = ended ? 4 : 5;
			}

			campaigns[key] = Campaign;

			// console.log(Campaign.campaign_status);
		}
		return campaigns;
	},
	/**
	 * Rendereiza campanhas
	 * @param  {array} campaigns Array de objetos de campanhas
	 */
	render: function(campaigns) {
		this.qtd = 0;
		CreateClass.MyHandlebars(campaigns, "tplcampaigns").simpleRender();
	},
	/**
	 * Anexa novas campanhas
	 * @param  {array} campaigns Array de objetos de campanhas
	 */
	append: function(campaigns) {
		CreateClass.MyHandlebars(campaigns, "tplcampaigns").appendRender();
	},
	/**
	 * Reinicia filtros
	 */
	clearFilters: function() {
		this.preventOnChange = true;
		$("#period").selectpicker('val', 1);
		$("#statusfilter").selectpicker('val', 'ACTIVE,PAUSED,CAMPAIGN_GROUP_PAUSED');
		this.preventOnChange = false;
	},
	/**
	 * Busca campanhas por termo de pesquisa
	 */
	/*search: function() {
		this.clearFilters();
		this.getCampaigns();
	},*/
	/**
	 * Busca estatísticas
	 */
	getStats: function() {
		var accountid = $("#accountid").val();

		if (accountid)
			var timezone = window.g.adaccounts[accountid].timezone_name;
		else
			var timezone = 'America/Los_Angeles';

		var period = $("#period").val();
		var timestamps = this.getTimestamps(period, timezone);
		var adAccount = new api.AdAccount('act_' + accountid);
		var params = {
			start_time: timestamps.start,
			end_time: timestamps.end,
		}
		adAccount.getAdStatistics(null, params)
			.then(function(data) {
				CreateClass.MyHandlebars(stats, "stats").simpleRender();
			})
			.catch(function(error) {
				console.log('getStats error', error);
			});
	},
	/**
	 * Gerar Timestamps do início do dia do período selecionado
	 * @param  {int} 	period   	Quantidade de dias
	 * @param  {string} timezone
	 * @return {Object}				Timestamps
	 */
	getTimestamps: function(period, timezone) {
		var start = null;
		var end = null;
		var subtract = {
			1: 0,
			2: -1,
			3: -6,
			4: -27
		};
		if (period > 0) {
			subtractdays = subtract[period];

			start = moment().add('days', subtractdays).tz(timezone).startOf('day');

			if (subtractdays == -1) end = moment().tz(timezone).startOf('day');
			else end = moment().add('days', 1).tz(timezone).startOf('day');

			// log('from ' + start.format());
			start = start.format("X");
			// log('  to ' + end.format());
			end = end.format("X");
		}
		return {
			start: start,
			end: end
		};
	},
	/**
	 * Altera status de uma campanhas
	 * @param  {DOMObject} button
	 */
	changeStatus: function(button) {
		try { mixpanel.track("Dashboard Action",{'Type':'Change Status'}); } 
		catch(e) { console.log('mixpanel error', e); }

		if (button.attr('lock')) return;
		button.attr('lock', 1);

		var actionsdiv = button.parent();
		var campaigndiv = actionsdiv.parent();
		var id = campaigndiv.attr('id');

		var statusId = button.val();
		if (statusId == 'ACTIVE') console.log('Activate campaign ' + id);
		else console.log('Pause campaign ' + id);

		actionsdiv.addClass('fixed');
		var spinnerOpts = {
			zIndex: 1,
			lines: 8,
			length: 2,
			width: 2,
			radius: 3,
			color: '#7b98d3'
		};
		button.css('color', 'transparent');
		spinner = button.spin(spinnerOpts);

		statusId = button.val();

		var self = this;
		var adSet = new api.AdSet(id);
		adSet.campaign_status = statusId;
		adSet.update()
			.then(function(response) {
				self.statusChanged(id, response); 
			})
			.catch(function(error) {
				console.log('changeStatus error', error);
			});
	},
	/**
	 * Atualiza status da campanha na UI
	 */
	statusChanged: function(id, result) {
		console.log('statusChanged',id,result);
		try {
			button = $('button', '#' + id);
			if (id && result.success) {
				button.css('color', '');
				if (button.val() == 'ACTIVE') {
					button.val('PAUSED').text(_('btnPause'));
					$('#' + id + ' .status').removeClass('paused').addClass('active').text(_('fbActive'));
				} else {
					button.val('ACTIVE').text(_('btnActivate'));
					$('#' + id + ' .status').removeClass('active').addClass('paused').text(_('fbPaused'));
				}
			} else {
				button.text("Tente novamente");
				button.css('color', 'red');
			}
			button.attr('lock', '');
			button.data('spinner').stop();
			var actionsdiv = button.parent();
			actionsdiv.removeClass('fixed');
		} catch (e) {
			console.log('Error statusChanged', e);
		}
	}
};

////////////
// LOADER //
////////////

Loader = {
	spinner: $("#spinner"),
	show: function() {
		$("#loadmorebutton").hide();
		$("#broken").hide();
		$("#fetching").show();
		$("#loader").show();
		this.spinner.spin();
	},
	hide: function() {
		$("#loadmorebutton").show();
		$("#loader").hide();
		this.spinner.data('spinner').stop();
	},
	error: function() {
		this.spinner.data('spinner').stop();
		this.spinner.spin({
			lines: 9,
			length: 0,
			width: 5,
			radius: 12,
			color: '#ffcc00',
			speed: 0
		});
		$("#fetching").hide();
		$("#broken").show();
	},
	setEvents: function() {
		$("#loadmorebutton").add($("#retrybutton")).click(function(e) {
			e.preventDefault();
			Campaigns.getCampaigns(true);
		});
	}
};

////////////////////////
// HANDLEBARS HELPERS //
////////////////////////

/* STATUS
1 - ativas
2 - pausadas
3 - excluídas
4 - finalizadas
5 - agendadas
6 - pendentes
*/
Handlebars.registerHelper('campaignActions', function(status) {
	try {
		var value;
		var label;
		if (typeof status == 'string') {
			switch (status.toUpperCase()) {
				case 'ACTIVE':
					value = 'PAUSED';
					label = _('btnPause');
					break;
				case 'PAUSED':
					value = 'ACTIVE';
					label = _('btnActivate');
					break;
			}
		}

		if (label)
			return '<button class="btn medium white ad-action" value="' + value + '">' + label + '</button>';
	} catch (e) {
		console.log('Handlebars.Helper.campaignActions', e);
	}
});

Handlebars.registerHelper('adUrl', function(campaign) {
	// console.log(campaign);
	var objCode;
	switch(campaign.objective) {
		case 'POST_ENGAGEMENT':
			objCode = 1;
			break;
		case 'PAGE_LIKES':
			objCode = 2;
			break;
		case 'WEBSITE_CLICKS':
		case 'WEBSITE_CONVERSIONS':
			objCode = 3;
			break;
		default:
			objCode = 0;
			break;
	}

	url = '/' + Campaigns.accountid;
	url += '/' + campaign.id;
	url += '/' + objCode;
	return '<a class="btn medium white" href="/ad' + url + '">' + _('btnDetails') + '</a>';
});

})();