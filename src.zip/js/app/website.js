;(function() {

var loginButtons = $('[rel="fb-login"]');
var deniedPermissions = false; // Permissions denied in this login process

window.fbAsyncInit = function() {
    FB.init({
        appId: g.appId,
        status: true, // check login status
        cookie: true, // enable cookies to allow the server to access the session
        xfbml: true, // parse XFBML
        version: 'v2.1'
    });

    setMenu();

    // Events

    loginButtons.click(function(e) {
        e.preventDefault();
        ga('send', 'event', 'login', 'click', 'login-button-' + $(this).attr('location'));
        mixpanel.track("Login Button Click", {
            'Type': 'Connect',
            'Location': $(this).attr('location')
        });
        login();
    });

    $('#authorize').click(function(e) {
        e.preventDefault();
        ga('send', 'event', 'login', 'click', 'authorize-button');
        mixpanel.track("Login Button Click", {
            'Type': 'Authorize'
        });
        login(true);
    });

    $('#contact-form').submit(function() {
        sendContact();
        return false;
    });
};

/**
 * Menu scrolling
 */
function setMenu() {
    $('#hud a[href*=#]:not([href=#])').click(function() {
        if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
            if (target.length) {
                $('html,body').animate({
                    scrollTop: target.offset().top - 30
                }, 1000);
                return false;
            }
        }
    });
};

///////////
// LOGIN //
///////////

var adManagementDenied = false; // Flag for Mixpanel

/**
 * Facebook Login
 */
function login(rerequest) {
    if (loginButtons.attr('loading')) return;
    startSpinner(loginButtons);
    $('#modalPermissions').modal('hide');

    var scope = {
        scope: g.scope
    }
    if(rerequest)
        scope.auth_type = 'rerequest';

    FB.login(function(response) {
        console.log(response);
        if (response.authResponse) {
            var token = response.authResponse.accessToken;
            appLogin(token);
        } else {
            ga('send', 'event', 'login', 'permission-denied', 'user-data');
            mixpanel.track("Permission Denied", {
                'Type': 'User Data'
            });
            console.log('mixit');
            permissionError();
        }
    }, scope);
}

/**
 * Application Login
 */
function appLogin(token) {
    var loginURL = "/login";
    $.post(loginURL, {
        'token': token
    }, function(response) {
        console.log(response);
        if (response.success) {
            var redirectUrl;
            if (response.message) 
                redirectUrl = response.message;
            else if (response.data.loginData['Has Published Ads?']) 
                redirectUrl = "/dashboard";
            else 
                redirectUrl = "/goals";

            // Analtyics Login Events
            var action = response.data.registration ? 'registration' : 'login';
            var label = deniedPermissions ? 'recovered-permissions' : 'granted-permissions';
            var fbId = response.data.fbId;
            ga('set', 'dimension1', 'logged'); // Login custom dimension
            ga('send', 'event', {
                'eventCategory': 'login',
                'eventAction': action,
                'eventLabel': label,
            });

            // Mixpanel tracking
            if (response.data.registration) { // Registration
                redirectUrl += '?registration=true';
                mixpanel.alias(fbId);
                if (!adManagementDenied) 
                    mixpanel.track("Permission Granted", {'Type': 'User Data'});
                mixpanel.track("Permission Granted", {'Type': 'Ad Management'});
                mixpanel.track("Registration", response.data.loginData);
            } else {
                mixpanel.identify(fbId);
                mixpanel.track("Login", response.data.loginData);
            }
            // Mixpanel profiling
            mixpanel.people.set(response.data.mixpanelProfile);
            mixpanel.people.increment('Logins', 1);

            // Redirect Timeout for js calls
            setTimeout(function() {
                location.href = redirectUrl;
            }, 1000);
        } else {
            switch (response.code) {
                case 403: // management permissions
                    ga('send', 'event', 'login', 'permission-denied', 'ad-management');
                    mixpanel.track("Permission Granted", {
                        'Type': 'User Data'
                    });
                    adManagementDenied = true;
                    mixpanel.track("Permission Denied", {
                        'Type': 'Ad Management'
                    });
                    permissionError();
                    break;
                case 500: // Facebook Communication Error
                    ga('send', 'event', 'error', 'facebook', 'login');
                    console.log('Facebook Communication Error. Please try again.');
                    stopSpinner(loginButtons);
                    break;
                default: // Server Errors
                    ga('send', 'event', 'error', 'server', 'login');
                    console.log('Server Error. Please try again.');
                    stopSpinner(loginButtons);
            }
        }
    });
}

/**
 * Permission error handler
 */
function permissionError() {
    console.log('permissionError');
    deniedPermissions = true;
    stopSpinner(loginButtons);
    $('#modalPermissions').modal('show');
}

/////////////
// CONTACT //
/////////////

/**
 * Send contact form
 */
function sendContact() {
    var submitBtn = $('#submitbtn');
    if (submitBtn.attr('loading')) 
        return false;
    $('#reponsesuccess,#reponseerror').fadeOut();
    if (!validateForm()) 
        return false;
    startSpinner(submitBtn);
    var contactForm = $('#contact-form');
    var data = contactForm.serialize();
    contactFormUrl = '/sendcontact';

    $.post(contactFormUrl, data, function(response) {
        stopSpinner(submitBtn);
        if (response.success) {
            contactForm[0].reset();
            $('#reponsesuccess').fadeIn();
            mixpanel.track("Contact Form Sent");
        } else {
            $('#reponseerror').fadeIn();
        }
    });
}

function validateForm() {
    var nameValidationResult = applyValidation($('#namefield'), emptyValidation);
    var emailValidationResult = applyValidation($('#emailfield'), emailValidation);
    var messageValidationResult = applyValidation($('#messagefield'), emptyValidation);
    return (nameValidationResult && messageValidationResult && emailValidationResult);
}

/**
 * Set UI validation feedback
 */
function applyValidation(el, validation) {
    if (validation(el)) {
        el.css({
            'border-color': '',
            'background-color': ''
        });
        return true;
    }
    el.css({
        'border-color': 'red',
        'background-color': '#ffe6df'
    });
    return false;
}

function emptyValidation(el) {
    return el.val();
}

function emailValidation(el) {
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(el.val());
}

////////////
// LOADER //
////////////

var spinnerOpts = {
    zIndex: 1,
    lines: 8,
    length: 2,
    width: 2,
    radius: 3,
    color: '#fff'
};

function startSpinner(obj) {
    obj.addClass('loading').spin(spinnerOpts).attr('loading', true);
}

function stopSpinner(objs) {
    objs.each(function() {
        $(this).removeClass('loading').attr('loading', '').data('spinner').stop();
    });
}

})();