var currentPlan = null;
$(document).ready(function() {
    $("#reallyCancelPlan").click(function(e) {
        mixpanel.track("Dashboard Action",{'Type':'Cancel Plan'});
        $("form#cancelPlan").submit();
    });
    $('button[rel=subscribeButton]').click(function(e) {
        currentPlan = $(this).attr('plan');
        if(hasPlan) {
            e.stopPropagation();
            mixpanel.track("Subscription Action",{'Type':'Show Modal'});
            $('#modalConfirmChange').modal('show');
        }
    });
    $("#payIt").click(function(e) {
        // console.log(currentPlan);
        mixpanel.track("Dashboard Action",{'Type':'Leave For Paypal'});
        $("form#formPlan"+currentPlan).submit();
    });
    $("#reallyChangePlan").click(function(e) {
        // console.log(currentPlan);
        mixpanel.track("Dashboard Action",{'Type':'Change Plan'});
        $("form#formPlan"+currentPlan).submit();
    });
});
