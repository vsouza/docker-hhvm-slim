///////////////////////////////////////////
// FLUXO DE EDIÇÃO DE ANÚNCIOS - PARCIAL //
///////////////////////////////////////////

function getCreativeAndEdit(creativeId) { console.log('getCreativeAndEdit');
	try {
		if (!creativeId) throw 'invalid creativeId';

		CreateClass.AdCreative().getCreative(creativeId, window.g.token, 'story_id,type,object_id,image_url,body,title,name,link_url,image_hash,image_file', 'handleGetCreativeAndEdit'); // buscando as informações do creative
	} catch (e) {
		console.log('getCreativeAndEdit()', e);
	}
}

function handleGetCreativeAndEdit(data) { console.log('handleGetCreativeAndEdit');
	console.log('handleGetCreativeAndEdit', data);
	try {
		if (!data instanceof Object || $.isEmptyObject(data))
			throw 'invalid data object';

		// verificação de erro
		if (data && data.hasOwnProperty('error') && data.error && data.error.hasOwnProperty('message'))
			throw data.error.message;

		// caso não tenhamos data.type
		if (!inObject('type', data)) {
			if (Campaign && typeof Campaign === "object" && !$.isEmptyObject(Campaign)) {
				if (Campaign.hasOwnProperty('masterAd')) {
					if (Campaign.masterAd.hasOwnProperty('objective') && typeof Campaign.masterAd.objective == 'string') {
						if ($.isArray(Campaign.masterAd.creative_ids)) {
							if (Campaign.masterAd.creative_ids.indexOf(tryParse(data.id, 'justNumber', 0)) > -1) {

								switch (Campaign.masterAd.objective.toLowerCase()) {
									case 'post_engagement':
										data.type = 27
										break;
									case 'page_likes':
										data.type = 2
										break;
									case 'website_clicks':
									case 'website_conversions':
										data.type = 1
										break;
									default:
										break;
								}
							}
						}
					}
				}
			}
		}

		if (!inObject('type', data))
			throw 'invalid data object';

		// caso seja domain ad
		if (data.type == 1) {
			var container = 'div#modalChangeCreativeDomain';

			if (inObject('title', data)) {
				$('input#titAd', container).val(data.title);
				$('.pag-name', container).text(data.title);
			}

			if (inObject('body', data)) {
				$('textarea#txtText', container).val(data.body);
				$('.pageLikeAdMessage', container).text(data.body);
			}

			if (inObject('link_url', data))
				$('.pageLikeAdTitle', container).text(data.link_url);

			if (inObject('image_url', data))
				window.g.creative.imgUrl = data.image_url;

			if (inObject('image_hash', data))
				window.g.creative.imgHash = data.image_hash

			$('.pag-thumb', container).html('&nbsp;');
			if (inObject('image_url', data)) {
				if (data.image_url) {
					$('.pag-thumb', container).html('<img src="' + data.image_url + '" border="0">');
				}
			} else if (inObject('image_hash', data)) {
				if (data.image_hash) {
					CreateClass.AdImage().getImageByHash(window.g.accountId, data.image_hash, window.g.token, 'handleGetImageByHash');
				}
			}


			// Abre o modal de edição de criativo
			showModal('#modalChangeCreativeDomain', {
				backdrop: 'static',
				keyboard: false
			});
		}

		// caso seja fan page ad
		if (data.type == 2) {

			var container = 'div#modalChangeCreative';

			if (inObject('title', data)) {
				$('input#titAd', container).val(data.title);
				$('.pag-name', container).text(data.title);
				$('.pageLikeAdTitle', container).text(data.title);
			}

			if (inObject('body', data)) {
				$('textarea#txtText', container).val(data.body);
				$('.pageLikeAdMessage', container).text(data.body);
			}

			if (inObject('link_url', data))
				window.g.pageUrl = data.link_url;

			if (inObject('object_id', data))
				window.g.pageId = data.object_id;

			$('.pag-thumb', container).html('&nbsp;');
			if (inObject('image_url', data)) {
				if (data.image_url) {
					$('.pag-thumb', container).html('<img src="' + data.image_url + '" border="0">');
				}
			} else if (inObject('image_hash', data)) {
				if (data.image_hash) {
					CreateClass.AdImage().getImageByHash(window.g.accountId, data.image_hash, window.g.token, 'handleGetImageByHash');
				}
			}

			// Abre o modal de edição de criativo
			showModal('#modalChangeCreative', {
				backdrop: 'static',
				keyboard: false
			});
		}

		// caso seja page post ad
		if (data.type == 27) {

			// verifica se existe uma pageId
			if (inObject('object_id', data)) {
				// define o postId atual na agulha
				window.g.ppCurrentStoryId = data.story_id;
				// captura os post promovíveis da página selecionada
				CreateClass.FbPage().getPromotablePosts(window.g.token, data.object_id, window.g.locale, window.g.ppFields, 10, 'fbHandlePromotablePosts', null);
			}
		}

	} catch (e) {
		console.log('handleGetCreativeAndEdit() : ', e);

		//exibe mensagem de erro
		bootbox.dialog({
			className: 'red',
			locale: window.g.languageMin,
			message: e,
			closeButton: false,
			buttons: {
				'ok': {
					label: _('ok'),
				},
			}
		});
	} finally {
		// disableButtonLoader($('tbody tr td [data-ad-action=edit]'));
	}
}

function handleGetImageByHash(data) { console.log('handleGetImageByHash');
	try {

		if (!data instanceof Object || $.isEmptyObject(data))
			throw 'invalid data object';

		if (data && data.hasOwnProperty('error') && data.error && data.error.hasOwnProperty('message'))
			throw data.error.message;

		if (!inObject('data', data))
			throw 'invalid data object';

		// capturando a primeira propriedade do objeto
		var data = data.data[Object.keys(data.data)[0]];

		if (!inObject('url', data))
			throw 'invalid data.url';

		// aplicando url em todos os thumbs DOM
		$('.pag-thumb').html('<img src="' + data.url + '" border="0">');
	} catch (e) {
		console.log('handleGetImageByHash():', e);
	}
}

function fbHandlePromotablePosts(data) { console.log('fbHandlePromotablePosts');
	try {
		if (!data instanceof Object || $.isEmptyObject(data))
			throw 'invalid data object';

		if (data && data.hasOwnProperty('error') && data.error && data.error.hasOwnProperty('message'))
			throw data.error.message;

		if (!inObject('data', data))
			throw 'invalid data object';

		window.g.ppArr = data.data; // guardando o objeto retornado da consulta

		// Abre o modal de edição de criativo
		showModal('#modalChooseCreative', {
			backdrop: 'static',
			keyboard: false
		});
	} catch (e) {
		console.log('fbHandlePromotablePosts():', e);
	}
}

// ↓ Função que starta os comportamentos Js do modal #modalChooseCreative

function modalChooseCreativePrepare(opt) { console.log('modalChooseCreativePrepare');
	try {
		var ppArr = window.g.ppArr || [];
		if (!$.isArray(ppArr)) throw 'invalid array data';
		if (ppArr.length < 1) throw 'invalid array data';

		var append = '';
		var liKlon = $('#modalChooseCreative li:first').clone();
		var currentId = window.g.ppCurrentStoryId || 0;

		for (i = 0, l = ppArr.length; i < l; i++) {
			if (currentId == ppArr[i].id) continue;
			var li = liKlon;
			var post = '';

			if (inObject('message', ppArr[i])) {
				post += ppArr[i].message;
			} else {
				if (inObject('story', ppArr[i])) {
					post += ppArr[i].story;
				}
			}

			if (inObject('full_picture', ppArr[i])) {
				if (ppArr[i].full_picture.indexOf('_s.') > -1) ppArr[i].full_picture = ppArr[i].full_picture.replace('_s.', '_n.');
				post += '<img src="' + ppArr[i].full_picture + '" border="0">';
				post += (ppArr[i].type == 'video' ? '<span class="videoPlay"></span>' : '');
			} else {
				if (inObject('picture', ppArr[i])) {
					if (ppArr[i].picture.indexOf('_s.') > -1) ppArr[i].picture = ppArr[i].picture.replace('_s.', '_n.');
					post += '<img src="' + ppArr[i].picture + '" border="0">';
					post += (ppArr[i].type == 'video' ? '<span class="videoPlay"></span>' : '');
				}
			}

			$('.fbCreative', li).attr('id', ppArr[i].id);
			$('p', li).html(post);
			append += '<li>' + $(li).html() + '</li>';
		}

		$('#modalChooseCreative > .modal-body > ul').html(append);

		var c = $('div#modalChooseCreative .fbCreative');
		var f = $('div#modalChooseCreative .modal-footer button');
		f.removeClass('btn-green').addClass('btn-modal-disabled');

		if (c.length > 0) {
			c.removeClass('selected')
			c.unbind('click').bind('click', function() {
				c.removeClass('selected');
				$(this).addClass('selected');
				var selId = $(this).attr('id');

				if (f.length > 0) {
					if (inArray('btn-modal-disabled', f.attr('class').split(' '))) {
						f.removeClass('btn-modal-disabled').addClass('btn-green');
						f.unbind('click').bind('click', function() {
							$("#modalChooseCreative").modal("hide");

							var selObj = $.grep(ppArr, function(e) {
								return e.id == selId;
							});

							if (!selObj instanceof Object || $.isEmptyObject(selObj))
								throw 'invalid selObj';

							if ($.isArray(selObj))
								if (selObj.length > 0)
									selObj = selObj[0];

							if (inObject('id', selObj)) {
								if (selObj.id.indexOf('_') > -1) {
									var split = selObj.id.split('_');
									if (split.length > 1) {

										//objeto creative
										var creative = {};
										// creative.type = 27;
										creative.object_id = split[0];
										creative.story_id = split[1];

										// chama a função que edita o arquivo
										editMainAd({
											creative: creative
										});
									}
								}
							}
						});
					}
				}
			});
		}

		$('#modalChooseCreative').modal(opt); //exibe o modal
	} catch (e) {
		bootbox.dialog({
			className: 'yellow',
			locale: window.g.languageMin,
			message: _('youDontHaveOtherPromotablesPosts'),
			closeButton: false,
			buttons: {
				'ok': {
					label: _('ok'),
				},
			}
		});
	}
}

function modalChangeCreativePrepare(opt) { console.log('modalChangeCreativePrepare');
	try {
		var container = 'div#modalChangeCreative';
		var titAd = $('input#titAd', container);
		var txtText = $('textarea#txtText', container);
		var adMedia = $('div.pageLikeAdMedia', container);
		var inputAddMedia = $('form#postForm input#file');
		var btnGo = $('button#btnGo_modalChangeCreative', container);

		maskFileInput(container); // definindo botão de input estilizado

		// definindo tooltip
		$('button#addMediaBtn', container).tooltip({
			placement: 'top'
		});

		// Função de replicação do conteúdo digitado no titAd para o preview
		titAd.unbind('keyup').bind('keyup', function() {
			var t = $(this).val();
			$('h6.pageLikeAdTitle', container).html(t);

			//show / hide btn
			if (titAd.val() && txtText.val()) {
				btnGo.attr('class', 'btn-green');
			} else {
				btnGo.attr('class', 'btn-modal-disabled');
			}
		});

		// Função de replicação do conteúdo digitado no txtText para o preview
		txtText.unbind('keyup').bind('keyup', function() {
			var t = $(this).val();
			$('div.pageLikeAdMessage', container).html(t);

			//show / hide btn
			if (titAd.val() && txtText.val()) {
				btnGo.attr('class', 'btn-green');
			} else {
				btnGo.attr('class', 'btn-modal-disabled');
			}
		});

		// Função de adicionar mídia no preview
		inputAddMedia.unbind('change').bind('change', function() {
			//criar o objeto que vai renderizar a imagem no preview
			var reader = new window.FileReader();
			reader.onload = function(e) {
				var result = e.target.result;
				if (result) {
					var splt = result.split(';')[0];
					splt = splt.replace('data:', '');

					try {
						//caso seja imagem
						if (splt.indexOf('image') > -1) {
							$(adMedia).html('<img src="' + result + '">');
							window.g.mustUploadImg = true;
							throw 1; // throw de sucesso
						}

						throw 0; // throw de arquivo inválido
					} catch (e) {
						if (e === 0) {
							// reseta o valor do input
							var postFile = $(':file', 'form#postForm');
							postFile.replaceWith(postFile = postFile.clone(true));

							$(adMedia).html('<div class="thumbInvalid"><span>' + _('invalidFile') + '</span></div>')
						}
					}
				}
			};

			// chama a função de renderizar
			reader.readAsDataURL($(this).get(0).files[0]);
		});

		//Função de GoOut do modal
		btnGo.unbind('click').bind('click', function() {
			var st = $(this).attr('class').split(' ');
			if (inArray('btn-modal-disabled', st))
				return false;

			var creative = {};
			// creative.type = 2;
			creative.object_id = window.g.pageId;
			creative.title = titAd.val();
			creative.body = txtText.val();
			creative.link_url = window.g.pageUrl;

			if (window.g.creative.imgHash && typeof window.g.creative.imgHash === 'string') {
				creative.image_hash = window.g.creative.imgHash;
			} else {
				if (window.g.creative.imgUrl && typeof window.g.creative.imgUrl === 'string')
					creative.image_url = window.g.creative.imgUrl;
			}

			if (!window.g.mustUploadImg) {
				// alterando o anúncio
				editMainAd({
					creative: creative
				});
			} else {
				// guardando objeto de edição para posteriormente ser chamado
				window.g.objEditAd = {
					creative: creative
				};

				// postando a imagem
				publish_uploadImgToAccountLibrary();
			}

			btnGo.unbind('click'); // unblind o click do botão
			$(container).modal('hide'); // esconde o modal
		});

		//exibe o modal
		$(container).modal(opt);
	} catch (e) {
		console.log('modalChangeCreativePrepare() : ', e);
	}
}

function modalChangeCreativeDomainPrepare(opt) { console.log('modalChangeCreativeDomainPrepare');
	try {
		var container = 'div#modalChangeCreativeDomain';
		var titAd = $('input#titAd', container);
		var txtText = $('textarea#txtText', container);
		var adMedia = $('div.pageLikeAdMedia', container);

		var inputAddMedia = $('form#postForm input#file');
		var btnGo = $('button#btnGo_modalChangeCreativeDomain', container);

		maskFileInput(container); // definindo botão de input estilizado

		// definindo tooltip
		$('button#addMediaBtn', container).tooltip({
			placement: 'top'
		});

		// Função de replicação do conteúdo digitado no titAd para o preview
		titAd.unbind('keyup').bind('keyup', function() {
			var t = $(this).val();
			$('.pag-name', container).html(t);

			//show / hide btn
			if (titAd.val() && txtText.val()) {
				btnGo.attr('class', 'btn-green');
			} else {
				btnGo.attr('class', 'btn-modal-disabled');
			}
		});

		// Função de replicação do conteúdo digitado no txtText para o preview
		txtText.unbind('keyup').bind('keyup', function() {
			var t = $(this).val();
			$('div.pageLikeAdMessage', container).html(t);

			//show / hide btn
			if (titAd.val() && txtText.val()) {
				btnGo.attr('class', 'btn-green');
			} else {
				btnGo.attr('class', 'btn-modal-disabled');
			}
		});

		// Função de adicionar mídia no preview
		inputAddMedia.unbind('change').bind('change', function() {
			//criar o objeto que vai renderizar a imagem no preview
			var reader = new window.FileReader();
			reader.onload = function(e) {
				var result = e.target.result;
				if (result) {
					var splt = result.split(';')[0];
					splt = splt.replace('data:', '');

					try {
						//caso seja imagem
						if (splt.indexOf('image') > -1) {
							$(adMedia).html('<img src="' + result + '">')
							window.g.mustUploadImg = true;
							btnGo.attr('class', 'btn-green');
							throw 1; // throw de sucesso
						}

						throw 0; // throw de arquivo inválido
					} catch (e) {
						if (e === 0) {
							// reseta o valor do input
							var postFile = $(':file', 'form#postForm');
							postFile.replaceWith(postFile = postFile.clone(true));

							$(adMedia).html('<div class="thumbInvalid"><span>' + _('invalidFile') + '</span></div>')
						}
					}
				}
			};

			// chama a função de renderizar
			reader.readAsDataURL($(this).get(0).files[0]);
		});

		//Função de GoOut do modal
		btnGo.unbind('click').bind('click', function() {
			var st = $(this).attr('class').split(' ');
			if (inArray('btn-modal-disabled', st))
				return false;

			//objeto creative
			var creative = {};
			// creative.type = 1;
			creative.title = titAd.val();
			creative.body = txtText.val();

			if (window.g.creative.imgHash && typeof window.g.creative.imgHash === 'string') {
				creative.image_hash = window.g.creative.imgHash;
			} else {
				if (window.g.creative.imgUrl && typeof window.g.creative.imgUrl === 'string')
					creative.image_url = window.g.creative.imgUrl;
			}

			if (!window.g.mustUploadImg) {
				// alterando o anúncio
				editMainAd({
					creative: creative
				});
			} else {
				// guardando objeto de edição para posteriormente ser chamado
				window.g.objEditAd = {
					creative: creative
				};

				// postando a imagem
				publish_uploadImgToAccountLibrary();
			}

			btnGo.unbind('click'); // unblind o click do botão
			$(container).modal('hide'); // esconde o modal
		});

		//exibe o modal
		$(container).modal(opt);
	} catch (e) {
		console.log('modalChangeCreativePrepare() : ', e);
	}
}

function publish_uploadImgToAccountLibrary() { console.log('publish_uploadImgToAccountLibrary');
	try {
		var token = tryParse(window.g.token, 'string', null);
		var accountId = tryParse(window.g.accountId, 'string', null);
		var callback = 'window.parent.publish_HandleUploadImgToAccountLibrary';
		var uriPostAccountLibrary = tryParse(window.g.uriPostAccountLibrary, 'string', null);
		window.g.mustUploadImg = false; // retornando a flag ao estado original

		if (!token) throw 'invalid token';
		if (!accountId) throw 'invalid accountId';
		if (!uriPostAccountLibrary) throw 'invalid uriPostAccountLibrary';

		$('form#postForm input#token').val(token);
		$('form#postForm input#accountId').val(accountId);
		$('form#postForm input#callback').val(callback);
		$('form#postForm').attr('action', uriPostAccountLibrary).submit();
	} catch (e) {
		console.log('publish_uploadImgToAccountLibrary', e);
	}
}

function publish_HandleUploadImgToAccountLibrary(data) { console.log('publish_HandleUploadImgToAccountLibrary');
	console.log('publish_HandleUploadImgToAccountLibrary', data);
	try {
		if (data.hasOwnProperty('data'))
			data = data.data;

		//facebook error
		if (data && data.hasOwnProperty('error') && data.error && data.error.hasOwnProperty('message'))
			throw data.error.message; //throw exception

		// backend error
		if (data.hasOwnProperty('success'))
			if (!data.success)
				throw data.message || 'backend error';

			// checando parametros recebidos
		if (data.hasOwnProperty('hash')) {
			if (!data.hash || typeof data.hash != 'string')
				throw 'invalid data.hash';

			window.g.creative.imgHash = data.hash;
		}

		if (data.hasOwnProperty('url')) {
			if (!data.url || typeof data.url != 'string')
				throw 'invalid data.url';

			window.g.creative.imgUrl = data.url;
		}

		// refatoração do objeto de edição
		if (window.g.creative.imgHash && typeof window.g.creative.imgHash === 'string') {
			window.g.objEditAd.creative.image_hash = window.g.creative.imgHash;
		} else {
			if (window.g.creative.imgUrl && typeof window.g.creative.imgUrl === 'string')
				window.g.objEditAd.creative.image_url = window.g.creative.imgUrl;
		}

		//editar anúncio
		editMainAd(window.g.objEditAd);
	} catch (e) {
		console.log('publish_HandleUploadImgToAccountLibrary():', e);
		bootbox.dialog({
			className: 'red',
			locale: window.g.languageMin || 'pt',
			message: e,
			closeButton: false,
			buttons: {
				'return': {
					label: _('ok')
				}
			}
		});
	}
}

function editMainAd(editObject) { console.log('editMainAd');
	try {
		if (!editObject instanceof Object || $.isEmptyObject(editObject))
			throw 'missing paremeter editObject';

		CreateClass.AdGroup().fbUpdate(window.g.token, window.g.currentAdId, editObject, 'fbHandleChangeCreativeDomain'); // chamada facebook solicitando edição de anúncio

		editVariationAds(editObject); // atribuindo mudanças também as variações de anúncios

		window.g.objEditAd = null; // retornano o objeto ao estado original
	} catch (e) {
		console.log('editMainAd():', e);
	}
}

function editVariationAds(editObject) { console.log('editVariationAds');
	try {
		if (!editObject instanceof Object || $.isEmptyObject(editObject))
			throw 'missing paremeter editObject';

		if (!$.isArray(Campaign.ads) || Campaign.ads.length < 1)
			throw 'no ad variations to be edited';

		// filtra os arrays nulos
		var vAds = $.grep(Campaign.ads, function(e) {
			return e != null;
		});

		if (!$.isArray(vAds) || vAds.length < 1)
			throw 'no ad variations to be edited';

		var objAdGroup = CreateClass.AdGroup();

		var loop = 0;
		var maxLoop = (vAds.length - 1);
		var milisegundos = 1000;
		var interval = setInterval(function() {
			// encerra o loop de intervalo
			if (loop > maxLoop)
				clearInterval(interval);
			else {
				//chama a edição de anúncio junto ao facebook
				if (vAds[loop].id)
					objAdGroup.fbUpdate(window.g.token, vAds[loop].id, editObject, 'fbHandleEditVariationAds');
			}

			loop++;
		}, milisegundos);
	} catch (e) {
		console.log('editVariationAds():', e);
	}
}

function fbHandleEditVariationAds(data) { console.log('fbHandleEditVariationAds');
	try {
		console.log(data);
	} catch (e) {
		console.log('fbHandleEditVariationAds():', e);
	}
}

function fbHandleChangeCreativeDomain(data) { console.log('fbHandleChangeCreativeDomain');
	try {
		if (!data || isNaN(data))
			throw _('msgErrorEditingAd');

		bootbox.dialog({
			className: 'green',
			locale: window.g.languageMin || 'pt',
			message: _('msgAdSuccessfullyChanged'),
			closeButton: false,
			buttons: {
				'return': {
					label: _('ok')
				}
			}
		});
	} catch (e) {
		console.log('fbHandleChangeCreativeDomain(): ', e);
		bootbox.dialog({
			className: 'red',
			locale: window.g.languageMin || 'pt',
			message: e,
			closeButton: false,
			buttons: {
				'return': {
					label: _('ok')
				}
			}
		});
	}
}
