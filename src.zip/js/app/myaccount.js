$(document).ready(function() {
    getAdAccounts();
    $('.selectpicker').selectpicker({
        style: 'tb-dropdown',
        dropupAuto: true,
        showSubtext: true,
    });
    $("#btn-uptfbadacc").click(function() {
        getAdAccounts(true);
    });
    $('#dropDownTimezone').selectpicker('val', g.useri18n.timezone);
    $('#dropDownLanguage').selectpicker('val', g.useri18n.lang);

});

// Loader
var spinner = $("#spinner");
var spinnerOpts = {
    lines: 8,
    length: 2,
    width: 2,
    radius: 3,
    color: '#7b98d3'
};

/**
 * Busca/Atualiza contas de Ads
 * @param  {bool} update flag de atualização
 */
function getAdAccounts(update) {
    update = (update || false);
    try {
        spinner.css("display", "block");
        spinner.spin(spinnerOpts);
        $('#accountstable').add($("#btn-uptfbadacc")).css("display", "none");
        var adUser = new api.AdUser('me');
        adUser.getAdAccounts().then(printAccounts);
        if (update)
            updateAdAccounts();
    } catch (e) {
        console.log('ERROR getAdAccounts : ' + e);
    }
}

/**
 * Autaliza contas de ads no backend
 */
function updateAdAccounts() {
    $.ajax({
        type: 'GET',
        url: '/updateadaccounts',
        success: function(response) {
            console.log('session updated');
        },
        error: function() {
            console.log('error saving session');
        }
    });
}

/**
 * Renderiza contas na tela
 * @param  {Object} accounts
 */
function printAccounts(accounts) {
    CreateClass.MyHandlebars(accounts, "fbaccounts_rows").simpleRender();
    $('#accountstable').add($("#btn-uptfbadacc")).css("display", "");
    $('.money').currency({
        region: window.g.currency,
        thousands: window.g.thousandSymbol,
        decimal: window.g.decimalSymbol,
        decimals: window.g.decimalCount,
        hidePrefix: false,
        hidePostfix: true,
    });
    spinner.data('spinner').stop();
    spinner.css("display", "none");
}