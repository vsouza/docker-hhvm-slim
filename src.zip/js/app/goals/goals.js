window.g.accountId = (g.hasOwnProperty('accountId') ? g.accountId : tbCookie.get("currentAccountId")); //recuperando a AccountId atual do cliente
window.g.arrVid = ['3g2', '3gp', '3gpp', 'asf', 'avi', 'dat', 'divx', 'dv', 'f4v', 'flv', 'm2ts', 'm4v', 'mkv', 'mod', 'mov', 'mp4', 'mpe', 'mpeg', 'mpeg4', 'mpg', 'mts', 'nsv', 'ogm', 'ogv', 'qt', 'tod', 'ts', 'vob', 'wmv']; // array de extensões válidas para vídeos
window.g.stepperW = 960; // largura dos passos dos objetivos
window.g.oldStepper = 1; // start do oldStepper sempre pelo 0
window.g.stepper = 1; // start do stepper sempre pelo 1
window.g.ppFields = 'name, message, story, type, timeline_visibility, link, picture, full_picture, created_time, is_published'; // campos que serão buscados na chamada dos posts promovíveis
window.g.ppArr = null; // array de posts promovíveis
window.g.ppNextUrl = null; // próxima url de post promovíveis
window.g.pageId = null; // id da fan page
window.g.pageUrl = null; // url da fan page
window.g.lastUrl = ''; // última url processada no objetivo 03
window.g.pageToken = null; // token da fan page
window.g.stpGuideChecked = (tbCookie.get("stpGuideChecked") == 1); // flag de checagem do guide
window.g.stpFirstReachSearch = false; // flag de primeira busca de segmentação
window.g.stpDateTimePickerSet = false; // flag de instância do datetimepicker
window.g.stpSimulated = false; // flag de simulação de bidding efetivada
window.g.reachEstimate = 0; // reach de pessoas baseado na segmentação
window.g.avgCpmValue = 0; // média do valor de CPM
window.g.avgCentsByDay = 5000; // valor estipulado pelo FRED HEITASKJDSMAN para cálculo diário de exibição
window.g.frequencyIndex = 3.242178905384657; // frequência estática adicionada ao cáulculo de exibições, baseada na média da ezlike
window.g.createCampaignBy = ''; // flag de modo de cálculo de biddin
window.g.uriPostAccountLibrary = '/upload/fb/album/photo'; // url da chamada no back para upload de imagem
window.g.postFormPhoto = '/upload/fb/photo';
window.g.postFormVideo = '/upload/fb/video';
window.g.assetsPath = DEF_CONFIG.get('ASSETSPATH')
window.g.uriThumbVideo = '/' + window.g.assetsPath + '/img/thumbVideo.jpg';
window.g.uriThumbInvalid = '/' + window.g.assetsPath + '/img/thumbInvalid.jpg';
window.g.postSendPixelEmail = '/pixel/send'; // url de envio de email
window.g.uriPostWizardPixel = '/#'; //url de submit de conclusão do wizard pixel
window.g.variationAd = []; // array de variações de anúncios
window.g.arrRelatedPageId = []; // array de fan pages utilizada para inserir nos criativos
window.g.adKeyWord = []; // preset / valores de interesses utilizados na definição do targeting
// preset | valores de localizações utilizados na definição do targeting
// window.g.adGeoLocation = [{
//     key: "BR",
//     name: "Brasil",
//     type: "country",
//     supports_city: false,
//     supports_region: false,
// }]; 
// window.g.adKeyWord = [{
//     id: 6003065815607,
//     name: "Copa Do Mundo Brasil 2014"
// }];
window.g.creative = {
    imgUrl: null, //'https://fbcdn-creative-a.akamaihd.net/hads-ak-ash3/1487607_6014166794091_1968530152_n.png',
    imgHash: null, //'35772e5279b79e4303754377452ffb2c',
    imgWidth: null,
    imgHeight: null,
};
// objeto utilizado para auxílio com tratamento de constução do objeto Ad Creative
window.g.metaTag = {
    postGetMetaTags: '/segmentation/url',
    description: null,
};
// objeto utilizado para armazenar dados oriundos da busca de meta tags
window.g.pixel = {
    pixelAsk: false,
    pixelId: null,
    pixelName: '',
    pixelTrack: null,
    pixelTag: null,
    pixelPrettyTag: null,
};
// objeto utilizado para armazenamento do de informações do pixel
window.g.publish = {
    postConsistency: '/goal/consistency',
    name: null,
    objective: null,
    postId: null,
    campaignGroupId: null,
    campaignId: null,
    primaryAdId: null,
    adVariations: [],
};
// objeto utilizado para o armazenamento e auxílio para consistência dos dados de conclusão de todos os objetivos
window.g.currentGoal; // Objetivo atual para GA

// objeto que receberei do backend
var pageData = {}
pageData.targeting = {
    age: {
        begin: '13',
        end: '65',
    },
    gender: 0,
}; // objeto de auxílio do preset de segmentação


// SDK Targeting Specs
window.g.targetingSpecs = new TB.Targeting.Specs();

// User has Pages (mixpanel helper)
window.g.hasPages;
window.g.suggestedInterests = null;
window.g.interestsInput = false;

//////////////////////
// FACEBOOK OBJECTS //
//////////////////////

var adAccount = new api.AdAccount('act_' + window.g.accountId);

///////////////////////////
// HELPERS DO HANDLEBARS //
///////////////////////////

// Helper do Handlebars para montar o indicador do carousel de escolha de páginas
Handlebars.registerHelper('carouselChooseYourPageIndicators', function(array) {
    var i = 0,
        counter = 0,
        ret = "";

    if (array && typeof array === 'object') {
        if (array instanceof Array) {
            for (var j = array.length; i < j; i++) {
                if (array[i].type != 1 && array[i].type != 6) continue; // (1 page; 6 Place)

                if (i % 2 === 0) {
                    ret += '<li data-target="#carouselChooseYourPage" data-slide-to="' + counter + '" class="' + (i == 0 ? 'active' : '') + '"></li>';
                    counter++
                }
            }
        } else {
            ret += '<li data-target="#carouselChooseYourPage" data-slide-to="0" class="active"></li>';
        }
    }
    return ret;
});

// Helper do Handlebars para separar de 2 em 2 as páginas no carousel de escolha da página
Handlebars.registerHelper('carouselChooseYourPageInner', function(array) {
    try {
        var i = 0;
        var counter = 0;
        var ret = '';
        var open = '<div class="active item"><ul>';
        var close = '</ul></div>';
        var li = '';

        if (!$.isArray(array) || array.length < 1) return '<span class="fbInfoYellow14" style="line-height:1.5; display:block; text-align:center;">' + _('fanPageNotFound') + '</span>';

        for (var j = array.length; i < j; i++) {
            // (1 page, 6 Place)
            if (array[i].type != 1 && array[i].type != 6) continue;

            li += '<li id="' + array[i].id + '" thumb="' + array[i].picture + '" pageurl="' + array[i].url + '">' +
                '<span></span>' +
                '<div class="pageContainer">' +
                '<div></div>' +
                '<span>' + (array[i].picture ? '<img src="' + array[i].picture + '" border="0">' : '') + '</span>' +
                '<h5>' + (array[i].name ? array[i].name : '') + '</h5>' +
                '<p>' + (array[i].url ? array[i].url : '') + '</p>' +
                '</div>' +
                '</li>';

            counter++

            if (counter % 2 == 0) {
                ret += open + li + close;
                open = '<div class="item"><ul>';
                li = '';
            }
        }

        if (counter % 2 != 0) ret += open + li + close;

    } catch (e) {
        ret = '<span class="fbInfoYellow14" style="line-height:1.5; display:block; text-align:center;">' + _('ERROR') + '</span>';
    } finally {
        return ret;
    }
});

// Helper do Handlebars para fazer iterações de um tpl substituindo a key pelo indice
Handlebars.registerHelper("iterateTpl", function(begin, end, sel, tpl) {
    try {
        var out = '';

        begin = (!begin || isNaN(begin) ? 0 : parseFloat(begin));
        end = (!end || isNaN(end) ? 1 : parseFloat(end));
        sel = (!sel || isNaN(sel) ? begin : parseFloat(sel));
        if (!tpl || typeof tpl != 'string') throw 'invalid template';

        for (i = begin; i <= end; i++) {
            var t = '';
            if (sel == i) {
                t = replaceAll(tpl, '%0', i);
                t = replaceAll(t, '%1', 'selected="selected"');
            } else {
                t = replaceAll(tpl, '%0', i);
                t = replaceAll(t, '%1', '');
            }
            out += t;
        }

        return $.trim(out);
    } catch (e) {
        console.log('HHelper.iterateTpl : ', e);
        return '';
    }
});

// Helper do Handlebars escrever a oração de ex: "20 a 30 anos"
Handlebars.registerHelper("madeRange", function(oData, oTerms) {
    try {
        var out = '';

        if (!oData instanceof Object || $.isEmptyObject(oData)) throw 'missing paremeter oData';
        if (!oTerms instanceof Object || $.isEmptyObject(oTerms)) throw 'missing paremeter oTerms';

        if (inObject('of', oTerms))
            out += (oTerms.of + ' ' || '');

        if (inObject('begin', oData)) {
            out += (oData.begin + ' ' || '');
        } else {
            throw 'missing paremeter oData.begin';
        }

        if (inObject('conjunctive', oTerms))
            out += (oTerms.conjunctive + ' ' || '- ');

        if (inObject('end', oData)) {
            if (parseFloat(oData.end) >= parseFloat(oData.begin) && parseFloat(oData.end) != 0) {
                out += (oData.end + ' ' || '');
            } else {
                out += (oTerms.indefinite + ' ' || '');
            }
        }

        out += _n(oTerms.misgid, (oData.end || oData.begin));

        return $.trim(out);
    } catch (e) {
        console.log('HHelper.madeRange : ', e);
        return '';
    }
});

//Helper do Handlebars que escolhe a classe de acordo com as propriedades do objeto gender
Handlebars.registerHelper("genderShowClass", function(oData) {
    try {
        if (!oData instanceof Object || $.isEmptyObject(oData)) throw 'missing paremeter oData';

        var arrClass = ['sex0', 'sex1', 'sex2'];

        if (inObject('male', oData) && !inObject('female', oData))
            return arrClass[0];

        if (!inObject('male', oData) && inObject('female', oData))
            return arrClass[1];

        return arrClass[2];
    } catch (e) {
        console.log('HHelper.genderShowClass : ', e);
        return '';
    }
});

// Helper do Handlebars escrever a oração de ex: "Homens e Mulheres"
Handlebars.registerHelper("genderShow", function(oData, oTerms) {
    try {
        var out = '';

        if (!oData instanceof Object || $.isEmptyObject(oData)) throw 'missing paremeter oData';
        if (!oTerms instanceof Object || $.isEmptyObject(oTerms)) throw 'missing paremeter oTerms';

        if (inObject('male', oData))
            out += (oData.male + ' ' || '- ');

        if (inObject('female', oData)) {
            if (oData.female) {
                if (out.length > 0) {
                    if (inObject('conjunctive', oTerms)) {
                        out += (oTerms.conjunctive + ' ' || '- ');
                        out += (oData.female + ' ' || '- ');
                    }
                } else {
                    out += (oData.female + ' ' || '- ');
                }
            }
        }

        return $.trim(out);
    } catch (e) {
        console.log('HHelper.genderShow : ', e);
        return '';
    }
});

/////////////////////////////////////////////
// COMPORTAMENTO VISUAL DE TODO O CONTEXTO //
/////////////////////////////////////////////

/**
 * Função para aplicar tamanho dinâmico nas li do fullCarousel
 * @param  {integer} step :
 * @param  {integer} plus :
 */
function liFullCarouselAutoH(step, plus) {
    if (!step) return;
    $('#goalContent > div.fullCarousel > ul').animate({
        height: $('#goalContent > div.fullCarousel > ul > li:nth-child(' + step + ')').height() + (plus || 10)
    }, 200);
};

/////////////////////////////////////////////////////////
// FUNÇÕES DE AUXÍLIO AO SELETOR DE CONNECTION OBJECTS //
/////////////////////////////////////////////////////////

/**
 * Callback do facebook que instancia o comportamento das telas dos objetivos (goal1, goal2, goal3)
 * @param object data: Resposta do facebook, objeto contendo (Connection Objects), que são as Páginas, Locias, Aplicativos, Eventos e Dominios
 */
function fbReady(data) {
    try {
        fullLoaderStop(); // esconde o fullLoader

        // Adiciona o carrosel com as páginas e locais (Connection Objects) retornados pelo facebook ou exibe a mensagem de "not found"
        if (data.length) {

            CreateClass.MyHandlebars(data, "carouselChooseYourPage").simpleRender();

            // definição do carousel carouselGoal para não agir sozinho
            $('.carouselGoal').carousel({
                interval: false,
                wrap: true
            }).on('slide.bs.carousel', function() { // antes de executar o slide
            }).on('slid.bs.carousel', function() { // depois de executar o slider
                showHidePaginatorCarousel('.pageList'); //  Aplica regra de limites de paginação evitando o loop
                getPagesIdToSearch(window.g.token, 'fbFeedMorePageInfo'); //complementar informação das fanpages
            });

            // esconder os paginadores do carousel quando os dados forem menores que 3
            if (data.length < 3) {
                $('div#carouselChooseYourPage .carousel-control').hide();
                $('div#carouselChooseYourPage .carousel-indicators').hide();
            }

            fanPageBinder(); // Define o comportamento de seleção de páginas no carrosel de paginas
            showHidePaginatorCarousel('.pageList'); // Aplica regra de limites de paginação evitando o loop
            stepperVerify(window.g.stepper); // Gerecia o comportamento de passo a passo de cada objetivo distintamente
            getPagesIdToSearch(window.g.token, 'fbFeedMorePageInfo'); //complementar informação das fanpages

            if (window.g.currentGoal != 3) {
                startFullCarousel(); //iniciar o comportamento do fullCarousel

                $('.fullCarousel').on('jcarousel:scroll', function(event, carousel) {
                    $('#goalContent > div.fullCarousel > ul').animate({
                        height: 1000
                    }, 200);
                });

                $('.fullCarousel').on('jcarousel:scrollend', function(event, carousel) {
                    $('html,body').animate({
                        scrollTop: 0
                    }, 300);
                });
            }
        } else {
            $('#noPages').show();
        }
    } catch (e) {
        console.log('fbReady : ', e);
    }
};

/**
 * Captura os ids das páginas (Connection Object) e busca mais informações
 * @param  {string} token
 * @param  {string} callback
 */
function getPagesIdToSearch(token, callback) {
    if (!token || (typeof token !== 'string')) return false;
    if (!callback || (typeof callback !== 'string')) return false;

    var $lis = $('div.pageList > div.active > ul > li');
    if ($lis.length > 0) {
        $lis.each(function() {
            var id = $(this).attr('id');
            var load = $(this).attr('load');

            if (load) return false;
            if (!id || isNaN(id)) return false;
            if (parseFloat(id) < 1) return false;

            $(this).spin(null, '#7b98d3'); // inclusão do preloader

            TB.Page.getPage(callback, id, ['cover', 'about', 'name', 'link']);
        });
    }
};

/**
 * Callback resposável por aplicar mais informações de (Connection Objects) ao carrosel de Páginas e Locais
 * @param  {object} data: objeto retornado pelo facebook
 * @return {[type]}
 */
function fbFeedMorePageInfo(data) {
    if ((data instanceof Object) && !$.isEmptyObject(data)) {
        // erro encontrado
        if (inObject('error', data)) {
            bootbox.dialog({
                className: 'red',
                locale: window.g.languageMin,
                message: data.error.message,
                closeButton: false,
                buttons: {
                    'return': {
                        label: _('btnBack'),
                        callback: function() {
                            window.history.back();
                        }
                    },
                    'retry': {
                        label: _('btnRetry'),
                        callback: function() {
                            window.location.reload();
                        }
                    },
                }
            });
            return false;
        }

        var id = (inObject('id', data) ? data.id : null);
        var name = (inObject('name', data) ? data.name : null);
        var about = (inObject('about', data) ? data.about : '');
        var link = (inObject('link', data) ? data.link : null);
        var cover = null;

        if (inObject('cover', data)) { // caso tenha imagem de cover
            if (inObject('source', data.cover)) {
                cover = '<img src="' + data.cover.source + '" border="0">';
            }
        }

        var thumb = $('li#' + id, 'div.pageList').attr('thumb');
        if (thumb) {
            thumb = '<img src="' + thumb + '" border="0">';
        }
        if (!cover) cover = '<img src="/' + window.g.assetsPath + '/img/noMiniCover.jpg" border="0">';
        var pageContainer = '<span></span>' +
            '<div class="pageContainer">' +
            '<div class="nobefore">' + cover + '</div>' +
            '<span>' + thumb + '</span>' +
            '<h5>' + name + '</h5>' +
            '<p>' + strSummary(about, 70, '...') + '</p>' +
            '</div>';

        $('li#' + id, 'div.pageList').html(pageContainer).attr('load', 1);

        // $('.pag-cover').addClass('nobefore').html(cover);

        fanPageBinder(); // redefine os comportamentos que foram subtituidos no DOM
    }
};

// Função para aplicar quantas vezes for necessária uma determinada função a um elemento, devido as subtituições no DOM
var keywordsAjax;

/**
 * Define o comportamento de click do carrosel de seleção de páginas (Connection Objects)
 * @return {[type]}
 */
function fanPageBinder() {
    // Seleção de fanpage
    $('div.pageContainer', 'div.pageList', 'div.pageContainer > span').unbind('click').bind('click', function() {
        var $this = $(this);

        //aplica classe de selecionado
        $('div.pageList > .item > ul > li').removeClass('selected');
        $this.parent().addClass('selected');

        // alimentando variável de controle
        window.g.pageId = (!isNaN($this.parent().attr('id')) ? parseFloat($this.parent().attr('id')) : window.g.pageId);

        // console.log('pageId', window.g.pageId);
        if (keywordsAjax) keywordsAjax.abort(); //kill previous request
        var keywordsAjax = $.ajax({
            type: "POST",
            url: "/segmentation/fbpage",
            data: "pageId=" + window.g.pageId,
            success: function(response) {
                if (response.hasOwnProperty('data')) {
                    if (window.g.interestsInput) fillSuggestedInterests(response.data)
                    else window.g.suggestedInterests = response.data;
                } else {
                    if (window.g.interestsInput) {
                        // Efetua busca de interesses relacionados a página selecionada e aplica na segmentação do público
                        $("input#interestDefiner").tokenInput("clear");
                        updateInterests();
                    }
                }
            }
        });

        if (inObject('pageUrl', window.g)) window.g.pageUrl = $this.parent().attr('pageurl'); // alimentando variável de controle
        if (inObject('ppArr', window.g)) window.g.ppArr = null; // limpando a variável de controle

        // replica informações para o próximo passo
        var thmb = $this.parent().attr('thumb');
        window.g.creative.imgUrl = thmb;
        $('.pag-thumb').attr('hasmedia', '1').html((thmb ? '<img src="' + thmb + '" border="0">' : ''));
        $('.pag-cover').addClass('nobefore').html($this.children('div').html());
        $('.pag-name').text($this.children('h5').text());
        $('.pag-info').text($this.children('p').text());

        // gerencia os botões de paginação do stepper
        stepperVerify(window.g.stepper);
    });
};

/**
 * Função para alterar os status do paginador do carousel evitando o loop, habilitando e desabilitado o paginador
 * @param string selector: string contendo o identificador do elemento no DOM
 */
function showHidePaginatorCarousel(selector) {
    if (!selector || typeof selector != 'string') return false;
    if ($(selector).length < 1) return false;

    var carouselId = $(selector).closest('.carousel').attr('id');
    if (!carouselId) return false;

    $('div.carousel-control.left a', '#' + carouselId).removeClass('disabled').attr({
        'data-slide': 'prev',
        'href': '#' + carouselId,
    });

    $('div.carousel-control.right a', '#' + carouselId).removeClass('disabled').attr({
        'data-slide': 'next',
        'href': '#' + carouselId,
    });

    if ($('.item:first', selector).length > 0) { // desabilitando o paginador esquerdo
        var first = $('.item:first', selector).attr('class').split(' ');
        if (inArray('active', first)) {
            $('div.carousel-control.left a', '#' + carouselId).addClass('disabled').removeAttr('data-slide').attr({
                'href': '#',
            });
        }
    }

    if ($('.item:last', selector).length > 0) { // desabilitando o paginador direito
        var last = $('.item:last', selector).attr('class').split(' ');
        if (inArray('active', last)) {
            $('div.carousel-control.right a', '#' + carouselId).addClass('disabled').removeAttr('data-slide').attr({
                'href': '#',
            });
        }
    }

    if ($('#carouselChooseYourPage > div.carousel-inner.pageList').children('div').length < 1) { // escondendo todos os dois paginadores
        $('div.carousel-control a', '#' + carouselId).css({
            'visibility': 'hidden',
        });
    }
};

////////////
// MODAIS //
////////////

/**
 * Prepara o comportamento do modal #modalManageAge
 * @param  {object} opt : Objeto com parametros de inicialização
 */
function modalManageAgePrepare(opt) {
    try {
        mixpanel.track("Segmentation Modal", {
            'Type': 'Age'
        });
        $('a.bootstro-finish-btn').click(); //fechando qualquer guia de tutórial que estaja aberto

        var idModal = 'div#modalManageAge';
        var saveBtn = $('div.modal-footer > button', idModal);
        var beginAgeInstance = $('#modalManageAge div.modal-body div.bootstrap-select button[data-id="beginAge"]');
        var endAgeInstance = $('#modalManageAge div.modal-body div.bootstrap-select button[data-id="endAge"]');

        //singleton dos selectpicker com valores default
        if (!beginAgeInstance.length || !endAgeInstance.length) {
            $('.selectpicker', idModal).selectpicker({ //selects customizados
                style: 'tb-dropdown',
                width: 'auto',
                size: 7,
                dropupAuto: false,
                showSubtext: true,
            });
        }

        //ação de salvar parametros do modal
        saveBtn.unbind('click').bind('click', function() {
            var begin = $('#beginAge').val();
            var end = $('#endAge').val();
            if (!isNaN(begin) && !isNaN(end)) {
                begin = parseFloat(begin);
                end = parseFloat(end);

                if (end < begin && end != 0) {
                    end = begin;
                    $('#endAge').selectpicker('val', end);
                }

                var age = {
                    begin: begin,
                    end: end,
                };
            } else {
                var age = {
                    begin: 13,
                    end: 0,
                };
            }

            $('#segAge > div.r-body > div.r-content > span').html(madeRange(age, {
                conjunctive: _('labTo'),
                indefinite: _('labIndefinite'),
                misgid: 'year'
            }));

            $(idModal).modal('hide');
            getReachEstimate();
        });

        //exibe o modal
        $(idModal).modal(opt);
    } catch (e) {
        console.log('modalManageAgePrepare() : ', e);
    }
};

/**
 * Prepara o comportamento do modal #modalManageGenre
 * @param  {object} opt : Objeto com parametros de inicialização
 */
function modalManageGenrePrepare(opt) {
    try {
        mixpanel.track("Segmentation Modal", {
            'Type': 'Genre'
        });
        $('a.bootstro-finish-btn').click(); //fechando qualquer guia de tutórial que estaja aberto

        var idModal = 'div#modalManageGenre';
        var radios = $('.radio', idModal);
        var saveBtn = $('div.modal-footer > button', idModal);

        // Função de comportamento dos "radios buttons" do modal
        if (radios.length > 0) {
            radios.unbind('click').bind('click', function() {
                radios.removeClass('selected');
                $(this).addClass('selected');
            });
        }

        //ação de salvar parametros do modal
        saveBtn.unbind('click').bind('click', function() {

            var radioSel = $('.tbRadio div.selected');
            if (radioSel.length > 0) {
                var option = radioSel.attr('id').replace('radio', '');
                var gender = {};
                switch (parseFloat(option)) {
                    case 0:
                        gender.male = $('#radio0 > span', idModal).text();
                        break;
                    case 1:
                        gender.female = $('#radio1 > span', idModal).text();
                        break;
                    case 2:
                        gender.male = $('#radio0 > span', idModal).text();
                        gender.female = $('#radio1 > span', idModal).text();
                        break;
                }

                $('#segSex > div.r-body > div.r-bg.height137 > span').attr('class', 'sex' + option);
                $('#segSex > div.r-body > div.r-content > span').html(genderShow(gender, {
                    conjunctive: _('labAnd')
                }));
            }
            $(idModal).modal('hide');
            getReachEstimate();
        });

        //exibe o modal
        $(idModal).modal(opt);
    } catch (e) {
        console.log('modalManageGenrePrepare() : ', e);
    }
};

/**
 * Prepara o comportamento do modal #modalManagePlace
 * @param  {object} opt : Objeto com parametros de inicialização
 */
function modalManagePlacePrepare(opt) {
    try {
        mixpanel.track("Segmentation Modal", {
            'Type': 'Location'
        });
        $('a.bootstro-finish-btn').click(); //fechando qualquer guia de tutórial que estaja aberto

        var idModal = 'div#modalManagePlace';
        var saveBtn = $('div.modal-footer > button', idModal);

        //iniciar o comportamento tokenInput para localização
        startPlaceDefiner();

        //ação de salvar parametros do modal
        saveBtn.unbind('click').bind('click', function() {
            //sincronizar os valores que estão no cache do elemento placeDefiner com o HTML da página goal.php
            finderCacheSyncHTML('placeDefiner');
            $(idModal).modal('hide');
            getReachEstimate();
        });

        //exibe o modal
        $(idModal).modal(opt);
    } catch (e) {
        console.log('modalManagePlacePrepare() : ', e);
    }
};

/**
 * Prepara o comportamento do modal #modalManageInterest
 * @param  {object} opt : Objeto com parametros de inicialização
 */
function modalManageInterestPrepare(opt) {
    try {
        mixpanel.track("Segmentation Modal", {
            'Type': 'Interests'
        });
        $('a.bootstro-finish-btn').click(); //fechando qualquer guia de tutórial que estaja aberto

        var idModal = 'div#modalManageInterest';
        var saveBtn = $('div.modal-footer > button', idModal);
        var langPkg = $('input#langPkg', idModal);

        //iniciar o comportamento tokenInput para interesses
        startInterestDefiner();

        //ação de salvar parametros do modal
        saveBtn.unbind('click').bind('click', function() {
            updateInterests();
            $(idModal).modal('hide');
        });

        //exibe o modal
        $(idModal).modal(opt);
    } catch (e) {
        console.log('modalManageInterestPrepare() : ', e);
    }
};

/**
 * Prepara o comportamento do modal #modalCreateFanPage
 * @param  {object} opt : Objeto com parametros de inicialização
 */
function modalCreateFanPagePrepare(opt) {
    try {
        mixpanel.track("Fan Page Creation Action", {
            'Type': 'Modal Open'
        });
        var idModal = 'div#modalCreateFanPage';
        var modalBtn = $('div.modal-footer > button', idModal);
        var paragraph = $('div.modal-body > p', idModal);
        var labContinue = modalBtn.attr('labContinue');
        var labContinueP = paragraph.attr('labContinue');
        var createNewFanPage = 'https://www.facebook.com/pages/create/';

        //ação de salvar parametros do modal
        modalBtn.unbind('click').bind('click', function() {
            mixpanel.track("Fan Page Creation Action", {
                'Type': 'Leave for Facebook'
            });
            var modalBtnCls = modalBtn.attr('class').split(' ');

            if (modalBtnCls.indexOf('create') > -1) {
                modalBtn.removeClass('create').text(labContinue);
                paragraph.text(labContinueP);
                window.open(createNewFanPage, '_blank');
                $('div.modal-header > button', idModal).hide();
            } else {
                mixpanel.track("Fan Page Creation Action", {
                    'Type': 'Clicked Continue'
                });
                window.location.reload();
            }
        });

        //exibe o modal
        $(idModal).modal(opt);
    } catch (e) {
        console.log('modalManageInterestPrepare() : ', e);
    }
};

///////////////////////////////////////
// FACEBOOK OBJECT MAKER and HANDLER //
///////////////////////////////////////

/**
 * Função que faz a leitura no dom capturando as informações montarão um objeto targeting-specs{}
 * https://developers.facebook.com/docs/reference/ads-api/targeting-specs/
 * @return {object|null} : objeto targeting-specs ou null
 */
function getTargetingSpecFromSegmentation() {
    try {
        // definição de idade
        var aMin = parseFloat($('#beginAge').val() || 13);
        var aMax = parseFloat($('#endAge').val() || 65);
        window.g.targetingSpecs.setAge(aMin, aMax);

        // definição de genero no html -- 0 = male; 1 = female ; 2 = both
        // definição de genero -- 1 = male;  2 = female
        var gender = $('.tbRadio > div.selected').attr('id').replace('radio', '') || 2;
        // returnObj.genders = (gender == 0 ? [1] : (gender == 1 ? [2] : []));
        gender = (gender == 0 ? 1 : (gender == 1 ? 2 : null));
        window.g.targetingSpecs.setGenders(gender);

        return specs = window.g.targetingSpecs.getPreparedObject() || null;
    } catch (e) {
        console.log('getTargetingSpecFromSegmentation() : ', e);
        return null;
    }
};

/**
 * Função que lida como o retorno do facebook (reach estimate) e aplica no passo de definição de público
 * @param  {object} data : Objeto de retorno do facebook
 */
function fbHandleReachEstimate(data) {
    try {
        //facebook error
        if (data.hasOwnProperty('error'))
            if (data.error.hasOwnProperty('message'))
                throw data.error.message;

            // capturando a média do custo do cpm
        if (!data.hasOwnProperty('bid_estimations')) throw 'error when capturing bid_estimations parameter';

        if ($.isArray(data.bid_estimations)) {
            if (data.bid_estimations[0].hasOwnProperty('cpm_median')) {
                window.g.avgCpmValue = data.bid_estimations[0].cpm_median
            }
        } else {
            if (data.bid_estimations.hasOwnProperty('cpm_median')) {
                window.g.avgCpmValue = data.bid_estimations.cpm_median
            }
        }

        // capturando o valor estimado de pessoas que serão atingindas
        if (!data.hasOwnProperty('users')) throw 'error when capturing user parameter';

        var end = parseInt(data.users) || 1;

    } catch (e) {
        console.log('fbHandleReachEstimate():', e);

        var end = 0;

        var consoleE = '<div class="row-fluid">' +
            '<div class="span12">' +
            '<div id="logCreatePixel" class="bodyAlert lef">' +
            '<div><i class="tb-icon-29x-alert"></i></div>' +
            '<div>' + e + '</div>' +
            '</div>' +
            '</div>' +
            '</div>';
        $('#segPlace > div.r-body > div.r-content > div.r-content-overflow').html(consoleE);

    } finally {
        var textShow = null;
        var mask = null;

        var begin = (end - 100);
        window.g.reachEstimate = end;

        var interval = setInterval(function() {
            textShow = $.number(begin, 0, '', window.g.thousandSymbol);
            $('span.reachEstimateSpan').text(textShow);
            if (begin >= end) clearInterval(interval);
            begin++;
        }, 5);

        stepperVerify(window.g.stepper); // gerencia os botões de paginação do stepper
    }
};

////////////////////////////////////
// FUNÇÕES DE APOIO A SEGMENTAÇÃO //
////////////////////////////////////

/**
 * Função tutorial popover da segmentação
 */
function startGuideTabStp03() {
    var $button = $('#segAge > div.r-footer.aRig > button,' +
        '#segSex > div.r-footer.aRig > button,' +
        '#segPlace > div.r-footer.aRig > button,' +
        '#segInterest > div.r-footer.aRig > button');

    var options = {
        stopOnBackdropClick: false,
        stopOnEsc: false,
        onComplete: function(params) {
            console.log("onComplete # " + (params.idx + 1))
        },
        onExit: function(params) {
            console.log("onExit # " + (params.idx + 1))

            // exibir os botões de edição
            $button.css('visibility', 'visible');
        },
        onStep: function(params) {
            console.log("onStep # " + (params.idx + 1))
        },
    };

    // esconder os botões de edição
    $button.css('visibility', 'hidden');
    bootstro.start(".bootstro", options);
};

function getReachEstimate() {
    var targeting_spec = getTargetingSpecFromSegmentation();
    var reachData = {
        targeting_spec: targeting_spec,
        currency: window.g.currency
    }
    adAccount.getReachEstimate(reachData).then(fbHandleReachEstimate); 
}

//////////////////////////////////////////////////
// FUNÇÕES DE APOIO A SEGMENTAÇÃO - GEOLOCATION //
//////////////////////////////////////////////////

/**
 * Iniciando o plugin tokenInput, para gerenciar informações de localidades
 */
function startPlaceDefiner() {
    var idModal = 'div#modalManagePlace';
    var langPkg = $('input#langPkg', idModal);

    //singleTon do placeDefiner
    if ($('input#token-input-placeDefiner', idModal).length < 1) {

        //definindo valor padrão para país de acordo com a nacionalidade
        if (window.g.locale && typeof window.g.locale == 'string' && window.g.locale.toLowerCase() == 'en_us') {
            var us = {
                "key": "US",
                "name": "United States",
                "type": "country",
                "supports_city": false,
                "supports_region": false
            };
            // window.g.adGeoLocation = [us];
            window.g.targetingSpecs.addGeoLocation('country', us);
        } else {
            var br = {
                    "key": "BR",
                    "name": "Brasil",
                    "type": "country",
                    "supports_city": false,
                    "supports_region": false
                }
                // window.g.adGeoLocation = [br];
            window.g.targetingSpecs.addGeoLocation('country', br);
        }

        // modularizar a chamada do facebook
        var uri = 'https://graph.facebook.com/search?access_token={0}&endpoint={1}&locale={2}&pretty={3}&type={4}';
        uri = uri.replace('{0}', window.g.token);
        uri = uri.replace('{1}', '/search');
        uri = uri.replace('{2}', window.g.locale);
        uri = uri.replace('{3}', '0');
        uri = uri.replace('{4}', 'adgeolocation');

        $("input#placeDefiner").tokenInput(uri, {
            preventDuplicates: true,
            queryParam: 'q',
            searchDelay: 500,
            minChars: 3,
            propertyToSearch: 'name',
            propertyToId: "key",
            // prePopulate: window.g.adGeoLocation,
            prePopulate: window.g.targetingSpecs.getFlatGeoLocations(),
            animateDropdown: false,
            hintText: false,
            noResultsText: langPkg.attr('data-noResultsText'),
            searchingText: langPkg.attr('data-searchingText'),
            tokenLimit: 200,
            minInputWidth: 496,
            zindex: 9000,
            onReady: function() {
                $('input#token-input-placeDefiner').attr({
                    'placeholder': langPkg.attr('data-placeholder'),
                });
            },
            onAdd: function(item) {
                placeDefinerAdd(item); // objeto já adicionado no cache do componente, agora será adicionado na variável global controladora
            },
            onDelete: function(item) {
                placeDefinerDelete(item); // objeto já removido do cache do componente, agora será adicionado na variável global controladora
            },
            onResult: function(data) {
                if (data.hasOwnProperty('data')) {
                    var qryObj = data.data;
                    var myObj = $("input#placeDefiner").tokenInput("get");

                    if ($.isArray(myObj)) {
                        if (myObj.length > 0) {
                            for (i = 0, l = myObj.length; i < l; i++) {
                                qryObj = qryObj.filter(function(o) {
                                    return o.key != myObj[i].id;
                                });
                            }
                        }
                    }
                    return qryObj;
                }
                return {};
            },
            resultsFormatter: function(item) { //formata os valores que serão exibidos no dropdown de seleção
                return '<li id="' + item[this.propertyToId] + '">' + item[this.propertyToSearch] + (item.region ? ', ' + item.region : '') + '</li>';
            },
            tokenFormatter: function(item) { // Formata os tokens que serão exibidos
                return '<li id="' + replaceAll(item[this.propertyToId], ':', '_') + '"><p>' + item[this.propertyToSearch] + (item.region ? ', ' + item.region : '') + '</p></li>';
            },
        });
    }

    // esconde o botão de fechar do modal quando houver
    $('#token-input-placeDefiner').unbind('click').bind('click', function() {
        $('#token-input-placeDefiner').closest('.modal').find('.modal-header > button.close').css({
            visibility: 'hidden'
        });
    });
}

/**
 * Função que adiciona um adGeoLocation{} na variável global controladora
 * @param  {objeto} obj : adGeoLocation object
 */
function placeDefinerAdd(obj) {
    try {
        mixpanel.track("Segmentation Action", {
            'Type': 'Location',
            'Action': 'Add'
        });

        window.g.targetingSpecs.addGeoLocation(obj.type, obj);
        // console.log('placeDefinerAdd', obj);
    } catch (e) {
        console.log('placeDefinerAdd() : ', e);
    }
};

/**
 * Função que remove um adGeoLocation{} na variável global controladora
 * @param  {objeto} obj : adGeoLocation object
 */
function placeDefinerDelete(obj) {
    try {
        mixpanel.track("Segmentation Action", {
            'Type': 'Interests',
            'Action': 'Remove'
        });
        window.g.targetingSpecs.removeGeoLocation(obj.type, obj);
    } catch (e) {
        console.log('placeDefinerDelete() : ', e);
    }
};

////////////////////////////////////////////////
// FUNÇÕES DE APOIO A SEGMENTAÇÃO - INTERESTS //
////////////////////////////////////////////////

/**
 * Função que sincroniza os valores que estão no cache do elemento "definer" com o HTML da página goal.php
 * @param  {string} container : Identificado de destino a sicronizar.
 */
function finderCacheSyncHTML(container) {
    try {
        if (!container || (typeof container != 'string')) throw 'invalid container param';

        switch (container) {
            case 'placeDefiner':
                var myObj = $("input#placeDefiner").tokenInput("get");
                var mirrorContent = $('#segPlace > div.r-body > div.r-content > div.r-content-overflow');
                var tagTpl = '<span class="tag" id="%0">%1<button type="button" class="close" onclick="deleteFromFinder(\'modalManagePlace\',\'%0\');">×</button></span>';
                break;
            case 'interestDefiner':
                var myObj = $("input#interestDefiner").tokenInput("get");
                var mirrorContent = $('#segInterest > div.r-body > div.r-content > div.r-content-overflow');
                var tagTpl = '<span class="tag" id="%0">%1<button type="button" class="close" onclick="deleteFromFinder(\'modalManageInterest\',\'%0\');">×</button></span>';
                break;
            default:
                throw 'invalid container';
                break;
        };

        mirrorContent.html(''); //limpa o html corrente

        if ((myObj instanceof Object) && !$.isEmptyObject(myObj)) {
            if ($.isArray(myObj)) {
                if (myObj.length > 0) {
                    var tags = '';
                    for (i = 0, l = myObj.length; i < l; i++) {
                        tg = replaceAll(tagTpl, '%0', myObj[i].id);
                        tg = replaceAll(tg, '%1', myObj[i].name);
                        tags += tg;
                    }
                    mirrorContent.html(tags);
                }
            } else {
                tagTpl = replaceAll(tagTpl, '%0', myObj.id);
                tagTpl = replaceAll(tagTpl, '%1', myObj.name);
                mirrorContent.html(tagTpl);
            }
        };
    } catch (e) {
        console.log('finderCacheSyncHTML() : ', e);
    }
}

/**
 * Efetua busca de interesses relacionados a página selecionada e aplica na segmentação do público
 */
function updateInterests() {
    finderCacheSyncHTML('interestDefiner');
    getReachEstimate();  
};

/**
 * Função que inicia o comportamento tokenInput para interesses
 */
function startInterestDefiner() {
    var idModal = 'div#modalManageInterest';
    var langPkg = $('input#langPkg', idModal);

    if ($('input#token-input-interestDefiner', idModal).length < 1) {
        // modularizar a chamada do facebook
        var uri = 'https://graph.facebook.com/search?access_token={0}&limit={1}&locale={2}&pretty={3}&type={4}';
        uri = uri.replace('{0}', window.g.token);
        uri = uri.replace('{1}', '15');
        uri = uri.replace('{2}', window.g.locale);
        uri = uri.replace('{3}', '0');
        uri = uri.replace('{4}', 'adinterest');
        // uri = uri.replace('{4}', 'adkeyword');
        // uri = uri.replace('{4}', 'type=adTargetingCategory&q=interests');
        // uri = uri.replace('{4}', 'adkeywordsuggestion');

        $("input#interestDefiner").tokenInput("clear");
        $("input#interestDefiner").tokenInput(uri, {
            preventDuplicates: true,
            queryParam: 'q',
            searchDelay: 500,
            minChars: 3,
            propertyToSearch: 'name',
            propertyToId: "id",
            prePopulate: window.g.targetingSpecs.getInterests(),
            animateDropdown: false,
            hintText: false,
            noResultsText: langPkg.attr('data-noResultsText'),
            searchingText: langPkg.attr('data-searchingText'),
            tokenLimit: 200,
            searchingText: false,
            onReady: function() {
                $('input#token-input-interestDefiner').attr({
                    'placeholder': langPkg.attr('data-placeholder'),
                }).show().focus().click();
            },
            onAdd: function(item) {
                // objeto já adicionado no cache do componente, agora será adicionado na variável global controladora
                interestDefinerAdd(item);
            },
            onDelete: function(item) {
                // objeto já removido do cache do componente, agora será adicionado na variável global controladora
                interestDefinerDelete(item);
            },
            onResult: function(data) { //console.log('----->onResult : ', data);
                if (data.hasOwnProperty('data')) {
                    var qryObj = data.data;
                    var myObj = $("input#interestDefiner").tokenInput("get");

                    if ($.isArray(myObj)) {
                        if (myObj.length > 0) {
                            for (i = 0, l = myObj.length; i < l; i++) {
                                qryObj = qryObj.filter(function(o) {
                                    return o.key != myObj[i].id;
                                });
                            }
                        }
                    }
                    return qryObj;
                }
                return {};
            },
            resultsFormatter: function(item) { //formata os valores que serão exibidos no dropdown de seleção
                return '<li id="' + item[this.propertyToId] + '">' + item[this.propertyToSearch] + '</li>';
                // return '<li id="' + item[this.propertyToId] + '">' + item[this.propertyToSearch] + (item.description ? ', ' + item.description : '') + '</li>';
            },
            tokenFormatter: function(item) { // Formata os tokens que serão exibidos
                return '<li id="' + replaceAll(item[this.propertyToId], ':', '_') + '"><p>' + item[this.propertyToSearch] + '</p>' + '</li>';
                // return '<li id="' + replaceAll(item[this.propertyToId], ':', '_') + '"><p>' + item[this.propertyToSearch] + '</p>' + (item.description ? ' <font>' + item.description + '</font>' : '') + '</li>';
            },
        });
        window.g.interestsInput = true;
        if (window.g.suggestedInterests) fillSuggestedInterests(window.g.suggestedInterests);
    }

    // esconde o botão de fechar do modal quando houver
    $('#token-input-interestDefiner').unbind('click').bind('click', function() {
        $('#token-input-interestDefiner').closest('.modal').find('.modal-header > button.close').css({
            visibility: 'hidden'
        });
    });

    // não deixa escapar o focus
    $('#token-input-interestDefiner').unbind('blur').bind('blur', function() {
        $(this).focus();
    });
};

/**
 * Alimenta o plugin de interesses
 * @param  {object} interests : lista de interesses a ser inputada no plugin
 */
function fillSuggestedInterests(interests) {
    // console.log('fillSuggestedInterests');
    $("input#interestDefiner").tokenInput("clear");
    $.each(interests, function(index, value) {
        $("input#interestDefiner").tokenInput("add", {
            id: value.id,
            name: value.name
        });
    });
    updateInterests();
};

/**
 * Função que adiciona um adKeyWord{} na variável global controladora
 * @param  {object} obj: objeto a ser inserido no [targeting.interests]
 */
function interestDefinerAdd(obj) {
    try {
        mixpanel.track("Segmentation Action", {
            'Type': 'Interests',
            'Action': 'Add'
        });

        window.g.targetingSpecs.addInterest(obj);
    } catch (e) {
        console.log('interestDefinerAdd() : ', e);
    }
};

/**
 * Função que remove um adKeyWord{} na variável global controladora
 * @param  {object} obj: objeto a ser removido no [targeting.interests]
 */
function interestDefinerDelete(obj) {
    try {
        mixpanel.track("Segmentation Action", {
            'Type': 'Interests',
            'Action': 'Remove'
        });

        window.g.targetingSpecs.removeInterest(obj);
    } catch (e) {
        console.log('interestDefinerDelete() : ', e);
    }
};

/**
 * Função que possibilita deletar uma tag do componente dentro do modal
 * @param  {string} container : contexto onde esta inserido o componente
 * @param  {string} id: Id do registro a ser removido
 * @return {[type]}
 */
function deleteFromFinder(container, id) {
    try {
        if (!container || (typeof container != 'string')) throw 'invalid container parameter';
        if (!id || (typeof id != 'string')) throw 'invalid id parameter';

        $('div#' + container + ' li#' + id + ' > span').click();

        var plc = null;
        switch (container) {
            case 'modalManagePlace':
                plc = 'placeDefiner';
                break;
            case 'modalManageInterest':
                plc = 'interestDefiner';
                break;
        }

        if (plc) finderCacheSyncHTML(plc);
        getReachEstimate();
    } catch (e) {
        console.log('deleteFromFinder() : ', e);
    }
};

/////////////////////////////////////////////
// FUNÇÕES DE APOIO A DEFINIÇÃO DE BIDDING //
/////////////////////////////////////////////

/**
 * Verificando o budget mínimo a cada mudança de data no bidding por valor
 * @param  {string} nDay : quantidade de dias para ser calculado com o o budget
 */
function verifyTheMinimumBudget(nDay) {
    try {
        var byValueBud = $('div#byValue #budget');
        if (byValueBud) {
            bVal = tryParse(byValueBud.val(), 'fbMoney', 1);

            nDay = nDay * (window.g.avgCentsByDay / 100);
            byValueBud.val($.number((nDay), window.g.decimalCount, window.g.decimalSymbol, window.g.thousandSymbol));
        }
    } catch (e) {
        console.log('verifyTheMinimumBudget(nDay);:', e);
    }
};

/**
 * Função que starta o comportamento de simulação de acordo com a escolha do cliente
 * @param  {string} option : Calcula o bid baseado no valor ou no período (byValue | byPeriod).
 */
function initSimulate(option) {
    try {
        if ($('div#byValue', 'div#stp04').length > 0) {
            var container = 'div#stp04';
        } else if ($('div#byValue', 'div#stp05').length > 0) {
            var container = 'div#stp05';
        } else {
            var container = 'div#stp06';
        }

        if (!option || typeof option != 'string') throw 'invalid option param';
        if (!inArray(option, ['byValue', 'byPeriod'])) throw 'invalid option param';

        var byValueW = $('div.simulate.byValue', container);
        var byPeriodW = $('div.simulate.byPeriod', container);

        var conv = tryParse(window.g.avgCpmValue, 'int', 0);
        conv = (conv / 1000) * window.g.frequencyIndex;
        var reach = tryParse(window.g.reachEstimate, 'int', 0);

        // if (parseInt(conv) < 1) throw 2;
        // if (parseInt(reach) < 1) throw 2;

        if (option === 'byValue') {
            byPeriodW.hide();

            var budget = $('div#byValue input#budget').val();
            if (!budget) throw 0;

            budget = tryParse(budget, 'fbMoney', 0);

            if (parseInt(budget) < 1) throw 1;
            if (parseInt(budget) < 300) throw 4;

            // procedimento de cálculo da pocentagem
            var probable = Math.ceil(budget / conv);

            //caso o total provável de pessoas alcançadas ultrapasse 80% das pessoas estimadas
            if (calcPercent(probable, reach, 0) > 80) {
                if (budget > 1000) { // 10 conto nunca e muito
                    bootbox.dialog({
                        className: 'yellow',
                        locale: window.g.languageMin,
                        message: _('toMuchAmountInvested'),
                        closeButton: false,
                        buttons: {
                            'ok': {
                                label: _('ok'),
                            },
                        },
                    });
                }

                // throw 5;
            }

            //var probablePercent = calcPercent(probable, reach, 1);
            var probablePercent = calcPercent((probable > (reach * 0.8) ? (reach * 0.8) : probable), reach, 1);
            var rotation = Math.ceil(tryParse(probablePercent, 'float', 1)) * 1.80
            rotation = (rotation > 180 ? 180 : rotation); // máxima rotação do percentCircle é 180deg

            $('div.simulate.byValue span.reachedEstimateSpan', container).text($.number(probable, 0, '', window.g.thousandSymbol));
            $('div.simulate.byValue div.percenter > div.percentLimiter > div.percentIndicator', container).html('<span>' + Math.ceil(probablePercent) + '<font>%</font></span>');

            // monta o percenter
            $('div.simulate.byValue div.percenter > div.percentLimiter > div.percentCircle', container).animateRotate(rotation, 3000, 'linear');

            // exibindo o resultado do cálculo e setando valores default para o período da campanha
            var begin = $('#sub_beginDate').data('datetimepicker');
            var end = $('#sub_endDate').data('datetimepicker');
            var calcDays = Math.floor((budget / window.g.avgCentsByDay < 1 ? 1 : budget / window.g.avgCentsByDay));
            begin.setLocalDate(moment().toDate());
            end.setLocalDate(moment().add('days', calcDays).toDate());

            //renderiza a quantidade de dias no calendário
            var nDay = simulatebyValueChangeDate();
            $('div.simulate.byValue > div.simuBody div.calendar span.aux', container).text(_n('day', nDay));
            $('div.simulate.byValue > div.simuBody div.calendar span.value', container).text(nDay);

            byValueW.fadeIn(500, function() {});
        } else {
            byValueW.hide();

            var inputDateBegin = $('input#top_beginDateI').val();
            var inputDateEnd = $('input#top_endDateI').val();
            var avgCentsByDay = tryParse(window.g.avgCentsByDay, 'int', 0);

            if (!inputDateBegin || !inputDateEnd) throw 3;
            if (avgCentsByDay < 1) throw 2;

            begin = moment.utc(inputDateBegin, window.g.dateTime24);
            end = moment.utc(inputDateEnd, window.g.dateTime24);

            if (!begin.isBefore(end)) throw 0;

            var diffDays = Moment.utcDiff(begin, end, 'days');
            var budget = (avgCentsByDay * diffDays);
            var probable = Math.ceil(budget / conv);

            // renderizar o texto da diferença de dias
            $('div.simulate.byPeriod div.simuBody > div:nth-child(1) > span.info', container).html(_n('idealInvestDuringXdaysIs', diffDays));

            // caso o total provável de pessoas alcançadas ultrapasse 80% das pessoas estimadas
            // faço uma tentativa de redução do valor ideal para caber no orçamento
            if (calcPercent(probable, reach, 0) > 80) {
                // var pass = false;
                // for (i = 1; i < 20; i++) {
                //     budget = budget - (budget * (i * 0.05));
                //     probable = Math.ceil(budget / conv);

                //     if (calcPercent(probable, reach, 0) < 80) {
                //         pass = true;
                //         break;
                //     }
                // }

                var pass = true // REMOVER ISSO

                // caso a tentativa não faça efeito, exeption
                if (!pass) {
                    bootbox.dialog({
                        className: 'yellow',
                        locale: window.g.languageMin,
                        message: _('msgDangerousDateRange'),
                        closeButton: false,
                        buttons: {
                            'ok': {
                                label: _('ok'),
                            },
                        },
                    });

                    // throw 5;
                }
            }

            // renderizando a opção de investimento que a ferramenta calculou
            renderInvestmentOption(container, budget, probable, conv, reach);

            // montando e instanciando o select que dará mais opções ao usuário
            var options = '';
            for (i = 0; i < 3; i++) {
                var off = (i * 0.25);
                budget = budget - (budget * off);
                probable = Math.ceil(budget / conv);
                var budgetStr = $.number(fbOffsetCalc(window.g.currency, budget), getDecimalCurrency(window.g.currency), window.g.decimalSymbol, window.g.thousandSymbol);
                var budgetStr = _('iWantToUseXasAnInvestment').replace('%d', window.g.currencySymbol + ' ' + budgetStr);
                var probableStr = $.number(probable, 0, '', window.g.thousandSymbol);
                options += '<option value="' + budget + '" data-icon="sIco" data-subtext="' + probableStr + ' ' + _('labViews') + '">' + budgetStr + '</option>';
            }

            if (!$('div.simulate.byPeriod > div.simuFooter button.dropdown-toggle[data-id="investmentOption"]', container).length) {
                $('#investmentOption').html(options).selectpicker({
                    width: 450,
                    showSubtext: false,
                    showContent: false,
                }).change(function(event) {
                    var budget = $(this).val();
                    var probable = $('#investmentOption option[value="' + budget + '"]').attr('data-subtext').split(' ');
                    renderInvestmentOption(container, budget, tryParse(probable[0], 'justNumber', 0), conv, reach);
                });
            } else {
                $('#investmentOption').html(options).selectpicker('refresh').change(function(event) {
                    var budget = $(this).val();
                    var probable = $('#investmentOption option[value="' + budget + '"]').attr('data-subtext').split(' ');
                    renderInvestmentOption(container, budget, tryParse(probable[0], 'justNumber', 0), conv, reach);
                });
            }

            byPeriodW.fadeIn(500, function() {});
        }

        window.g.createCampaignBy = option;

        if (container === 'div#stp04') window.g.stpSimulated = (window.g.stpSimulated == false); // if (!window.g.stpSimulated) window.g.stpSimulated = true;
        else if (container === 'div#stp05') window.g.stpSimulated = (window.g.stpSimulated == false); // if (!window.g.stpSimulated) window.g.stpSimulated = true;
        else if (container === 'div#stp06') window.g.stpSimulated = (window.g.stpSimulated == false); // if (!window.g.stpSimulated) window.g.stpSimulated = true;

        $('#goalContent > div.fullCarousel > ul > li').css('height', 'auto');

        liFullCarouselAutoH(window.g.stepper);
    } catch (e) {
        if (!isNaN(e)) {
            var message = '';
            var className = 'blue';
            var buttons = {
                'return': {
                    label: _('ok'),
                    callback: function() {}
                },
            };

            switch (e) {
                case 0:
                    message = _('enterInvestValue');
                    break;
                case 1:
                    className = 'yellow';
                    message = _('invalidBudget');
                    break;
                case 2:
                    className = 'red';
                    message = _('simulationError');
                    buttons = {
                        'return': {
                            label: _('btnReturn'),
                            callback: function() {
                                window.history.back();
                            }
                        },
                    };
                    break;
                case 3:
                    className = 'yellow';
                    message = _('startdateEnddateIsRequired');
                    break;
                case 4:
                    className = 'yellow';
                    var minBudgetStr = $.number(fbOffsetCalc(window.g.currency, 300), getDecimalCurrency(window.g.currency), window.g.decimalSymbol, window.g.thousandSymbol);
                    message = _('theMinimumToAnnunciateisX');
                    message = message.replace('%d', window.g.currencySymbol + ' ' + minBudgetStr);
                    break;
                default:
                    console.log('initSimulate() : ', e);
                    break;
            }

            bootbox.dialog({
                className: className,
                locale: window.g.languageMin,
                message: message,
                closeButton: false,
                buttons: buttons,
            });
        }
        if (container === 'div#stp04') window.g.stpSimulated = false;
        else if (container === 'div#stp05') window.g.stpSimulated = false;
        else if (container === 'div#stp06') window.g.stpSimulated = false;
    } finally {
        stepperVerify(window.g.stepper);
    }
};

/**
 * Função que renderiza as opções do select na simulação por período
 * @param  {string} container : contexto onde será renderizado o resultado
 * @param  {float} budget : valor do orçamento.
 * @param  {integer} probable : valor do orçamento dividido por (valor do cpm medio dividido por 1000)
 * @param  {integer} conv : valor do cpm medio dividido por 1000
 * @param  {integer} reach : probabilidade de público dito pelo facebook
 */
function renderInvestmentOption(container, budget, probable, conv, reach) {
    try {
        // console.log(container, budget, probable, conv, reach);
        if (!container) throw 0;
        if (!budget) throw 0;
        if (!probable) throw 0;
        if (!conv) throw 0;
        if (!reach) throw 0;

        //aplica o valor total que o cliente gastará, lembrando que esse montante deve ser dividido por dias de campanha
        $('div.simulate.byPeriod div.simuBody div.currentBudget', container).html('<font>' + window.g.currencySymbol + '</font><font>' + budget + '</font>');
        $('div.simulate.byPeriod div.simuBody div.currentBudget > font:nth-child(2)', container).currency({
            region: window.g.currency,
            thousands: window.g.thousandSymbol,
            decimal: window.g.decimalSymbol,
            decimals: window.g.decimalCount,
            hidePrefix: true,
            hidePostfix: true,
        });

        //calculando a quantidade de pessoas que podem ser atingidas
        // var probablePercent = calcPercent(probable, reach, 1);
        var probablePercent = calcPercent((probable > (reach * 0.8) ? (reach * 0.8) : probable), reach, 1);
        var rotation = Math.ceil(tryParse(probablePercent, 'float', 1)) * 1.80
        rotation = (rotation > 180 ? 180 : rotation); // máxima rotação do percentCircle é 180deg

        $('div.simulate.byPeriod span.reachedEstimateSpan', container).text($.number(probable, 0, '', window.g.thousandSymbol));
        $('div.simulate.byPeriod div.percenter > div.percentLimiter > div.percentIndicator', container).html('<span>' + Math.ceil(probablePercent) + '<font>%</font></span>');
        $('div.simulate.byPeriod div.percenter > div.percentLimiter > div.percentCircle', container).animateRotate(rotation, 1000, 'linear');
    } catch (e) {
        console.log('renderInvestmentOption():', e);
        bootbox.dialog({
            className: 'red',
            locale: window.g.languageMin,
            message: _('errorWhenRenderingSimulation'),
            closeButton: false,
            buttons: {
                'return': {
                    label: _('btnReturn'),
                    callback: function() {
                        window.history.back();
                    }
                },
            }
        });
    }
};

/**
 * Função que calcula o range de data, da simulação de por valor vitalício além de tratar seus erros
 * @return {string} : número de dias calculados de acordo comos ranges de data escolhido
 */
function simulatebyValueChangeDate() {
    try {
        var inputDateBegin = $('input#sub_beginDateI').val();
        var inputDateEnd = $('input#sub_endDateI').val();

        if (!inputDateBegin || !inputDateEnd) throw 'can not calculate end of days';

        var momentUtcBegin = moment.utc(inputDateBegin, window.g.dateTime24);
        var momentUtcEnd = moment.utc(inputDateEnd, window.g.dateTime24);
        if (!momentUtcBegin.isBefore(momentUtcEnd)) throw 0;

        return Moment.utcDiff(momentUtcBegin, momentUtcEnd, 'days');
    } catch (e) {
        console.log('simulatebyValueChangeDate():', e);

        if (!isNaN(e)) {
            var message = 'a';
            switch (e) {
                case 0:
                    message = _('startDateCannotBeGreaterEndDate');
                    break;
                case 1:
                    message = _('startDateCannotBeEarlierCurrentDate');
                    break;
            }

            bootbox.dialog({
                className: 'red',
                locale: window.g.languageMin,
                message: message,
                closeButton: false,
                buttons: {
                    'return': {
                        label: _('ok'),
                        callback: function() {}
                    },

                }
            });
        }

        return '?';
    }
};

////////////////////////////
// PUBLICANDO NO FACEBOOK //
////////////////////////////

/**
 * Função que gerencia a visibilidade dos botões do modal de publicação
 * @param  {integer} st: (1 || -1) parametro que indica caso de sucesso ou erro
 */
function publish_setBtnOptions(st) {
    if (isNaN(st)) return;

    var btnPublishCancel = $('div#modalPublish button#btnPublishCancel');
    var btnPublishRetry = $('div#modalPublish button#btnPublishRetry');
    var btnPublishFinish = $('div#modalPublish button#btnPublishFinish');

    btnPublishCancel.attr('class', 'btn-modal-disabled').css('visibility', 'hidden');
    btnPublishRetry.attr('class', 'btn-modal-disabled').css('visibility', 'hidden');
    btnPublishFinish.attr('class', 'btn-modal-disabled').css('visibility', 'hidden');

    // sucesso
    if (st == 1) {
        gaGoalView(window.g.currentGoal, 'published');
        btnPublishFinish.attr('class', 'btn-green').css('visibility', 'visible').click(function() {
            window.location.href = window.location.origin + '/dashboard';
        });
    }

    // erro
    if (st == -1) {
        gaGoalView(window.g.currentGoal, 'error');
        btnPublishCancel.attr('class', 'btn-cancel').css('visibility', 'visible').click(function() {
            // rollback create campaing 
            // rollback create campaign group
            $(this).css('visibility', 'hidden');

            if (window.g.publish instanceof Object && !$.isEmptyObject(window.g.publish)) {
                if (window.g.publish.campaignId && !isNaN(window.g.publish.campaignId)) {
                    TB.AdSet.del(publish_rollBackCreateCampaign, window.g.publish.campaignId);
                } else {
                    window.location.href = '/dashboard';
                }
            }
        });

        btnPublishRetry.attr('class', 'btn-green').css('visibility', 'visible').click(function() {
            $('#nav-0').click();
            $('#modalPublish').modal('hide');
        });
    }
};

/**
 * Redireciona o usuário para o inicio do processo de criação de seu anúncio
 */
function publish_rollBackCreateCampaign() {
    window.location.href = '/goals';
};

/**
 * Função que aplica mensagens pre-definidas ao usuário
 * @param  {string} code: código da mensagem a ser exibida ao usuário
 * @param  {string} extra: informação extra para que seja adicionada a mensagem pre-definida
 */
function publish_setStatus(code, extra) {
    if (!code) return;
    var out = '';
    extra = extra || '';

    if (code == '1.0') out = _('seekingPermissionsPage');
    if (code == '1.1') out = _('postCreatedSuccessfully');
    if (code == '1.2') out = _('creatingCampaign');
    if (code == '1.3') out = _('campaignSuccessfullyCreated');
    if (code == '1.4') out = _('adCreatedSuccessfully');
    if (code == '1.5') out = _('goalWasSuccessfullyCreated');
    if (code == '1.6') out = _('msgImageUploadDoneSuccessfully');
    if (code == '1.7') out = _('msgPublishingAdVariations');
    if (code == '1.8') out = _('labSendingImage');
    if (code == '1.9') out = _('creatingCampaignGroup');
    if (code == '2.0') out = _('campaignGroupSuccessfullyCreated');
    if (code == '0.0') out = _('errorCreatingVariationAd');
    if (code == '-1.1') out = _('errorRetrievingPermissionsPages');
    if (code == '-1.2') out = _('errorCreatingPostOnFacebook');
    if (code == '-1.3') out = _('errorCreatingCampaign');
    if (code == '-1.4') out = _('errorCreatingMajorAd');
    if (code == '-1.6') out = _('msgErrorUploadingImagesToLibrary');
    if (code == '-1.7') out = _('msgPleaseSelectAnImage');
    if (code == '-1.9') out = _('errorCreatingCampaignGroup');

    if(extra)
        out += ': ' + extra;

    $('#modalPublish p.currentStatus').text(out); //exibe no modal a mensagem

    // exibe os botões do rodape do modal em caso de falha com direito a retry
    if (code.substring(0, 1) == '0')
        publish_setBtnOptions(1);

    // exibe os botões do rodape do modal em caso de falha
    if (code.substring(0, 2) == '-1')
        publish_setBtnOptions(-1);
};

/**
 * Função responsável por criar um grupo de campanha no facebook (AdCampaign)
 */
function publish_createCampaignGroup() {
    // console.log('publish_createCampaignGroup()');
    try {
        publish_setStatus('1.9');

        //verificando se já possuo uma campanha criada no objeto global
        if (window.g.publish.campaignGroupId && !isNaN(window.g.publish.campaignGroupId)) {
            // chamando a função que lida com a criação de campanha simulando a criação via facebook
            publish_createCampaign();
        } else {
            var name = '_' + $('input#campaignName').val();
            var objective = '';
            var buying_type = 'AUCTION';
            switch (window.g.currentGoal) {
                case 1:
                    objective = 'POST_ENGAGEMENT';
                    break;
                case 2:
                    objective = 'PAGE_LIKES';
                    break;
                case 3:
                    objective = window.g.pixel.pixelId ? 'WEBSITE_CONVERSIONS' : 'WEBSITE_CLICKS';
                    break;
            }
            var callback = 'publish_fbHandleCreateCampaignGroup';
            var adCampaignData = {
                name: name,
                objective: objective,
                buying_type: buying_type,
            };
            var adCampaign = new api.AdCampaign(adCampaignData, adAccount.id);
            adCampaign.create().then(publish_fbHandleCreateCampaignGroup);
            window.g.publish.objective = objective;
        }
    } catch (e) {
        console.log('publish_createCampaignGroup():', e);
        publish_setStatus('-1.9', e);
    }
};

/**
 * Callback que lida com o o resultado da criação da campanha (publish_createCampaignGroup)
 */
function publish_fbHandleCreateCampaignGroup(data) {
    // console.log('publish_fbHandleCreateCampaignGroup()', data);
    try {
        if (inObject('error', data))
            if (data.error.hasOwnProperty('message'))
                throw data.error.message;

        if (inObject('id', data)) {
            if (!data.id || isNaN(data.id))
                throw 'invalid campaign id';

            window.g.publish.campaignGroupId = data.id
            publish_setStatus('2.0');
            publish_createCampaign();
        }
    } catch (e) {
        console.log('publish_fbHandleCreateCampaignGroup():', e);
        publish_setStatus('-1.9', e);
    }
};

/**
 * Função de criação da campanha (AdSet)
 */
function publish_createCampaign() {
    // console.log('publish_createCampaign()');
    try {
        publish_setStatus('1.2');

        //verificando se já possuo uma campanha criada no objeto global
        if (window.g.publish.campaignId && !isNaN(window.g.publish.campaignId)) {

            // chamando a função que lida com a criação de campanha simulando a criação via facebook
            publish_fbHandleCreateCampaign({
                id: window.g.publish.campaignId
            });

        } else {
            //recuperando valores de acordo com a escolha do orçamento
            if (window.g.createCampaignBy == 'byValue') {
                var start_time = $('input#sub_beginDateI').val();
                var end_time = $('input#sub_endDateI').val();
                var investiment = $('div#byValue #budget').val();
            } else {
                var start_time = $('input#top_beginDateI').val();
                var end_time = $('input#top_endDateI').val();
                var investiment = $('div.simulate.byPeriod > div.simuBody div.currentBudget > font:nth-child(2)').text();
            }

            investiment = tryParse(investiment, 'justNumber', 0);

            if (!start_time) throw 'invalid start time';
            if (!end_time) throw 'invalid end time';
            if (!investiment) throw 'invalid investiment';

            start_time = moment(start_time, window.g.dateTime24).format("X");
            end_time = moment(end_time, window.g.dateTime24).format("X");
            var name = $('input#campaignName').val();
            var campaign_status = 'ACTIVE';
            var lifetime_budget = investiment;
            var campaign_group_id = window.g.publish.campaignGroupId;
            var bid_type = 'ABSOLUTE_OCPM';
            var targeting = getTargetingSpecFromSegmentation();
            var buying_type = 'AUCTION';
            var adSetData = {
                campaign_group_id: campaign_group_id,
                campaign_status: campaign_status,
                lifetime_budget: lifetime_budget,
                name: name,
                start_time: start_time,
                end_time: end_time,
                bid_type: bid_type,
                targeting: targeting,
                // bid_info: bid_info,
                is_autobid: true,
            };
            switch (window.g.currentGoal) {
                case 1:
                    adSetData.targeting.page_types = ["feed"];
                    break;
                case 2:
                    adSetData.targeting.page_types = ["rightcolumn"];
                    adSetData.promoted_object = {page_id: window.g.pageId};
                    break;
                case 3:
                    adSetData.targeting.page_types = ["desktop"];
                    var promoted_object = {};
                    if (window.g.pageId)
                        promoted_object = {page_id: window.g.pageId};
                    if (window.g.pixel.pixelId) { // WEBSITE_CONVERSIONS
                        promoted_object = {pixel_id: window.g.pixel.pixelId};
                    }
                    if(!$.isEmptyObject(promoted_object))
                        adSetData.promoted_object = promoted_object;
                    
                    adSetData.bid_info = {
                        'ACTIONS': 2000,
                        'REACH': 1000,
                        'CLICKS': 2000,
                        'SOCIAL': 1000
                    };
                    adSetData.is_autobid = false;
                    break;
            }
            var adSet = new api.AdSet(adSetData, adAccount.id);
            adSet.create().then(publish_fbHandleCreateCampaign);
            mixpanel.track("Publish AdSet", {
                'Lifetime Budget': lifetime_budget,
                'Start Time': start_time,
                'End Time': end_time
            });
        }
    } catch (e) {
        console.log('publish_createCampaign():', e);
        publish_setStatus('-1.3', e);
    }
};

/**
 * Callback que lida com o o resultado da criação da campanha (publish_createCampaign)
 */
function publish_fbHandleCreateCampaign(data) {
    // console.log('publish_fbHandleCreateCampaign', data);
    try {
        if (inObject('error', data))
            if (data.error.hasOwnProperty('message')) throw data.error.message;

        if (inObject('id', data)) {
            if (!data.id || isNaN(data.id)) throw 'invalid campaign id';

            window.g.publish.campaignId = data.id
            publish_setStatus('1.3');
            publish_createMainAd();
        }
    } catch (e) {
        console.log('publish_fbHandleCreateCampaign():', e);
        publish_setStatus('-1.3', e);
    }
};

/**
 * Callback que lida com o resutado da criação do anúncio principal da campanha
 * @param  {object} data: Objeto retornado pelo facebook
 */
function publish_fbHandleCreateMainAd(data) {
    try {
        if (inObject('error', data))
            if (data.error.hasOwnProperty('message')) throw data.error;

        publish_hitCreationPixel(); // Campaign Creation Pixel

        if (inObject('id', data)) {
            if (!data.id || isNaN(data.id)) throw 'invalid main ad id';

            window.g.publish.primaryAdId = data.id;
            // publish_createVariationAd();
            publish_setStatus('1.5');
            publish_setBtnOptions(1); // processo finalizado com sucesso
            publish_setConsistency(); // processo de envio ao back end com o resultado do processo
            // console.log('window.g.publish:', window.g.publish)
        }
    } catch (e) {
        mixpanel.track("Publish Campaign Error", {
            'Code': e.code,
            'Message': e.message,
            'UserMessage': e.error_user_msg
        });
        console.log('publish_fbHandleCreateMainAd():', e.error_user_msg);
        publish_setStatus('-1.4', e.error_user_msg);
    }
};

/**
 * Método responsável por procurar variações de Anúncios e cria-los na graph
 */
// function publish_createVariationAd() {
//     try {
//         // definições
//         var primaryAdId = window.g.publish.primaryAdId;
//         var variationAd = window.g.variationAd;

//         // validações básicas
//         if (!primaryAdId || isNaN(primaryAdId)) throw 'invalid primary ad id';
//         if (!$.isArray(variationAd)) throw 'invalid variationAd array';

//         // caso tenhamos pelo menos uma variação a processar, processaremos
//         console.log(variationAd);
//         if (variationAd.length > 0) {
//             TB.AdGroup.createAd(publish_fbHandleCreateVariationAd, window.g.accountId, variationAd[0])
//         } else {
//             publish_setStatus('1.5');
//             publish_setBtnOptions(1); // processo finalizado com sucesso
//             publish_setConsistency(); // processo de envio ao back end com o resultado do processo
//             console.log('window.g.publish:', window.g.publish);
//         }
//     } catch (e) {
//         console.log('publish_createVariationAd():', e);
//         publish_setStatus('0.0', e);
//     }
// };

/**
 * Callback responsável por lidar com as informações retoradas pelo facebook, caso haja outros anúncios variantes do pricipal, invoca o publish_createVariationAd
 * @param  {object} data: objeto returnado pelo facebook
 */
function publish_fbHandleCreateVariationAd(data) {
    try {
        if (inObject('error', data))
            if (data.error.hasOwnProperty('message')) throw data.error.message;

        if (inObject('id', data)) {
            if (!data.id || typeof data.id != 'string') throw '';

            // adiciona id da variação anúncio no objeto de controle
            window.g.publish.adVariations.push(data.id);

            // remover o primeiro índice do array variationAd
            var variationAd = window.g.variationAd;
            if ($.isArray(variationAd)) {
                if (variationAd.length > 0) {
                    window.g.variationAd.splice(0, 1);
                }
            }

            // chamada recorrente de criação de variações de anúncios
            publish_createVariationAd();
        }
    } catch (e) {
        console.log('publish_fbHandleCreateVariationAd():', e);
        publish_setStatus('0.0', e);
    }
};

/**
 * Função que envia para o back-end as informações do Anúncio, para consistir no banco de dados da ferrameenta
 */
function publish_setConsistency() {
    try {
        var pub = window.g.publish;
        if (pub instanceof Object && !$.isEmptyObject(pub)) {

            if (!inObject('postConsistency', pub)) throw 'invalid postConsistency parameter';
            if (!inObject('objective', pub)) throw 'invalid objective parameter';
            if (!inObject('campaignId', pub)) throw 'invalid campaignId parameter';
            if (!inObject('primaryAdId', pub)) throw 'invalid primaryAdId parameter';
            if (!inObject('adVariations', pub)) throw 'invalid adVariations parameter';

            var objPost = {};
            objPost.accountId = window.g.accountId;
            objPost.name = pub.name;
            objPost.objective = pub.objective;
            objPost.campaignGroupId = (pub.campaignGroupId || 0);
            objPost.campaignId = pub.campaignId;
            objPost.primaryAdId = pub.primaryAdId;
            objPost.adVariations = pub.adVariations.join(',');
            objPost.callback = 'window.parent.publish_HandleSetConsistency';

            // condição para o envio de pixel na consistência
            if (window.g.pixel instanceof Object && !$.isEmptyObject(window.g.pixel)) {
                var p = {};

                if (window.g.pixel.hasOwnProperty('pixelId') && window.g.pixel.pixelId) p.pixelId = window.g.pixel.pixelId;
                if (window.g.pixel.hasOwnProperty('pixelTag') && window.g.pixel.pixelTag) p.pixelTag = window.g.pixel.pixelTag;
                if (window.g.pixel.hasOwnProperty('pixelName') && window.g.pixel.pixelName) p.pixelName = window.g.pixel.pixelName;
                if (window.g.pixel.hasOwnProperty('pixelTrack') && window.g.pixel.pixelTrack) p.pixelTrack = window.g.pixel.pixelTrack;
                if (p instanceof Object && !$.isEmptyObject(p)) objPost.pixel = JSON.stringify(p);
            }

            $.ajax({
                type: 'POST',
                url: pub.postConsistency,
                data: objPost,
                dataType: 'script',
                success: function(retur) {
                    // console.log(retur);
                    try {
                        retur;
                    } catch (e) {
                        console.log('publish_setConsistency().successError: ', e);
                    }
                },
                error: function() {
                    console.log('publish_setConsistency().successError: ', arguments);
                }
            });

        } else {
            throw 'invalid publish object';
        }
    } catch (e) {
        console.log('publish_setConsistency():', e);
    }
};

/**
 * Callback do método de consistencia no banco de dados
 * @param  {object} data: resposta do back-end na consistencia do anúncio salvo
 */
function publish_HandleSetConsistency(data) {
    // console.log('publish_HandleSetConsistency', data);
    try {
        if (!inObject('data', data)) throw 'consistency fails';
        else if (!inObject('success', data.data)) throw 'consistency fails';
        else if (!data.data.success) throw 'consistency fails';

        // console.log('publish_HandleSetConsistency(): consistency success !!');
    } catch (e) {
        console.log('publish_HandleSetConsistency():', e);
    }
};

/**
 * Função que faz o upload de imagem para a bilbioteca criativa via backend, auxiliando na criação dos Posts
 */
function publish_uploadImgToAccountLibrary() {
    try {
        var token = tryParse(window.g.token, 'string', null);
        var accountId = tryParse(window.g.accountId, 'string', null);
        var callback = 'window.parent.publish_HandleUploadImgToAccountLibrary';
        var uriPostAccountLibrary = tryParse(window.g.uriPostAccountLibrary, 'string', null);

        if (!token) throw 'invalid token';
        if (!accountId) throw 'invalid accountId';
        if (!uriPostAccountLibrary) throw 'invalid uriPostAccountLibrary';

        $('form#postForm input#token').val(token);
        $('form#postForm input#accountId').val(accountId);
        $('form#postForm input#callback').val(callback);
        $('form#postForm').attr('action', uriPostAccountLibrary).submit();

    } catch (e) {
        console.log('publish_uploadImgToAccountLibrary', e);
        publish_setStatus('-1.6', e);
    }
};

/**
 * Callback que lida com a resposta do upload de imagem para a bilbioteca criativa via backend, em caso de sucesso, invoca a criação de (AdCampaign)
 * @param  {object} data [description]
 */
function publish_HandleUploadImgToAccountLibrary(data) {
    console.log('publish_HandleUploadImgToAccountLibrary', data);
    try {
        if (data.hasOwnProperty('data'))
            data = data.data;

        //facebook error
        if (data.hasOwnProperty('error'))
            if (data.error.hasOwnProperty('message'))
                throw data.error.message;

            // backend error
        if (data.hasOwnProperty('success'))
            if (!data.success)
                throw data.message || 'backend error';

            // checando parametros recebidos
        if (data.hasOwnProperty('hash')) {
            if (!data.hash || typeof data.hash != 'string')
                throw 'invalid data.hash';

            window.g.creative.imgHash = data.hash;
        }

        if (data.hasOwnProperty('url')) {
            if (!data.url || typeof data.url != 'string')
                throw 'invalid data.url';

            window.g.creative.imgUrl = data.url;
        }

        publish_setStatus('1.6'); //escrever status
        publish_createCampaignGroup();

    } catch (e) {
        console.log('publish_HandleUploadImgToAccountLibrary():', e);
        publish_setStatus('-1.6', e);
    }
};

///////////////
// ANALYTICS //
///////////////

function gaGoalView(goal, step) {
    var goals = {
        1: 'post',
        2: 'fan',
        3: 'conv'
    };
    if (step == 1) step = '';
    else step = '/' + step;
    var url = '/goals/' + goals[goal] + step;
    ga('send', 'pageview', url);
    // console.log(url);
};

///////////////////////
// PIXEL CONVERISION //
///////////////////////

/**
 * Método que tranfere atributos entre um elemento no DOM
 */
function publish_hitCreationPixel() {
    // console.log('publish_hitCreationPixel');
    var $pxl = $('#finishCampaignPixel');
    $pxl.attr('src', $pxl.attr('data-src'));
};