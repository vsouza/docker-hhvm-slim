$(document).ready(function() {
    try {
        window.g.currentGoal = 2;
        gaGoalView(window.g.currentGoal, 1);
        mixpanel.track("Start Goal", {
            'Goal': window.g.currentGoal
        });

        // exibe o loader na DOM
        fullLoader(null, null, 'fullLoaderBg', 0);

        // aplicando templates do handlebars
        CreateClass.MyHandlebars(pageData, "beginAge").simpleRender();
        CreateClass.MyHandlebars(pageData, "endAge").simpleRender();
        if (inObject('targeting', pageData)) {
            //idade
            var hAge = pageData.targeting;
            hAge.ageTerms = {
                conjunctive: _('labTo'),
                indefinite: _('labIndefinite'),
                misgid: 'year'
            };
            CreateClass.MyHandlebars(hAge, "madeRange").simpleRender();

            // exibir avatar de gender
            var hSex = (pageData.targeting.gender || 2);
            var genderShow = {};
            var gender = {};
            switch (hSex) {
                case 0:
                    gender.male = _('men');
                    break;
                case 1:
                    gender.female = _('women');
                    break;
                case 2:
                    gender.male = _('men');
                    gender.female = _('women');
                    break;
            }
            CreateClass.MyHandlebars(gender, "genderShowClass").simpleRender();

            // exibir gender por escrito
            genderShow.gender = gender;
            genderShow.genderTerms = {
                conjunctive: _('labAnd')
            };
            CreateClass.MyHandlebars(genderShow, "genderShow").simpleRender();
        }
        // chamando os conection objects do accountid, filtrando e exibindo somente as pages
        adAccount.getConnectionObjects().then(fbReady);

        stepperTrigger(window.g.stepper); // gerencia o stepper no footer

        //definição do caruosel para não agir sozinho
        $('.carouselPostVariation').carousel({
            interval: false,
            wrap: true
        }).on('slide.bs.carousel', function() {}).on('slid.bs.carousel', function() {});

        /* definição de parametros regionais da ferramenta + aplicação de máscara*/
        CreateClass.Regional().setMaskForAll('mask', null);

        // Word Size Sentinel
        wordSizeSentinel();
    } catch (e) {
        console.log('goal2.php.js : ' + e);
    } finally {
        // window.g.stepper = 4;
        // stepperTrigger(window.g.stepper);
        // $('.fullCarousel').jcarousel();
        // $('.fullCarousel').jcarousel('scroll', '+=3');
    }
});

/////////////////////////////////////
// FUNÇÕES DE INTERFACE DE USUÁRIO //
/////////////////////////////////////

/**
 * Inicia o comportamento do FullCarousel do objetivo 02 da ferramenta
 */
function startFullCarousel() {
    $('.fullCarousel').jcarousel({
        animation: {
            vertical: true,
            duration: 300,
            easing: 'linear',
            complete: function() {
                // altera o stepper da página no objeto controlador e chama seus métodos de controle
                if ($('div.fullCarousel > ul').length > 0) {
                    $('#goalContent > div.fullCarousel > ul > li').css('height', 'auto'); //reseta as alturas de todas as li's do fullCarousel
                    var left = parseFloat($('div.fullCarousel > ul').css('left'));
                    left = Math.abs(left);
                    window.g.stepper = (left / window.g.stepperW) + 1;
                    gaGoalView(window.g.currentGoal, window.g.stepper);
                    mixpanel.track("Goal Step", {
                        'Goal': window.g.currentGoal,
                        'Step': window.g.stepper
                    });
                    stepperTrigger(window.g.stepper); // gatilho do stepper
                }
            }
        }
    });
    $('#fPrev').click(function() { //ação do voltar do fullCarousel
        var cls = $('#fPrev').attr('class').split(' ');
        if (inArray('btn-goal-disabled', cls)) return false;
        if (window.g.stepper == 1) window.location = "/goals";
        $('.fullCarousel').jcarousel('scroll', '-=1');
    });
    $('#fNext').click(function() { //ação de next do fullCarousel
        var cls = $('#fNext').attr('class').split(' ');
        if (inArray('btn-goal-disabled', cls)) return false;
        if (!beginStepperTrigger(window.g.stepper)) return false;
        if (inArray('publish', cls)) {
            publish_Objective02Start();
        } else {
            $('.fullCarousel').jcarousel('scroll', '+=1');
        }
    });
    $('.stepper7-indicators a').bind('click', function(event) { //click direto no indicador do fullCarousel
        var navId = $(this).attr('id');
        if (!navId || typeof navId != 'string') return false;
        navId = parseFloat(navId.replace('nav-', ''));

        if ((navId + 1) >= window.g.stepper) return false;
        $('.fullCarousel').jcarousel('scroll', navId);

        window.g.stepper = navId + 1;
        stepperTrigger(window.g.stepper); // gatilho do stepper
    });
};

/**
 * Método executado antes de cada mudança de passo
 * @param  {integer} oldStep: passo anterior do objetivo corrente
 */
function beginStepperTrigger(oldStep) {
    try {
        if (isNaN(oldStep) || !oldStep) throw 'invalid param';
        return true;
    } catch (e) {
        console.log('beginStepperTrigger :' + e);
        return false;
    }
};

/**
 * Método executado a cada mudança de passo
 * @param  {integer} step: passo anterior do objetivo corrente
 */
function stepperTrigger(step) {
    stepperVerify(window.g.stepper); // gerencia os botões de paginação do stepper
    changeFooterStepper(window.g.stepper); // gerencia o stepper no footer

    if (isNaN(step) || !step) return;

    //aplicando tamanho dinâmico as li do fullCarousel
    liFullCarouselAutoH(step, 10);

    switch (step) {
        case 1: // seleção de páginas
            $('div#mainQuestion').html(_('hMainQuestion01'));
            break;
        case 2: // criação de criativo
            $('div#mainQuestion').html(_('hMainQuestion12'));
            bindCreateYourAd();
            break;
        case 3: // visualização do criativo
            $('div#mainQuestion').html(_('hMainQuestion13'));
            break;
        case 4: // definindo targeting
            $('div#mainQuestion').html(_('hMainQuestion03'));

            if (!window.g.stpGuideChecked) {

                if (!tbCookie.has("stpGuideChecked"))
                    tbCookie.set("stpGuideChecked", 1);

                window.g.stpGuideChecked = true;
                startGuideTabStp03();
            }

            // exibir os valores pré definidos, para localização caso existam
            startPlaceDefiner();
            finderCacheSyncHTML('placeDefiner');

            // exibir os valores pré definidos, para interesses caso existam
            startInterestDefiner();
            finderCacheSyncHTML('interestDefiner');

            // chamada reach estimate
            if (!window.g.stpFirstReachSearch) {
                window.g.stpFirstReachSearch = true;
                var targeting_spec = getTargetingSpecFromSegmentation();
                var reachData = {
                    targeting_spec: targeting_spec,
                    currency: window.g.currency
                }
                adAccount.getReachEstimate(reachData).then(fbHandleReachEstimate);
            }

            break;
        case 5: // definindo bidding
            $('div#mainQuestion').html(_('hMainQuestion04'));

            //Seleção de forma de pagamento da campanha
            var selectValue = $('div#stp05 div#byValue div.r-body.sel');
            var selectPeriod = $('div#stp05 div#byPeriod div.r-body.sel');
            var formValue = $('div#stp05 div#byValue div.r-body.form');
            var formPeriod = $('div#stp05 div#byPeriod div.r-body.form');
            $('div#stp05 div#byValue').unbind('click').bind('click', function() {
                if (selectValue.is(':visible')) {
                    selectValue.hide();
                    formValue.show();
                }
                selectPeriod.show();
                formPeriod.hide();
            });
            $('div#stp05 div#byPeriod').unbind('click').bind('click', function() {
                if (selectPeriod.is(':visible')) {
                    selectPeriod.hide();
                    formPeriod.show();
                }
                selectValue.show();
                formValue.hide();
            });

            if (!$('span.reachEstimateSpan', '#stp05').text())
                $('span.reachEstimateSpan', '#stp05').text($.number(window.g.reachEstimate, 0, '', window.g.thousandSymbol));

            // instanciando elementos datetimepicker que serão usados no passo 4
            if (!window.g.stpDateTimePickerSet) {
                window.g.stpDateTimePickerSet = true;

                // instanciando e aplicando 30 dias de default para duração da campanha por período
                $('#top_beginDate, #top_endDate').datetimepicker({
                    format: window.g.componetSetup.datetimepicker.format,
                    language: window.g.componetSetup.datetimepicker.language,
                    orientation: 'left',
                    startDate: moment({
                        hour: 0
                    }).toDate(),
                });
                var begin = $('#top_beginDate').data('datetimepicker');
                var end = $('#top_endDate').data('datetimepicker');
                begin.setLocalDate(moment().toDate());
                end.setLocalDate(moment().add('days', 2).toDate());

                // instanciando datepickers para campanhas vitalícias
                $('#sub_beginDate, #sub_endDate').datetimepicker({
                    format: window.g.componetSetup.datetimepicker.format,
                    language: window.g.componetSetup.datetimepicker.language,
                    orientation: 'bottom-left',
                    startDate: moment({
                        hour: 0
                    }).toDate(),
                });

                $('#sub_beginDate').on('changeDate', function(e) {
                    var nDay = simulatebyValueChangeDate();
                    $('#stp05 div.simulate.byValue > div.simuBody div.calendar span.aux').text(_n('day', nDay));
                    $('#stp05 div.simulate.byValue > div.simuBody div.calendar span.value').text(nDay);

                    // verificando o budget mínimo a cada mudança de data no bidding por valor
                    verifyTheMinimumBudget(nDay);
                });

                $('#sub_endDate').on('changeDate', function(e) {
                    var nDay = simulatebyValueChangeDate();
                    $('#stp05 div.simulate.byValue > div.simuBody div.calendar span.aux').text(_n('day', nDay));
                    $('#stp05 div.simulate.byValue > div.simuBody div.calendar span.value').text(nDay);

                    // verificando o budget mínimo a cada mudança de data no bidding por valor
                    verifyTheMinimumBudget(nDay);
                });
            }
            break;
        case 6: // escrevendo o nome da campanha
            $('div#mainQuestion').html(_('hMainQuestion05'));

            var text = $('#stp06 input#campaignName');
            text.unbind('change').bind('change', function() {
                stepperVerify(window.g.stepper);
            }).bind('keydown', function(e) {
                stepperVerify(window.g.stepper);
                if (e.which == 9) {
                    e.preventDefault();
                }
            });
            break;
        case 7: // preview
            $('div#mainQuestion').html(_('hMainQuestion06'));

            // gênero
            $('#stp07 #reviewGenderStr').text($('#segSex > div.r-body > div.r-content > span').text());
            // idade
            $('#stp07 #reviewAgeStr').text($('#segAge > div.r-body > div.r-content > span').text());
            // localidades
            var adGeoLocation = window.g.targetingSpecs.getFlatGeoLocations();
            if (adGeoLocation instanceof Object && !$.isEmptyObject(adGeoLocation)) {
                if ($.isArray(adGeoLocation)) {
                    if (adGeoLocation.length) {
                        var str = '';
                        for (i = 0, l = adGeoLocation.length; i < l; i++) {
                            str += adGeoLocation[i].name + (adGeoLocation[i].hasOwnProperty('region') ? ', ' + adGeoLocation[i].region : '') + ', ';
                        }
                        $('#stp07 #reviewLocatedStr').text(str.substring(0, str.length - 2));
                    }
                } else {
                    $('#stp07# reviewLocatedStr').text(adGeoLocation.name)
                }
            }

            // interesses
            var adKeyWord = window.g.targetingSpecs.getInterests();
            if (adKeyWord instanceof Object && !$.isEmptyObject(adKeyWord)) {
                if ($.isArray(adKeyWord)) {
                    if (adKeyWord.length) {
                        var str = '';
                        for (i = 0, l = adKeyWord.length; i < l; i++) {
                            str += adKeyWord[i].name + ', ';
                        }
                        $('#stp07 #reviewInterestedStr').text(str.substring(0, str.length - 2));
                    }
                } else {
                    $('#stp07 #reviewInterestedStr').text(adKeyWord.name)
                }
            }
            // nome da campanha
            $('#stp07 #reviewCampaignName').text($('#stp06 input#campaignName').val());

            //recuperando valores de acordo com a escolha do orçamento
            if (window.g.createCampaignBy == 'byValue') {
                var begin = $('input#sub_beginDateI').val();
                var end = $('input#sub_endDateI').val();
                var investiment = $('div#byValue #budget').val();
            } else {
                var begin = $('input#top_beginDateI').val();
                var end = $('input#top_endDateI').val();
                var investiment = $('div.simulate.byPeriod > div.simuBody div.currentBudget > font:nth-child(2)').text();
            }

            // recuperando datas iniciais
            //  Formatando e exibindo datas iniciais e finais
            if (begin && begin.length == 19) {
                begin = moment(begin, window.g.dateTime24).format(window.g.dateTimeShortDotted);
                begin = begin.replace('%0', _('labAt'));
                $('#stp07 #reviewBeginDate').text(begin);
            }
            if (end && end.length == 19) {
                end = moment(end, window.g.dateTime24).format(window.g.dateTimeShortDotted);
                end = end.replace('%0', _('labAt'));
                $('#stp07 #reviewEndDate').text(end);
            }

            //formatando e exibindo valor do investimento
            $('#stp07 #reviewInvestment').text(tryParse(investiment, 'justNumber', investiment)).currency({
                region: window.g.currency,
                thousands: window.g.thousandSymbol,
                decimal: window.g.decimalSymbol,
                decimals: window.g.decimalCount,
                hidePrefix: false,
                hidePostfix: true,
            });
            break;
        default:
            break;
    }
};

/**
 * Função para alterar os status do paginador do stepper, validando alguns parâmetros quando necessário
 * @param  {integer} currentStep: Passo atual do objetivo corrente
 */
function stepperVerify(currentStep) {
    if (isNaN(currentStep) || !currentStep) return false;

    var lArr = ['btn-goal-disabled', 'btn-goal-normal'];
    var rArr = ['btn-goal-disabled', 'btn-green'];

    var lClass = lArr[0];
    var rClass = rArr[0];

    if (currentStep > 1) lClass = lArr[1];

    if (currentStep === 1) {
        lClass = lArr[1];
        if ($('div.pageList > .item > ul > li.selected').length) rClass = rArr[1];
    } else if (currentStep === 2) {
        var titAd = $('input#titAd', 'div#stp02');
        var txtText = $('textarea#txtText', 'div#stp02');
        if (titAd.val() && txtText.val()) {
            rClass = rArr[1];
        }
    } else if (currentStep === 3) {
        rClass = rArr[1];
    } else if (currentStep === 4) {
        var segPlaceBtnLabel = _('btnChange');
        var segInterestBtnLabel = _('btnChange');

        var segPlaceContent = $('#segPlace > div.r-body > div.r-content > div.r-content-overflow');
        var segInterestContent = $('#segInterest > div.r-body > div.r-content > div.r-content-overflow');

        if (!segPlaceContent.children('span').length)
            segPlaceBtnLabel = _('btnAdd');

        if (!segInterestContent.children('span').length)
            segInterestBtnLabel = _('btnAdd');

        $('#segPlace > div.r-footer.aRig > button').text(segPlaceBtnLabel);
        $('#segInterest > div.r-footer.aRig > button').text(segInterestBtnLabel);

        //caso tenhamos atingidos mais de 5000 pessoas prosseguiremos
        if (window.g.reachEstimate > 5000) {
            rClass = rArr[1];
        } else if (window.g.reachEstimate != 0) {
            bootbox.dialog({
                className: 'blue',
                locale: window.g.languageMin,
                message: _('segmentationExpectMore'),
                closeButton: false,
                buttons: {
                    'return': {
                        label: _('ok'),
                        callback: function() {}
                    }
                }
            });
        }
    } else if (currentStep === 5) {
        if (window.g.stpSimulated) {
            rClass = rArr[1];
        }
    } else if (currentStep === 6) {
        var text = $('#stp06 input#campaignName');
        if (text.length > 0) {
            if (text.val()) {
                rClass = rArr[1];
            }
        }
    } else if (currentStep === 7) {
        rClass = rArr[1] + ' publish';
    }

    $('button#fPrev', '#fWrapper').attr('class', lClass);
    $('button#fNext', '#fWrapper').attr('class', rClass).text(currentStep === 7 ? _('btnPublish') : _('btnContinue'));
};

/**
 * Método que realiza os eventos visuais de manipulação do indicador de passo no footer da página
 * @param  {integer} step: passo atual do objetivo X/N
 */
function changeFooterStepper(step) {
    var maxStep = $('li', '.stepper7-indicators').length;
    if (isNaN(step) || isNaN(maxStep)) return false;
    if (step > maxStep) return false;

    var stepPercent = 100 / (maxStep - 1);

    $('.stepper7 .stepperFIll').animate({
        'width': (stepPercent * (step - 1)) + '%'
    }, 300, function() {
        $('.stepper7-indicators > ul > li').removeClass('done');
        $('.stepper7-indicators-labels > div').removeClass('done');
        for (i = 1; i <= step; i++) {
            $('.stepper7-indicators > ul > li:nth-child(' + i + ')').addClass('done');
            $('.stepper7-indicators-labels > div:nth-child(' + i + ')').addClass('done');
        }
    });
};

/**
 * Função que organiza o comportamento do passo 2.2
 */
function bindCreateYourAd() {
    try {
        var container = 'div#stp02';
        var titAd = $('input#titAd', container);
        var txtText = $('textarea#txtText', container);
        var adMedia = $('div.pageLikeAdMedia', container);
        var inputAddMedia = $('form#postForm input#file');

        maskFileInput(container); // definindo botão de input estilizado

        // definindo tooltip
        $('button#addMediaBtn', container).tooltip({
            placement: 'top'
        });

        // Função de replicação do conteúdo digitado no titAd para o preview
        titAd.unbind('keyup').bind('keyup', function() {
            var t = $(this).val();
            $('h6.pageLikeAdTitle', container).html(t);
            $('h6.pageLikeAdTitle', '#stp03').html(t); // alimentando o html do próximo passo
            $('h6.pageLikeAdTitle', '.stpPublish').html(t); // alimentando o html do passo de publicação
            stepperVerify(window.g.stepper); // gerencia os botões de paginação do stepper
        });

        // Função de replicação do conteúdo digitado no txtText para o preview
        txtText.unbind('keyup').bind('keyup', function() {
            var t = $(this).val();
            $('div.pageLikeAdMessage', container).html(t);
            $('div.pageLikeAdMessage', '#stp03').html(t); // alimentando o html do próximo passo
            $('div.pageLikeAdMessage', '.stpPublish').html(t); // alimentando o html do passo de publicação
            stepperVerify(window.g.stepper); // gerencia os botões de paginação do stepper
        });

        // Função de adicionar mídia no preview
        inputAddMedia.unbind('change').bind('change', function() {
            //criar o objeto que vai renderizar a imagem no preview
            var reader = new window.FileReader();
            reader.onload = function(e) {
                var result = e.target.result;
                if (result) {
                    var splt = result.split(';')[0];
                    splt = splt.replace('data:', '');

                    try {
                        //caso seja imagem
                        if (splt.indexOf('image') > -1) {
                            $(adMedia).html('<img src="' + result + '">').attr('hasMedia', 1);
                            $('.pag-thumb', '#stp03').html('<img src="' + result + '">'); // alimentando o html do próximo passo
                            $('.pag-thumb', '.stpPublish').html('<img src="' + result + '">'); // alimentando o html do passo de publicação

                            $('form#postForm input#type').val('photo');

                            // zerar o objeto criativo
                            window.g.creative = {
                                imgUrl: null,
                                imgHash: null,
                                imgWidth: null,
                                imgHeight: null,
                            };

                            throw 1; // throw de sucesso
                        }
                        throw 0; // throw de arquivo inválido
                    } catch (e) {
                        if (e === 0) {
                            // reseta o valor do input
                            var postFile = $(':file', 'form#postForm');
                            postFile.replaceWith(postFile = postFile.clone(true));

                            $(adMedia).html('<div class="thumbInvalid"><span>' + _('invalidFile') + '</span></div>').attr('hasMedia', 1);
                            $('form#postForm input#type').val('status');
                        }
                    }
                }
            };

            // chama a função de renderizar
            reader.readAsDataURL($(this).get(0).files[0]);
        });
    } catch (e) {
        console.log('bindCreateYourAd() : ', e);
    }
};


////////////////////////////
// PUBLICANDO NO FACEBOOK //
////////////////////////////

/**
 * Função que inicia o processo de publicação do objetivo 02
 */
function publish_Objective02Start() {
    bootbox.dialog({
        className: 'blue',
        locale: window.g.languageMin,
        title: _('labConfirmation'),
        message: _('proceedWithCreationGoal02'),
        closeButton: false,
        buttons: {
            'no': {
                label: _('labNo'),
                callback: function() {},
            },
            'yes': {
                label: _('labYes'),
                callback: function() {
                    $('button#fNext').attr('class', 'btn-goal-disabled'); //desabilitando o botão de publicar campanha

                    var imgUrl = window.g.creative.imgUrl;
                    var imgHash = window.g.creative.imgHash;
                    var hasFileToUpload = $('form#postForm input#file').val();
                    // testando se temos o hash ou url da imagem que será usada na criação do AD
                    if (!imgUrl && !imgHash && hasFileToUpload) {
                        publish_setStatus('1.8'); //escrever status
                        publish_uploadImgToAccountLibrary();
                    } else {
                        publish_createCampaignGroup();
                    }

                    setTimeout(function() {
                        showModal('#modalPublish', {
                            backdrop: 'static',
                            keyboard: false,
                            closeButton: false
                        });
                    }, 400);
                },
            },
        }
    });
};

/**
 * Função que criará o anúncio principal (Nova estrutura)
 */
function publish_createMainAd() {
    try {
        window.g.variationAd = [];

        //verificando se já possuo o anúncio principal criado no objeto global
        if (window.g.publish.primaryAdId && !isNaN(window.g.publish.primaryAdId)) {
            // chamando a função que lida com a criação de anúncio principal simulando a criação via facebook
            publish_fbHandleCreateMainAd({
                id: window.g.publish.primaryAdId
            });
        } else {
            // Creative
            var pageId = window.g.pageId;
            var body = $('textarea#txtText', 'div#stp02').val();
            var title = $('input#titAd', 'div#stp02').val();

            if (window.g.creative.imgFile)
                var image_file = window.g.creative.imgFile;
            else if (window.g.creative.imgUrl)
                var image_url = window.g.creative.imgUrl;
            else if (window.g.creative.imgHash)
                var image_hash = window.g.creative.imgHash;

            var pageUrl = window.g.pageUrl;
            var creative = TB.AdCreative.make.page_like_ad(pageId, body, title, null, image_hash, image_url, image_file, pageUrl);

            // AdGroup
            var campaign_id = window.g.publish.campaignId;
            var name = _('mainAdName').replace('%d', campaign_id);

            var adGroupData =  {
                campaign_id: campaign_id,
                name: name,
                creative: creative,
            };
            var adGroup = new api.AdGroup(adGroupData, adAccount.id);
            adGroup.create().then(publish_fbHandleCreateMainAd);
            // TB.AdGroup.create('publish_fbHandleCreateMainAd', account_id, campaign_id, name, bid_type, bid_info, creative, targeting, objective);
            mixpanel.track("Publish Campaign", {
                'Goal': window.g.currentGoal,
            });

            window.g.publish.name = name;
        }
    } catch (e) {
        console.log('publish_createMainAd():', e);
        publish_setStatus('-1.4', e);
    }
};