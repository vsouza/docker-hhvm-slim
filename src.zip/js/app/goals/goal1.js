window.g.hasPublishActionsPermissions = false;
$(document).ready(function() {
    try {
        window.g.currentGoal = 1;
        gaGoalView(window.g.currentGoal, 1);
        mixpanel.track("Start Goal", {
            'Goal': window.g.currentGoal
        });

        // exibe o loader na DOM
        fullLoader(null, null, 'fullLoaderBg', 0);

        // aplicando templates do handlebars
        CreateClass.MyHandlebars(pageData, "beginAge").simpleRender();
        CreateClass.MyHandlebars(pageData, "endAge").simpleRender();

        if (inObject('targeting', pageData)) {
            //idade
            var hAge = pageData.targeting;
            hAge.ageTerms = {
                conjunctive: _('labTo'),
                indefinite: _('labIndefinite'),
                misgid: 'year'
            };
            CreateClass.MyHandlebars(hAge, "madeRange").simpleRender();

            // exibir avatar de gender
            var hSex = (pageData.targeting.gender || 2);
            var genderShow = {};
            var gender = {};
            switch (hSex) {
                case 0:
                    gender.male = _('men');
                    break;
                case 1:
                    gender.female = _('women');
                    break;
                case 2:
                    gender.male = _('men');
                    gender.female = _('women');
                    break;
            }
            CreateClass.MyHandlebars(gender, "genderShowClass").simpleRender();

            // exibir gender por escrito
            genderShow.gender = gender;
            genderShow.genderTerms = {
                conjunctive: _('labAnd')
            };
            CreateClass.MyHandlebars(genderShow, "genderShow").simpleRender();
        }
        adAccount.getConnectionObjects().then(fbReady);

        // gerência o stepper no footer
        stepperTrigger(window.g.stepper);

        //definição do caruosel para não agir sozinho
        $('.carouselPostVariation').carousel({
            interval: false,
            wrap: true
        }).on('slide.bs.carousel', function() {}).on('slid.bs.carousel', function() {});

        /* definição de parametros regionais da ferramenta + aplicação de máscara */
        CreateClass.Regional().setMaskForAll('mask', null);

        // Word Size Sentinel
        wordSizeSentinel();

        // Check for publich_action permissions
        api.graph.get('debug_token', {input_token: window.g.token}).then(handlePermissions);
    } catch (e) {
        console.log('goal1.php.js : ' + e);
    }
});


/////////////////////////////////////////
// PERMISSÕES DE PUBLICAÇÃO EM PÁGINAS //
/////////////////////////////////////////

/**
 * Callback que recebe as informações de permissão de publicação no feed do cliente
 */
function handlePermissions(response) {
    if (response.data.scopes.indexOf('publish_actions') > -1)
        window.g.hasPublishActionsPermissions = true;
};

/**
 * Inicialização assíncrona do Objeto FB, que executa o método de busca e verificação de permissões
 */
window.fbAsyncInit = function() {
    FB.init({
        appId: g.appId,
        status: true, // check login status
        cookie: true, // enable cookies to allow the server to access the session
        xfbml: true // parse XFBML
    });
    $('#btnPublishActions').click(function() {
        getPublishActionsPermission();
    });
};

/**
 * Método de verificação de token do usuário com o foco em "publish_actions"
 */
function getPublishActionsPermission() {
    FB.login(function(response) {
        api.graph.get('debug_token', {input_token: window.g.token}).then(checkPermissions);
        $('#modalPublishActions').modal('hide');
        fullLoader(null, null, 'fullLoaderBg', 0); // exibe o loader na DOM
    }, {
        scope: 'publish_actions'
    });
};

/**
 * Método que recebe a resposta da análise do token do usuário e libera o clienta pra o uso da publicação
 * @param  {object} response: resposta do facebook
 */
function checkPermissions(response) {
    if (response.data.scopes.indexOf('publish_actions') > -1)
        publish_Objective01Go();
    else {
        fullLoaderStop();
        showModal('#modalPublishActions', {
            backdrop: 'static',
            keyboard: false
        });
    }
};

/////////////////////////////////////
// FUNÇÕES DE INTERFACE DE USUÁRIO //
/////////////////////////////////////

/**
 * Inicia o comportamento do FullCarousel do objetivo 01 da ferramenta
 */
function startFullCarousel() {
    $('.fullCarousel').jcarousel({
        animation: {
            vertical: true,
            duration: 300,
            easing: 'linear',
            complete: function() {
                // altera o stepper da página no objeto controlador e chama seus métodos de controle
                if ($('div.fullCarousel > ul').length > 0) {
                    $('#goalContent > div.fullCarousel > ul > li').css('height', 'auto'); //reseta as alturas de todas as li's do fullCarousel
                    var left = parseFloat($('div.fullCarousel > ul').css('left'));
                    left = Math.abs(left);
                    window.g.stepper = (left / window.g.stepperW) + 1;
                    gaGoalView(window.g.currentGoal, window.g.stepper);
                    mixpanel.track("Goal Step", {
                        'Goal': window.g.currentGoal,
                        'Step': window.g.stepper
                    });
                    stepperTrigger(window.g.stepper); // gatilho do stepper
                }
            }
        }
    });
    $('#fPrev').click(function() { //ação do voltar do fullCarousel
        var cls = $('#fPrev').attr('class').split(' ');
        if (inArray('btn-goal-disabled', cls)) return false;
        if (window.g.stepper == 1) window.location = "/goals";
        $('.fullCarousel').jcarousel('scroll', '-=1');
    });
    $('#fNext').click(function() { //ação de next do fullCarousel
        var cls = $('#fNext').attr('class').split(' ');
        if (inArray('btn-goal-disabled', cls)) return false;
        if (!beginStepperTrigger(window.g.stepper)) return false;
        if (inArray('publish', cls)) {
            publish_Objective01Start();
        } else {
            $('.fullCarousel').jcarousel('scroll', '+=1');
        }
    });
    $('.stepper6-indicators a').bind('click', function(event) { //click direto no indicador do fullCarousel
        var navId = $(this).attr('id');
        if (!navId || typeof navId != 'string') return false;
        navId = parseFloat(navId.replace('nav-', ''));

        if ((navId + 1) >= window.g.stepper) return false;
        $('.fullCarousel').jcarousel('scroll', navId);

        window.g.stepper = navId + 1;
        stepperTrigger(window.g.stepper); // gatilho do stepper
    });
};

/**
 * Método que realiza os eventos visuais de manipulação do indicador de passo no footer da página
 * @param  {integer} step: passo atual do objetivo X/N
 */
function changeFooterStepper(step) {
    var maxStep = $('li', '.stepper6-indicators').length;
    if (isNaN(step) || isNaN(maxStep)) return false;
    if (step > maxStep) return false;

    var stepPercent = 100 / (maxStep - 1);

    $('.stepper6 .stepperFIll').animate({
        'width': (stepPercent * (step - 1)) + '%'
    }, 300, function() {
        $('.stepper6-indicators > ul > li').removeClass('done');
        $('.stepper6-indicators-labels > div').removeClass('done');
        for (i = 1; i <= step; i++) {
            $('.stepper6-indicators > ul > li:nth-child(' + i + ')').addClass('done');
            $('.stepper6-indicators-labels > div:nth-child(' + i + ')').addClass('done');
        }
    });
};

/**
 * Método executado antes de cada mudança de passo
 * @param  {integer} oldStep: passo anterior do objetivo corrente
 */
function beginStepperTrigger(oldStep) {
    try {
        if (isNaN(oldStep) || !oldStep) throw 'invalid param';
        if (oldStep === 1 && window.g.ppArr === null) { // caso seja o do passo 1 -> 2 e não tenha sido efetuado uma consulta dos promotables posts
            fullLoader(null, null, 'fullLoaderBg', 0); // exibe o loader na DOM
        }
        return true;
    } catch (e) {
        console.log('beginStepperTrigger :' + e);
        return false;
    }
};

/**
 * Método executado a cada mudança de passo
 * @param  {integer} step: passo anterior do objetivo corrente
 */
function stepperTrigger(step) {
    stepperVerify(window.g.stepper); // gerencia os botões de paginação do stepper
    changeFooterStepper(window.g.stepper); // gerencia o stepper no footer

    if (isNaN(step) || !step) return;

    //aplicando tamanho dinâmico as li do fullCarousel
    if (step != 2) {
        liFullCarouselAutoH(step, 10);
    } else {
        liFullCarouselAutoH(step, 80);
    }

    switch (step) {
        case 1: // seleção de páginas
            $('div#mainQuestion').html(_('hMainQuestion01'));
            break;
        case 2: // gerenciando posts promovíveis
            $('div#mainQuestion').html(_('hMainQuestion02'));

            //instancioando o select
            if (!$('button.dropdown-toggle[data-id="contentDecision"]', 'div#stp02').length) {
                $('select#contentDecision').selectpicker({
                    width: 350,
                    showSubtext: false,
                    showContent: false,
                }).change(function(event) {
                    var val = $(this).val();

                    if (val == 0) return;
                    else if (val == 1) { //escolher outro conteúdo
                        showModal('#modalChooseCreative', {
                            backdrop: 'static',
                            keyboard: false
                        });
                    } else if (val == 2) { // criar um novo conteúdo
                        showModal('#modalCreateCreative', {
                            backdrop: 'static',
                            keyboard: false
                        });
                    } else if (val == 3) { // criar um conteúdo semelhante
                        showModal('#modalCreateCreativeSimilar', {
                            backdrop: 'static',
                            keyboard: false
                        });
                    }

                    $('select#contentDecision').selectpicker('val', '0'); // reset default value

                });
            }

            if (window.g.ppArr === null) {
                //verifica se há alguma página selecionada
                var liSel = $('div.pageList > .item > ul > li.selected');
                if (liSel.lengtsh < 1) return;

                // captura os post promovíveis da página selecionada
                CreateClass.FbPage().getPromotablePosts(window.g.token, window.g.pageId, window.g.locale, window.g.ppFields, 10, 'fbHandlePromotablePosts', null);
            }
            break;
        case 3: // definindo targeting
            $('div#mainQuestion').html(_('hMainQuestion03'));

            if (!window.g.stpGuideChecked) {

                if (!tbCookie.has("stpGuideChecked"))
                    tbCookie.set("stpGuideChecked", 1);

                window.g.stpGuideChecked = true;
                startGuideTabStp03();
            }

            // exibir os valores pré definidos, para localização caso existam
            startPlaceDefiner();
            finderCacheSyncHTML('placeDefiner');

            // exibir os valores pré definidos, para interesses caso existam
            startInterestDefiner();
            finderCacheSyncHTML('interestDefiner');

            // chamada reach estimate
            if (!window.g.stpFirstReachSearch) {
                window.g.stpFirstReachSearch = true;
                var targeting_spec = getTargetingSpecFromSegmentation();
                var reachData = {
                    targeting_spec: targeting_spec,
                    currency: window.g.currency
                }
                adAccount.getReachEstimate(reachData).then(fbHandleReachEstimate);
            }

            break;
        case 4: // definindo bidding
            $('div#mainQuestion').html(_('hMainQuestion04'));

            //Seleção de forma de pagamento da campanha
            var selectValue = $('div#stp04 div#byValue div.r-body.sel');
            var selectPeriod = $('div#stp04 div#byPeriod div.r-body.sel');
            var formValue = $('div#stp04 div#byValue div.r-body.form');
            var formPeriod = $('div#stp04 div#byPeriod div.r-body.form');
            $('div#stp04 div#byValue').unbind('click').bind('click', function() {
                if (selectValue.is(':visible')) {
                    selectValue.hide();
                    formValue.show();
                }
                selectPeriod.show();
                formPeriod.hide();
            });
            $('div#stp04 div#byPeriod').unbind('click').bind('click', function() {
                if (selectPeriod.is(':visible')) {
                    selectPeriod.hide();
                    formPeriod.show();
                }
                selectValue.show();
                formValue.hide();
            });

            if (!$('span.reachEstimateSpan', '#stp04').text())
                $('span.reachEstimateSpan', '#stp04').text($.number(window.g.reachEstimate, 0, '', window.g.thousandSymbol));

            // instanciando elementos datetimepicker que serão usados no passo 4
            if (!window.g.stpDateTimePickerSet) {
                window.g.stpDateTimePickerSet = true;

                // instanciando e aplicando 30 dias de default para duração da campanha por período
                $('#top_beginDate, #top_endDate').datetimepicker({
                    format: window.g.componetSetup.datetimepicker.format,
                    language: window.g.componetSetup.datetimepicker.language,
                    orientation: 'left',
                    startDate: moment({
                        hour: 0
                    }).toDate(),
                });
                var begin = $('#top_beginDate').data('datetimepicker');
                var end = $('#top_endDate').data('datetimepicker');
                begin.setLocalDate(moment().toDate());
                end.setLocalDate(moment().add('days', 2).toDate());

                // instanciando datepickers para campanhas vitalícias
                $('#sub_beginDate, #sub_endDate').datetimepicker({
                    format: window.g.componetSetup.datetimepicker.format,
                    language: window.g.componetSetup.datetimepicker.language,
                    orientation: 'bottom-left',
                    startDate: moment({
                        hour: 0
                    }).toDate(),
                });
                $('#sub_beginDate').on('changeDate', function(e) {
                    var nDay = simulatebyValueChangeDate();
                    $('#stp04 div.simulate.byValue > div.simuBody div.calendar span.aux').text(_n('day', nDay));
                    $('#stp04 div.simulate.byValue > div.simuBody div.calendar span.value').text(nDay);
                    // console.log('#sub_beginDate utc: ', e.date.toString());
                    // console.log('#sub_beginDate local: ', e.localDate.toString());

                    // verificando o budget mínimo a cada mudança de data no bidding por valor
                    verifyTheMinimumBudget(nDay);
                });
                $('#sub_endDate').on('changeDate', function(e) {
                    var nDay = simulatebyValueChangeDate();
                    $('#stp04 div.simulate.byValue > div.simuBody div.calendar span.aux').text(_n('day', nDay));
                    $('#stp04 div.simulate.byValue > div.simuBody div.calendar span.value').text(nDay);
                    // console.log('#sub_endDate utc: ', e.date.toString());
                    // console.log('#sub_endDate local: ', e.localDate.toString());

                    // verificando o budget mínimo a cada mudança de data no bidding por valor
                    verifyTheMinimumBudget(nDay);
                });
            }

            break;
        case 5: // escrevendo o nome da campanha
            $('div#mainQuestion').html(_('hMainQuestion05'));
            var text = $('#stp05 input#campaignName');
            text.unbind('change').bind('change', function() {
                stepperVerify(window.g.stepper);
            }).bind('keydown', function(e) {
                stepperVerify(window.g.stepper);
                if (e.which == 9) {
                    e.preventDefault();
                }
            });
            break;
        case 6: // preview
            $('div#mainQuestion').html(_('hMainQuestion06'));

            // aplicação dos tooltip do review
            $('#stp06 > div > div:nth-child(1) > ul.miniPost > li > div.model').each(function() {
                $(this).attr({
                    'data-original-title': '<div class="model">' + $(this).html() + '</div>',
                });
            });
            setTimeout(function() {
                $('#stp06 > div > div:nth-child(1) > ul.miniPost > li > div.model').tooltip({
                    animation: false,
                    html: true,
                    placement: 'top',
                    container: 'body',
                    template: '<div class="tooltip blueSolid"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',
                });
            }, 500);

            // gênero
            $('#stp06 #reviewGenderStr').text($('#segSex > div.r-body > div.r-content > span').text());
            // idade
            $('#stp06 #reviewAgeStr').text($('#segAge > div.r-body > div.r-content > span').text());
            // localidades
            var adGeoLocation = window.g.targetingSpecs.getFlatGeoLocations();
            if (adGeoLocation instanceof Object && !$.isEmptyObject(adGeoLocation)) {
                if ($.isArray(adGeoLocation)) {
                    if (adGeoLocation.length) {
                        var str = '';
                        for (i = 0, l = adGeoLocation.length; i < l; i++) {
                            str += adGeoLocation[i].name + (adGeoLocation[i].hasOwnProperty('region') ? ', ' + adGeoLocation[i].region : '') + ', ';
                        }
                        $('#stp06 #reviewLocatedStr').text(str.substring(0, str.length - 2));
                    }
                } else {
                    $('#stp06 #reviewLocatedStr').text(adGeoLocation.name)
                }
            }

            // interesses
            var adKeyWord = window.g.targetingSpecs.getInterests();
            if (adKeyWord instanceof Object && !$.isEmptyObject(adKeyWord)) {
                if ($.isArray(adKeyWord)) {
                    if (adKeyWord.length) {
                        var str = '';
                        for (i = 0, l = adKeyWord.length; i < l; i++) {
                            str += adKeyWord[i].name + ', ';
                        }
                        $('#stp06 #reviewInterestedStr').text(str.substring(0, str.length - 2));
                    }
                } else {
                    $('#stp06 #reviewInterestedStr').text(adKeyWord.name)
                }
            }
            // nome da campanha
            $('#stp06 #reviewCampaignName').text($('#stp05 input#campaignName').val());

            //recuperando valores de acordo com a escolha do orçamento
            if (window.g.createCampaignBy == 'byValue') {
                var begin = $('input#sub_beginDateI').val();
                var end = $('input#sub_endDateI').val();
                var investiment = $('div#byValue #budget').val();
            } else {
                var begin = $('input#top_beginDateI').val();
                var end = $('input#top_endDateI').val();
                var investiment = $('#stp04 div.simulate.byPeriod > div.simuBody div.currentBudget > font:nth-child(2)').text();
            }

            // recuperando datas iniciais
            // Formatando e exibindo datas iniciais e finais
            if (begin && begin.length == 19) {
                begin = moment(begin, window.g.dateTime24).format(window.g.dateTimeShortDotted);
                begin = begin.replace('%0', _('labAt'));
                $('#stp06 #reviewBeginDate').text(begin);
            }

            if (end && end.length == 19) {
                end = moment(end, window.g.dateTime24).format(window.g.dateTimeShortDotted);
                end = end.replace('%0', _('labAt'));
                $('#stp06 #reviewEndDate').text(end);
            }

            //formatando e exibindo valor do investimento
            $('#stp06 #reviewInvestment').text(tryParse(investiment, 'justNumber', investiment)).currency({
                region: window.g.currency,
                thousands: window.g.thousandSymbol,
                decimal: window.g.decimalSymbol,
                decimals: window.g.decimalCount,
                hidePrefix: false,
                hidePostfix: true,
            });
            break;
        default:
            break;
    }
};

/**
 * Função para alterar os status do paginador do stepper, validando alguns parâmetros quando necessário
 * @param  {integer} currentStep: Passo atual do objetivo corrente
 */
function stepperVerify(currentStep) {
    if (isNaN(currentStep) || !currentStep) return false;

    var lArr = ['btn-goal-disabled', 'btn-goal-normal'];
    var rArr = ['btn-goal-disabled', 'btn-green'];

    var lClass = lArr[0];
    var rClass = rArr[0];

    if (currentStep > 1) lClass = lArr[1];

    if (currentStep === 1) {
        lClass = lArr[1];
        if ($('div.pageList > .item > ul > li.selected').length) rClass = rArr[1];
    } else if (currentStep === 2) {
        rClass = rArr[1];
    } else if (currentStep === 3) {
        var segPlaceBtnLabel = _('btnChange');
        var segInterestBtnLabel = _('btnChange');

        var segPlaceContent = $('#segPlace > div.r-body > div.r-content > div.r-content-overflow');
        var segInterestContent = $('#segInterest > div.r-body > div.r-content > div.r-content-overflow');

        if (!segPlaceContent.children('span').length)
            segPlaceBtnLabel = _('btnAdd');

        if (!segInterestContent.children('span').length)
            segInterestBtnLabel = _('btnAdd');

        $('#segPlace > div.r-footer.aRig > button').text(segPlaceBtnLabel);
        $('#segInterest > div.r-footer.aRig > button').text(segInterestBtnLabel);

        //caso tenhamos atingidos mais de 5000 pessoas prosseguiremos
        if (window.g.reachEstimate > 5000) {
            rClass = rArr[1];
        } else if (window.g.reachEstimate != 0) {
            //console.log(window.g.reachEstimate);
            bootbox.dialog({
                className: 'blue',
                locale: window.g.languageMin,
                message: _('segmentationExpectMore'),
                closeButton: false,
                buttons: {
                    'return': {
                        label: _('ok'),
                        callback: function() {}
                    }
                }
            });
        }
    } else if (currentStep === 4) {
        if (window.g.stpSimulated) {
            rClass = rArr[1];
        }
    } else if (currentStep === 5) {
        var text = $('#stp05 input#campaignName');
        if (text.length > 0) {
            if (text.val()) {
                rClass = rArr[1];
            }
        }
    } else if (currentStep === 6) {
        rClass = rArr[1] + ' publish';
    }

    $('button#fPrev', '#fWrapper').attr('class', lClass);
    $('button#fNext', '#fWrapper').attr('class', rClass).text(currentStep === 6 ? _('btnPublish') : _('btnContinue'));
};

////////////
// MODAIS //
////////////

/**
 * Prepara o comportamento do modal ##modalChooseCreative
 * @param  {object} opt : Objeto com parametros de inicialização
 */
function modalChooseCreativePrepare(opt) {
    try {
        var ppArr = window.g.ppArr || [];
        if (!$.isArray(ppArr)) throw 'invalid array data';
        if (ppArr.length < 1) throw 'invalid array data';

        var append = '';
        var liKlon = $('#modalChooseCreative li:first').clone();
        var currentId = $('div#stp02 div.mainBox').attr('id') ? $('div#stp02 div.mainBox').attr('id') : 0;

        for (i = 0, l = ppArr.length; i < l; i++) {
            if (currentId == ppArr[i].id) continue;
            var li = liKlon;
            var post = '';

            if (inObject('message', ppArr[i])) {
                post += ppArr[i].message
            } else {
                if (inObject('story', ppArr[i])) {
                    post += ppArr[i].story;
                }
            }

            if (inObject('full_picture', ppArr[i])) {
                if (ppArr[i].full_picture.indexOf('_s.') > -1) ppArr[i].full_picture = ppArr[i].full_picture.replace('_s.', '_n.');
                post += '<img src="' + ppArr[i].full_picture + '" border="0">';
                post += (ppArr[i].type == 'video' ? '<span class="videoPlay"></span>' : '');
            } else {
                if (inObject('picture', ppArr[i])) {
                    if (ppArr[i].picture.indexOf('_s.') > -1) ppArr[i].picture = ppArr[i].picture.replace('_s.', '_n.');
                    post += '<img src="' + ppArr[i].picture + '" border="0">';
                    post += (ppArr[i].type == 'video' ? '<span class="videoPlay"></span>' : '');
                }
            }

            $('.fbCreative', li).attr('id', ppArr[i].id);
            $('p', li).html(post);
            append += '<li>' + $(li).html() + '</li>';
        }

        $('#modalChooseCreative > .modal-body > ul').html(append);

        var c = $('div#modalChooseCreative .fbCreative');
        var f = $('div#modalChooseCreative .modal-footer button');
        f.removeClass('btn-green').addClass('btn-modal-disabled');

        if (c.length > 0) {
            c.removeClass('selected');
            c.unbind('click');
            c.bind('click', function() {
                c.removeClass('selected');
                $(this).addClass('selected');
                var selId = $(this).attr('id');

                if (f.length > 0) {
                    if (inArray('btn-modal-disabled', f.attr('class').split(' '))) {
                        f.removeClass('btn-modal-disabled').addClass('btn-green');

                        f.unbind('click');
                        f.bind('click', function() {
                            $("#modalChooseCreative").modal("hide");
                            var selObj = $.grep(ppArr, function(e) {
                                return e.id == selId;
                            });
                            fbFeedBestPromotablePost(selObj[0]);
                        });
                    }
                }
            });
        }

        $('#modalChooseCreative').modal(opt); //exibe o modal
    } catch (e) {
        bootbox.dialog({
            className: 'yellow',
            locale: window.g.languageMin,
            message: _('youDontHaveOtherPromotablesPosts'),
            closeButton: false,
            buttons: {
                'ok': {
                    label: _('ok'),
                },
            }
        });
    }
};

/**
 * Prepara o comportamento do modal ##modalCreateCreative
 * @param  {object} opt : Objeto com parametros de inicialização
 */
function modalCreateCreativePrepare(opt) {
    try {
        var idModal = 'div#modalCreateCreative';
        var objTxtArea = $('#txtText', idModal);
        var elSample = '<span class="targetSquareSample140"></span>';
        var defautP = '-------------------------------------------';
        var hasMedia = $('.fbCreative article > p', idModal).attr('hasMedia');
        // var inputAddMedia = $('input#addMedia', idModal);
        var inputAddMedia = $('form#postForm input#file');
        var btnGo = $('button#btnGo_modalCreateCreative', idModal);

        // definindo botão de input estilizado
        maskFileInput(idModal);

        // definindo tooltip
        $('button#addMediaBtn', idModal).tooltip({
            placement: 'top'
        });

        if (objTxtArea.length > 0 && $('.fbCreative article > p', idModal).length > 0) {
            objTxtArea.val(''); //limpa o conteúdo disposto no html
            $('.fbCreative article > p', idModal).html('<span class="text">' + defautP + '<br>' + defautP + '</span>');
            $('.fbCreative article > p', idModal).append('<span class="imgHandle">' + elSample + '</span>').attr('hasMedia', 0);

            //desabilita o botão de prosseguir
            btnGo.attr('class', 'btn-modal-disabled');

            // Função de replicação do conteúdo digitado no objTxtArea para o preview
            objTxtArea.unbind('keyup');
            objTxtArea.bind('keyup', function() {

                //desabilita / habilita o botão de prosseguir
                if ($(this).val()) {
                    if ($('.imgHandle > div.thumbInvalid', idModal).length < 1)
                        btnGo.attr('class', 'btn-green');
                } else {
                    btnGo.attr('class', 'btn-modal-disabled');
                }

                //clonando o texto digitado no textarea para a div .fbCreative
                $(idModal + ' .fbCreative article > p > .text').html($(this).val());
            });

            // Função de adicionar mídia no preview
            inputAddMedia.unbind('change');
            inputAddMedia.bind('change', function() {
                $('.fbCreative article > p', idModal).html('<span class="text">' + objTxtArea.val() + '</span>');

                //criar o objeto que vai renderizar a imagem no preview
                var reader = new window.FileReader();
                reader.onload = function(e) {
                    var result = e.target.result;
                    if (result) {
                        var splt = result.split(';')[0];
                        splt = splt.replace('data:', '');

                        try {

                            //caso seja imagem
                            if (splt.indexOf('image') > -1) {
                                $('.fbCreative article > p', idModal).append('<span class="imgHandle"><img src="' + result + '"><i class="tb-icon-21x-close"></i></span>').attr('hasMedia', 1);
                                $('form#postForm input#type').val('photo');
                                btnGo.attr('class', 'btn-green');
                                throw 1; // throw de sucesso
                            } else {
                                if (!isAllowedVideo(inputAddMedia)) throw 0;

                                // $('.fbCreative article > p', idModal).append('<span class="imgHandle"><div class="thumbVideo"><span></span></div><i class="tb-icon-21x-close"></i></span>').attr('hasMedia', 1);
                                $('.fbCreative article > p', idModal).append('<span class="imgHandle"><img src="' + window.g.uriThumbVideo + '"><i class="tb-icon-21x-close"></i></span>').attr('hasMedia', 1);

                                $('form#postForm input#type').val('video');

                                btnGo.attr('class', 'btn-green');

                                window.g.creative.imgUrl = null;
                                window.g.creative.imgHash = null;
                                window.g.creative.imgWidth = null;
                                window.g.creative.imgHeight = null;

                                throw 1; // throw de sucesso
                            }

                            throw 0; // throw de arquivo inválido

                        } catch (e) {
                            if (e === 0) {

                                // reseta o valor do input
                                var postFile = $(':file', 'form#postForm');
                                postFile.replaceWith(postFile = postFile.clone(true));

                                // $('.fbCreative article > p', idModal).append('<span class="imgHandle"><div class="thumbInvalid"><span>' + _('invalidFile') + '</span></div><i class="tb-icon-21x-close"></i></span>').attr('hasMedia', 1);
                                $('.fbCreative article > p', idModal).append('<span class="imgHandle"><img src="' + window.g.uriThumbInvalid + '"><i class="tb-icon-21x-close"></i></span>').attr('hasMedia', 1);
                                btnGo.attr('class', 'btn-modal-disabled');
                                $('form#postForm input#type').val('status');
                            }
                        }
                    }

                    //função de comportamento da imagem
                    modalHandleWithPreviewImage(idModal);
                };

                // chama a função de renderizar
                reader.readAsDataURL($(this).get(0).files[0]);
            });
        }

        //Função de GoOut do modal
        btnGo.unbind('click');
        btnGo.bind('click', function() {
            var st = $(this).attr('class').split(' ');
            if (inArray('btn-modal-disabled', st)) return false;

            // checagem de type
            if ($('span.imgHandle > span.targetSquareSample140', idModal).length > 0)
                $('form#postForm input#type').val('status');

            //alimentar o melhor promotable post
            fbFeedBestPromotablePost({
                "message": objTxtArea.val(),
                "picture": ($('form#postForm input#type').val() == 'video' ? window.g.uriThumbVideo : ($('span.imgHandle > img', idModal)[0] ? $('span.imgHandle > img', idModal)[0].src : '')),
                "timeline_visibility": '',
                "full_picture": ($('form#postForm input#type').val() == 'video' ? window.g.uriThumbVideo : ($('span.imgHandle > img', idModal)[0] ? $('span.imgHandle > img', idModal)[0].src : '')),
                "link": '',
                "created_time": '',
                "is_published": '',
                "type": $('form#postForm input#type').val() || 'status',
                "id": '',
                "insightsStatus": '',
                "insightsTotal": '',
                "insightsMedia": ''
            });

            btnGo.unbind('click'); // unblind o click do botão
            $(idModal).modal('hide'); // esconde o modal
        });

        //exibe o modal
        $(idModal).modal(opt);
    } catch (e) {
        console.log('modalCreateCreative : ', e);
    }
};

/**
 * Prepara o comportamento do modal ##modalCreateCreativeSimilar
 * @param  {object} opt : Objeto com parametros de inicialização
 */
function modalCreateCreativeSimilarPrepare(opt) {;
    try {
        var idModal = 'div#modalCreateCreativeSimilar';
        var objTxtArea = $('#txtText', idModal);
        var elSample = '<span class="targetSquareSample140"></span>';
        var backP = $('.mainBox .pag-info');
        var inputAddMedia2 = $('form#postForm input#file');
        var img = $('img', backP);
        var hasMedia = $('.fbCreative article > p', idModal).attr('hasMedia');
        var btnGo = $('button#btnGo_modalCreateCreativeSimilar', idModal);

        maskFileInput(idModal);
        $('button#addMediaBtn', idModal).tooltip({
            placement: 'top'
        });

        if (objTxtArea.length > 0 && $('.fbCreative article > p', idModal).length > 0) {

            $('.fbCreative article > p', idModal).html('');
            objTxtArea.val(backP.text()); //insere o conteudo que está disposto no .mainBox
            $('.fbCreative article > p', idModal).append('<span class="text">' + backP.text() + '</span>');

            //caso tenhamos imagem no post, exibiremos o "close" para excluir a imagem
            if (img.length) {
                var videoPlay = $('form#postForm input#type').val() == 'video' ? '<span class="videoPlay"><span>' : '';

                //append inicial com a imagem default
                $('.fbCreative article > p', idModal).append('<span class="imgHandle">' + $(img)[0].outerHTML + '<i class="tb-icon-21x-close"></i></span>' + videoPlay).attr('hasMedia', 1);

                //função de comportamento da imagem
                modalHandleWithPreviewImage(idModal);
            }

            // Função de replicação do conteúdo digitado no objTxtArea para o preview
            objTxtArea.unbind('keyup');
            objTxtArea.bind('keyup', function() {
                if ($(this).val()) {
                    if ($('.imgHandle > div.thumbInvalid', idModal).length < 1)
                        btnGo.attr('class', 'btn-green');
                } else {
                    btnGo.attr('class', 'btn-modal-disabled');
                }

                if ($('.fbCreative article > p .text', idModal).length > 0) {
                    $('.fbCreative article > p .text', idModal).html($(this).val());
                }
            });

            // Função de adicionar mídia no preview
            inputAddMedia2.unbind('change').bind('change', function() {
                $('.fbCreative article > p', idModal).html('<span class="text">' + objTxtArea.val() + '</span>');

                var reader2 = new window.FileReader();
                reader2.onload = function(e) {
                    var result = e.target.result;
                    if (result) {
                        var splt = result.split(';')[0];
                        splt = splt.replace('data:', '');

                        try {
                            //caso seja imagem
                            if (splt.indexOf('image') > -1) {
                                $('.fbCreative article > p', idModal).append('<span class="imgHandle"><img src="' + result + '"><i class="tb-icon-21x-close"></i></span>').attr('hasMedia', 1);

                                $('form#postForm input#type').val('photo');

                                btnGo.attr('class', 'btn-green');

                                throw 1; //throw de sucesso
                            } else {
                                if (!isAllowedVideo(inputAddMedia)) throw 0;

                                // $('.fbCreative article > p', idModal).append('<span class="imgHandle"><div class="thumbVideo"><span></span></div><i class="tb-icon-21x-close"></i></span>').attr('hasMedia', 1);
                                $('.fbCreative article > p', idModal).append('<span class="imgHandle"><img src="' + window.g.uriThumbVideo + '"><i class="tb-icon-21x-close"></i></span>').attr('hasMedia', 1);

                                $('form#postForm input#type').val('video');

                                btnGo.attr('class', 'btn-green');

                                window.g.creative.imgUrl = null;
                                window.g.creative.imgHash = null;
                                window.g.creative.imgWidth = null;
                                window.g.creative.imgHeight = null;

                                throw 1; //throw de sucesso
                            }

                            throw 0; //throw de arquivo inválido

                        } catch (e) {
                            if (e === 0) {
                                // reseta o valor do input
                                var postFile = $(':file', 'form#postForm');
                                postFile.replaceWith(postFile = postFile.clone(true));

                                // $('.fbCreative article > p', idModal).append('<span class="imgHandle"><div class="thumbInvalid"><span>' + _('invalidFile') + '</span></div><i class="tb-icon-21x-close"></i></span>').attr('hasMedia', 1);
                                $('.fbCreative article > p', idModal).append('<span class="imgHandle"><img src="' + window.g.uriThumbInvalid + '"><i class="tb-icon-21x-close"></i></span>').attr('hasMedia', 1);
                                btnGo.attr('class', 'btn-modal-disabled');
                                $('form#postForm input#type').val('status');
                            }
                        }
                    }

                    //função de comportamento da imagem
                    modalHandleWithPreviewImage(idModal);
                };

                // chama a função de renderizar
                reader2.readAsDataURL($(this).get(0).files[0]);
            });
        }

        //Função de GoOut do modal
        btnGo.unbind('click');
        btnGo.bind('click', function() {
            var st = $(this).attr('class').split(' ');
            if (inArray('btn-modal-disabled', st)) return false;

            btnGo.unbind('click'); // unblind o click do botão
            $(idModal).modal('hide'); // esconde o modal

            //alimentar o melhor promotable post
            fbFeedBestPromotablePost({
                "message": objTxtArea.val(),
                "picture": ($('form#postForm input#type').val() == 'video' ? window.g.uriThumbVideo : ($('span.imgHandle > img', idModal)[0] ? $('span.imgHandle > img', idModal)[0].src : '')),
                "timeline_visibility": '',
                "full_picture": ($('form#postForm input#type').val() == 'video' ? window.g.uriThumbVideo : ($('span.imgHandle > img', idModal)[0] ? $('span.imgHandle > img', idModal)[0].src : '')),
                "link": '',
                "created_time": '',
                "is_published": '',
                "type": $('form#postForm input#type').val() || 'status',
                "id": '',
                "insightsStatus": '',
                "insightsTotal": '',
                "insightsMedia": ''
            });
        });

        // registra função antes de exibir o modal
        $(idModal).on('shown', function() {
            modalHandleWithPreviewImage(idModal);
        });

        //exibe o modal
        $(idModal).modal(opt);
        //$('#frmModalCreateCreativeSimilar span.imgHandle > img').height();
    } catch (e) {
        console.log('modalCreateCreativeSimilarPrepare : ', e);
    }
};

/**
 * Função que lida com a manipulação de imagens dentro do preview
 * @param {string} container: contexto onde o preview esta inserido
 */
function modalHandleWithPreviewImage(container) {
    try {
        if (!container || (typeof container != 'string')) return false;
        if ($(container).length < 1) return false;

        var img = $('.fbCreative .imgHandle > img', container);
        var div = $('.fbCreative .imgHandle > div', container);
        var videoPlay = $('.videoPlay ', container);
        var el = (img.length > 0 ? img : (div.length > 0 ? div : null));
        var elSample = '<span class="targetSquareSample140"></span>';
        var icoClose = $('.fbCreative .imgHandle .tb-icon-21x-close', container);

        if (el && el.length > 0) {
            // Função que excluir a imagem do preview
            icoClose.unbind("click").bind("click", function() {

                //esconde o botão de exluir mídia
                $(this).hide();

                //remove o videoPlay
                videoPlay.remove();

                // posiciona o square de exemplo
                el.parent().html(elSample);

                // reseta o valor do input
                var postFile = $(':file', 'form#postForm');
                postFile.replaceWith(postFile = postFile.clone(true));

                //define o valor padrão para o type
                $('form#postForm input#type').val('status');
            });

            setTimeout(function() { // delay 800
                var w = (el.width() || 0);
                var h = (el.height() || 0);

                if (w > 0 && h > 0) {
                    icoClose.css({
                        'top': ((parseFloat(h) - 5) * -1) + 'px',
                        'left': (parseFloat(w) - 25) + 'px',
                        'visibility': 'visible',
                        'position': 'relative',
                        'cursor': 'pointer',
                    });
                } else { //quando o elemento estiver completamente carregado
                    el.load(function() {
                        var w = ($(this).width() || 0);
                        var h = ($(this).height() || 0);
                        icoClose.css({
                            'top': ((parseFloat(h) - 5) * -1) + 'px',
                            'left': (parseFloat(w) - 25) + 'px',
                            'visibility': 'visible',
                            'position': 'relative',
                            'cursor': 'pointer',
                        });
                    });
                }
            }, 800);
        }

    } catch (e) {
        console.log('modalHandleWithPreviewImage():' + container, e);
    }
};

/////////////////////////
// FACEBOOK OPERATIONS //
/////////////////////////

/**
 * Callback que lida com a respota da chamada posts promovíveis (PROMOTABLE POSTS)
 * @param  {object} data: objeto retornado pelo facebook
 */
function fbHandlePromotablePosts(data) {
    if ((data instanceof Object) && !$.isEmptyObject(data)) {
        //erro encontrado
        if (inObject('error', data)) {
            if (data.error.message) {
                bootbox.dialog({
                    className: 'red',
                    locale: window.g.languageMin,
                    message: data.error.message,
                    closeButton: false,
                    buttons: {
                        'return': {
                            label: _('btnBack'),
                            callback: function() {
                                window.history.back();
                            }
                        },
                        'retry': {
                            label: _('btnRetry'),
                            callback: function() {
                                window.location.reload();
                            }
                        },
                    }
                });
                return false;
            }
        }

        if (inObject('paging', data)) { //objeto contendo os links de paginação
            if (inObject('next', data.paging)) {
                window.g.ppNextUrl = data.paging.next; //guardando a url da proxima busca de promotables posts
            }
        }

        if (inObject('data', data)) {
            var changedData = null;

            if (data.data instanceof Array) {
                if (data.data.length < 1) { //caso não ache nenhum post promovível
                    fullLoaderStop(); //remove o fullLoader
                    bootbox.dialog({
                        className: 'blue',
                        locale: window.g.languageMin,
                        message: _('noPromotablePostFoundMessage'),
                        closeButton: false,
                        buttons: {
                            'return': {
                                label: _('btnBack'),
                                callback: function() {
                                    window.history.back();
                                }
                            },
                            'create': {
                                label: _('createPromotablePost'),
                                callback: function() {
                                    showModal('#modalCreateCreative', {
                                        backdrop: 'static',
                                        keyboard: false,
                                        closeButton: false,
                                    });
                                }
                            },
                        }
                    });
                }

                changedData = [];

                for (i = 0, j = data.data.length; i < j; i++) {
                    var itObj = data.data[i];
                    itObj.insightsStatus = 0;
                    itObj.insightsTotal = null;
                    itObj.insightsMedia = null;
                    changedData.push(itObj);
                }

                itObj = null;
            } else {
                var changedData = data.data;
                changedData.insightsStatus = 0;
            }

            window.g.ppArr = changedData; // guardando o objeto retornado da consulta
            changedData = null;

            //iniciando o processo de loop
            fbGetInsightsFromControlList();
        }
    }
};

/**
 * Função que realiza busca dos insights dos posts relacionados no objeto de controle
 * @return {[type]} [description]
 */
function fbGetInsightsFromControlList() {
    var inn = window.g.ppArr || [];

    if (Array.isArray(inn)) {
        if (inn.length < 1) { // erro
            bootbox.dialog({
                className: 'red',
                locale: window.g.languageMin,
                message: _('unableToRetrieveInsights'),
                closeButton: false,
                buttons: {
                    'return': {
                        label: _('btnBack'),
                        callback: function() {
                            window.history.back();
                        }
                    },
                    'retry': {
                        label: _('btnRetry'),
                        callback: function() {
                            window.location.reload();
                        }
                    },
                }
            });
            return false;
        }

        // menos que 10 itens para o insights, aborta e busca e realiza novas buscas
        // if (inn.length < 10) {
        //     var fb = CreateClass.FbPage();
        //     fb.getPromotablePosts(window.g.token, window.g.pageId, window.g.locale, window.g.ppFields, 10, 'fbHandlePromotablePosts', window.g.ppNextUrl);
        //     return false;
        // }

        // Fluxo normal
        var id = null;
        for (i = 0, l = inn.length; i < l; i++) {
            if (inObject('id', inn[i]) && inObject('insightsStatus', inn[i])) {
                if (inn[i].insightsStatus === 0 && inn[i].id) {
                    window.g.ppArr[i].insightsStatus = 1; // alteração de status identificador 0 -> 1
                    id = inn[i].id;
                    break;
                }
            }
        }

        if (id != null) {
            //faça nova busca
            CreateClass.FbPage().getPostInsights(window.g.token, id, 'fbHandlePostInsights');
        } else {
            // não há mais buscas a serem feitas,
            // portanto verifique qual dos promotables posts é melhor
            // e preencha a tela do usuário
            var thebest = fbAnalizeBestPromotablePosts(window.g.ppArr);
            fbFeedBestPromotablePost(thebest);
        }
    }
};

/**
 * Callback que lida com o retorno dos insights de cada post
 * @param  {object} data: retorno do facebook
 */
function fbHandlePostInsights(data) {
    if ((data instanceof Object) && !$.isEmptyObject(data)) {
        //erro encontrado
        if (inObject('error', data)) {
            bootbox.dialog({
                className: 'red',
                locale: window.g.languageMin,
                message: data.error.message,
                closeButton: false,
                buttons: {
                    'return': {
                        label: _('btnBack'),
                        callback: function() {
                            window.history.back();
                        }
                    },
                    'retry': {
                        label: _('btnRetry'),
                        callback: function() {
                            window.location.reload();
                        }
                    },
                }
            });
            return false;
        }

        // capturando as url para chamadas futuras
        if (inObject('paging', data)) {
            var previous = data.paging.previous;
            var next = data.paging.next;
        }

        //analizando os valores dentro de data.data
        if (inObject('data', data)) {
            if (!$.isArray(data.data)) alert('o objeto data.data não é um array favor fazer outra chamada');
            var arrList = [];

            for (i = 0, l = data.data.length; i < l; i++) {

                var loopObj = data.data[i];
                var appendObj = {};
                appendObj.total = 0;

                if (inObject('id', loopObj)) {
                    appendObj.id = loopObj.id.split('/')[0];
                    //appendObj.fullId = loopObj.id; ex.: "119847624717227_613051928730125/insights/post_impressions_by_paid_non_paid/lifetime"
                }

                if (inObject('values', loopObj)) { //checando a existencia da propriedade values
                    if ($.isArray(loopObj.values)) { //checando se values é um array
                        if (loopObj.values.length > 0) { //checando se values não é nulo
                            for (ii = 0, ll = loopObj.values.length; ii < ll; ii++) { //varrendo o values que não é nulo
                                vObj = loopObj.values[ii]; //setando objeto contido no array dentro da variável ex: values[0]*
                                if (vObj instanceof Object && !$.isEmptyObject(vObj)) { //verifinaco se a variável é um objeto válido
                                    if ($.isArray(vObj[v])) {
                                        //tratamento quando for array
                                    } else {
                                        //é apenas um objeto mesmo
                                        for (var v in vObj) {
                                            //console.log(i, ii, v, vObj[v]);
                                            if (vObj[v] instanceof Object) {
                                                var subObj = vObj[v];
                                                for (var z in subObj) {
                                                    appendObj.total += (!isNaN(subObj[z]) && subObj[z] ? parseFloat(subObj[z]) : 0);
                                                }
                                                subObj = null;
                                            } else {
                                                appendObj.total += (!isNaN(vObj[v]) && vObj[v] ? parseFloat(vObj[v]) : 0);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // só alimenta a alimentando a lista quando houver um valor calculável
                if (appendObj.total > 0) {
                    arrList.push(appendObj);
                }
            }
        }

        if (arrList.length > 0) {
            // ordenando decrescentemente
            var sortedList = arrList.sort(function(a, b) {
                return b.total - a.total;
            });
            // pega o registro top
            var top = sortedList[0];
            var arr = window.g.ppArr;

            //varre o array controlador
            if ($.isArray(arr)) {
                for (i = 0, l = arr.length; i < l; i++) {
                    if (inObject('id', arr[i]) && inObject('insightsTotal', arr[i])) {
                        if (arr[i].id === top.id) {
                            window.g.ppArr[i].insightsTotal = top.total;
                        }
                    }
                }
            }

            arrList = top = arr = null;
        }

        // dando sequência no loop
        fbGetInsightsFromControlList();
    }
};

/**
 * Função que analizará um array de objetos ([promotable posts] + [total de insights]) e cauculará o melhor
 * promotable posts, se baaaseando no total de insights por quantidade de horoas de vida do post [total de insights] / [now - created_time]
 *
 * @param  {array} arrObj: array de objetos [promotable posts]
 * @return {array} : melhor array encontrado de acordo com a regra
 */
function fbAnalizeBestPromotablePosts(arrObj) {
    try {
        if (!$.isArray(arrObj)) throw 'is not an array';
        if (arrObj.length < 1) throw 'empty array';

        // varre calculando a média
        for (i = 0, l = arrObj.length; i < l; i++) {

            if (!inObject('insightsTotal', arrObj[i]) || !inObject('created_time', arrObj[i])) throw 'impossible to calculate';
            if (!inObject('insightsMedia', arrObj[i])) throw 'impossible to calculate';
            if (isNaN(arrObj[i].insightsTotal)) throw 'impossible to calculate';

            var utcCreateTime = moment.utc(arrObj[i].created_time);
            var utcNow = moment.utc();
            var diffHours = utcNow.diff(utcCreateTime, 'hours');
            diffHours = (diffHours < 1 ? 1 : diffHours);

            arrObj[i].insightsMedia = arrObj[i].insightsTotal / diffHours;
        }

        // ordena de acordo coma média de forma decrescente
        var bestObj = arrObj.sort(function(a, b) {
            return b.insightsMedia - a.insightsMedia;
        });

        //console.log('media ordenada : ',bestObj);
        return bestObj[0];
    } catch (e) {
        console.log('fbAnalizeBestPromotablePosts : ', e);
        bootbox.dialog({
            className: 'red',
            locale: window.g.languageMin,
            message: e,
            closeButton: false,
            buttons: {
                'return': {
                    label: _('btnBack'),
                    callback: function() {
                        window.history.back();
                    }
                },
                'retry': {
                    label: _('btnRetry'),
                    callback: function() {
                        window.location.reload();
                    }
                },
            }
        });
    }
};

/**
 * Função para aplicar no html as informações do melhor promotable posts
 * @param  {object} data: objeto promotable post
 */
function fbFeedBestPromotablePost(data) {
    try {
        fullLoaderStop(); //remove o fullLoader

        if (!data instanceof Object || $.isEmptyObject(data)) throw 'no data';

        if (inObject('id', data)) window.g.publish.postId = data.id;

        var post = '';
        if (inObject('message', data)) {
            post += data.message
        } else {
            if (inObject('story', data)) {
                post += data.story;
            }
        }

        //alimentando form de postagem para criação de post
        $('form#postForm input#type').val(data.type || 'status');
        $('form#postForm input#message').val(post);

        if (inObject('full_picture', data)) {
            if (data.full_picture) {
                if (data.full_picture.indexOf('_s.') > -1)
                    data.full_picture = data.full_picture.replace('_s.', '_n.');

                post += '<span class="cb"></span>';
                post += '<img src="' + data.full_picture + '" border="0">';

                if (data.full_picture.indexOf('thumbVideo') < 1)
                    post += (data.type == 'video' ? '<span class="videoPlay"></span>' : '');
            }
        } else {
            if (inObject('picture', data)) {
                if (data.picture) {
                    if (data.picture.indexOf('_s.') > -1)
                        data.picture = data.picture.replace('_s.', '_n.');

                    post += '<span class="cb"></span>';
                    post += '<img src="' + data.picture + '" border="0">';

                    if (data.picture.indexOf('thumbVideo') < 1)
                        post += (data.type == 'video' ? '<span class="videoPlay"></span>' : '');
                }
            }
        }

        $('div#stp02 div.mainBox').attr('id', data.id);
        $('div#stp02 div.mainBox article p').html(post);

        $('#stp06 div.fbCreative > article > p').html(post);
        $('div.model div.modelBody > article > p').html(post);

    } catch (e) {
        console.log('fbFeedBestPromotablePost:', e);
    }
};

////////////////////////////
// PUBLICANDO NO FACEBOOK //
////////////////////////////

/**
 * Função que inicia o processo de publicação do objetivo 01 exibindo um confirm
 */
function publish_Objective01Start() {
    bootbox.dialog({
        className: 'blue',
        locale: window.g.languageMin,
        title: _('labConfirmation'),
        message: _('proceedWithCreationGoal01'),
        closeButton: false,
        buttons: {
            'no': {
                label: _('labNo'),
                callback: function() {},
            },
            'yes': {
                label: _('labYes'),
                callback: function() {
                    // TODO check if it's a "creational" ad
                    if (!window.g.hasPublishActionsPermissions) {
                        $('#modalPublish').hide();
                        setTimeout(function() {
                            showModal('#modalPublishActions', {
                                backdrop: 'static',
                                keyboard: false
                            });
                        }, 500);
                        return;
                    }

                    publish_Objective01Go();
                },
            },
        }
    });
};

/**
 * Método que inicia o processo de criação de publicação logo após a confirmação do método "publish_Objective01Start"
 */
function publish_Objective01Go() {
    //desabilitando o botão de publicar campanha
    $('button#fNext').attr('class', 'btn-goal-disabled');

    // verificando já temos um post ou precisamos criar um
    if (window.g.publish.postId && typeof window.g.publish.postId == 'string') {
        publish_createCampaignGroup();
    } else {
        publish_setStatus('1.0');
        // recuperando o token da página
        CreateClass.FbPage().getPagePermissions(window.g.token, null, 'publish_fbHandlePagePermissions');
    }

    setTimeout(function() {
        showModal('#modalPublish', {
            backdrop: 'static',
            keyboard: false,
            closeButton: false
        });
    }, 400);
};

/**
 * Callback que recebe as informações de permissão da Página/Local (Connection Object), ou seja o token de página.
 * Com o token recebido, inicia o processo de criação de post.
 *
 * @param  {object} data: retorno do facebook (supostamente com o access_token da página)
 */
function publish_fbHandlePagePermissions(data) {
    console.log('publish_fbHandlePagePermissions');
    try {
        var pageToken = '';
        var currPageId = tryParse(window.g.pageId, 'string', null);
        var type = $('form#postForm input#type').val() || 'status';
        var message = $('form#postForm input#message').val();

        if (!message || typeof message != 'string') throw 'invalid message';
        if (!currPageId) throw 'invalid currPageId';
        if (!inObject('data', data)) throw 'invalid data.data';
        if (['status', 'photo', 'video'].indexOf(type) > -1) 'invalid type';

        // identificando e varrendo a resposta do facebook e recuperando o token da página
        if ($.isArray(data.data)) {
            for (i = 0, l = data.data.length; i < l; i++) {
                if (data.data[i].hasOwnProperty('id') && data.data[i].hasOwnProperty('access_token')) {
                    if (data.data[i].id == currPageId.toString()) {
                        pageToken = data.data[i].access_token;
                    }
                }
            }
        } else {
            if (data.data.hasOwnProperty('id') && data.data.hasOwnProperty('access_token')) {
                if (data.data.id == currPageId.toString()) {
                    pageToken = data.data.access_token;
                }
            }
        }

        // caso não tenhamos o token da página o processo é abortado
        if (!pageToken)
            throw 'invalid pageToken';

        if (type == 'status') {
            // criando um post de status, processo independente do backend
            var objPost = {
                message: message
            };
            CreateClass.FbPage().createStatusPost(objPost, pageToken, currPageId, 'publish_fbHandleCreatePost');
        } else {
            $('form#postForm input#token').val(pageToken);
            $('form#postForm input#pageId').val(currPageId);
            $('form#postForm input#message').val(message);
            $('form#postForm input#callback').val('window.parent.publish_fbHandleCreatePost');

            if (type == 'photo') {
                // PHP Upload
                $('form#postForm').attr('action', window.g.postFormPhoto).submit();
            } else if (type == 'video') {
                // PHP Upload
                $('form#postForm').attr('action', window.g.postFormVideo).submit();

                // IFrame JS Upload
                /*
                // mudar o nome de alguns campos para postar na graph
                $('form#postForm input#message').attr({
                    id: 'description',
                    name: 'description'
                });

                $('form#postForm input#file').attr({
                    id: 'source',
                    name: 'source'
                });

                var uri = window.g.postFormVideo;
                uri = uri.replace('{0}', currPageId);
                uri = uri.replace('{1}', window.g.token);
                $('form#postForm').attr('action', uri).submit();
                iframe = $('#ifrmPostForm').load(function ()
                {
                    //PROTOCOLS MUST MATCH
                    //CROS ORIGIN POLICY ERROR
                });

                // DESmudar o nome de alguns campos para postar na graph

                setTimeout(function() {
                    $('form#postForm input#description').attr({
                        id: 'message',
                        name: 'message'
                    });

                    $('form#postForm input#source').attr({
                        id: 'file',
                        name: 'file'
                    });
                }, 3000);
                */
            }
        }
    } catch (e) {
        console.log('publish_fbHandlePagePermissions', e);
        publish_setStatus('-1.1', e);
    }
};

/**
 * Callback que lida com a resposta do método createStatusPost()
 * @param  {object} fbData: objeto de retorno do facebook
 */
function publish_fbHandleCreatePost(fbData) {
    try {
        //extract data
        if (fbData.hasOwnPropertfbData('data')) {
            if ($.isArrafbData(fbData.data))
                fbData = fbData.data[0];
            else fbData = fbData.data;
        }

        //publich_action permission error
        if (fbData.hasOwnPropertfbData('success') && !fbData.success)
            throw fbData.message;

        //checando id recebido
        var pId = null;

        if (fbData.hasOwnPropertfbData('id')) {
            if (!fbData.id)
                throw 'invalid post id';

            pId = fbData.id;
        }

        if (fbData.hasOwnPropertfbData('postId')) {
            if (!fbData.postId)
                throw 'invalid post id';

            pId = fbData.postId;
        }

        if (!pId) throw 'invalid post id';

        // window.g.publish.postId = window.g.pageId+'_'+pId;
        window.g.publish.postId = pId;

        publish_setStatus('1.1'); //escrever status
        publish_createCampaignGroup();
    } catch (e) {
        console.log('publish_fbHandleCreatePost:', e);
        publish_setStatus('-1.2', e);
    }
};

/**
 * Método de criação do Anúncio (AdGroup)
 */
function publish_createMainAd() {
    // console.log('publish_createMainAd');
    try {
        window.g.variationAd = [];

        //verificando se já possuo o anúncio principal criado no objeto global
        if (window.g.publish.primaryAdId && !isNaN(window.g.publish.primaryAdId)) {
            // chamando a função que lida com a criação de anúncio principal simulando a criação via facebook
            publish_fbHandleCreateMainAd({
                id: window.g.publish.primaryAdId
            });
        } else {
            // Creative
            var postId = window.g.publish.postId;
            var object_story_id = postId;
            var creative = TB.AdCreative.make.page_post_ad(object_story_id);

            // AdGroup
            var campaign_id = window.g.publish.campaignId;
            var name = _('mainAdName').replace('%d', campaign_id);
            var adGroupData =  {
                campaign_id: campaign_id,
                name: name,
                creative: creative,
            };
            var adGroup = new api.AdGroup(adGroupData, adAccount.id);
            adGroup.create().then(publish_fbHandleCreateMainAd);
            // console.log('adGroup.create');
            mixpanel.track("Publish Campaign", {
                'Goal': window.g.currentGoal
            });

            window.g.publish.name = name;
        }
    } catch (e) {
        mixpanel.track("Publish Campaign Error", {
            'Error': e
        });
        console.log('publish_createMainAd():', e);
        publish_setStatus('-1.4', e);
    }
};