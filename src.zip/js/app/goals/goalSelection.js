var paymentURL = 'https://secure.facebook.com/ads/manage/funding.php?act=';

$(document).ready(function() {
    $('.tip').tooltip();
    $('#goalSelection .choice a').click(function(e) {
        var numberOfAccounts = 0;
        var options = '';
        var accountId;
        for (var i in g.adaccounts) {
            numberOfAccounts++;
            accountId = i;
            options += '<option value="' + g.adaccounts[i].account_id + '">' + g.adaccounts[i].prettyName + '</option>';
        }

        var goal = $(this).attr('goal');

        if(numberOfAccounts==1) {
            window.location.href = getGoalUrl(goal, accountId);
        } else {

           var selectPicker = $('#selectAccountId').html(options).selectpicker({
                style: 'tb-dropdown',
                width: 'auto',
                size: 7,
                dropupAuto: false,
                showSubtext: true,
            }).change(function(event) {
                setChooseAccount(goal, $(this).val(), g.adaccounts[$(this).val()].hasPaymentMethod);
            });
            setChooseAccount(goal, selectPicker.val(), g.adaccounts[selectPicker.val()].hasPaymentMethod);
            $('#modalChooseAccount').modal('show');
        }
    })
});

/**
 * Sets up Welcome modal and checks for Ad Accounts
 */
function setUpNewUser() {
    $('#modalWelcome').modal('show');
    if (!g.adaccounts) {
        $(this).on('hide',function() {
            setUpNoAccount();
        });
    }
}
/**
 * Checks if the user has and Ad Account and Payment Method
 * @param  string refresh Signals if the page was refreshed
 */
function checkAdAccounts(refresh) {
    if(refresh) {
        $('#modalAccounts1 .warning').removeClass('hide');
        $('#modalAccounts2 .warning').removeClass('hide');
        $('#modalAccounts1 .steps').removeClass('hide');
    }
    var hasPayment = false;

    if (!g.adaccounts) {
        setUpNoAccount();
    } else {
        var firstAccount = false;
        for (var i in g.adaccounts) {
            if(!firstAccount) firstAccount = i;
            if(g.adaccounts[i].hasPaymentMethod) hasPayment = true;
        };
        if(!hasPayment)
            setUpNoPayment(firstAccount);
    }

    if(refresh=='adaccount' && hasPayment) {
        mixpanel.track("Ad Account Creation Action",{'Type':'Back from Facebook', 'With Ad Account?': !!g.adaccounts, 'With Payment Method?': hasPayment});
    }

    if(refresh=='payment')
        mixpanel.track("Payment Method Creation Action",{'Type':'Back from Facebook', 'With Payment Method?': hasPayment});
}

/**
 * Sets up Ad Account creation modal
 */
function setUpNoAccount() {
    $('#btnAdAccountAccessFacebook').click(function() {
        mixpanel.track("Ad Account Creation Action",{'Type':'Leave for Facebook'});
        $(this).addClass('hide');
        $('#btnAdAccountContinue').removeClass(('hide')).click(function() {
           mixpanel.track("Ad Account Creation Action",{'Type':'Clicked Continue'});
        });
    });
    mixpanel.track("Ad Account Creation Action",{'Type':'Modal Open'});
    $('#modalAccounts1').modal({
            backdrop: 'static',
            keyboard: false,
            closeButton: false,
    });
}

/**
 * Sets up Payment Method creation modal
 */
function setUpNoPayment(accountId) {
    $('#btnPaymentAccessFacebook').attr('href', paymentURL + accountId).click(function() {
        mixpanel.track("Payment Method Creation Action",{'Type':'Leave for Facebook'});
        $(this).addClass('hide');
        $('#btnPaymentContinue').removeClass(('hide')).click(function() {
           mixpanel.track("Payment Method Creation Action",{'Type':'Clicked Continue'});
        });
    })

    mixpanel.track("Payment Method Creation Action",{'Type':'Modal Open'});
    $('#modalAccounts2').modal({
            backdrop: 'static',
            keyboard: false,
            closeButton: false,
    });
}

/**
 * Generate URL for chosen Goal and Ad Account id
 * @param  {int} goal      1 for Post Engagement, 2 for Fans, 3 for Conversions
 * @param  {int} accountId Chosen ad Account
 */
function getGoalUrl(goal, accountId) {
    if (goal == 1)
        return '/goals/post/' + accountId;
    if (goal == 2)
        return '/goals/fan/' + accountId;
    if (goal == 3)
        return '/goals/conv/' + accountId;
}

/**
 * Prepare Choose Account modal
 * @param  {int} goal      1 for Post Engagement, 2 for Fans, 3 for Conversions
 * @param  {int} accountId Chosen ad Account
 */
function setChooseAccount (goal, accountId, hasPaymentMethod) {
    $('#btnContinueModalChooseAccount').unbind('click').attr('href', getGoalUrl(goal, accountId));
    if(hasPaymentMethod) {
        $('#btnContinueModalChooseAccount').removeClass('hide');
        $('#modalChooseAccount .warning').addClass('hide');
    } else {
        $('#btnContinueModalChooseAccount').addClass('hide');
        $('#modalChooseAccount .warning').removeClass('hide');
        $('#modalChooseAccount .warning a').attr('href', paymentURL + accountId).attr('target', '_blank').click(function(){
            $('#modalChooseAccount .warning').addClass('hide');
            $('#btnContinueModalChooseAccount').removeClass('hide').click(function(e) {
                e.preventDefault();
                if($(this).attr('disabled')) return;
                var spinnerOpts = {
                    zIndex: 1,
                    lines: 8,
                    length: 2,
                    width: 2,
                    radius: 3,
                    color: '#fff'
                };
                $(this).css({'color': 'transparent'}).attr('disabled','disabled');
                spinner = $(this).spin(spinnerOpts);
                updateAdAccounts(goal, accountId);
            });
        });
    }
}

/**
 * Update Ad Accounts on the Server and check for Payment method
 * @param  {int} goal      1 for Post Engagement, 2 for Fans, 3 for Conversions
 * @param  {int} accountId Chosen ad Account
 */
function updateAdAccounts(goal, accountId) {
    $.ajax({
        type: 'GET',
        url: '/updateadaccounts',
        success: function(response) {
            $('#btnContinueModalChooseAccount').removeAttr('disabled').css({'color': ''}).data('spinner').stop();
            if(response.data.adaccounts[accountId].hasPaymentMethod) {
                window.location.href = getGoalUrl(goal, accountId);
            } else {
                setChooseAccount(goal, accountId, false);
            }
        },
        error: function() {
            console.log('error updateAdAccounts');
        }
    });
}
