$(document).ready(function() {
    try {
        window.g.currentGoal = 3;
        gaGoalView(window.g.currentGoal, 1);
        mixpanel.track("Start Goal", {
            'Goal': window.g.currentGoal
        });

        // aplicando templates do handlebars
        CreateClass.MyHandlebars(pageData, "beginAge").simpleRender();
        CreateClass.MyHandlebars(pageData, "endAge").simpleRender();

        if (inObject('targeting', pageData)) {

            // idade
            var hAge = pageData.targeting;

            hAge.ageTerms = {
                conjunctive: _('labTo'),
                indefinite: _('labIndefinite'),
                misgid: 'year'
            };

            CreateClass.MyHandlebars(hAge, "madeRange").simpleRender();

            // exibir avatar de gender
            var hSex = (pageData.targeting.gender || 2);
            var genderShow = {};
            var gender = {};

            switch (hSex) {
                case 0:
                    gender.male = _('men');
                    break;
                case 1:
                    gender.female = _('women');
                    break;
                case 2:
                    gender.male = _('men');
                    gender.female = _('women');
                    break;
            }

            CreateClass.MyHandlebars(gender, "genderShowClass").simpleRender();

            // exibir gender por escrito
            genderShow.gender = gender;
            genderShow.genderTerms = {
                conjunctive: _('labAnd')
            };

            CreateClass.MyHandlebars(genderShow, "genderShow").simpleRender();
        }

        startFullCarousel(); //iniciar o comportamento do fullCarousel

        $('.fullCarousel').on('jcarousel:scroll', function(event, carousel) {
            $('#goalContent > div.fullCarousel > ul').animate({
                height: 1000
            }, 200);
        });
        $('.fullCarousel').on('jcarousel:scrollend', function(event, carousel) {
            $('html,body').animate({
                scrollTop: 0
            }, 300);
        });

        stepperTrigger(window.g.stepper); // gerencia o stepper no footer

        //definição do caruosel para não agir sozinho
        $('.carouselPostVariation').carousel({
            interval: false,
            wrap: true
        }).on('slide.bs.carousel', function() {}).on('slid.bs.carousel', function() {});

        /* definição de parametros regionais da ferramenta + aplicação de máscara*/
        CreateClass.Regional().setMaskForAll('mask', null);

        // checagem no facebook para saber se o usuário ja aceitou os termos do Pixel de Conversão
        adAccount.read(['offsite_pixels_tos_accepted']).then(fbHandlePixelTermsQuery);

        // esconder o modal que possibilita a criação de uma nova página
        $('div.selectFanPage > div:nth-child(1)').css({
            'visibility': 'hidden'
        });

        // Word Size Sentinel
        wordSizeSentinel();
    } catch (e) {
        console.log('goal3.php.js : ' + e);
    }
});

/////////////////////////////////////
// FUNÇÕES DE INTERFACE DE USUÁRIO //
/////////////////////////////////////

/**
 * Inicia o comportamento do FullCarousel do objetivo 03 da ferramenta
 */
function startFullCarousel() {
    $('.fullCarousel').jcarousel({
        animation: {
            vertical: true,
            duration: 300,
            easing: 'linear',
            complete: function() {
                // altera o stepper da página no objeto controlador e chama seus métodos de controle
                if ($('div.fullCarousel > ul').length > 0) {
                    $('#goalContent > div.fullCarousel > ul > li').css('height', 'auto'); //reseta as alturas de todas as li's do fullCarousel
                    var left = parseFloat($('div.fullCarousel > ul').css('left'));
                    left = Math.abs(left);
                    window.g.stepper = (left / window.g.stepperW) + 1;
                    gaGoalView(window.g.currentGoal, window.g.stepper);
                    mixpanel.track("Goal Step", {
                        'Goal': window.g.currentGoal,
                        'Step': window.g.stepper
                    });
                    stepperTrigger(window.g.stepper); // gatilho do stepper
                }
            }
        }
    });
    $('#fPrev').click(function() { //ação do voltar do fullCarousel
        var cls = $('#fPrev').attr('class').split(' ');
        if (inArray('btn-goal-disabled', cls)) return false;
        if (window.g.stepper == 1) window.location = "/goals";
        window.g.oldStepper = window.g.stepper;
        $('.fullCarousel').jcarousel('scroll', '-=1');
    });
    $('#fNext').click(function() { //ação de next do fullCarousel
        var cls = $('#fNext').attr('class').split(' ');
        if (inArray('btn-goal-disabled', cls)) return false;
        if (!beginStepperTrigger(window.g.stepper)) return false;
        if (inArray('publish', cls)) {
            publish_Objective03Start();
        } else {
            window.g.oldStepper = window.g.stepper;
            $('.fullCarousel').jcarousel('scroll', '+=1');
        }
    });
    $('.stepper8-indicators a').bind('click', function(event) { //click direto no indicador do fullCarousel
        var navId = $(this).attr('id');
        if (!navId || typeof navId != 'string') return false;
        navId = parseFloat(navId.replace('nav-', ''));

        if ((navId + 1) >= window.g.stepper) return false;
        $('.fullCarousel').jcarousel('scroll', navId);

        window.g.oldStepper = window.g.stepper;
        window.g.stepper = navId + 1;
        stepperTrigger(window.g.stepper); // gatilho do stepper
    });
};

/**
 * Método executado antes de cada mudança de passo
 * @param  {integer} oldStep: passo anterior do objetivo corrente
 */
function beginStepperTrigger(oldStep) {
    try {
        if (isNaN(oldStep) || !oldStep) throw 'invalid param';

        // do passo 1 para ?
        if (oldStep === 1) {

            var text = $('#stp01 input#urlWebSite');
            if (text.length > 0) {
                if (!ValidUrl($.trim(text.val()))) {
                    text.addClass('inputError');
                    return false;
                }
            }

            // exibe o loader na DOM
            fullLoader(null, null, 'fullLoaderBg', 0);
        }

        if (oldStep === 3)
            adAccount.getConversionPixels().then(fbHandleConversionPixels);

        return true;
    } catch (e) {
        console.log('beginStepperTrigger :' + e);
        return false;
    }
};

/**
 * Método executado a cada mudança de passo
 * @param  {integer} step: passo anterior do objetivo corrente
 */
function stepperTrigger(step) {
    stepperVerify(window.g.stepper); // gerencia os botões de paginação do stepper
    changeFooterStepper(window.g.stepper); // gerencia o stepper no footer

    if (isNaN(step) || !step) return;

    //aplicando tamanho dinâmico as li do fullCarousel
    liFullCarouselAutoH(step, 10);

    switch (step) {
        case 1: // endereço do domínio
            $('div#mainQuestion').html(_('hMainQuestion31'));

            var text = $('#stp01 input#urlWebSite');
            text.keyup(function(event) {
                if (event.which == 9)
                    event.preventDefault();

                stepperVerify(window.g.stepper);
            });

            break;
        case 2:
            $('div#mainQuestion').html(_('hMainQuestion01'));

            if (window.g.lastUrl != $('#stp01 input#urlWebSite').val()) {
                // consulta de paginas relacionadas
                api.graph.search($('#stp01 input#urlWebSite').val(), 'adobjectbyurl').then(fbHandleSearchAdObjectByUrl);

                // consultando meta tags
                getUrlMetaTags($('#stp01 input#urlWebSite').val());
            } else {
                fullLoaderStop(); //esconde o fullLoader

                if ($('#carouselChooseYourPage > div.carousel-inner.pageList li').length < 1) {
                    if (window.g.oldStepper == 3)
                        $('#fPrev').click();
                    else
                        $('#fNext').click();
                }
            }

            break;
        case 3: // criação de criativo
            $('div#mainQuestion').html(_('hMainQuestion12'));
            bindCreateYourAd();
            break;
        case 4: // visualização do criativo
            $('div#mainQuestion').html(_('hMainQuestion13'));
            break;
        case 5: // definindo targeting
            $('div#mainQuestion').html(_('hMainQuestion03'));

            if (!window.g.stpGuideChecked) {

                if (!tbCookie.has("stpGuideChecked"))
                    tbCookie.set("stpGuideChecked", 1);

                window.g.stpGuideChecked = true;
                startGuideTabStp03();
            }

            // exibir os valores pré definidos, para localização caso existam
            startPlaceDefiner();
            finderCacheSyncHTML('placeDefiner');

            // exibir os valores pré definidos, para interesses caso existam
            startInterestDefiner();
            finderCacheSyncHTML('interestDefiner');

            // chamada reach estimate
            if (!window.g.stpFirstReachSearch) {
                window.g.stpFirstReachSearch = true;
                var targeting_spec = getTargetingSpecFromSegmentation();
                var reachData = {
                    targeting_spec: targeting_spec,
                    currency: window.g.currency
                }
                adAccount.getReachEstimate(reachData).then(fbHandleReachEstimate);
            }

            break;
        case 6: // definindo bidding
            $('div#mainQuestion').html(_('hMainQuestion04'));

            //Seleção de forma de pagamento da campanha
            var selectValue = $('div#stp06 div#byValue div.r-body.sel');
            var selectPeriod = $('div#stp06 div#byPeriod div.r-body.sel');
            var formValue = $('div#stp06 div#byValue div.r-body.form');
            var formPeriod = $('div#stp06 div#byPeriod div.r-body.form');
            $('div#stp06 div#byValue').unbind('click').bind('click', function() {
                if (selectValue.is(':visible')) {
                    selectValue.hide();
                    formValue.show();
                }
                selectPeriod.show();
                formPeriod.hide();
            });
            $('div#stp06 div#byPeriod').unbind('click').bind('click', function() {
                if (selectPeriod.is(':visible')) {
                    selectPeriod.hide();
                    formPeriod.show();
                }
                selectValue.show();
                formValue.hide();
            });

            if (!$('span.reachEstimateSpan', 'div#stp06').text())
                $('span.reachEstimateSpan', 'div#stp06').text($.number(window.g.reachEstimate, 0, '', window.g.thousandSymbol));

            // instanciando elementos datetimepicker que serão usados no passo 4
            if (!window.g.stpDateTimePickerSet) {
                window.g.stpDateTimePickerSet = true;

                // instanciando e aplicando 30 dias de default para duração da campanha por período
                $('#top_beginDate, #top_endDate').datetimepicker({
                    format: window.g.componetSetup.datetimepicker.format,
                    language: window.g.componetSetup.datetimepicker.language,
                    orientation: 'left',
                    startDate: moment({
                        hour: 0
                    }).toDate(),
                });
                var begin = $('#top_beginDate').data('datetimepicker');
                var end = $('#top_endDate').data('datetimepicker');
                begin.setLocalDate(moment().toDate());
                end.setLocalDate(moment().add('days', 2).toDate());

                // instanciando datepickers para campanhas vitalícias
                $('#sub_beginDate, #sub_endDate').datetimepicker({
                    format: window.g.componetSetup.datetimepicker.format,
                    language: window.g.componetSetup.datetimepicker.language,
                    orientation: 'bottom-left',
                    startDate: moment({
                        hour: 0
                    }).toDate(),
                });
                $('#sub_beginDate').on('changeDate', function(e) {
                    var nDay = simulatebyValueChangeDate();
                    $('div#stp06 div.simulate.byValue > div.simuBody div.calendar span.aux').text(_n('day', nDay));
                    $('div#stp06 div.simulate.byValue > div.simuBody div.calendar span.value').text(nDay);

                    // verificando o budget mínimo a cada mudança de data no bidding por valor
                    verifyTheMinimumBudget(nDay);
                });
                $('#sub_endDate').on('changeDate', function(e) {
                    var nDay = simulatebyValueChangeDate();
                    $('div#stp06 div.simulate.byValue > div.simuBody div.calendar span.aux').text(_n('day', nDay));
                    $('div#stp06 div.simulate.byValue > div.simuBody div.calendar span.value').text(nDay);

                    // verificando o budget mínimo a cada mudança de data no bidding por valor
                    verifyTheMinimumBudget(nDay);
                });
            }
            break;
        case 7: // escrevendo o nome da campanha
            $('div#mainQuestion').html(_('hMainQuestion05'));
            var text = $('#stp07 input#campaignName');
            text.unbind('change').bind('change', function() {
                stepperVerify(window.g.stepper);
            }).bind('keydown', function(e) {
                stepperVerify(window.g.stepper);
                if (e.which == 9) {
                    e.preventDefault();
                }
            });
            break;
        case 8: // preview
            $('div#mainQuestion').html(_('hMainQuestion06'));

            // gênero
            $('#stp08 #reviewGenderStr').text($('#segSex > div.r-body > div.r-content > span').text());
            // idade
            $('#stp08 #reviewAgeStr').text($('#segAge > div.r-body > div.r-content > span').text());
            // localidades
            var adGeoLocation = window.g.targetingSpecs.getFlatGeoLocations();
            if (adGeoLocation instanceof Object && !$.isEmptyObject(adGeoLocation)) {
                if ($.isArray(adGeoLocation)) {
                    if (adGeoLocation.length) {
                        var str = '';
                        for (i = 0, l = adGeoLocation.length; i < l; i++) {
                            str += adGeoLocation[i].name + (adGeoLocation[i].hasOwnProperty('region') ? ', ' + adGeoLocation[i].region : '') + ', ';
                        }
                        $('#stp08 #reviewLocatedStr').text(str.substring(0, str.length - 2));
                    }
                } else {
                    $('#stp08 #reviewLocatedStr').text(adGeoLocation.name)
                }
            }

            // interesses
            var adKeyWord = window.g.targetingSpecs.getInterests();
            if (adKeyWord instanceof Object && !$.isEmptyObject(adKeyWord)) {
                if ($.isArray(adKeyWord)) {
                    if (adKeyWord.length) {
                        var str = '';
                        for (i = 0, l = adKeyWord.length; i < l; i++) {
                            str += adKeyWord[i].name + ', ';
                        }
                        $('#stp08 #reviewInterestedStr').text(str.substring(0, str.length - 2));
                    }
                } else {
                    $('#stp08 #reviewInterestedStr').text(adKeyWord.name)
                }
            }
            // nome da campanha
            $('#stp08 #reviewCampaignName').text($('#stp07 input#campaignName').val());

            //recuperando valores de acordo com a escolha do orçamento
            if (window.g.createCampaignBy == 'byValue') {
                var begin = $('input#sub_beginDateI').val();
                var end = $('input#sub_endDateI').val();
                var investiment = $('div#byValue #budget').val();
            } else {
                var begin = $('input#top_beginDateI').val();
                var end = $('input#top_endDateI').val();
                var investiment = $('div.simulate.byPeriod > div.simuBody div.currentBudget > font:nth-child(2)').text();
            }

            // recuperando datas iniciais
            // Formatando e exibindo datas iniciais e finais
            if (begin && begin.length == 19) {
                begin = moment(begin, window.g.dateTime24).format(window.g.dateTimeShortDotted);
                begin = begin.replace('%0', _('labAt'));
                $('#stp08 #reviewBeginDate').text(begin);
            }
            if (end && end.length == 19) {
                end = moment(end, window.g.dateTime24).format(window.g.dateTimeShortDotted);
                end = end.replace('%0', _('labAt'));
                $('#stp08 #reviewEndDate').text(end);
            }

            //formatando e exibindo valor do investimento
            $('#stp08 #reviewInvestment').text(tryParse(investiment, 'justNumber', investiment)).currency({
                region: window.g.currency,
                thousands: window.g.thousandSymbol,
                decimal: window.g.decimalSymbol,
                decimals: window.g.decimalCount,
                hidePrefix: false,
                hidePostfix: true,
            });

            // exibindo as informações de FanPage Vinculada
            if (window.g.pageId || window.g.pixel.pixelId) {

                if (window.g.pageId)
                    $('#stp08 div.linkedPageContent').show();
                if (window.g.pixel.pixelId) {
                    $('#stp08 #reviewPixelName').text(window.g.pixel.pixelName);
                    // $('#stp08 #reviewPixelType').text($('#pixelType option[value="' + window.g.pixel.pixelPrettyTag + '"]').text() || window.g.pixel.pixelPrettyTag);
                    $('#stp08 #reviewPixelType').text(window.g.pixel.pixelPrettyTag);
                    $('#stp08 div.infoPixelContent').show();
                }

                window.setTimeout(function() {
                    $('#goalContent > div.fullCarousel > ul > li').css('height', 'auto');
                    liFullCarouselAutoH(step, 10);
                }, 500);
            }

            break;
        default:
            break;
    }
};

/**
 * Função para alterar os status do paginador do stepper, validando alguns parâmetros quando necessário
 * @param  {integer} currentStep: Passo atual do objetivo corrente
 */
function stepperVerify(currentStep) {
    if (isNaN(currentStep) || !currentStep) return false;

    var lArr = ['btn-goal-disabled', 'btn-goal-normal'];
    var rArr = ['btn-goal-disabled', 'btn-green'];

    var lClass = lArr[0];
    var rClass = rArr[0];

    if (currentStep > 1) lClass = lArr[1];

    if (currentStep === 1) { // endereço do domínio
        lClass = lArr[1];
        var text = $('#stp01 input#urlWebSite');
        if (text.length > 0)
            if (ValidUrl($.trim(text.val())))
                rClass = rArr[1];
    } else if (currentStep === 2) { // seleçao de páginas sem obrigatóriadade de escolha
        rClass = rArr[1];
    } else if (currentStep === 3) { // criação de criativo
        var titAd = $('input#titAd', 'div#stp03');
        var txtText = $('textarea#txtText', 'div#stp03');
        var cMedia = $('div.pageLikeAdMedia.pag-thumb', 'div#stp03');
        var hasMedia = cMedia.attr('hasmedia') || 0;
        if (titAd.val() && txtText.val() && hasMedia) {
            rClass = rArr[1];
        }
    } else if (currentStep === 4) { // visualização do criativo
        rClass = rArr[1]
    } else if (currentStep === 5) { // definindo targeting
        var segPlaceBtnLabel = _('btnChange');
        var segInterestBtnLabel = _('btnChange');

        var segPlaceContent = $('#segPlace > div.r-body > div.r-content > div.r-content-overflow');
        var segInterestContent = $('#segInterest > div.r-body > div.r-content > div.r-content-overflow');

        if (!segPlaceContent.children('span').length)
            segPlaceBtnLabel = _('btnAdd');

        if (!segInterestContent.children('span').length)
            segInterestBtnLabel = _('btnAdd');

        $('#segPlace > div.r-footer.aRig > button').text(segPlaceBtnLabel);
        $('#segInterest > div.r-footer.aRig > button').text(segInterestBtnLabel);

        //caso tenhamos atingidos mais de 5000 pessoas prosseguiremos
        if (window.g.reachEstimate > 5000) {
            rClass = rArr[1];
        } else if (window.g.reachEstimate != 0) {
            bootbox.dialog({
                className: 'blue',
                locale: window.g.languageMin,
                message: _('segmentationExpectMore'),
                closeButton: false,
                buttons: {
                    'return': {
                        label: _('ok'),
                        callback: function() {}
                    }
                }
            });
        }
    } else if (currentStep === 6) { // definindo bidding
        if (window.g.stpSimulated) {
            rClass = rArr[1];
        }
    } else if (currentStep === 7) { // escrevendo o nome da campanha 
        var text = $('#stp07 input#campaignName');
        if (text.length > 0) {
            if (text.val()) {
                rClass = rArr[1];
            }
        }
    } else if (currentStep === 8) { // preview
        rClass = rArr[1] + ' publish';
    }

    $('button#fPrev', '#fWrapper').attr('class', lClass);
    $('button#fNext', '#fWrapper').attr('class', rClass).text(currentStep === 8 ? _('btnPublish') : _('btnContinue'));
};

/**
 * Método que realiza os eventos visuais de manipulação do indicador de passo no footer da página
 * @param  {integer} step: passo atual do objetivo X/N
 */
function changeFooterStepper(step) {
    var maxStep = $('li', '.stepper8-indicators').length;
    if (isNaN(step) || isNaN(maxStep)) return false;
    if (step > maxStep) return false;

    var stepPercent = 100 / (maxStep - 1);

    $('.stepper8 .stepperFIll').animate({
        'width': (stepPercent * (step - 1)) + '%'
    }, 300, function() {
        $('.stepper8-indicators > ul > li').removeClass('done');
        $('.stepper8-indicators-labels > div').removeClass('done');
        for (i = 1; i <= step; i++) {
            $('.stepper8-indicators > ul > li:nth-child(' + i + ')').addClass('done');
            $('.stepper8-indicators-labels > div:nth-child(' + i + ')').addClass('done');
        }
    });
};

/**
 * Função que organiza o comportamento do passo 3.3
 */
function bindCreateYourAd() {
    // console.log('bindCreateYourAd');
    try {
        var container = 'div#stp03';
        var titAd = $('input#titAd', container);
        var txtText = $('textarea#txtText', container);
        var adMedia = $('div.pageLikeAdMedia', container);
        var inputAddMedia = $('form#postForm input#file');

        maskFileInput(container); // definindo botão de input estilizado

        // definindo tooltip
        $('button#addMediaBtn', container).tooltip({
            placement: 'top'
        });

        $('h6.pageLikeAdTitle', container).html($('input#urlWebSite', 'div#stp01').val());
        $('h6.pageLikeAdTitle', '#stp04').html($('input#urlWebSite', 'div#stp01').val());

        // Função de replicação do conteúdo digitado no titAd para o preview
        titAd.unbind('keyup').bind('keyup', function() {
            var t = $(this).val();
            $('h5.fanPageTitle', container).html(t);
            $('h5.fanPageTitle', '#stp04').html(t); // alimentando o html do próximo passo
            $('.pag-name', '#stp04').text(t); // alimentando o html do próximo passo
            $('h5.fanPageTitle', '.stpPublish').html(t); // alimentando o html do passo de publicação
            $('.pag-name', '#stp08').text(t); // alimentando o html do passo de publicação

            stepperVerify(window.g.stepper); // gerencia os botões de paginação do stepper
        });

        // Função de replicação do conteúdo digitado no txtText para o preview
        txtText.unbind('keyup').bind('keyup', function() {
            $('div.pageLikeAdMessage', container).html($(this).val());
            $('div.pageLikeAdMessage', '#stp04').html($(this).val()); // alimentando o html do próximo passo
            $('div.pageLikeAdMessage', '.stpPublish').html($(this).val()); // alimentando o html do passo de publicação
            stepperVerify(window.g.stepper); // gerencia os botões de paginação do stepper
        });

        // Função de adicionar mídia no preview
        inputAddMedia.unbind('change').bind('change', function() {
            //criar o objeto que vai renderizar a imagem no preview
            var reader = new window.FileReader();
            reader.onload = function(e) {
                var result = e.target.result;
                if (result) {
                    var splt = result.split(';')[0];
                    splt = splt.replace('data:', '');

                    try {
                        //caso seja imagem
                        if (splt.indexOf('image') > -1) {
                            $(adMedia).html('<img src="' + result + '">').attr('hasMedia', 1);
                            $('.pag-thumb', '#stp04').html('<img src="' + result + '">'); // alimentando o html do próximo passo
                            $('.pag-thumb', '.stpPublish').html('<img src="' + result + '">'); // alimentando o html do passo de publicação

                            $('form#postForm input#type').val('photo');
                            throw 1; // throw de sucesso
                        }

                        //caso seja video
                        if (splt.indexOf('video') > -1) {
                            splt = splt.split('/')[1];

                            if (window.g.arrVid.indexOf(splt) < 0) throw 0;

                            $(adMedia).html('<div class="thumbVideoSmall"></div>').attr('hasMedia', 1);
                            $('.pag-thumb', '#stp04').html('<div class="thumbVideoSmall"></div>'); // alimentando o html do próximo passo
                            $('.pag-thumb', '.stpPublish').html('<div class="thumbVideoSmall"></div>'); // alimentando o html do passo de publicação

                            $('form#postForm input#type').val('video');
                            throw 1; // throw de sucesso
                        }

                        throw 0; // throw de arquivo inválido
                    } catch (e) {
                        if (e === 0) {
                            // reseta o valor do input
                            var postFile = $(':file', 'form#postForm');
                            postFile.replaceWith(postFile = postFile.clone(true));

                            $(adMedia).html('<div class="thumbInvalid"><span>' + _('invalidFile') + '</span></div>').attr('hasMedia', 1);
                            $('form#postForm input#type').val('status');
                        }
                    }
                }
                stepperVerify(window.g.stepper); // gerencia os botões de paginação do stepper

                // inclusão das dimensões da imagem no objeto de controle
                var objImg = new Image();
                var objSrc = $('#stp03 div.pageLikeAdMedia > img').attr('src');
                objImg.onload = function() {
                    window.g.creative.imgWidth = this.width || 0;
                    window.g.creative.imgHeight = this.height || 0;
                }
                if (objSrc)
                    objImg.src = objSrc;
            };

            // chama a função de renderizar
            reader.readAsDataURL($(this).get(0).files[0]);
        });
    } catch (e) {
        console.log('bindCreateYourAd() : ', e);
    }
};

/**
 * Callback resposável por interpretar a url digitada pelo usuário, e buscar (Connection Objects) relacionados
 * @param {object} data: objeto de retorno do facebook
 */
function fbHandleSearchAdObjectByUrl(data) {
    try {
        if ((data instanceof Object) && !$.isEmptyObject(data)) {
            //erro encontrado
            if (inObject('error', data)) {
                bootbox.dialog({
                    className: 'red',
                    locale: window.g.languageMin,
                    message: data.error.message,
                    closeButton: false,
                    buttons: {
                        'return': {
                            label: _('btnBack'),
                            callback: function() {
                                window.history.back();
                            }
                        },
                        'retry': {
                            label: _('btnRetry'),
                            callback: function() {
                                window.location.reload();
                            }
                        },
                    }
                });
                throw 'error found';
            };

            if (!inObject('data', data)) throw 'invalid data';
            if (!$.isArray(data.data)) throw 'invalid array data';
            if (data.data.length < 1) throw 'invalid array data';

            // captura os id para um array simples
            window.g.arrRelatedPageId = [];
            for (i = 0, len = data.data.length; i < len; i++) {
                if (data.data[i].hasOwnProperty('id')) {
                    // alimenta o array global que contém os ids das páginas relacionadas a url digitada
                    window.g.arrRelatedPageId.push(data.data[i].id);
                }
            }

            // ultima url processada pelo objetivo 03
            window.g.lastUrl = $('#stp01 input#urlWebSite').val();

            // chamando os conection objects do accountid, filtrando e exibindo somente as pages
            adAccount.getConnectionObjects().then(fbReady);
        } else {
            throw 'invalid data';
        }
    } catch (e) {
        console.log('fbHandleSearchAdObjectByUrl() :', e);
    }
};

/**
 * Callback que lida com a resposta da chamada de listagem de pixel da conta de ads caso se comporte como o esperado ela armazena no objeto global a lista de pixel existente
 * @param {object} data: objeto de retorno do facebook
 */
function fbHandleConversionPixels(data) {
    try {
        // caso o retorno do facebook não seja um objeto válido
        if (!(data instanceof Object) || $.isEmptyObject(data)) throw 'pixel not received';

        // erro encontrado
        if (inObject('error', data))
            if (inObject('message', data.error))
                throw data.error.message;

            // console.log(data.data);

        if (window['g'] == undefined)
            var g = {};

        // atribuição de lista de pixel no objeto global
        window.g.pixelList = data;
    } catch (e) {
        console.log('fbHandleConversionPixels() :', e);
    } finally {
        showModal('#modalPixelAsk', {
            backdrop: 'static',
            keyboard: false,
            closeButton: false,
        });
    }
};

////////////
// MODAIS //
////////////

/**
 * Prepara o comportamento do modal ##modalLinkFanPage
 * @param  {object} opt : Objeto com parametros de inicialização
 */
function modalLinkFanPagePrepare(opt) {
    try {
        var idModal = 'div#modalLinkFanPage';
        var yesBtn = $('div.modal-footer > button.btn-modal-solildWhite', idModal);
        var noBtn = $('div.modal-footer > button.btn-cancel', idModal);

        yesBtn.unbind('click').bind('click', function() {
            $(idModal).modal('hide');
        });

        noBtn.unbind('click').bind('click', function() {
            $('#fNext').click(); //pressiona o botão de próximo passo
            $(idModal).modal('hide');
        });

        //exibe o modal
        $(idModal).modal(opt);
    } catch (e) {
        console.log('modalLinkFanPagePrepare() : ', e);
    }
};

/**
 * Prepara o comportamento do modal ##modalPixelAsk
 * @param  {object} opt : Objeto com parametros de inicialização
 */
function modalPixelAskPrepare(opt) {
    try {
        var idModal = 'div#modalPixelAsk';
        var btnNo = $('div.modal-footer > button#btnNo', idModal);
        var btnYes = $('div.modal-footer > button#btnYes', idModal);

        var aCreate = $('div.modal-footer > a#aCreate', idModal);
        var btnCancel = $('div.modal-footer > button#btnCancel', idModal);
        var btnContinue = $('div.modal-footer > button#btnContinue', idModal);

        $('div.modal-body > p strong', idModal).tooltip({
            placement: 'top'
        });

        try {
            // caso tenhamos pixel existentes exibimos caso contrário
            if (!window.g.pixelList instanceof Object || $.isEmptyObject(window.g.pixelList)) throw 'invalid pixelList';

            if ($.isArray(window.g.pixelList)) {

                if (window.g.pixelList.length < 1) throw 'invalid array of pixels';

                for (i = 0, len = window.g.pixelList.length; i < len; i++) {

                    var x = window.g.pixelList[i];
                    var newTag = '';

                    if (!inObject('id', x)) throw 'pixel object has no id parameter';
                    if (!inObject('name', x)) throw 'pixel object has no name parameter';
                    if (!inObject('tag', x)) throw 'pixel object has no tag parameter';

                    newTag = translatePixelTag(x.tag); // recuperando o nome amigável da tag do pixel

                    $('select#pixelList').append('<option value="' + x.id + '">' + x.name + ' / ' + newTag + '</option>');
                }
            } else {
                // caso seja um objeto
            }

            $('.veteran', idModal).show();
            $('.noob', idModal).hide();
        } catch (ee) {
            console.log('sub try : ', ee);

            $('.noob', idModal).show();
            $('.veteran', idModal).hide();
        }

        // instanciando o selectpicker
        $('.selectpicker', idModal).selectpicker({ //selects customizados
            style: 'tb-dropdown',
            width: 'auto',
            size: 7,
            dropupAuto: false,
            showSubtext: true,
        });

        // optou por não adicionar um pixel de conversão
        btnNo.unbind('click').bind('click', function() {
            $(idModal).modal('hide');
        });
        btnCancel.unbind('click').bind('click', function() {
            $(idModal).modal('hide');
        });
        btnContinue.unbind('click').bind('click', function() {
            $(idModal).modal('hide');

            if (!$('select#pixelList').val()) return;
            if (!$('select#trackMode').val()) return;
            if (!window.g.pixelList instanceof Object || $.isEmptyObject(window.g.pixelList)) return;

            // efetua uma consulta no array de pixel
            var rs = $.grep(window.g.pixelList, function(e) {
                return e.id == $('select#pixelList').val();
            });

            if (!rs instanceof Object || $.isEmptyObject(rs)) return;

            if ($.isArray(rs)) {
                if (rs.length < 1) return;
                rs = rs[0];
            }

            window.g.pixel.pixelId = $('select#pixelList').val();
            window.g.pixel.pixelName = rs.name;
            window.g.pixel.pixelPrettyTag = translatePixelTag(rs.tag); // recuperando o nome amigável da tag do pixel
            window.g.pixel.pixelTag = rs.tag;
            window.g.pixel.pixelTrack = $('select#trackMode').val();

            //setando valor ao reviewTextScript e selecionando todo o conteudo no focus event
            $('textarea#reviewTextScript').val(rs.js_pixel).focus(function() {
                var $this = $(this);
                $this.select();

                // Work around Chrome's little problem
                $this.mouseup(function() {
                    // Prevent further mouseup intervention
                    $this.unbind("mouseup");
                    return false;
                });
            });
        });

        // optou por adicionar um pixel de conversão
        btnYes.unbind('click').bind('click', function() {
            $(idModal).modal('hide');
            bindPixelWizard();
        });

        aCreate.unbind('click').bind('click', function() {
            $(idModal).modal('hide');
            bindPixelWizard();
        });

        //exibe o modal
        $(idModal).modal(opt);
    } catch (e) {
        console.log('modalLinkFanPagePrepare() : ', e);
    }
};

////////////////////
// WIZARD (PIXEL) //
////////////////////

/**
 * Wizard de criação e escoha de pixel de conversão
 */
function bindPixelWizard() {
    var wizardContent = 'div#fbPixel-wizard';
    var radio = $('div#tbRadioSmll01 > .radio', wizardContent);
    var check = $('div#tbRadioSmll02 > .radio', wizardContent);

    // instanciando o selectpicker
    $('.selectpicker', wizardContent).selectpicker({ //selects customizados
        style: 'tb-dropdown',
        width: 'auto',
        size: 7,
        dropupAuto: false,
        showSubtext: true,
    });

    // Função de comportamento dos "radios buttons" do wizard
    if (radio.length > 0) {
        $(radio[0]).addClass('selected');
        radio.unbind('click').bind('click', function() {
            radio.removeClass('selected');
            $(this).addClass('selected');

            //escondendo e exibindo o formulário de email do píxel
            if ($(this).attr('id') == 'radio1') {
                $('div.wizard-card-container > div:nth-child(2) > div > div.senderEmail').show();

                $('div.wizard input#emailSender').unbind('change').bind('change', function() {
                    $(this).removeClass('error-popover');
                    $(this).next('.popover').remove();
                });

                $('div.wizard input#emailReceiver').unbind('change').bind('change', function() {
                    $(this).removeClass('error-popover');
                    $(this).next('.popover').remove();
                });

            } else {
                $('div.wizard-card-container > div:nth-child(2) > div > div.senderEmail').hide();
            }
        });
    }
    if (check.length > 0) {
        check.unbind('click').bind('click', function() {
            $(this).toggleClass('selected');
            $('div#tbRadioSmll02').next('.popover').remove();
        });
    }

    // WIZARD https://github.com/amoffat/bootstrap-application-wizard
    $.fn.wizard.logging = false; // escrever console.log
    var wizard = $(wizardContent).wizard({
        keyboard: false, // Closes the modal when escape key is pressed.
        backdrop: 'static', // Includes a modal-backdrop element. Alternatively, specify `static` for a backdrop which doesn't close the modal on click.
        show: false, // Shows the modal when initialized.
        submitUrl: window.g.uriPostWizardPixel, // Default submit url
        showCancel: false, // Show cancel button when initialized.
        showClose: true, // Show close button when initialized
        increaseHeight: 0, // Deprecated
        contentHeight: 400, // Default height of content view
        contentWidth: 760, // Default width of wizard dialog, includes step navigation, which takes 28%.
        buttons: {
            cancelText: _('labCancel'),
            nextText: _('labNext'),
            backText: _('btnReturn'),
            submitText: _('Continue'),
            submittingText: _('labSending'),
        },
        formClass: "form-horizontal", // Allows the configuration of the class(es) of the form. Default `form-horizontal` is set. Multiple classes are allow by separation of space.
        progressBarCurrent: false,
    });

    // Triggers when the wizard is closed
    wizard.on('closed', function() {
        wizard.reset();
    });

    // Reset event is called when the dialog is either closed or when submit is done
    wizard.on("reset", function() {
        wizard.modal.find(':input').val('').removeAttr('disabled');
        wizard.modal.find('textarea').val('').removeAttr('disabled');
    });

    // Triggers when the previous card becomes the current card
    wizard.on("decrementCard", function() {
        $('div.wizard-footer button.btn.wizard-next').show();
    });

    // Triggers when the wizard has reached its final card
    wizard.on('readySubmit', function() {
        // aplica o spinner
        $('textarea#textScript').parent().spin(null, '#7b98d3');

        // captura os parâmetros para criação do pixel
        var name = $('input#pixelName', '.modal.wizard').val();
        var tag = $('select#pixelType', '.modal.wizard').val();
        window.g.pixel.pixelName = name;
        window.g.pixel.pixelTag = tag;
        window.g.pixel.pixelPrettyTag = translatePixelTag(tag); // recuperando o nome amigável da tag do pixel
        window.g.pixel.pixelTrack = $('select#trackMode', '.modal.wizard').val();

        if (window.g.pixel.pixelId && !isNaN(window.g.pixel.pixelId)) {
            // buscando informações do pixel criado
            var conversionPixel = new api.AdConversionPixel(window.g.pixel.pixelId);
            conversionPixel.read().then(fbHandleConversionPixelsGet);
        } else {
            // criando pixel
            mixpanel.track("Create Conversion Pixel");
            var pixelData = {
                name: name,
                tag: tag
            }
            var conversionPixel = new api.AdConversionPixel(pixelData, adAccount.id);
            conversionPixel.create().then(fbHandleConversionPixelsCreate);
        }
    });

    // Trigger when submit was succesfull
    wizard.on('submitSuccess', function() {});

    // Trigger when submit failed
    wizard.on('submitFailure', function() {});

    // Triggers when submit encounters an error
    wizard.on('submitError', function() {});

    // Triggers when wizard is loaded
    wizard.on('loaded', function() {
        // exibe aviso de aceitação de termos com mais ênfase caso usuário nao tenha aceito ainda
        if (inObject('offsite_pixels_tos_accepted', window.g)) {
            if (!window.g.offsite_pixels_tos_accepted) {

                var alertTemplate = '<div class="row-fluid">' +
                    '<div class="span12">' +
                    '<div id="logCreatePixel" class="bodyAlert lef">' +
                    '<div><i class="tb-icon-29x-alert"></i></div>' +
                    '<div>' + _('msgPixelTerm') + '</div>' +
                    '</div>' +
                    '</div>' +
                    '</div>';

                // exibindo alerta
                $('div.wizard-card-container > div:nth-child(1)').append(alertTemplate);
            }
        }
    });

    // Triggers when the submit button is clicked on the final card
    wizard.on('submit', function() {
        try {
            var checkOtherPerson = $('div#tbRadioSmll01 div#radio1');
            var splCls = checkOtherPerson.attr('class').split(' ');

            if (splCls.indexOf('selected') < 1) {
                wizard.hide();
                setTimeout(function() {
                    wizard.reset();
                }, 250);

                throw 1;
            }

            var to = $('div.wizard input#emailSender').val();
            var from = $('div.wizard input#emailReceiver').val();
            var subject = _('labSubjectMailPixel');
            var text = $('div.wizard textarea#msgReceiver').val();
            var script = $('div.wizard textarea#textScript').val();

            if (!window.g.postSendPixelEmail || typeof window.g.postSendPixelEmail != 'string') throw 'invalid window.g.postSendPixelEmail param';
            if (!to || typeof to != 'string') throw 'invalid to param';
            if (!from || typeof from != 'string') throw 'invalid from param';
            if (!subject || typeof subject != 'string') throw 'invalid subject param';
            if (!text || typeof text != 'string') text = '';
            if (!script || typeof script != 'string') script = '';

            var objPost = {};
            objPost.to = to;
            objPost.from = from;
            objPost.name = "sender";
            objPost.subject = subject;
            objPost.text = text;
            objPost.script = script;

            $.ajax({
                type: 'POST',
                url: window.g.postSendPixelEmail,
                data: objPost,
                dataType: 'json',
                cache: false,
                crossDomain: true,
                success: function(data) {
                    try {
                        if (!inObject('success', data))
                            throw 'invalid sendEmail response';

                        if (!data.success)
                            throw 'success false';

                        // sucesso esconde o wizard e bola pra frente
                        wizard.hide();

                        setTimeout(function() {
                            wizard.reset();
                        }, 250);

                    } catch (e) {
                        console.log('sendEmail successError: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.log('sendEmail error: ', jqXHR, textStatus, errorThrown);

                    $('div.modal-body.wizard-body > form > div > div.wizard-footer > div > button.wizard-cancel').show();
                    $('div.modal-body.wizard-body > form > div > div.wizard-footer > div > div > button.btn.wizard-next').attr({
                        disabled: false,
                        class: 'btn wizard-next btn-success',
                    }).text($('#fbPixel-wizard').attr('labRetry'));
                }
            });
        } catch (e) {
            if (e != 1) {

                console.log('error sending email : ', e);

                $('div.modal-body.wizard-body > form > div > div.wizard-footer > div > button.wizard-cancel').show();
                $('div.modal-body.wizard-body > form > div > div.wizard-footer > div > div > button.btn.wizard-next').attr({
                    disabled: false,
                    class: 'btn wizard-next btn-success',
                }).text($('#fbPixel-wizard').attr('labRetry'));

            }
        }
    });

    // abrindo o wizard
    window.setTimeout(function() {
        wizard.show();
        // wizard.changeNextButton('changeNextButton');
    }, 300);

    //validações do wizard card('creating');
    wizard.cards["creating"].on("validate", function(card) {
        var check = $('div#tbRadioSmll02 .radio');
        if (check.length < 1) return false;

        var arrCls = check.attr('class').split(' ');
        if (!$.isArray(arrCls)) return false;

        if (arrCls.indexOf('selected') < 0) {
            card.wizard.errorPopover($('div#tbRadioSmll02 div#radio0'), _('msgMustAcceptTheTerms'), false);
            return false;
        }
        return true;
    });

    //validações do wizard card('sending');
    wizard.cards["sending"].on("validate", function(card) {
        var checkOtherPerson = $('div#tbRadioSmll01 div#radio1');
        var splCls = checkOtherPerson.attr('class').split(' ');

        if (splCls.indexOf('selected') > -1) {

            var to = $('div.wizard input#emailSender');
            var from = $('div.wizard input#emailReceiver');

            if (!to.val()) {
                card.wizard.errorPopover(to, _('msgSenderEmailRequired'), false);
                return false;
            }

            if (!from.val()) {
                card.wizard.errorPopover(from, _('msgReceiverEmailRequired'), false);
                return false;
            }

            return true;
        }
    });
};

/**
 * Função que valida o campo de nome do pixel
 * @param {input:text} el: objeto HTML de input de texto
 */
function validatePixelName(el) {
    var name = el.val();
    var retValue = {};

    if (name == "") {
        retValue.status = false;
        retValue.msg = _('msgPlzEnterPixelName');
    } else {
        retValue.status = true;
    }

    return retValue;
};

/**
 * Callback que lida com a resposta da criação do pixel
 * @param {object} data: objeto de retorno do facebook
 */
function fbHandleConversionPixelsCreate(data) {
    try {
        // caso o retorno do facebook não seja um objeto válido
        if (!data instanceof Object || $.isEmptyObject(data)) throw 'pixel not created';

        // erro encontrado
        if (inObject('error', data))
            if (inObject('message', data.error))
                throw data.error.message;

        window.g.pixel.pixelId = data.id // atribuindo

        // exibindo sucesso no passo 2
        $('div.wizard-card-container > div:nth-child(2) > *:not(h3)').show();
        $('div.wizard-card-container div#logCreatePixel').remove();
        $('div.wizard-footer button.btn.wizard-next').show();

        // buscando informações do pixel criado
        var conversionPixel = new api.AdConversionPixel(window.g.pixel.pixelId);
        conversionPixel.read().then(fbHandleConversionPixelsGet);
    } catch (e) {
        console.log('fbHandleConversionPixelsCreate() :', e);

        var alert = '';
        if (e.indexOf('http') > -1) {
            var pos = e.indexOf('http');
            var link = e.substring(pos, e.length);
            var alert = e.substring(0, pos);
            link = replaceAll('<a href="%0" target="_blank">%0<a/>', '%0', link);
            alert += link;
        } else {
            alert = e;
        }

        var alertTemplate = '<div class="row-fluid">' +
            '<div class="span12">' +
            '<div id="logCreatePixel" class="bodyAlert lef">' +
            '<div><i class="tb-icon-29x-alert"></i></div>' +
            '<div>' + alert + '</div>' +
            '</div>' +
            '</div>' +
            '</div>';

        // exibindo falha
        $('div.wizard-card-container > div:nth-child(2) > *').hide();
        $('div.wizard-card-container > div:nth-child(2)').append(alertTemplate);
        $('div.wizard-footer button.btn.wizard-next').hide();
    }
};

/**
 * Callback que lida com a resposta da busca do pixel, e exibe no textArea
 * @param {object} data: objeto de retorno do facebook
 */
function fbHandleConversionPixelsGet(data) {
    try {
        // remove o spinner
        $('textarea#textScript').parent().spin(false);

        // caso o retorno do facebook não seja um objeto válido
        if (!data instanceof Object || $.isEmptyObject(data)) throw 'pixel not received';

        // erro encontrado
        if (inObject('error', data))
            if (inObject('message', data.error))
                throw data.error.message;

        if (inObject('js_pixel', data)) {
            //setando valor ao textScript e selecionando todo o conteudo no focus event
            $('textarea#textScript').val(data.js_pixel).focus(function() {
                var $this = $(this);
                $this.select();

                // Work around Chrome's little problem
                $this.mouseup(function() {
                    // Prevent further mouseup intervention
                    $this.unbind("mouseup");
                    return false;
                });
            });

            //setando valor ao reviewTextScript e selecionando todo o conteudo no focus event
            $('textarea#reviewTextScript').val(data.js_pixel).focus(function() {
                var $this = $(this);
                $this.select();

                // Work around Chrome's little problem
                $this.mouseup(function() {
                    // Prevent further mouseup intervention
                    $this.unbind("mouseup");
                    return false;
                });
            });
        }
    } catch (e) {
        console.log('fbHandleConversionPixelsGet() :', e);
        $('textarea#textScript').val(e);
    }
};

/**
 * Função que retorna o nome amigável correspondente as tag dos pixel sde conversão
 * @param  {string} tag: string de identificação do tipo de pixel
 * @return {string}: nome amigável para o cliente em relação ao tipo de pixel
 */
function translatePixelTag(tag) {
    try {
        if (!tag || typeof tag != 'string') throw 'no valid tag';

        tag = tag.toLowerCase();

        if (tag === 'checkout') return _('labPixelType0');
        if (tag === 'registration') return _('labPixelType1');
        if (tag === 'lead') return _('labPixelType2');
        if (tag === 'key_page_view') return _('labPixelType3');
        if (tag === 'add_to_cart') return _('labPixelType4');
        if (tag === 'other') return _('labPixelType5');

        throw 'no matches found';
    } catch (e) {
        console.log('error translating tag', e);
        return 'unknown';
    }
};

/**
 * Função que lida com a resposta da consulta sobre os termos do pixel e armazena no objeto global
 * @param {object} data: objeto de retorno do facebook
 */
function fbHandlePixelTermsQuery(data) {
    try {
        // caso o retorno do facebook não seja um objeto válido
        if (!data instanceof Object || $.isEmptyObject(data))
            throw 'pixel terms not received';

        // erro encontrado
        if (inObject('error', data))
            if (inObject('message', data.error))
                throw data.error.message;

        if (inObject('offsite_pixels_tos_accepted', data)) {
            if (window['g'] == undefined)
                var g = {};

            window.g.offsite_pixels_tos_accepted = data.offsite_pixels_tos_accepted;
        }
    } catch (e) {
        console.log('fbHandlePixelTermsQuery() :', e);
    }
};

////////////////////////////
// PUBLICANDO NO FACEBOOK //
////////////////////////////

/**
 * Função que inicia o processo de publicação do objetivo 02
 */
function publish_Objective03Start() {
    // console.log('publish_Objective03Start');
    bootbox.dialog({
        className: 'blue',
        locale: window.g.languageMin,
        title: _('labConfirmation'),
        message: _('proceedWithCreationGoal03'),
        closeButton: false,
        buttons: {
            'no': {
                label: _('labNo'),
                callback: function() {},
            },
            'yes': {
                label: _('labYes'),
                callback: function() {
                    $('button#fNext').attr('class', 'btn-goal-disabled'); //desabilitando o botão de publicar campanha

                    window.g.publish.identifier = 'WEBSITES'; // setando o identificador para o objetivo 3

                    var pageId = window.g.pageId;
                    var imgUrl = window.g.creative.imgUrl;
                    var imgHash = window.g.creative.imgHash;
                    var description = window.g.metaTag.description;
                    var imgWidth = window.g.creative.imgWidth;
                    var imgHeight = window.g.creative.imgHeight;
                    var hasFileToUpload = $('form#postForm input#file').val();

                    // definindo se devo criar um Page Post Link Ad (dark)
                    if (pageId && !isNaN(pageId)) { // verificando se ha related page
                        if ((imgWidth && !isNaN(imgWidth)) && (imgHeight && !isNaN(imgHeight))) { // checando dimensões da imagem part 1
                            if (imgWidth > 399 && imgHeight > 208) { // checando dimensões da imagem part 1
                                if (description) { //checando se há um description para a criação do dark post
                                    CreateClass.FbPage().getPagePermissions(window.g.token, null, 'publish_fbHandlePagePermissions'); // recuperando o token da página corrente
                                }
                            }
                        }
                    }

                    if (hasFileToUpload) {
                        publish_setStatus('1.8'); //escrever status de uploading de imagens
                        publish_uploadImgToAccountLibrary();
                    } else if (!imgUrl && !imgHash) {
                        publish_setStatus('-1.7');
                    } else {
                        publish_createCampaignGroup();
                    }

                    // testando se temos o hash ou url da imagem que será usada na criação do AD
                    // if (!imgUrl && !imgHash) { //TODO imgUrl is here
                    //     if (!hasFileToUpload) {
                    //         publish_setStatus('-1.7'); //o usuário precisa de uma imagem engatilhada para upload
                    //     } else {
                    //         publish_setStatus('1.8'); //escrever status de uploading de imagens
                    //         publish_uploadImgToAccountLibrary();
                    //     }
                    // } else {
                    //     publish_createCampaignGroup();
                    // }

                    setTimeout(function() {
                        showModal('#modalPublish', {
                            backdrop: 'static',
                            keyboard: false,
                            closeButton: false
                        });
                    }, 400);
                },
            },
        }
    });
};

/**
 * Função que criará o anúncio principal (Nova estrutura)
 */
function publish_createMainAd() {
    try {
        window.g.variationAd = [];

        //verificando se já possuo o anúncio principal criado no objeto global
        if (window.g.publish.primaryAdId && !isNaN(window.g.publish.primaryAdId)) {
            // chamando a função que lida com a criação de anúncio principal simulando a criação via facebook
            publish_fbHandleCreateMainAdObjective03({
                id: window.g.publish.primaryAdId
            });
        } else {
            // Creative
            var title = $('input#titAd', 'div#stp03').val();
            var body = $('textarea#txtText', 'div#stp03').val();
            var object_url = $('#urlWebSite', 'div#stp01').val();

            if (window.g.creative.imgUrl)
                var image_url = window.g.creative.imgUrl;
            else if (window.g.creative.imgHash)
                var image_hash = window.g.creative.imgHash;

            var creative = TB.AdCreative.make.domain_ad(title, body, null, null, image_hash, image_url, null);

            if(window.g.pageId) {
                creative.object_story_spec = {
                    page_id: window.g.pageId,
                    link_data: {
                        name: title,
                        caption: body,
                        link: object_url,
                    }
                };
                if(image_url)
                    creative.object_story_spec.link_data.picture = image_url;
                else if(image_hash)
                    creative.object_story_spec.link_data.image_hash = image_hash;
            } else {
                creative.object_url = object_url;
            }

            // AdGroup
            var campaign_id = window.g.publish.campaignId;
            var name = _('mainAdName').replace('%d', campaign_id);

            var pixelId = window.g.pixel.pixelId;
            if (pixelId) { //pixel
                var conversion_specs = TB.AdGroup.conversion_specs.custom.offsite_conversion(pixelId);
                var tracking_specs = TB.AdGroup.tracking_specs.custom.offsite_conversion(pixelId);
            } else {
                var conversion_specs = TB.AdGroup.conversion_specs.custom.link_click.url(object_url);
            }

            // ------------------------------------------------------------------------------------------------------

            var imgWidth = window.g.creative.imgWidth;
            var imgHeight = window.g.creative.imgHeight;
            var description = window.g.metaTag.description;
            var pageToken = window.g.pageToken;
            var pixelId = window.g.pixel.pixelId;

            //------------------------------------------------------------------------------
            // fanpage | img         | format                       | placement
            //------------------------------------------------------------------------------
            // não | qualquer        | Domain Ad                    | rightcolumn
            // sim | menor 400 x 209 | Domain Ad                    | rightcolumn
            // sim | maior 400 x 209 | Domain Ad & Page Post Link Ad| rightcolumn + feed
            //------------------------------------------------------------------------------
            var pageId = window.g.pageId;
            // definindo se devemos criar um Page Post Link Ad (dark)
            if (pageId && !isNaN(pageId) && pageToken) { // verificando se ha uma related page + page token válido
                if ((imgWidth && !isNaN(imgWidth)) && (imgHeight && !isNaN(imgHeight))) { // checando dimensões da imagem part 1
                    if (imgWidth > 399 && imgHeight > 208) { // checando dimensões da imagem part 1
                        if (description) { //checando se há um description para a criação do dark post

                            // Page Post Link Ad (dark)
                            if (description) {
                                var objPost = {
                                    message: description
                                };
                                CreateClass.FbPage().createStatusDarkPost(objPost, pageToken, pageId, 'publish_fbHandleCreatePost');
                            }
                        }
                    }
                }
            }

            // ------------------------------------------------------------------------------------------------------
            var adGroupData =  {
                campaign_id: campaign_id,
                name: name,
                creative: creative,
                conversion_specs: conversion_specs,
                tracking_specs: tracking_specs
            };
            var adGroup = new api.AdGroup(adGroupData, adAccount.id);
            adGroup.create().then(publish_fbHandleCreateMainAd);

            window.g.publish.name = name;
            mixpanel.track("Publish Campaign", {
                'Goal': window.g.currentGoal
            });        }
    } catch (e) {
        console.log('publish_createMainAd():', e);
        publish_setStatus('-1.4', e);
    }
};

/**
 * Callback de retorno de criação de post
 * @param  {object} data: objeto retornando pelo facebook
 */
// function publish_fbHandleCreatePost(data) {
//     try {
//         //facebook error
//         if (inObject('error', data)) throw data.error.message || 'facebook error';

//         //backend error
//         if (inObject('success', data)) {
//             if (!data.success || data.success == 'false') {
//                 throw data.message || 'backend error';
//             }
//         }

//         //checando id recebido
//         var pId = null;
//         if (!inObject('id', data) && !inObject('postId', data)) {
//             throw 'invalid id';
//         } else {
//             if (data.hasOwnProperty('id')) {
//                 if (!data.id || typeof data.id != 'string') throw 'invalid id';
//                 pId = data.id;
//             }
//             if (data.hasOwnProperty('postId')) {
//                 if (!data.postId || isNaN(data.postId)) throw 'invalid postId';
//                 pId = data.postId;
//             }
//         }

//         window.g.publish.postId = pId;
//         publish_setStatus('1.1'); //escrever status

//         // definições do Page Post Link Ad (dark)
//         var pageId = window.g.pageId;
//         var postId = window.g.publish.postId;
//         var storyId = (postId.indexOf('_') > -1 ? postId.split('_')[1] : postId);
//         var campaignId = window.g.publish.campaignId;
//         var targeting = getTargetingSpecFromSegmentation();
//         var pixelId = window.g.pixel.pixelId;

//         // validações do Page Post Link Ad (dark)
//         if (!pageId || isNaN(pageId)) throw 'invalid pageId';
//         if (!campaignId || isNaN(campaignId)) throw 'invalid campaignId';
//         if (!targeting instanceof Object || $.isEmptyObject(targeting)) throw 'invalid targeting';

//         //objeto creative
//         var creative = {};
//         /*creative.type = 27;*/
//         /*creative.object_id = pageId;*/
//         /*creative.story_id = storyId;*/
//         creative.object_story_id = (postId.indexOf('_') > -1) ? postId : pageId + '_' + postId;

//         // objeto variationAd
//         var variationAd = {};
//         variationAd.name = _('variationAdName').replace('%0', campaignId).replace('%1', (i + 1));
//         variationAd.bid_type = 'ABSOLUTE_OCPM';
//         variationAd.bid_info = JSON.stringify({
//             'ACTIONS': 3000,
//             'REACH': 0,
//             'CLICKS': 0,
//             'SOCIAL': 0
//         });
//         variationAd.campaign_id = campaignId;
//         variationAd.creative = JSON.stringify(creative);
//         targeting.page_types = ["feed"]; // definindo posicionamento
//         variationAd.targeting = JSON.stringify(targeting);
//         //pixel
//         if (pixelId && !isNaN(pixelId)) {
//             variationAd.conversion_specs = JSON.stringify({
//                 "action.type": "offsite_conversion",
//                 "offsite_pixel": pixelId,
//             });

//             variationAd.tracking_specs = JSON.stringify({
//                 "action.type": "offsite_conversion",
//                 "offsite_pixel": pixelId
//             });
//         }

//         window.g.variationAd.push(variationAd); //adiciona variação na variável de controle

//         publish_createVariationAd(); // faz a publicação das variações de Anúncios
//     } catch (e) {
//         console.log('publish_fbHandleCreatePost():', e);
//         publish_setStatus('-1.2', e);
//     }
// };

/**
 * Função que lida com a resposta da criação do anúncio principal
 * @param  {object} data: objeto de retorno do facebook
 */
// function publish_fbHandleCreateMainAdObjective03(data) {
//     try {
//         if (inObject('error', data))
//             if (data.error.hasOwnProperty('message')) throw data.error.message;

//         if (inObject('id', data)) {
//             if (!data.id || isNaN(data.id)) throw 'invalid main ad id';

//             publish_setStatus('1.7');

//             window.g.publish.primaryAdId = data.id;

//             var tentativa = 1;
//             var tentativas = 3;
//             var milisegundos = 3000;
//             var interval = setInterval(function() {

//                 if ((tentativa >= tentativas) || (window.g.variationAd.length > 0)) {
//                     publish_createVariationAd(); // faz a publicação das variações de Anúncios
//                     clearInterval(interval);
//                 }

//                 tentativa++;

//             }, milisegundos);
//         }
//     } catch (e) {
//         console.log('publish_fbHandleCreateMainAdObjective03():', e);
//         publish_setStatus('-1.4', e);
//     }
// };

/**
 * Callback que recebe as informações de permissão da Página/Local (Connection Object), ou seja o token de página.
 * Com o token recebido, inicia o processo de criação de post.
 *
 * @param  {object} data: retorno do facebook (supostamente com o access_token da página)
 */
function publish_fbHandlePagePermissions(data) {
    try {
        if (inObject('error', data)) throw (data.error.message || 'facebook error');

        var currPageId = tryParse(window.g.pageId, 'string', null);

        if (!currPageId) throw 'invalid currPageId';

        // identificando e varrendo a resposta do facebook e recuperando o token da página
        if ($.isArray(data.data)) {
            for (i = 0, l = data.data.length; i < l; i++) {
                if (data.data[i].hasOwnProperty('id') && data.data[i].hasOwnProperty('access_token')) {
                    if (data.data[i].id == currPageId.toString()) {
                        window.g.pageToken = data.data[i].access_token;
                    }
                }
            }
        } else {
            if (data.data.hasOwnProperty('id') && data.data.hasOwnProperty('access_token')) {
                if (data.data.id == currPageId.toString()) {
                    window.g.pageToken = data.data.access_token;
                }
            }
        }

        // caso não tenhamos o token da página o processo é abortado
        if (!window.g.pageToken) throw 'invalid pageToken';

    } catch (e) {
        console.log('publish_fbHandlePagePermissions', e);
        publish_setStatus('-1.1', e);
    }
};




/**
 * Callback da chamada de Connection Objects
 * @param {object} data: objeto de retorno do facebook
 */
function fbHandleGetConnectionObjects(data) {
    try {
        fullLoaderStop(); //esconde o fullLoader

        $('div.selectFanPage #carouselChooseYourPage > ol').remove();
        $('div.selectFanPage #carouselChooseYourPage > div').remove();

        if (data instanceof Object && !$.isEmptyObject(data)) {

            //erro encontrado
            if (inObject('error', data)) {
                if (data.error.message) {
                    throw data.error.message;
                }
            }

            // validando o array global
            if (!$.isArray(window.g.arrRelatedPageId)) throw 'related page not found';
            if (window.g.arrRelatedPageId.length < 1) throw 'related page not found';
            // array que conterá objetos página relacionados
            var filterData = [];

            // para cada objeto relacionado contigo no array global, filtre os que que foram encontrados
            for (i = 0, len = window.g.arrRelatedPageId.length; i < len; i++) {

                var tmp = $.grep(data.data, function(e) {
                    return e.id == window.g.arrRelatedPageId[i];
                });

                if ($.isArray(tmp) && tmp.length > 0) {
                    for (j = 0, leng = tmp.length; j < leng; j++) {
                        if (tmp[j].hasOwnProperty('id'))
                            filterData.push(tmp[j]);
                    }
                } else {
                    if (tmp.hasOwnProperty('id'))
                        filterData.push(tmp);
                }
            }

            if (!$.isArray(filterData)) throw 'data is not an array';
            if (filterData.length < 1) throw 'data is an empty array';

            // aplicar template para o carousel de escolha de página
            CreateClass.MyHandlebars(filterData, "carouselChooseYourPage").appendRender();

            // definição do carousel carouselGoal para não agir sozinho
            $('.carouselGoal').carousel({
                interval: false,
                wrap: true
            }).on('slide.bs.carousel', function() { //antes de executar o slide
            }).on('slid.bs.carousel', function() { //depois de executar o slider
                showHidePaginatorCarousel('.pageList'); // Aplica regra de limites de paginação evitando o loop
                getPagesIdToSearch(window.g.token, 'fbFeedMorePageInfo'); //complementar informação das fanpages
            });

            // esconder os paginadores do carousel quando os dados forem menores que 3
            if (filterData.length < 3) {
                $('div#carouselChooseYourPage .carousel-control').hide();
                $('div#carouselChooseYourPage .carousel-indicators').hide();
            }

            fanPageBinder(); // Seleção de fanpage
            showHidePaginatorCarousel('.pageList'); // Aplica regra de limites de paginação evitando o loop
            stepperVerify(window.g.stepper); // gerencia os botões de paginação do stepper
            getPagesIdToSearch(window.g.token, 'fbFeedMorePageInfo'); //complementar informação das fanpages
        }
    } catch (e) {
        console.log('fbHandleGetConnectionObjects : ', e);
    }
};
