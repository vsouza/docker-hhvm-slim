
var spinner = $("#spinner");
var spinnerOpts = {
	lines: 8,
	length: 2,
	width: 2,
	radius: 3,
	color: '#7b98d3'
};
function getNotifications() {
    Notifications.getNotifications(true);
}
function handleNotitifications(notifications) {
	spinner.data('spinner').stop();
	spinner.css( "display", "none");
    CreateClass.MyHandlebars(notifications, "notificationslist").appendRender();
    if(!notifications.data) $('#loadmore').hide();
}

$(document).ready(function() {
	return; //TODO
	spinner.spin(spinnerOpts);
	$("#loadmore").click(function(event) {
	  	event.preventDefault();
		spinner.css( "display", "block");
	  	spinner.spin(spinnerOpts);
		Notifications.getNotifications(true);
	});
});