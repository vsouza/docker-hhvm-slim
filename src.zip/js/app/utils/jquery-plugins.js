(function($) {
    /**
     * Spin.js plugins
     */
    jQuery.fn.spin = function(opts, color) {
        var presets = {
            "tiny": {
                lines: 8,
                length: 2,
                width: 2,
                radius: 3
            },
            "small": {
                lines: 8,
                length: 4,
                width: 3,
                radius: 5
            },
            "large": {
                lines: 10,
                length: 8,
                width: 4,
                radius: 8
            }
        };
        var defaultOpts = {
            lines: 9, // The number of lines to draw
            length: 0, // The length of each line
            width: 6, // The line thickness
            radius: 12, // The radius of the inner circle
            corners: 1, // Corner roundness (0..1)
            rotate: 0, // The rotation offset
            direction: 1, // 1: clockwise, -1: counterclockwise
            color: '#ffcc00', // #rgb or #rrggbb or array of colors
            speed: 1, // Rounds per second
            trail: 60, // Afterglow percentage
            shadow: false, // Whether to render a shadow
            hwaccel: false, // Whether to use hardware acceleration
            className: 'spinner', // The CSS class to assign to the spinner
            zIndex: 2000000000, // The z-index (defaults to 2000000000)
            top: 'auto', // Top position relative to parent in px
            left: 'auto' // Left position relative to parent in px
        };

        if ((!opts instanceof Object || $.isEmptyObject(opts)) && (opts !== false)) {
            opts = defaultOpts;
        }

        if (Spinner) {
            return this.each(function() {
                var $this = $(this),
                    data = $this.data();

                if (data.spinner) {
                    data.spinner.stop();
                    delete data.spinner;
                }

                if (opts !== false) {
                    if (color) opts.color = color;

                    data.spinner = new Spinner($.extend({
                        color: $this.css('color')
                    }, opts)).spin(this);
                }
            });

        } else {
            throw "Spinner class not available.";
        }
    };

    /**
     * Resizing Animation Plugin
     */
    jQuery.fn.animateAuto = function(prop, speed, callback) {
        var elem, height, width;
        return this.each(function(i, el) {
            el = jQuery(el), elem = el.clone().css({
                "height": "auto",
                "width": "auto"
            }).appendTo("body");
            height = elem.css("height"),
            width = elem.css("width"),
            elem.remove();

            if (prop === "height")
                el.animate({
                    "height": height
                }, speed, callback);
            else if (prop === "width")
                el.animate({
                    "width": width
                }, speed, callback);
            else if (prop === "both")
                el.animate({
                    "width": width,
                    "height": height
                }, speed, callback);
        });
    };
    
    /**
     * Rotation Animation Plugin
     */
    jQuery.fn.animateRotate = function(angle, duration, easing, complete) {
        var args = $.speed(duration, easing, complete);
        var step = args.step;
        return this.each(function(i, e) {
            args.step = function(now) {
                $.style(e, 'transform', 'rotate(' + now + 'deg)');
                if (step) return step.apply(this, arguments);
            };

            $({
                deg: 0
            }).animate({
                deg: angle
            }, args);
        });
    };
})(jQuery);