/* Aplica a classe selecionada [selStyle] ao elemento <a> dentro do container [aTag] que seja correspondente com o [window.location.href] atual */

function selectedStyle(aTag, selStyle) {
    if (!aTag || typeof aTag != 'string') return;
    if ($(aTag + ' a').length < 1) return;
    if (!selStyle || typeof selStyle != 'string') return;

    var b = tryParse(window.location.href, 'string', '');
    if (b === '') return;
    var bb = lastInArray(b.split('/'));

    $(aTag + ' a').removeClass(selStyle); /*remove todas as classes [selStyle] das tag <a> dentro do escopo*/
    $(aTag + ' a').each(function() {
        var a = $(this).attr('href');
        var aa = lastInArray(a.split('/'));
        if (aa === bb) {
            $(this).addClass(selStyle); /*aplica a classe [selStyle] somente a qual for necessára*/
        }
    })
}

/* Retorna a máscara de um elemento ou [null] */

function getMaskFromElement(formId, elementId) {
    if (!elementId || typeof elementId != 'string') return false;

    var sel = (formId && typeof formId === 'string' ? $(elementId, formId) : $(elementId));
    if (sel.length < 1) return false;

    var arrClass = sel.attr('class').split(' ');
    if (arrClass.length < 1) return false;

    var lcl = CreateClass.Regional();
    var objMask = lcl.getObjParam('mask');

    for (i = 0, len = arrClass.length; i < len; i++) {
        if (inObject(arrClass[i], objMask)) {
            return objMask[arrClass[i]];
        }
    }

    return false;
}

// Função que exibe o fullLoader no DOM

function fullLoader(opt, color, bgCls, countDown) {
    try {
        if (!bgCls || typeof bgCls != 'string') return;
        if (color && typeof color === 'string') {
            opt.color = color;
        }

        var f = $("div#fullLoader00");
        if (f.length < 1) $('<div id="fullLoader00" class="' + bgCls + '"></div>').appendTo('body');
        $("div#fullLoader00").show();
        //$("div#fullLoader00").spin(opt);
        $("div#fullLoader00").spin();

        if (countDown && typeof countDown === 'number') {
            if (parseFloat(countDown) > 999) {
                window.setTimeout(function() {
                    //$("div#fullLoader00").spin(false).remove();
                    fullLoaderStop();
                }, countDown);
            }
        }
    } catch (e) {
        console.log('fullLoader : ' + e);
    }
}
// Função que remove o fullLoader do DOM

function fullLoaderStop() {
    try {
        var f = $("div#fullLoader00");
        if (f.length > 0) {
            f.spin(false).hide();
        }
    } catch (e) {
        console.log('fullLoaderStop : ' + e);
    }
}

// Função varre todo o DOM e aplica a lib de file input nos elementos .filestyle

function maskFileInput(container) {
    if (!container || typeof container != 'string') return false;
    if ($(container).length < 1) return false;

    $(':file', container).each(function() {
        var $this = $(this),
            o = {
                'inputFileId': $this.attr('id'),
                'buttonText': $this.attr('data-buttonText'),
                'input': $this.attr('data-input') === 'false' ? false : true,
                'icon': $this.attr('data-icon') === 'false' ? false : true,
                'classButton': $this.attr('data-classButton'),
                'titleButton': $this.attr('data-titleButton'),
                'classInput': $this.attr('data-classInput'),
                'classIcon': $this.attr('data-classIcon'),
                'idButton': $this.attr('data-idButton'),
                'targeting': $this.attr('data-targeting'),
            };

        //caso não exista o botão, o mesmo é criado
        if ($('#' + o.idButton, container).length < 1) {
            var replaceInput = $('<button/>', {
                text: o.buttonText,
                attr: {
                    'class': o.classButton,
                    'type': 'button',
                    'id': o.idButton,
                    'title': o.titleButton,
                    'data-container': 'body'
                },
                click: function() {
                    if (!o.targeting || $(o.targeting).length < 1) {
                        $this.click();
                    } else {
                        $(o.targeting).click();
                    }
                }
            });
        }

        $this.css('display', 'none').before(replaceInput);
    });
}

// Função para escrever a oração de ex: "20 a 30 anos"

function madeRange(oData, oTerms) {
    try {
        var out = '';

        if (!oData instanceof Object || $.isEmptyObject(oData)) throw 'missing paremeter oData';
        if (!oTerms instanceof Object || $.isEmptyObject(oTerms)) throw 'missing paremeter oTerms';

        if (inObject('of', oTerms))
            out += (oTerms.of + ' ' || '');

        if (inObject('begin', oData)) {
            out += (oData.begin + ' ' || '');
        } else {
            throw 'missing paremeter oData.begin';
        }

        if (inObject('conjunctive', oTerms))
            out += (oTerms.conjunctive + ' ' || '- ');

        if (inObject('end', oData)) {
            if (parseFloat(oData.end) >= parseFloat(oData.begin) && parseFloat(oData.end) != 0) {
                out += (oData.end + ' ' || '');
            } else {
                out += (oTerms.indefinite + ' ' || '');
            }
        }

        out += _n(oTerms.misgid, (oData.end || oData.begin));

        return $.trim(out);
    } catch (e) {
        console.log('HHelper.madeRange : ', e);
        return '';
    }
}

// Função para escrever a oração de ex: "Homens e Mulheres"

function genderShow(oData, oTerms) {
    try {
        var out = '';

        if (!oData instanceof Object || $.isEmptyObject(oData)) throw 'missing paremeter oData';
        if (!oTerms instanceof Object || $.isEmptyObject(oTerms)) throw 'missing paremeter oTerms';

        if (inObject('male', oData))
            out += (oData.male + ' ' || '- ');

        if (inObject('female', oData)) {
            if (oData.female) {
                if (out.length > 0) {
                    if (inObject('conjunctive', oTerms)) {
                        out += (oTerms.conjunctive + ' ' || '- ');
                        out += (oData.female + ' ' || '- ');
                    }
                } else {
                    out += (oData.female + ' ' || '- ');
                }
            }
        }

        return $.trim(out);
    } catch (e) {
        console.log('HHelper.genderShow : ', e);
        return '';
    }
}

/* Função para exibir um modal bootstrap simples */

function showModal(selector, opt) {
    if (!selector || typeof selector != 'string') return;
    if (!opt instanceof Object || $.isEmptyObject(opt)) opt = {};

    var sel = selector.replace('#', '');
    var arrM = [
        'modalChooseCreative',
        'modalChooseAccount',
        'modalCreateAccount',
        'modalCreateCreative',
        'modalChangeCreative',
        'modalChangeCreativeDomain',
        'modalCreateCreativeSimilar',
        'modalCreateFanPage',
        'modalLinkFanPage',
        'modalManageGenre',
        'modalManageAge',
        'modalManagePlace',
        'modalManageInterest',
        'modalPublish',
        'modalPixelAsk',
        'modalSynchronization',
        'modalPublishActions',
    ];

    if (inArray(sel, arrM)) {

        // gerenciando parâmetro extra: closeButton
        $(selector + '> div.modal-header > button.close').css('visibility', 'visible');
        if (inObject('closeButton', opt)) {
            if (!opt.closeButton) {
                $(selector + '> div.modal-header > button.close').css('visibility', 'hidden');
            }
        }

        switch (sel) {
            case 'modalCreateFanPage':
                modalCreateFanPagePrepare(opt);
                break;
            case 'modalSynchronization':
                modalSynchronizationPrepare(opt);
                break;
            case 'modalPixelAsk':
                modalPixelAskPrepare(opt);
                break;
            case 'modalLinkFanPage':
                modalLinkFanPagePrepare(opt);
                break;
            case 'modalChooseCreative':
                modalChooseCreativePrepare(opt);
                break;
            case 'modalCreateCreative':
                modalCreateCreativePrepare(opt);
                break;
            case 'modalChangeCreative':
                modalChangeCreativePrepare(opt);
                break;
            case 'modalChangeCreativeDomain':
                modalChangeCreativeDomainPrepare(opt);
                break;
            case 'modalCreateCreativeSimilar':
                modalCreateCreativeSimilarPrepare(opt);
                break;
            case 'modalManageGenre':
                modalManageGenrePrepare(opt);
                break;
            case 'modalManageAge':
                modalManageAgePrepare(opt);
                break;
            case 'modalManagePlace':
                modalManagePlacePrepare(opt);
                break;
            case 'modalManageInterest':
                modalManageInterestPrepare(opt);
                break;
            case 'modalChooseAccount':
                modalChooseAccountPrepare(opt);
                break;
            case 'modalCreateAccount':
                modalCreateAccountPrepare(opt);
                break;
            default:
                $(selector).modal(opt);
                break;
        }
    }
}