////////////////
// LANGUAGES  //
////////////////

var LANGUAGES = {
    'en_US': {
        locale: {
            writeDirection: 'LTR', // LTR, RTL
            firstWeekDay: 0, //Date().getDay() = 0 domingo    
            languageMin: 'en',
            language: 'en_US',
            currency: 'USD',
            currencySymbol: '$',
            thousandSymbol: ',',
            decimalSymbol: '.',
            decimalCount: 2,
            timezoneId: 1,
            timezoneName: 'America/Los_Angeles',
            timezoneOffsetHoursUtc: -7,
        },
        mask: {
            dateShorter: 'MM/DD', // ad/bM/yy
            dateShort: 'MM/DD/YY', // ad/bM/yy
            dateFull: 'MM/DD/YYYY',
            timeShort: 'HH:mm',
            timeFull: 'HH:mm:ss',
            dateTime24: 'MM/DD/YYYY HH:mm:ss',
            dateTime24datetimepicker: 'MM/dd/yyyy hh:mm:ss',
            dateTime12: 'MM/DD/YYYY HH:mm:ss ap',
            dateTimeUTC: 'MM/DD/YYYY HH:mm:ss.SSS Z',
            dateTimeShortDotted: 'MM.DD.YYYY %0 HH:mm',
            cep: '00000-000',
            phone: '0000-0000',
            phoneWithDDD: '(00) 0000-0000',
            money: '#,##0.00',
            decimal: '#,##0.00',
            int: '#.##0',
            cpf: '000.000.000-00'
        }
    },
    'pt_BR': {
        locale: {
            writeDirection: 'LTR', // LTR, RTL
            firstWeekDay: 0, //Date().getDay() = 0 domingo    
            languageMin: 'pt',
            language: 'pt_BR',
            currency: 'BRL',
            currencySymbol: 'R$',
            thousandSymbol: '.',
            decimalSymbol: ',',
            decimalCount: 2,
        },
        mask: {
            dateShorter: 'DD/MM',
            dateShort: 'DD/MM/YY',
            dateFull: 'DD/MM/YYYY',
            timeShort: 'HH:mm',
            timeFull: 'HH:mm:ss',
            dateTime24: 'DD/MM/YYYY HH:mm:ss',
            dateTime24datetimepicker: 'dd/MM/yyyy hh:mm:ss',
            dateTime12: 'DD/MM/YYYY HH:mm:ss ap',
            dateTimeUTC: 'DD/MM/YYYY HH:mm:ss.SSS Z',
            dateTimeShortDotted: 'DD.MM.YYYY %0 HH:mm',
            cep: '00000-000',
            phone: '0000-0000',
            phoneWithDDD: '(00) 0000-0000',
            money: '#.##0,00',
            decimal: '#.##0,00',
            int: '#.##0',
            cpf: '000.000.000-00'
        }
    },
};

var FB_LANGS = {
    'BRL': 'pt_BR',
    'USD': 'en_US'
};


// Set global localization based on language configurations
function setLanguage(lang) {
    try {
        if (LANGUAGES[lang]) {
            var regional = LANGUAGES[lang];
        } else {
            lang = DEF_CONFIG.get('LANGUAGE');
            var regional = DEF_CONFIG.get('REGIONAL');
        }

        // setando o cookie
        if (tbCookie.has("currentRegional"))
            tbCookie.remove("currentRegional");

        tbCookie.set("currentRegional", JSON.stringify(regional));

        window.g.locale = (lang || tbCookie.get("currentLanguage"));
        window.g.languageMin = regional.locale.languageMin;

        window.g.currency = regional.locale.currency;
        window.g.currencySymbol = regional.locale.currencySymbol;
        window.g.thousandSymbol = regional.locale.thousandSymbol;
        window.g.decimalSymbol = regional.locale.decimalSymbol;
        window.g.decimalCount = regional.locale.decimalCount;

        window.g.dateTime24 = regional.mask.dateTime24;
        window.g.dateTimeShortDotted = regional.mask.dateTimeShortDotted;

        window.g.componetSetup = {
            datetimepicker: {
                format: regional.mask.dateTime24datetimepicker,
                language: lang.substr(0, 2)
            },
        };
    } catch (e) {
        console.log('setLanguage():', e);
    }
}

/* gettext alias */

function _(msgid) {
    if (gt instanceof Object)
        return gt.gettext(msgid);
    else
        return '';
}

/* ngettext sprintf alias */

function _n(msgid, num) {
    if (gt instanceof Object)
        return sprintf(gt.ngettext(msgid, msgid, num), num);
    else
        return '';
}

/* Handlebars ngettext sprintf helper */
Handlebars.registerHelper('_', function(msgid, n) {
    return _(msgid);
});

/* Handlebars ngettext sprintf helper */
Handlebars.registerHelper('_n', function(msgid, n) {
    return _n(msgid, n);
});

/*  INTERNATIONALIZATION
 *  Basicamente lida com as trocas de palavras chave para outros idiomas
 *
 *  Internationalization.getObj() :
 *  Internationalization.setObj() :
 *  Internationalization.getLocaleObj() :
 *  Internationalization.changeLanguage() : altera as chaves de idioma da ferramenta de acordo com o parametro [str], [withCache] opcional para reload com cache
 *  Internationalization.includeMainCssFile() :
 */

var Internationalization = {
    obj: {},
    setObj: function(obj, cssLoad) {
        if (!$.isEmptyObject(obj)) {

            /* seta o objeto  */
            Internationalization.obj = obj;

            /*seta como default a primeira linguagem do objeto*/
            if ($.isArray(obj)) {
                if (obj[0].hasOwnProperty("lang") && obj[0].hasOwnProperty("data"))
                    if (!tbCookie.has("currentLanguage"))
                        tbCookie.set("currentLanguage", obj[0].lang);
            } else {
                /*caso seja um objeto*/
                if (obj.hasOwnProperty("lang") && obj.hasOwnProperty("data"))
                    if (!tbCookie.has("currentLanguage"))
                        tbCookie.set("currentLanguage", obj.lang);
            }

            /*setar valor default caso não haja currentLanguage*/
            if (!tbCookie.has("currentLanguage"))
                tbCookie.set("currentLanguage", DEF_CONFIG.get('LANGUAGE'));

            /*incluir css dinamicamente*/
            if (cssLoad)
                Internationalization.includeMainCssFile(tbCookie.get("currentLanguage"));
        }
    },
    getObj: function() {
        return Internationalization.obj;
    },
    getObjParam: function(param) {
        if (!param || typeof param != 'string') return null;

        var splt = param.split('.');
        var returnObj = this.obj;

        for (i = 0, len = splt.length; i < len; i++) {
            if (returnObj.hasOwnProperty(splt[i])) {
                returnObj = returnObj[splt[i]]
            }
        }

        return returnObj;
    },
    getLocaleObj: function(locale) {
        var obj = Internationalization.getObj();
        if (!$.isEmptyObject(obj)) {

            /*caso seja um array de objetos*/
            if ($.isArray(obj)) {
                if (!locale) return null;
                locale = $.trim(locale);

                if (obj.length > 0) {
                    for (var a = 0; a < obj.length; a++) {
                        if (obj[a].hasOwnProperty("lang") && obj[a].hasOwnProperty("data"))
                            if (obj[a].lang == locale)
                                return obj[a].data;
                    }
                }
            } else {
                /*caso seja um objeto*/
                if (obj.hasOwnProperty("lang") && obj.hasOwnProperty("data"))
                    if (obj.lang = locale)
                        return obj.data;
            }
            return null;
        }
    },
    changeLanguage: function(str, withCache) {
        if (!str || typeof str != 'string') return;

        var doReload = false;
        var obj = Internationalization.getObj();

        if (!$.isEmptyObject(obj)) {
            if ($.isArray(obj)) {
                if (obj.length > 0) {
                    for (var a = 0; a < obj.length; a++) {
                        if (obj[a].hasOwnProperty("lang")) {
                            if (obj[a].lang == str) {
                                doReload = true;
                                break;
                            }
                        }
                    }
                }
            } else {
                doReload = true;
            }
        }

        if (str != tbCookie.get("currentLanguage") && doReload) {
            tbCookie.set("currentLanguage", str);
            window.location.reload(withCache);
        }
    },
    includeMainCssFile: function(suffix) {
        if (!suffix && typeof suffix != 'string') return false;

        var file = 'css/internal/main_' + suffix.toUpperCase() + '.css';

        $.ajax({
            url: file,
            type: 'HEAD',
            error: function() {},
            success: function() {
                $('head').append($('<link />').attr({
                    'rel': 'stylesheet',
                    'href': file
                }));
            }
        });
    },
};

/*  MOMENT
 *  métodos de auxilio a lib de data moment.js [http://momentjs.com/docs/]
 *
 *  Moment.toUnixMilliseconds() : [dateIn] objeto moment.js -> unix milliseconds
 *  Moment.toUnixSeconds() : [dateIn] objeto moment.js -> unix seconds
 *  Moment.unixMillisecondsDate() : converte unix milliseconds [milli] para um formato de data [format] desejado
 *  Moment.unixSecondsToDate() : converte unix seconds [sec] para um formato de data [format] desejado
 *  Moment.toUtc() : converte um [dateIn] objeto moment.js -> para um objeto moment.js convertido em utc [format] opcional
 */

var Moment = {
    toUnixMilliseconds: function(dateIn) {
        try {
            if (!dateIn.isValid()) return null;

            return dateIn.valueOf();
        } catch (e) {
            return null;
        }
    },
    toUnixSeconds: function(dateIn) {
        try {
            if (!dateIn.isValid()) return null;

            return dateIn.unix();
        } catch (e) {
            return null;
        }
    },
    unixMillisecondsDate: function(milli, format) {},
    unixSecondsToDate: function(sec, format) {},
    toUtc: function(dateIn, format) {
        try {
            if (!dateIn.isValid()) return null;
            if (dateIn.zone() === 0) return dateIn;

            if (format && typeof format === 'string') {
                return moment.utc(dateIn).format(format);
            } else {
                return moment.utc(dateIn);
            }
        } catch (e) {
            return null;
        }
    },
    utcDiff: function(strDateA, strDateB, key) {
        try {
            if (!strDateA) throw 'error';
            if (!strDateB) throw 'error';
            if (!key) throw 'error';

            var a = moment.utc(strDateA);
            var b = moment.utc(strDateB);

            return b.diff(a, key);
        } catch (e) {
            return 0;
        }
    }
};

/*  REGIONAL
 *  Classe de formatação de valores (currency, moeda, datas, numeros, etc, ...)
 *
 *  getObj() : retorna a propriedade [obj]
 *  setObj() : aplica valor a propriedade [obj]
 *  getObjParam() : retorna uma propriedade especifica dentro da propriedade do objeto [obj]
 *  setMaskForAll() : efetua as chamadas de formatação de máscaras, chamando outros médotods de acordo com um switch
 *  setNormalMask() : aplica formatação a campos simples, sem uma regra de negócios definida
 *  setDateShortMask() : aplica formação a datas curtas ex.: DD/MM/YY
 *  setDateFullMask() : aplica formação a datas completas ex.: DD/MM/YYYY
 *  setTimeShortMask() : aplica formação a horas curtas sem os segundos ex.: HH:mm
 *  setTimeFullMask() : aplica formação a horas completas com os segundos ex.: HH:mm:ss
 *  setDateTime24Mask() : aplica formatação de datas completas de 24 horas ex.: DD/MM/YYYY HH:mm:ss
 *  setDateTime12Mask() : aplica formatação de datas completas de 12 horas ex.: DD/MM/YYYY hh:mm:ss ap
 *  setMoneyMask() : aplica formatação monetária ex.: ?.??0,00
 *  setDecimalMask() : aplica formatação decimal ex.: ?.??0,00
 *  setIntMask() : aplica formatação a numeros inteiros ex.: ?.??0
 */

function Regional(obj) {
    this.obj = null;
    if (typeof obj === 'object' && !$.isEmptyObject(obj))
        this.obj = obj;

    this.getObj = function() {
        return this.obj;
    };
    this.setObj = function(obj) {
        if (typeof obj === 'object' && !$.isEmptyObject(obj))
            this.obj = obj;
    };
    this.getObjParam = function(strParam) {
        try {
            if (!strParam || typeof strParam != 'string') throw 'invalid strParam';
            if (!this.obj instanceof Object || $.isEmptyObject(this.obj)) throw 'empty class object';

            var splt = strParam.split('.');
            var returnObj = this.obj;

            for (i = 0, len = splt.length; i < len; i++) {
                if (returnObj.hasOwnProperty(splt[i])) {
                    returnObj = returnObj[splt[i]]
                }
            }

            return returnObj;
        } catch (e) {
            console.log('Regional.getObjParam():', e);
            return {};
        }
    };
    this.setMaskForAll = function(paramObj, optionObj) {
        try {
            var localeObj = {};
            var maskObj = {};

            if (paramObj instanceof Object && !$.isEmptyObject(paramObj)) { //verifica se recebi um objeto via parametro
                maskObj = paramObj;
            } else { // caso contrario busca na propriedade [obj] da classe
                if (!paramObj || typeof paramObj != 'string') throw 'invalid paramObj param';
                maskObj = this.getObjParam(paramObj) /* aloca o objeto que contém as definições de máscaras */
            }

            if (!maskObj instanceof Object || $.isEmptyObject(maskObj)) throw 'invalid work object';

            localeObj = this.getObjParam('locale');

            for (propClass in maskObj) {
                /*caso tenha um elemento do dom com a classe igual ao nome do objeto */
                if ($('.' + propClass).length < 1) continue;

                switch (propClass) {
                    case 'dateShort':
                        /*jquery mask option*/
                        var option = {};
                        if (!optionObj instanceof Object || $.isEmptyObject(optionObj)) {
                            option = {
                                translation: {
                                    'a': {
                                        pattern: /[0-3]/
                                    },
                                    'b': {
                                        pattern: /[0-1]/
                                    }
                                }
                            };
                        } else {
                            if (optionObj.hasOwnProperty(propClass)) option = optionObj[propClass];
                        }

                        this.setDateShortMask(propClass, maskObj[propClass], option);
                        break;
                    case 'dateFull':
                        /*jquery mask option*/
                        var option = {};
                        if (!optionObj instanceof Object || $.isEmptyObject(optionObj)) {
                            option = {
                                translation: {
                                    'a': {
                                        pattern: /[0-3]/
                                    },
                                    'b': {
                                        pattern: /[0-1]/
                                    }
                                }
                            };
                        } else {
                            if (optionObj.hasOwnProperty(propClass)) option = optionObj[propClass];
                        }

                        this.setDateFullMask(propClass, maskObj[propClass], option);
                        break;
                    case 'timeShort':
                        /*jquery mask option*/
                        var option = {};
                        if (!optionObj instanceof Object || $.isEmptyObject(optionObj)) {
                            option = {
                                translation: {
                                    'a': {
                                        pattern: /[0-2]/
                                    },
                                    'b': {
                                        pattern: /[0-5]/
                                    }
                                }
                            };
                        } else {
                            if (optionObj.hasOwnProperty(propClass)) option = optionObj[propClass];
                        }

                        this.setTimeShortMask(propClass, maskObj[propClass], option);
                        break;
                    case 'timeFull':
                        /*jquery mask option*/
                        var option = {};
                        if (!optionObj instanceof Object || $.isEmptyObject(optionObj)) {
                            option = {
                                translation: {
                                    'a': {
                                        pattern: /[0-2]/
                                    },
                                    'b': {
                                        pattern: /[0-5]/
                                    }
                                }
                            };
                        } else {
                            if (optionObj.hasOwnProperty(propClass)) option = optionObj[propClass];
                        }

                        this.setTimeFullMask(propClass, maskObj[propClass], option);
                        break;
                    case 'dateTime24':
                        /*jquery mask option*/
                        var option = {};
                        if (!optionObj instanceof Object || $.isEmptyObject(optionObj)) {
                            option = {
                                translation: {
                                    'a': {
                                        pattern: /[0-3]/
                                    },
                                    'b': {
                                        pattern: /[0-1]/
                                    },
                                    'c': {
                                        pattern: /[0-2]/
                                    },
                                    'd': {
                                        pattern: /[0-5]/
                                    }
                                }
                            };
                        } else {
                            if (optionObj.hasOwnProperty(propClass)) option = optionObj[propClass];
                        }

                        this.setDateTime24Mask(propClass, maskObj[propClass], option);
                        break;
                    case 'dateTime12':
                        /*jquery mask option*/
                        var option = {};
                        if (!optionObj instanceof Object || $.isEmptyObject(optionObj)) {
                            option = {
                                translation: {
                                    'a': {
                                        pattern: /[0-3]/
                                    },
                                    'b': {
                                        pattern: /[0-1]/
                                    },
                                    'c': {
                                        pattern: /[0-1]/
                                    },
                                    'd': {
                                        pattern: /[0-5]/
                                    },
                                    'e': {
                                        pattern: /a|p/
                                    },
                                    'f': {
                                        pattern: /m/
                                    },
                                    'E': {
                                        pattern: /A|P/
                                    },
                                    'F': {
                                        pattern: /M/
                                    }
                                }
                            };
                        } else {
                            if (optionObj.hasOwnProperty(propClass)) option = optionObj[propClass];
                        }

                        this.setDateTime12Mask(propClass, maskObj[propClass], option);
                        break;
                    case 'money':
                        /*jquery mask option*/
                        var option = {};
                        if (!optionObj instanceof Object || $.isEmptyObject(optionObj)) {
                            option = {
                                reverse: true,
                                maxlength: false,
                                byPassKeys: [9, 37, 38, 39, 40]
                            };
                        } else {
                            if (optionObj.hasOwnProperty(propClass)) option = optionObj[propClass];
                        }

                        var placeholder;
                        try {
                            placeholder = (localeObj.currencySymbol || this.getCurrencySymbol(localeObj.currency))
                        } catch (e) {
                            placeholder = null;
                        }

                        this.setMoneyMask(propClass, maskObj[propClass], option, placeholder);
                        break;
                    case 'decimal':
                        /*jquery mask option*/
                        var option = {};
                        if (!optionObj instanceof Object || $.isEmptyObject(optionObj)) {
                            option = {
                                reverse: true,
                                byPassKeys: [9, 37, 38, 39, 40]
                            };
                        } else {
                            if (optionObj.hasOwnProperty(propClass)) option = optionObj[propClass];
                        }

                        this.setDecimalMask(propClass, maskObj[propClass], option, null);
                        break;
                    case 'int':
                        /*jquery mask option*/
                        var option = {};
                        if (!optionObj instanceof Object || $.isEmptyObject(optionObj)) {
                            option = {
                                reverse: true,
                                maxlength: false,
                            };
                        } else {
                            if (optionObj.hasOwnProperty(propClass)) option = optionObj[propClass];
                        }

                        this.setIntMask(propClass, maskObj[propClass], option, null);
                        break;
                    case 'cpf':
                        /*jquery mask option*/
                        var option = {};
                        if (!optionObj instanceof Object || $.isEmptyObject(optionObj)) {
                            option = {
                                reverse: true,
                                maxlength: 14
                            };
                        } else {
                            if (optionObj.hasOwnProperty(propClass)) option = optionObj[propClass];
                        }

                        this.setNormalMask(propClass, maskObj[propClass], option, null);
                        break;
                    default:
                        this.setNormalMask(propClass, maskObj[propClass], option);
                        break;
                }

            }
        } catch (e) {
            console.log('Region.setMaskForAll() : ', e);
        }
    };
    this.setNormalMask = function(classe, mask, option, placeholder) {
        if (!classe || typeof classe != 'string') return;
        if (!mask || typeof mask != 'string') return;
        if ($('.' + classe).length > 0) {
            $('.' + classe).mask(mask, option).attr({
                'placeholder': !placeholder ? mask : placeholder
            });
        }
    };
    this.setDateShortMask = function(classe, mask, option, placeholder) {
        if (!classe || typeof classe != 'string') return;
        if (!mask || typeof mask != 'string') return;
        if ($('.' + classe).length > 0) {

            /*definição de formatação*/
            var newMask = '00/00/00';
            switch (mask) {
                case 'DD/MM/YY':
                    newMask = 'a0/b0/00';
                    break;
                case 'MM/DD/YY':
                    newMask = 'b0/a0/00';
                    break;
            }

            $('.' + classe).mask(newMask, option).attr({
                'placeholder': (!placeholder ? mask : placeholder)
            });
        }
    };
    this.setDateFullMask = function(classe, mask, option, placeholder) {
        if (!classe || typeof classe != 'string') return;
        if (!mask || typeof mask != 'string') return;
        if ($('.' + classe).length > 0) {

            /*definição de formatação*/
            var newMask = '00/00/0000';
            switch (mask) {
                case 'DD/MM/YYYY':
                    newMask = 'a0/b0/0000';
                    break;
                case 'MM/DD/YYYY':
                    newMask = 'b0/a0/0000';
                    break;
            }

            $('.' + classe).mask(newMask, option).attr({
                'placeholder': !placeholder ? mask : placeholder
            });
        }
    };
    this.setTimeShortMask = function(classe, mask, option, placeholder) {
        if (!classe || typeof classe != 'string') return;
        if (!mask || typeof mask != 'string') return;
        if ($('.' + classe).length > 0) {
            $('.' + classe).mask('a0:b0', option).attr({
                'placeholder': !placeholder ? mask : placeholder
            });
        }
    };
    this.setTimeFullMask = function(classe, mask, option, placeholder) {
        if (!classe || typeof classe != 'string') return;
        if (!mask || typeof mask != 'string') return;
        if ($('.' + classe).length > 0) {
            $('.' + classe).mask('a0:b0:b0', option).attr({
                'placeholder': !placeholder ? mask : placeholder
            });
        }
    };
    this.setDateTime24Mask = function(classe, mask, option, placeholder) {
        if (!classe || typeof classe != 'string') return;
        if (!mask || typeof mask != 'string') return;
        if ($('.' + classe).length > 0) {

            /*definição de formatação*/
            var newMask = '00/00/0000 00:00:00';
            switch (mask) {
                case 'DD/MM/YYYY HH:mm:ss':
                    newMask = 'a0/b0/0000 c0:d0:d0';
                    break;
                case 'MM/DD/YYYY HH:mm:ss':
                    newMask = 'b0/a0/0000 c0:d0:d0';
                    break;
            }

            $('.' + classe).mask(newMask, option).attr({
                'placeholder': !placeholder ? mask : placeholder
            });
        }
    };
    this.setDateTime12Mask = function(classe, mask, option, placeholder) {
        if (!classe || typeof classe != 'string') return;
        if (!mask || typeof mask != 'string') return;
        if ($('.' + classe).length > 0) {

            /*definição de formatação*/
            var newMask = '00/00/0000 00:00:00 ef';
            switch (mask) {
                case 'DD/MM/YYYY HH:mm:ss ap':
                    newMask = 'a0/b0/0000 c0:d0:d0 ef';
                    break;
                case 'MM/DD/YYYY HH:mm:ss ap':
                    newMask = 'b0/a0/0000 c0:d0:d0 ef';
                    break;
            }

            $('.' + classe).mask(newMask, option).attr({
                'placeholder': !placeholder ? mask : placeholder
            });
        }
    };
    this.setMoneyMask = function(classe, mask, option, placeholder) {
        if (!classe || typeof classe != 'string') return;
        if (!mask || typeof mask != 'string') return;
        if ($('.' + classe).length > 0) {
            $('.' + classe).mask(mask, option).attr({
                'placeholder': !placeholder ? mask : placeholder
            });
        }
    }
	this.removeObjectMoneyMask = function(obj) {
        if($(obj) && $(obj).length > 0)
			$(obj).unmask();
    };
    this.setDecimalMask = function(classe, mask, option, placeholder) {
        if (!classe || typeof classe != 'string') return;
        if (!mask || typeof mask != 'string') return;
        if ($('.' + classe).length > 0) {
            $('.' + classe).mask(mask, option).attr({
                'placeholder': !placeholder ? mask : placeholder
            });
        }
    };
    this.setIntMask = function(classe, mask, option, placeholder) {
        if (!classe || typeof classe != 'string') return;
        if (!mask || typeof mask != 'string') return;
        if ($('.' + classe).length > 0) {
            $('.' + classe).mask(mask, option).attr({
                'placeholder': !placeholder ? mask : placeholder
            });
        }
    };
    this.getCurrencySymbol = function(c) {
        if (c == 'ALL') return 'Lek';
        if (c == 'ARS') return '$';
        if (c == 'AWG') return 'f';
        if (c == 'AUD') return '$';
        if (c == 'BSD') return '$';
        if (c == 'BBD') return '$';
        if (c == 'BYR') return 'p.';
        if (c == 'BZD') return 'BZ$';
        if (c == 'BMD') return '$';
        if (c == 'BOB') return '$b';
        if (c == 'BAM') return 'KM';
        if (c == 'BWP') return 'P';
        if (c == 'BRL') return 'R$';
        if (c == 'BND') return '$';
        if (c == 'CAD') return '$';
        if (c == 'KYD') return '$';
        if (c == 'CLP') return '$';
        if (c == 'CNY') return '&yen;';
        if (c == 'COP') return '$';
        if (c == 'CRC') return 'c';
        if (c == 'HRK') return 'kn';
        if (c == 'CZK') return 'Kc';
        if (c == 'DKK') return 'kr';
        if (c == 'DOP') return 'RD$';
        if (c == 'XCD') return '$';
        if (c == 'EGP') return '&pound;';
        if (c == 'SVC') return '$';
        if (c == 'EEK') return 'kr';
        if (c == 'EUR') return '&euro;';
        if (c == 'FKP') return '&pound;';
        if (c == 'FJD') return '$';
        if (c == 'GBP') return '&pound;';
        if (c == 'GHC') return 'c';
        if (c == 'GIP') return '&pound;';
        if (c == 'GTQ') return 'Q';
        if (c == 'GGP') return '&pound;';
        if (c == 'GYD') return '$';
        if (c == 'HNL') return 'L';
        if (c == 'HKD') return '$';
        if (c == 'HUF') return 'Ft';
        if (c == 'ISK') return 'kr';
        if (c == 'IDR') return 'Rp';
        if (c == 'IMP') return '&pound;';
        if (c == 'JMD') return 'J$';
        if (c == 'JPY') return '&yen;';
        if (c == 'JEP') return '&pound;';
        if (c == 'LVL') return 'Ls';
        if (c == 'LBP') return '&pound;';
        if (c == 'LRD') return '$';
        if (c == 'LTL') return 'Lt';
        if (c == 'MYR') return 'RM';
        if (c == 'MXN') return '$';
        if (c == 'MZN') return 'MT';
        if (c == 'NAD') return '$';
        if (c == 'ANG') return 'f';
        if (c == 'NZD') return '$';
        if (c == 'NIO') return 'C$';
        if (c == 'NOK') return 'kr';
        if (c == 'PAB') return 'B/.';
        if (c == 'PYG') return 'Gs';
        if (c == 'PEN') return 'S/.';
        if (c == 'PLN') return 'zl';
        if (c == 'RON') return 'lei';
        if (c == 'SHP') return '&pound;';
        if (c == 'SGD') return '$';
        if (c == 'SBD') return '$';
        if (c == 'SOS') return 'S';
        if (c == 'ZAR') return 'R';
        if (c == 'SEK') return 'kr';
        if (c == 'CHF') return 'CHF';
        if (c == 'SRD') return '$';
        if (c == 'SYP') return '&pound;';
        if (c == 'TWD') return 'NT$';
        if (c == 'TTD') return 'TT$';
        if (c == 'TRY') return 'TL';
        if (c == 'TRL') return '&pound;';
        if (c == 'TVD') return '$';
        if (c == 'GBP') return '&pound;';
        if (c == 'USD') return '$';
        if (c == 'UYU') return '$U';
        if (c == 'VEF') return 'Bs';
        if (c == 'ZWD') return 'Z$';
        return '';
    }
}

/* HANDLEBARS HELPERS */
Handlebars.registerHelper('Timezone', function(timestamp) {
    m = moment(timestamp).tz(DEF_CONFIG.get('REGIONAL').locale.timezoneName).format('lll');
    return m;
    // return options.fn(this);
});