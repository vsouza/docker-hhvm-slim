function MyHandlebars(data, target) {
    this.data = null;
    this.target = null;
    this.scriptTarget = null;

    if (!(data instanceof Object)) return;
    if ($.isEmptyObject(data)) return;
    if (!target || typeof target != 'string') return;

    this.data = data;
    this.target = "#" + target;
    this.scriptTarget = "#tpl_" + target;
    var self = this;

    this.simpleRender = function() {
        try {
            var toCompile = $(self.scriptTarget).html(); // captura o template script a ser compilado
            var doCompile = Handlebars.compile(toCompile); // prepara o processo de compilação atraves do método .compile()
            var result = doCompile(self.data); // executa o processo de compilação retornando o resultado na variável [result]
            $(self.target).html(result).css('visibility', 'visible'); // aplica o resultado no [target] que veio do parâmetro
        } catch (e) {
            console.log('MyHandlebars.simpleRender(): ' + e);
        }
    };
    this.appendRender = function() {
        try {
            var toCompile = $(self.scriptTarget).html(); // captura o template script a ser compilado
            var doCompile = Handlebars.compile(toCompile); // prepara o processo de compilação atraves do método .compile()
            var result = doCompile(self.data); // executa o processo de compilação retornando o resultado na variável [result]
            $(self.target).append(result).css('visibility', 'visible'); // aplica o resultado no [target] que veio do parâmetro
        } catch (e) {
            console.log('MyHandlebars.simpleRender(): ' + e);
        }
    };
    this.setHelpers = function(objMask) {
        if (typeof objMask !== 'object' || $.isEmptyObject(objMask)) return false;

        if (inObject('dateShort', objMask)) {
            Handlebars.registerHelper('dateShort', function(data, options) {
                if (moment.utc(data).isValid()) {
                    return moment.utc(data).format(objMask.dateShort);
                } else {
                    return data;
                }
            });
        }
        if (inObject('dateFull', objMask)) {
            Handlebars.registerHelper('dateFull', function(data, options) {
                if (!data) return '';
                if (moment.utc(data).isValid()) {
                    return moment.utc(data).format(objMask.dateFull);
                } else {
                    return data;
                }
            });
        }
        if (inObject('dateTime24', objMask)) {
            Handlebars.registerHelper('dateTime24', function(data, options) {
                if (!data) return '';
                if (moment.utc(data).isValid()) {
                    return moment.utc(data).format(objMask.dateTime24);
                } else {
                    return data;
                }
            });
        }
        if (inObject('dateTime12', objMask)) {
            Handlebars.registerHelper('dateTime12', function(data, options) {
                if (!data) return '';
                if (moment.utc(data).isValid()) {
                    return moment.utc(data).format(objMask.dateTime12);
                } else {
                    return data;
                }
            });
        }
        if (inObject('dateTimeUTC', objMask)) {
            Handlebars.registerHelper('dateTimeUTC', function(data, options) {
                if (!data) return '';
                if (moment.utc(data).isValid()) {
                    return moment.utc(data).format('DD/MM/YYYY HH:mm:ss.SSS Z');
                } else {
                    return data;
                }
            });
        }
    };
}

/* Helper para captalizar a primeira letra da string recebida  */
Handlebars.registerHelper('upFirst', function(data, options) {
    if (!data || typeof data != 'string') return data;
    return data.charAt(0).toUpperCase() + data.slice(1);
});

/* Helper para criação de um foreach com auxílio de first/last/index
 * {{# foreach foo}} <div class = '{{#if $first}} first{{/if}}{{#if $last}} last{{/if}}' > </div> {{/foreach}}
 */
Handlebars.registerHelper("foreach", function(arr, options) {
    if (options.inverse && !arr.length)
        return options.inverse(this);

    return arr.map(function(item, index) {
        item.$index = index;
        item.$first = index === 0;
        item.$last = index === arr.length - 1;
        return options.fn(item);
    }).join('');
});

/* Helper de aplicação de módulo*/
Handlebars.registerHelper("moduloIf", function(index_count, mod, block) {
    if (parseInt(index_count) % (mod) === 0) {
        return block.fn(this);
    }
});

// Handlebars condition
Handlebars.registerHelper('hIf', function(v1, operator, v2, options) {
    switch (operator) {
        case '==':
            return (v1 == v2) ? options.fn(this) : options.inverse(this);
        case '!=':
            return (v1 != v2) ? options.fn(this) : options.inverse(this);
        case '===':
            return (v1 === v2) ? options.fn(this) : options.inverse(this);
        case '<':
            return (v1 < v2) ? options.fn(this) : options.inverse(this);
        case '<=':
            return (v1 <= v2) ? options.fn(this) : options.inverse(this);
        case '>':
            return (v1 > v2) ? options.fn(this) : options.inverse(this);
        case '>=':
            return (v1 >= v2) ? options.fn(this) : options.inverse(this);
        case '&&':
            return (v1 && v2) ? options.fn(this) : options.inverse(this);
        case '||':
            return (v1 || v2) ? options.fn(this) : options.inverse(this);
        default:
            return options.inverse(this);
    }
});

// formatação de money
Handlebars.registerHelper('money', function(money, symbol) {
    try {
        if ((!money && money != 0) || isNaN(money)) throw money;

        money = $.currency(money, {
            region: window.g.currency,
            thousands: window.g.thousandSymbol,
            decimal: window.g.decimalSymbol,
            decimals: window.g.decimalCount,
            hidePrefix: (symbol == false),
            hidePostfix: true,
        });
    } catch (e) {
        console.log('Handlebars money helper error : ', e);
    } finally {
        return money;
    }
});

// formatação de money
Handlebars.registerHelper('accountmoney', function(money, symbol) {
    try {
        if ((!money && money != 0) || isNaN(money)) throw money;

        money = $.currency(money, {
            region: window.g.accountLang.currency,
            thousands: window.g.accountLang.thousandSymbol,
            decimal: window.g.accountLang.decimalSymbol,
            decimals: window.g.accountLang.decimalCount,
            hidePrefix: (symbol == false),
            hidePostfix: true,
        });
    } catch (e) {
        console.log('Handlebars money helper error : ', e);
    } finally {
        return money;
    }
});

// formatação de money
// Handlebars.registerHelper('accountmoney', function(money, symbol) {
//     try {
//         if ((!money && money != 0) || isNaN(money)) throw money;

//         money = $.currency(money, {
//             region: window.g.accountLang.currency,
//             thousands: window.g.accountLang.thousandSymbol,
//             decimal: window.g.accountLang.decimalSymbol,
//             decimals: window.g.accountLang.decimalCount,
//             hidePrefix: (symbol == false),
//             hidePostfix: true,
//         });
//     } catch (e) {
//         console.log('Handlebars money helper error : ', e);
//     } finally {
//         return money;
//     }
// });

// formatação de int's
Handlebars.registerHelper('int', function(int) {
    try {
        if (int == 0) return 0;
        if (!int || isNaN(int)) throw int;

        int = tryParse(int, 'int', 0);
        int = $.number(int, 0, window.g.decimalSymbol, window.g.thousandSymbol);
    } catch (e) {
        console.log('Handlebars int helper error : ', e);
    } finally {
        return int;
    }
});

// STATUS
// 1 - ativas
// 2 - pausadas
// 3 - excluídas
// TODO Separar
//// 4 - finalizadas
//// 5 - agendadas
//// 6 - pendentes

Handlebars.registerHelper('campaignStatus', function(status) {
    // console.log('campaignStatus', status);

    var classe = '';
    var label;

    if (!status)
        return '<span class="status ' + classe + '">' + label + '</span>';

    if (typeof status == 'string') {
        switch (status.toLowerCase()) {
            case 'active':
                classe = 'active';
                label = _('fbActive');
                break;
            case 'paused':
            case 'campaign_group_paused':
                classe = 'paused';
                label = _('fbPaused');
                break;
            case 'archived':
                classe = 'archived';
                label = _('fbArchived');
                break;
            case 'deleted':
                classe = 'excluded';
                label = _('fbDeleted');
                break;
            default:
                console.log('wrong code campaignStatus: ', status);
        }
    } else {
        switch (status) {
            case 1:
                classe = 'active';
                label = _('fbActive');
                break;
            case 2:
                classe = 'paused';
                label = _('fbPaused');
                break;
            case 3:
                classe = 'excluded';
                label = _('fbDeleted');
                break;
            case 4:
                classe = 'finalized';
                label = _('fbFinished');
                break;
            case 5:
                classe = 'scheduled';
                label = _('fbScheduled');
                break;
            case 6:
                classe = 'pending';
                label = _('fbPending');
                break;
            default:
                console.log('wrong code campaignStatus: ', status);
        }
    }

    if(label) return '<span class="status ' + classe + '">' + label + '</span>';
    return '';
});

// 1 - Fãs
// 2 - Conteúdo
// 3 - Site
Handlebars.registerHelper('campaignType', function(objective) {
    var classe;
    var label;
    switch (objective) {
        case 'POST_ENGAGEMENT':
            classe = 'typecontent';
            label = _('fbContent');
            break;
        case 'PAGE_LIKES':
            classe = 'fans';
            label = _('fbFans');
            break;
        case 'WEBSITE_CONVERSIONS':
        case 'WEBSITE_CLICKS':
            classe = 'website';
            label = _('fbWebsite');
            break;
    }

    if (label)
        return '<span class="type ' + classe + '"><b></b><span>' + label + '</span></span>';
    else
        return '<span class="type"><b class="clear"></b></span>';
});

/** Handlebars Facebook Account Status Helpers **/

/* STATUS
1 = Active
2 = Disabled
3 = Unsettled
7 = Pending Review
101 = temporarily unavailable
100 = pending closure.)
*/
Handlebars.registerHelper('fbAccountStatus', function(status) {
    switch (status) {
    case 1:
        return _('fbActive');
    case 2:
        return _('fbDisabled');
    case 3:
        return _('fbUnsettled');
    case 7:
        return _('fbPendingReview');
    case 101:
        return _('fbTempUnavailable');
    case 100:
        return _('fbPendingClosure');
    }
});
