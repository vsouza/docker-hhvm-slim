// Função eu efetua o cálculo de porcentagem, baseando-se em  uma regra de três -> [returnType: 0 = inteiro; 1 = decimal;]

function calcPercent(part, total, returnType) {
    try {
        var out = 0;
        if (!part || isNaN(part)) throw 'invalid part param';
        if (!total || isNaN(total)) throw 'invalid total param';

        part = parseFloat(part);
        total = parseFloat(total);

        if (total < 1) throw 'invalid total param';

        out = ((part * 100) / total);

        if (parseInt(returnType) == 0) {
            out = parseInt(out)
        } else {
            out = out.toFixed(2)
        }

        return out;
    } catch (e) {
        console.log('calcPercent(): ' + e);
        return 0
    }
};

// Função que remove o offset de centavos de um valor monetario retornado pelo facebook, exemplo 1000(centavos) -> 10(reais)

function fbOffsetCalc(code, cents) {
    if (!code || typeof code != "string") return 0;
    if (!cents || isNaN(cents)) return 0;
    if (parseFloat(cents) < 0) return 0;

    if (code == 'ARS') return cents / 100;
    if (code == 'AUD') return cents / 100;
    if (code == 'BOB') return cents / 100;
    if (code == 'BRL') return cents / 100;
    if (code == 'GBP') return cents / 100;
    if (code == 'BGN') return cents / 100;
    if (code == 'CAD') return cents / 100;
    if (code == 'CLP') return cents / 1;
    if (code == 'COP') return cents / 1;
    if (code == 'CRC') return cents / 1;
    if (code == 'CZK') return cents / 100;
    if (code == 'DKK') return cents / 100;
    if (code == 'EUR') return cents / 100;
    if (code == 'GTQ') return cents / 100;
    if (code == 'HNL') return cents / 100;
    if (code == 'HKD') return cents / 100;
    if (code == 'HUF') return cents / 1;
    if (code == 'ISK') return cents / 1;
    if (code == 'INR') return cents / 100;
    if (code == 'ILS') return cents / 100;
    if (code == 'JPY') return cents / 1;
    if (code == 'KRW') return cents / 1;
    if (code == 'MOP') return cents / 100;
    if (code == 'MYR') return cents / 100;
    if (code == 'MXN') return cents / 100;
    if (code == 'NZD') return cents / 100;
    if (code == 'NIO') return cents / 100;
    if (code == 'NOK') return cents / 100;
    if (code == 'PYG') return cents / 1;
    if (code == 'PEN') return cents / 100;
    if (code == 'PHP') return cents / 100;
    if (code == 'PLN') return cents / 100;
    if (code == 'QAR') return cents / 100;
    if (code == 'RON') return cents / 100;
    if (code == 'RUB') return cents / 100;
    if (code == 'SAR') return cents / 100;
    if (code == 'SGD') return cents / 100;
    if (code == 'ZAR') return cents / 100;
    if (code == 'SEK') return cents / 100;
    if (code == 'CHF') return cents / 100;
    if (code == 'TWD') return cents / 1;
    if (code == 'THB') return cents / 100;
    if (code == 'TRY') return cents / 100;
    if (code == 'AED') return cents / 100;
    if (code == 'USD') return cents / 100;
    if (code == 'UYU') return cents / 100;
    if (code == 'VEF') return cents / 100;
}

// Função que retorna a quantidade de casas decimais que a moeda utiliza (0,2)

function getDecimalCurrency(code) {
    if (!code || typeof code != "string") return 0;

    if (code == 'ARS') return 2;
    if (code == 'AUD') return 2;
    if (code == 'BOB') return 2;
    if (code == 'BRL') return 2;
    if (code == 'GBP') return 2;
    if (code == 'BGN') return 2;
    if (code == 'CAD') return 2;
    if (code == 'CLP') return 0;
    if (code == 'COP') return 0;
    if (code == 'CRC') return 0;
    if (code == 'CZK') return 2;
    if (code == 'DKK') return 2;
    if (code == 'EUR') return 2;
    if (code == 'GTQ') return 2;
    if (code == 'HNL') return 2;
    if (code == 'HKD') return 2;
    if (code == 'HUF') return 0;
    if (code == 'ISK') return 0;
    if (code == 'INR') return 2;
    if (code == 'ILS') return 2;
    if (code == 'JPY') return 0;
    if (code == 'KRW') return 0;
    if (code == 'MOP') return 2;
    if (code == 'MYR') return 2;
    if (code == 'MXN') return 2;
    if (code == 'NZD') return 2;
    if (code == 'NIO') return 2;
    if (code == 'NOK') return 2;
    if (code == 'PYG') return 0;
    if (code == 'PEN') return 2;
    if (code == 'PHP') return 2;
    if (code == 'PLN') return 2;
    if (code == 'QAR') return 2;
    if (code == 'RON') return 2;
    if (code == 'RUB') return 2;
    if (code == 'SAR') return 2;
    if (code == 'SGD') return 2;
    if (code == 'ZAR') return 2;
    if (code == 'SEK') return 2;
    if (code == 'CHF') return 2;
    if (code == 'TWD') return 0;
    if (code == 'THB') return 2;
    if (code == 'TRY') return 2;
    if (code == 'AED') return 2;
    if (code == 'USD') return 2;
    if (code == 'UYU') return 2;
    if (code == 'VEF') return 2;
}

// Sets account currency based on language configs

function setAccountCurrency(lang) {
    lang = FB_LANGS[lang];
    if (LANGUAGES[lang]) {
        var regional = LANGUAGES[lang];
    } else {
        lang = DEF_CONFIG.get('LANGUAGE');
        var regional = DEF_CONFIG.get('REGIONAL');
    }
    window.g.accountLang = {
        currency: regional.locale.currency,
        thousandSymbol: regional.locale.thousandSymbol,
        decimalSymbol: regional.locale.decimalSymbol,
        decimalCount: regional.locale.decimalCount,
    }
}