// Paul Irish's lightweight logger
// usage: log('inside coolFunc',this,arguments);
window.log = function() {
    log.history = log.history || [];
    log.history.push(arguments);
    if (this.console) {
        console.log(Array.prototype.slice.call(arguments))
    }
};

/* Checar a existencia de um determinado arquivo */

function existFile(path) {
    if (!path || typeof path != 'string') return false;
};

/* Substitui todas as ocorrencias selecionadas dentro de uma string */

function replaceAll(string, token, newtoken) {
    if (!string || typeof string != 'string') return string;
    if (!token || typeof token != 'string') return string;

    var toReplace = new RegExp(token, 'g');
    return string.replace(toReplace, newtoken);
};

/* Reduz uma string a uma quantidade determinada */

function strSummary(str, len, strEnd) {
    if (!str || typeof str != 'string') return str;
    if (typeof strEnd != 'string') return str;
    if (str.length > len) {
        str = str.substring(0, len);
        var lastPos = str.lastIndexOf(' ');
        return str.substring(0, lastPos) + strEnd;
    } else {
        return str;
    }
};

/* Retorna verdadeiro quando um determinado valor é encontrado dentro de um array */

function inArray(value, array) {
    if (!value) return false;
    if (!$.isArray(array)) return false;

    for (i = 0, len = array.length; i < len; i++) {
        if (array[i] == value)
            return true;
    }

    return false;
};

/* Retorna a primeira ocorrência do array quando houver*/

function firstInArray(array) {
    if (!$.isArray(array)) return array;
    return array[0];
};

/* Retorna a última ocorrência do array quando houver*/

function lastInArray(array) {
    if (!$.isArray(array)) return array;
    return array[array.length - 1];
};

/* Verifica se o objeto possui a determinada propriedade [return true/false]*/

function inObject(prop, obj) {
    if (!prop || typeof prop != 'string') return false;

    if (obj instanceof Object && !$.isEmptyObject(obj)) {
        if (obj.hasOwnProperty(prop))
            return true;
        else
            return false;
    }
};


/* Faz a tentativa de conversão para um tipo proposto, retornando um o valor proposto ou um valor default previamente definido */

function tryParse(input, convertTo, def) {
    var output = null;
    try {
        if (input === null || input === '') throw "force error";

        switch (convertTo) {
            case 'float':
                output = parseFloat(input);
                if (isNaN(output) || !output || output === null) throw "force error";
                break;
            case 'int':
                output = parseInt(input);
                if (isNaN(output) || !output || output === null) throw "force error";
                break;
            case 'string':
                output = input.toString();
                break;
            case 'fbMoney':
                input = '' + input + '';
                input = input.toString();
                output = input.replace(/[^\d]+/g, '');
                output = parseInt(output);
                break;
            case 'justNumber':
                input = '' + input + '';
                input = input.toString();
                output = input.replace(/[^\d]+/g, '');
                output = parseInt(output);
                break;
            case 'unixTimestamp':
                break;
            case 'bool':
                input = '' + input + '';
                output = (input === '1' || input === 'true' ? true : false);
                break;
            default:
                break;
        }
    } catch (e) {
        output = def;
    }
    return output;
};

/* Função de validação de url */

function ValidUrl(str) {
    var pattern = new RegExp('^(https?:\\/\\/)?' + // protocol
        '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|' + // domain name
        '((\\d{1,3}\\.){3}\\d{1,3}))' + // OR ip (v4) address
        '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' + // port and path
        '(\\?[;&a-z\\d%_.~+=-]*)?' + // query string
        '(\\#[-a-z\\d_]*)?$', 'i'); // fragment locator
    if (!pattern.test(str)) {
        return false;
    } else {
        return true;
    }
};

/**
 * Prevents words in Ads Title and Text from having more than 20 characters
 */
function wordSizeSentinel() {
    var timeout;
    var fields = $('input#titAd,textarea#txtText');
    fields.keydown(function(event) {
        var el = $(this);
        var value = el.val();
        lastWordLenght = value.split(/\s+/).pop().length;
        if (lastWordLenght >= 20) {
            char = String.fromCharCode(event.which);
            if (char.match(/\s/)) return;
            event.preventDefault();
        }
    });
};

/**
 * Método de validação de extensão de vídeo
 * @param  {input:file} input : objeto html "input:file" contendo o
 * @return {Boolean}
 */
function isAllowedVideo(input) {
    try {
        var filePath = input.val();
        var extension = filePath.substr((filePath.lastIndexOf('.') + 1));
        if (window.g.arrVid.indexOf(extension) < 0) return false;
        return true;
    } catch (e) {
        return false;
    }
};

/**
 * Função que consulta o backend para leitura dos meta tags da url informada pelo usuário e armazena na variavel global
 * @param  {string} url: url digitada pelo usuário
 */
function getUrlMetaTags(url) {
    try {
        if (!ValidUrl(url)) throw 'invalid url';
        if (!window.g.metaTag.postGetMetaTags) throw 'invalid url to post';

        $.ajax({
            type: 'POST',
            url: window.g.metaTag.postGetMetaTags,
            data: {
                url: url
            },
            dataType: 'text',
            success: function(retur) {
                try {
                    if (retur) {
                        objReturn = JSON.parse(retur);
                        if (inObject('description', objReturn))
                            window.g.metaTag.description = objReturn.description;
                    }
                } catch (e) {
                    console.log('getUrlMetaTags().successError: ', e);
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.log('getUrlMetaTags().error: ', jqXHR, textStatus, errorThrown);
            }
        });
    } catch (e) {
        console.log('getUrlMetaTags() ', e);
    }
};
