// https://developers.facebook.com/tools/explorer
// Funções estáticas de callback que são chamadas pelo facebook
// *
// *  FBCallBack.FbUser.getUserParam() :
// *  FBCallBack.FbUser.getAdAccounts() :
// *  FBCallBack.FbUser.getAccessTokenInfo() :
// *  FBCallBack.FbUser.getConnectionObjects() : 
// *
// *  FBCallBack.AdAccount.fbRead():
// *
// *  FBCallBack.AdCampaign.fbCreate() : 
// *  FBCallBack.AdCampaign.fbRead() : 

var FBCallBack = {
    FbUser: {

        getUserParam: function(data) {
            /*objeto*/
            if (data instanceof Object && !$.isEmptyObject(data)) {
                if (inObject('error', data)) {
                    if (inObject('message', data)) {
                        alert(data.error.message);
                    }
                }

                if (inObject('id', data)) {
                    console.log('id:', data.id);
                }

            }

            /*bool*/
            if (typeof data === 'boolean') {
                if (data) {
                    alert('true');
                } else {
                    alert('false');
                }

            }
        },
        getAdAccounts: function(data) {
            console.log(data);
        },
        getAdAccountsAndSaveInCookie: function(data) {
            if (data instanceof Object && !$.isEmptyObject(data)) { //se o retorno for um objeto válido
                if (inObject('data', data)) { //se tiver a propriedade data
                    if ($.isArray(data.data)) { // se a propriedade data for um array 
                        if (data.data.length > 0) {
                            var accountIds = [];
                            for (i = 0, len = data.data.length; i < len; i++) {
                                if (inObject('account_id', data.data[i])) {
                                    accountIds.push(data.data[i].account_id);
                                }
                            }

                            if (tbCookie.has("objTbSession")) { //se tiver o cookie session
                                var s = JSON.parse(tbCookie.get("objTbSession")); // cookie -> objeto
                                s.accountIds = accountIds; // incremento o objeto 
                                tbCookie.remove("objTbSession"); // remove o cookie 
                                tbCookie.set("objTbSession", JSON.stringify(s)); // cria um novo cookie
                            } else {
                                tbCookie.set("objTbSession", {
                                    'accountIds': accountIds
                                });
                            }
                        }
                    }
                }
            }
        },
        getAccessTokenInfo: function(data) {
            console.log(data);
        },
        getConnectionObjects: function(data) {
            console.log(data);
        },
    },
    AdAccount: {
        fbRead: function(data) {
            console.log(data);
        },
        fbRead_AndSaveInCookie: function(data) {
            if (data instanceof Object && !$.isEmptyObject(data)) { //se o retorno for um objeto válido
                tbCookie.set("objTbAdAccount", JSON.stringify(data)); // cria um novo cookie objTbAdAccount
            }
        }
    },
    AdCampaign: {
        fbCreate: function(data) {
            console.log(data);
        },
        fbRead: function(data) {

        },
        fbRead_campaignListTable: function(data) {
            if (data instanceof Object && !$.isEmptyObject(data)) { //se o retorno for um objeto válido
                if (inObject('data', data)) { //se tiver a propriedade data
                    if ($.isArray(data.data)) { // se a propriedade data for um array 
                        if (data.data.length > 0) {

                            var objR = CreateClass.Regional(); // instance
                            objMask = objR.getObjParam('mask'); // get masks{}

                            var hand = new MyHandlebars(data.data, "campaignListTable"); // instance
                            hand.setHelpers(objMask); // passando as máscaras para criação dos helpers
                            hand.simpleRender(); // renderiza

                            $('.moneyCurrency').currency({
                                region: 'USD', // The 3 digit ISO code you want to display your currency in
                                thousands: ',', // Thousands separator
                                decimal: '.', // Decimal separator
                                decimals: 2, // How many decimals to show
                                hidePrefix: false, // Hide any prefix
                                hidePostfix: false, // Hide any postfix
                            });
                        }
                    }
                }
            }
        },
    },
};

//  USER 
// * https://developers.facebook.com/docs/reference/api/user/
// * https://developers.facebook.com/docs/reference/ads-api/connectionobjects/
// * 
// *  TO-DO : REFATORAR O MÉTODO FBLOGIN, PARA QUE CONSULTE SE HÁ O TOKEN PERMANETE PARA NÃO SOLICITAR UM NOVO TODA HORA
// *
// *  getFbObj() : retorna o objeto fbObj da classe.
// *  setFbObj() : seta parametros no objeto fbObj da classe.
// *  clearFbObj() : redefine o objeto fbObj da classe.
// *  getUserParam() : retorna as informações requerida através do parametro [arrParam] contidas no facebook.
// *  getAdAccounts() : retornaas informações de Ad Account do usuário contidas no facebook.
// *  fbLogin() : efetua login junto a api do facebook, já requisitando o token permanet.
// *  fbLogout() : destrói a sessão do facebook e os cookies criados na máquina do usuário.
// *  getAccessTokenInfo(): faz uma consulta no facebook sobre o token informado, que retora se há ou não permissão junto como tempo de expiração do mesmo
// *  getLoginStatus() : retorna o status de login do usuário no facebook de acordo com a sessão da máquina do cliente
// *  getConnectionObjects() : retorna objetos de conexão são os objetos (por exemplo, páginas de Facebook, aplicativos, etc)

function FbUser(fbObj) {
    this.uriMe = 'https://graph.facebook.com/me';
    this.uriOauth = 'https://graph.facebook.com/oauth';
    this.uriAct = 'https://graph.facebook.com/act_';
    this.uriPage = 'https://graph.facebook.com';

    this.fbObj = {};

    /* ação construtora */
    if (typeof fbObj === 'object' && !$.isEmptyObject(fbObj)) {
        this.fbObj = fbObj;
    }

    this.getFbObj = function() {
        return this.fbObj;
    };
    this.setFbObj = function(fbObj) {
        if (typeof fbObj === 'object' && !$.isEmptyObject(fbObj)) {
            this.fbObj = fbObj;
        }
    };
    this.clearFbObj = function() {
        this.fbObj = {};
    };
    this.getLoginStatus = function() {
        var o = {};
        FB.getLoginStatus(function(response) {
            console.log('FbUser.getLoginStatus (response): ', response);
            if (response.status === 'connected') { //sim está
                o.status = response.status;
                o.uid = response.authResponse.userID;
                o.accessToken = response.authResponse.accessToken;
            } else if (response.status === 'not_authorized') { //sim está porém não autorizou a ferramenta
                o.status = response.status;
            } else { // não ainda não está conectado
                o.status = '';
            }
        });

        return o;
    };
    this.getAccessTokenInfo = function(clientId, token) {
        if (!clientId || isNaN(clientId)) clientId = FB_CONFIG.get('APP_ID');
        if (!token || typeof token != 'string') return {};

        var o = {};
        o.client_id = clientId;
        o.access_token = token;
        o.redirect_uri = FB_CONFIG.get('SITE_URL');

        $.get(self.uriOauth + '/access_token_info', o, function(retorno) {
            // if (retorno) {
            //     if (typeof retorno === 'object' && !$.isEmptyObject(retorno)) {
            //         if (inObject('expires_in', retorno)) {
            //              token não é permanente
            //         }
            //     }
            // }
            // 
            FBCallBack.FbUser.getAccessTokenInfo(retorno);
        });
    };
    this.fbLogout = function() {
        tbCookie.removeAll();
        FB.logout(function(response) {
            window.location.reload(); /*reload page*/
        });
    };
    this.fbLogin = function() {
        var token = '';
        var self = this;
        FB.login(function(response) {
            console.log('FbUser.fbLogin (response): ', response);

            if (inObject('status', response)) {
                if (response.status === "connected") {
                    if (inObject('authResponse', response)) {
                        if (inObject('accessToken', response.authResponse)) {

                            /* Trocando token curto para token permanete */
                            var fb_exchange_token = response.authResponse.accessToken;

                            var o = {};
                            o.client_id = FB_CONFIG.get('APP_ID');
                            o.client_secret = FB_CONFIG.get('APP_SECRET');
                            o.grant_type = 'fb_exchange_token';
                            o.fb_exchange_token = fb_exchange_token;
                            o.response_type = 'token';
                            o.redirect_uri = FB_CONFIG.get('SITE_URL');

                            $.get(self.uriOauth + '/access_token', o, function(retorno) {
                                if (retorno) {
                                    var arr = retorno.split('&');
                                    for (i = 0, len = arr.length; i < len; i++) {
                                        if (arr[i].indexOf('access_token') > -1) {
                                            token = arr[i].replace("access_token=", "");
                                        }
                                    }

                                    if (!token) token = fb_exchange_token; // caso o token permanete não veio, usaremos o token de momento

                                    console.log('token fb_exchange_token: ', fb_exchange_token);
                                    console.log('token permanente: ', token);

                                    /* captura as informações do usuário 
                                     * retorna as informações que default que não necessitam de passar o access_token
                                     */
                                    FB.api('/me', function(response) {
                                        console.log('FB.api (response): ', response);

                                        var data = {
                                            token: token ? token : null,
                                            id: response.id ? response.id : null,
                                            name: response.name ? response.name : null,
                                            first_name: response.first_name ? response.first_name : null,
                                            middle_name: response.middle_name ? response.middle_name : null,
                                            last_name: response.last_name ? response.last_name : null,
                                            gender: response.gender ? response.gender : null,
                                            locale: response.locale ? response.locale : null,
                                            link: response.link ? response.link : null,
                                            username: response.username ? response.username : null,
                                            picture: response.picture ? response.picture : null
                                        };

                                        /* post no backend */
                                        console.log('backend post (data): ', data);

                                        /* Gravando as informações na sessão ao ivés de postar para o back end e obter o retorno*/
                                        if (!tbCookie.has("objTbSession")) {
                                            dataCookie = data;
                                            dataCookie.status = 'connected';

                                            if (dataCookie.token) {
                                                /* criando o cookie objTbSession */
                                                tbCookie.set("objTbSession", JSON.stringify(dataCookie));

                                                /* incrementando o cookie objTbSession */
                                                self.getAdAccounts(dataCookie.token, 'FBCallBack.FbUser.getAdAccountsAndSaveInCookie');

                                                //window.location.reload();
                                            }
                                        }

                                        // (function() {
                                        //     $.post("/fblogin", data, function(retorno) {
                                        //         if (retorno.success) {
                                        //             console.log('sucesso:', retorno);
                                        //         } else {
                                        //             console.log('falso:', retorno);
                                        //         }
                                        //     });
                                        // })();
                                    });
                                }
                            });
                        }
                    }
                }
            }
        }, {
            scope: FB_CONFIG.get('APP_SCOPE')
        });
    };
    this.getAdAccounts = function(token, arrFields, callbackFunction) {
        try {
            if (!token || typeof token !== 'string') throw 'invalid token';
            if (!callbackFunction) throw 'invalid callbackFunction';
            if (!arrFields || typeof arrFields !== 'string') arrFields = defaultFields;

            var url = this.uriMe + '/adaccounts/';
            var defaultFields = 'account_id,account_status,age,amount_spent,balance,business_city,business_country_code,business_name,business_state,business_street2,' +
                'business_street,business_zip,capabilities,currency,daily_spend_limit,is_personal,name,spend_cap,timezone_id,timezone_name,timezone_offset_hours_utc,' +
                'tos_accepted,users,vat_status';

            var objPost = {};
            objPost.access_token = token;
            objPost.callback = callbackFunction;
            objPost.fields = arrFields;

            $.ajax({
                type: 'GET',
                url: url,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('FbUser.getAdAccounts: ' + e);
                            }
                        }
                    } catch (e) {
                        console.log('FbUser.getAdAccounts: ' + e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (callbackFunction && typeof callbackFunction == 'string') {
                        eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                    } else {
                        console.log('FbUser.getAdAccounts: ' + e);
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && typeof e == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e + '\'}});');
            } else {
                console.log('FbUser.getAdAccounts: ' + e);
            }
        }
    };
    this.getUserParam = function(token, action, arrParam, callbackFunction) {
        try {
            if (!token || typeof token !== 'string') throw 'invalid token';
            if (!arrParam || !$.isArray(arrParam)) throw 'invalid arrParam';
            if (arrParam.length < 1) throw 'invalid arrParam';
            if (!callbackFunction) throw 'invalid callbackFunction';

            var url = this.uriMe;
            var objPost = {};
            objPost.access_token = token;
            objPost.fields = arrParam.join(',');
            objPost.callback = callbackFunction;

            $.ajax({
                type: 'GET',
                url: url,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('FbUser.getUserParam: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('FbUser.getUserParam: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (callbackFunction && typeof callbackFunction == 'string') {
                        eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                    } else {
                        console.log('FbUser.getUserParam: ', e);
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && typeof e == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e + '\'}});');
            } else {
                console.log('FbUser.getUserParam: ', e);
            }
        }
    };
    this.prettyName = function(accountId, name, business_name) {
        if (business_name) return business_name;
        else if (name) return name;
        else return accountId;
    };
    this.getConnectionObjects = function(token, accountId, locale, callbackFunction) {
        try {
            if (!token || typeof token !== 'string') throw 'invalid token';
            if (!locale || typeof locale !== 'string') throw 'invalid locale';
            if (!accountId || isNaN(accountId)) throw 'invalid accountId';
            if (!callbackFunction) throw 'invalid callbackFunction';

            var url = this.uriAct + accountId + '/connectionobjects';
            var objPost = {};
            objPost.access_token = token;
            objPost.locale = (locale ? locale : 'pt_BR');
            objPost.callback = callbackFunction;

            $.ajax({
                type: 'GET',
                url: url,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('FbUser.getConnectionObjects: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('FbUser.getConnectionObjects: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (callbackFunction && typeof callbackFunction == 'string') {
                        eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                    } else {
                        console.log('FbUser.getConnectionObjects: ', e);
                    }
                },
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && typeof e == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e + '\'}});');
            } else {
                console.log('FbUser.getConnectionObjects: ', e);
            }
        }
    };
    var self = this; /* mágica da orientação a objetos */
}

// PAGE 
// https://developers.facebook.com/docs/reference/api/page/
// *
// *   getPage(): retorna informações de uma fanpage
// *   getPromotablePosts() : retorna uma lista paginável de posts promovívies de uma determinada fanpage
// *   getPostInsights() : retorna os insights(resultados) do post solicitado
// *   getPagePermissions() : retorna as informações de permissões da página. Com os parametros default são retornados {id, token, permissões}
// *   deletePost() : [https://developers.facebook.com/docs/reference/api/deleting/] --> detela um post
// *   createStatusPost() : [https://developers.facebook.com/docs/graph-api/reference/page/#posts] --> cria um post {
//         [publish_stream and manage_pages] required!
//         retorna o postId(string) como sucesso! 
//     } 

function FbPage() {
    this.uriPage = 'https://graph.facebook.com';
    this.getPage = function(token, pageId, fields, callbackFunction) {
        try {
            if (!token || typeof token !== 'string') throw 'invalid token';
            if (!pageId || isNaN(pageId)) throw 'invalid pageId';
            if (!callbackFunction) throw 'invalid callbackFunction';

            var url = this.uriPage + '/' + pageId
            var objPost = {};
            objPost.access_token = token;
            objPost.callback = callbackFunction;

            if (fields && typeof fields === 'string')
                objPost.fields = fields;

            $.ajax({
                type: 'GET',
                url: url,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('FbPage.getPage: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('FbPage.getPage: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (callbackFunction && typeof callbackFunction == 'string') {
                        eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                    } else {
                        console.log('FbPage.getPage: ', e);
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && typeof e == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e + '\'}});');
            } else {
                console.log('FbPage.getPage: ', e);
            }
        }
    };
    this.getPromotablePosts = function(token, pageId, locale, fields, limit, callbackFunction, pagUrl) {
        try {
            if (!token || typeof token !== 'string') throw 'invalid token';
            if (!pageId || isNaN(pageId)) throw 'invalid pageId';
            if (!locale || typeof locale !== 'string') locale = DEF_CONFIG.get('LANGUAGE');
            if (!limit || isNaN(limit)) limit = 100;
            if (!callbackFunction) throw 'invalid callbackFunction';

            var url = (pagUrl && typeof pagUrl === 'string' ? pagUrl : this.uriPage + '/' + pageId + '/promotable_posts');
            var objPost = {};
            objPost.access_token = token;
            objPost.callback = callbackFunction;
            objPost.locale = locale;
            objPost.limit = limit;

            if (fields && typeof fields === 'string')
                objPost.fields = fields;

            $.ajax({
                type: 'GET',
                url: url,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('FbPage.getPromotablePosts: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('FbPage.getPromotablePosts: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (callbackFunction && typeof callbackFunction == 'string') {
                        eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                    } else {
                        console.log('FbPage.getPromotablePosts: ', e);
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && typeof e == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e + '\'}});');
            } else {
                console.log('FbPage.getPromotablePosts: ', e);
            }
        }
    };
    this.getPostInsights = function(token, postId, callbackFunction) {
        try {
            if (!token || typeof token !== 'string') throw 'invalid token';
            if (!postId || typeof postId !== 'string') throw 'invalid postId';
            if (postId.indexOf('_') < 0) throw 'invalid postId';
            if (!callbackFunction) throw 'invalid callbackFunction';

            var url = this.uriPage + '/' + postId + '/insights'
            var objPost = {};
            objPost.access_token = token;
            objPost.callback = callbackFunction;

            $.ajax({
                type: 'GET',
                url: url,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('FbPage.getPostInsights: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('FbPage.getPostInsights: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (callbackFunction && typeof callbackFunction == 'string') {
                        eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                    } else {
                        console.log('FbPage.getPostInsights: ', e);
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && typeof e == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e + '\'}});');
            } else {
                console.log('FbPage.getPostInsights: ', e);
            }
        }
    };
    this.getPagePermissions = function(token, fields, callbackFunction) {
        try {
            if (!token || typeof token !== 'string') throw 'invalid token';
            if (!callbackFunction) throw 'invalid callbackFunction';

            var defaultFields = "access_token,perms,id";

            var url = this.uriPage + '/me/accounts';
            var objPost = {};
            objPost.access_token = token;
            objPost.fields = ((!fields || typeof fields != 'string') ? defaultFields : fields);
            objPost.callback = callbackFunction;
            objPost.limit = 100;

            $.ajax({
                type: 'GET',
                url: url,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('FbPage.getPagePermissions: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('FbPage.getPagePermissions: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (callbackFunction && typeof callbackFunction == 'string') {
                        eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                    } else {
                        console.log('FbPage.getPagePermissions: ', e);
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && typeof e == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e + '\'}});');
            } else {
                console.log('FbPage.getPagePermissions: ', e);
            }
        }
    };
    this.deletePost = function(token, postId) {
        try {
            if (!token || typeof token !== 'string') throw 'invalid token';
            if (!postId || typeof postId !== 'string') throw 'invalid postId';

            var url = this.uriPage + 'postId';
            objPost.access_token = token;
            objPost.method = 'delete';

            $.ajax({
                type: 'POST',
                url: url,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('FbPage.deletePost: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('FbPage.deletePost: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (callbackFunction && typeof callbackFunction == 'string') {
                        eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                    } else {
                        console.log('FbPage.deletePost: ', e);
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && typeof e == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e + '\'}});');
            } else {
                console.log('FbPage.deletePost: ', e);
            }
        }
    }
    this.createStatusPost = function(objFbPost, pageToken, pageId, callbackFunction) {
        try {
            if (!pageToken || typeof pageToken !== 'string') throw 'invalid pageToken';
            if (!pageId || typeof pageId !== 'string') throw 'invalid pageId';
            if (!callbackFunction || typeof callbackFunction !== 'string') throw 'invalid callbackFunction';
            if (!objFbPost instanceof Object || $.isEmptyObject(objFbPost)) throw 'invalid objFbPost';

            var url = this.uriPage + '/' + pageId + '/feed';
            var objPost = {};

            for (p in objFbPost) {
                if (objFbPost[p]) objPost[p] = objFbPost[p];
            }

            objPost.access_token = pageToken;
            objPost.callback = callbackFunction;

            $.ajax({
                type: 'POST',
                url: url,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('FbPage.createStatusPost: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('FbPage.createStatusPost: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (callbackFunction && typeof callbackFunction == 'string') {
                        eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                    } else {
                        console.log('FbPage.createStatusPost: ', e);
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && typeof e == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e + '\'}});');
            } else {
                console.log('FbPage.createStatusPost: ', e);
            }
        }
    }
}

// AD ACCOUNT
// *  https://developers.facebook.com/docs/reference/ads-api/adaccount/
// *
// *  getFbObj() : retorna a propriedade fbObj{} que está instanciada
// *  setFbObj() : aplica valor a propriedade fbObj{} que está instanciada
// *  clearFbObj() : limpa a propriedade fbObj{} que está instanciada
// *  fbRead() : efetua a leitura das proprieadades Ad Account de acordo como que foi requisitado pelo parametro [arrFields]
// *  fbCreate() : cria Ad Account através da api do facebook.

function AdAccount(fbObj) {
    this.uri = 'https://graph.facebook.com/act_';
    this.fbObj = {};

    /* ação construtora */
    if (typeof fbObj === 'object' && !$.isEmptyObject(fbObj)) {
        if ($.isArray(fbObj)) {
            this.fbObj = fbObj;
        }
    }

    this.getFbObj = function() {
        return this.fbObj;
    };
    this.setFbObj = function(fbObj) {
        if (typeof fbObj === 'object' && !$.isEmptyObject(fbObj)) {
            this.fbObj = fbObj;
        }
    };
    this.clearFbObj = function() {
        this.fbObj = {};
    };
    this.fbRead = function(token, accountId, arrFields, callbackFunction) {
        try {
            if (!token || typeof token !== 'string') throw 'invalid token';
            if (!accountId || isNaN(accountId)) throw 'invalid accountId';

            var defaultFields = 'account_id,account_status,age,amount_spent,balance,business_city,business_country_code,business_name,business_state,business_street2,' +
                'business_street,business_zip,capabilities,currency,daily_spend_limit,is_personal,name,spend_cap,timezone_id,timezone_name,timezone_offset_hours_utc,' +
                'tos_accepted,users,vat_status';

            if (!arrFields || typeof arrFields !== 'string') arrFields = defaultFields;

            if (!callbackFunction) throw 'invalid callbackFunction';

            var url = this.uri + accountId;

            var objPost = {};
            objPost.access_token = token;
            objPost.callback = callbackFunction;
            objPost.fields = arrFields;

            /*post*/
            $.ajax({
                type: 'GET',
                url: url,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdAccount.fbRead: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('AdAccount.fbRead: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (callbackFunction && typeof callbackFunction == 'string') {
                        eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                    } else {
                        console.log('AdAccount.fbRead: ', e);
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && typeof e == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e + '\'}});');
            } else {
                console.log('AdAccount.fbRead: ', e);
            }
        }
    };
    this.fbStats = function(token, accountId, callbackFunction, start_time, end_time) {
        try {
            if (!token || typeof token !== 'string') throw 'invalid token';
            if (!accountId || isNaN(accountId)) throw 'invalid accountId';

            var arrFields = 'unique_impressions,spent';

            var url = this.uri + accountId + '/stats';
            if (start_time) {
                url += '/' + start_time;
                if (end_time) url += '/' + end_time;
            }

            if (!callbackFunction) throw 'invalid callbackFunction';

            var objPost = {};
            objPost.access_token = token;
            objPost.callback = callbackFunction;
            objPost.fields = arrFields;

            $.ajax({
                type: 'GET',
                url: url,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdAccount.getPeriodStatus: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('AdAccount.getPeriodStatus: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (callbackFunction && typeof callbackFunction == 'string') {
                        eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                    } else {
                        console.log('AdAccount.getPeriodStatus: ', e);
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && typeof e == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e + '\'}});');
            } else {
                console.log('AdAccount.getPeriodStatus: ', e);
            }
        }
    }
    this.fbCreate = function(token, name, currency, timezone, callbackFunction) {
        if (!token || typeof token !== 'string') return;
        if (!name || typeof name !== 'string') return;
        if (!currency || typeof currency !== 'string') return;
        if (!timezone || typeof timezone !== 'string') return;
    };
    this.GetCss = function(token, accountId, callbackFunction) {
        try {
            if (!token || typeof token != 'string') {
                $.error('Invalid token');
            }
            if (!accountId || isNaN(accountId)) {
                $.error('Invalid account id');
            }
            if (!callbackFunction) {
                $.error('Invalid callback function');
            };

            var uri = this.uri + accountId + "/adpreviewscss";
            var objPost = {};

            objPost.access_token = token;
            objPost.callback = callbackFunction;

            /*post*/
            $.ajax({
                type: 'GET',
                url: uri,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdAccount.GetCss: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('AdAccount.GetCss: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (jqXHR.hasOwnProperty('responseText')) {
                        try {
                            eval(jqXHR.responseText);
                        } catch (e) {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdAccount.GetCss: ', e);
                            }
                        }
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && e.hasOwnProperty('message') && typeof e.message == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e.message + '\'}});');
            } else {
                console.log('AdAccount.GetCss: ', e);
            }
        }
    }
}

// ADCAMPAIGN GROUPS
// *
// *  https://developers.facebook.com/docs/reference/ads-api/adcampaign-alpha NEW
// *
// AdCampaignGroup.Create() : método para criação de Campaign Group
// [*name] 
// [objective] (NONE (default), OFFER_CLAIMS, PAGE_LIKES, CANVAS_APP_INSTALLS, CANVAS_APP_ENGAGEMENT, EVENT_RESPONSES, POST_ENGAGEMENT, WEBSITE_CONVERSIONS, MOBILE_APP_INSTALLS, MOBILE_APP_ENGAGEMENT, WEBSITE_CLICKS)
// [*campaign_group_status] (ACTIVE, PAUSED, DELETED)

function AdCampaignGroup() {
    this.uri = 'https://graph.facebook.com/';
    this.Create = function(token, accountId, AdCampaignGroupObj, callbackFunction) {
        console.log('AdCampaignGroup.Create');
        try {
            if (!token || typeof token != 'string') throw 'invalid token';
            if (!accountId || isNaN(accountId)) throw 'invalid accountId';
            if (!(AdCampaignGroupObj instanceof Object) || $.isEmptyObject(AdCampaignGroupObj)) throw 'invalid AdCampaignGroupObj';
            if (!callbackFunction) throw 'invalid callbackFunction';

            var uri = this.uri + 'act_' + accountId + "/adcampaign_groups";
            AdCampaignGroupObj.access_token = token;
            AdCampaignGroupObj.callback = callbackFunction;

            /*post*/
            $.ajax({
                type: 'POST',
                url: uri,
                data: AdCampaignGroupObj,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdCampaignGroup.Create: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('AdCampaignGroup.Create: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (callbackFunction && typeof callbackFunction == 'string') {
                        eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                    } else {
                        console.log('AdCampaignGroup.Create: ', e);
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && typeof e == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e + '\'}});');
            } else {
                console.log('AdCampaignGroup.Create: ', e);
            }
        }
    };
}


//  CAMPAIGN / AD SET
// *
// *  https://developers.facebook.com/docs/reference/ads-api/adcampaign/ OLD
// *
// *  Constructor pode receber um array de objetos Ad Campaing.
// *  getArrObj() : retorna o array de objetos da classe.
// *  setArrObj() : aplica valor a propriedade "arrObj[]".
// *  clearArrObj() : redefine a propriedade "arrObj[]" igual a um array vazio.
// *  startAdCampaignForm() : aplica regra de validação ao furmulário html baseado, utilizando a lib [jquery.mask.min.js].
// *  getFormValue : camptura as informações inputadas no formulário, montando objetos Ad Campaing, aplicando valor a propriedade "arrObj[]".
// *  tryParseArrObj : efetua a tentativa de conversão de valores para ser enviado ao fb
// *  validArrObj : efetua a validação do objeto da classe definindo se o mesmo está pronto para ser enviado.
// *  fbCreate() :
// *  fbReadById() : Get campaign data from single campaign id
// *  fbRead() :
// *  fbUpdate() :
// *  fbDelete() :

function AdCampaign(arrObj, objCredentials) {
    this.uri = 'https://graph.facebook.com/';
    this.objCredentials = {};
    this.arrObj = [];
    this.postArrObj = [];

    this.getArrObj = function() {
        return this.arrObj;
    };
    this.setArrObj = function(arrObj) {
        if (typeof arrObj === 'object' && !$.isEmptyObject(arrObj)) {
            if ($.isArray(arrObj)) {
                this.arrObj = arrObj;
            }
        }
    };
    this.clearArrObj = function() {
        this.arrObj = [];
        this.postArrObj = [];
    };
    this.getCredentials = function() {
        return this.objCredentials;
    };
    this.setCredentials = function(objCredentials) {
        if (typeof objCredentials === 'object' && !$.isEmptyObject(objCredentials)) {
            this.objCredentials = objCredentials;
        }
    };
    this.startAdCampaignForm = function(strForm, strBudType, objMessage, errorContainer) {
        /*validação de nullabilidade*/
        if (!strForm || typeof strForm != 'string') return;
        if (!strBudType || typeof strBudType != 'string') return;
        if (typeof objMessage !== 'object') return;
        if (!errorContainer || typeof errorContainer != 'string') errorContainer = '';

        /* Validação de existência*/
        if ($(strForm).length < 1) return;
        if ($(strBudType).length < 1) return;

        /* Aplicando ação ao alterar tipo de budget*/
        $(strBudType).change(function() {
            if ($(this).val() === "2") {
                $('#lifetime_budget').attr('disabled', false);
                $('#daily_budget').attr('disabled', true);
            } else {
                $('#lifetime_budget').attr('disabled', true);
                $('#daily_budget').attr('disabled', false);
            }
        });

        /* chute inicial no tipo de budget*/
        $(strBudType).change();

        /*definição de data inicial para start_time*/
        var startTimeMask = getMaskFromElement(strForm, '#start_time');
        if (startTimeMask) $('#start_time').val(moment().format(startTimeMask));

        /* sintaxe de validação de formularios baseada na lib [jquery.mask.min.js]. */
        $(strForm).validate({
            submitHandler: function(form) { /*ação executada caso a validação tenha êxito*/
                if ($.isEmptyObject(self.objCredentials)) {
                    alert('credenciais para criação de campanhas são inválidas');
                }

                self.clearArrObj(); // limpa o objeto e captura as informações do formulário

                if (self.getFormValue(strForm)) { // captura informações do formulário
                    if (self.tryParseArrObj()) { // efetua a tentativa de 
                        console.log(self.postArrObj);
                        self.fbCreate(self.objCredentials.token, self.objCredentials.accountId, self.postArrObj, 'FBCallBack.AdCampaign.fbCreate');
                    } else {
                        alert('erro ao converter informações de envio para o facebook');
                    }
                } else {
                    alert('erro ao capturar informações do formulário');
                }
            },
            rules: {
                name: {
                    required: true,
                    maxlength: 100
                },
                campaign_status: {
                    required: true
                },
                daily_budget: {
                    required: {
                        depends: function(element) {
                            return $(strBudType).val() === "1" ? true : false;
                        }
                    }
                },
                lifetime_budget: {
                    required: {
                        depends: function(element) {
                            return $(strBudType).val() === "2" ? true : false;
                        }
                    }
                },
                start_time: {
                    required: false
                },
                end_time: {
                    required: {
                        depends: function(element) {
                            return $('#lifetime_budget').val() ? true : false;
                        }
                    }
                },
                redownload: {
                    required: false
                }
            },
            invalidHandler: function(ev, validator) {},
            highlight: function(element, errorClass) {
                $(element).fadeOut(function() {
                    $(element).fadeIn();
                });
            },
            messages: objMessage,
            errorLabelContainer: errorContainer,
            debug: true,
        });
    };
    this.getFormValue = function(formId) {
        if (!formId || typeof formId != 'string') return false;
        if ($(formId).length < 1) return false;
        try {

            /*capturando os valores do form [formId]*/
            var startTime = null;
            var startTimeMask = getMaskFromElement(formId, '#start_time');
            if (startTimeMask && $('#start_time', formId).length > 0) {
                startTime = moment.utc($('#start_time', formId).val(), startTimeMask).format('X');
            }

            var endTime = null;
            var endTimeMask = getMaskFromElement(formId, '#end_time');
            if (endTimeMask && $('#end_time', formId).length > 0) {
                endTime = moment.utc($('#end_time', formId).val(), endTimeMask).format('X');
            }

            this.arrObj.push({
                'name': $('#name', formId).length > 0 ? $('#name', formId).val() : null,
                'campaign_status': $('#campaign_status', formId).length > 0 ? $('#campaign_status', formId).val() : null,
                'daily_budget': $('#daily_budget', formId).length > 0 ? $('#daily_budget', formId).val() : null,
                'lifetime_budget': $('#lifetime_budget', formId).length > 0 ? $('#lifetime_budget', formId).val() : null,
                'start_time': startTime,
                'end_time': endTime,
                'redownload': $('#redownload', formId).length > 0 ? $('#redownload', formId).val() : null,
            });

            return true;
        } catch (e) {
            return false;
        }
    };
    this.tryParseArrObj = function() {
        if (this.arrObj.length < 1) return false;

        var array = this.arrObj;
        for (i = 0, len = array.length; i < len; i++) {
            var parsedObj = {};

            if (inObject('name', array[i])) {
                if (array[i].name) {
                    parsedObj.name = tryParse(array[i].name, 'string', '');
                }
            }
            if (inObject('campaign_status', array[i])) {
                if (array[i].campaign_status) {
                    parsedObj.campaign_status = tryParse(array[i].campaign_status, 'int', 1); /* default 1 Active */
                }
            }
            if (inObject('daily_budget', array[i])) {
                if (array[i].daily_budget) {
                    parsedObj.daily_budget = tryParse(array[i].daily_budget, 'fbMoney', 0); /* default 0 [0 centavos] */
                }
            }
            if (inObject('lifetime_budget', array[i])) {
                if (array[i].lifetime_budget) {
                    parsedObj.lifetime_budget = tryParse(array[i].lifetime_budget, 'fbMoney', 0); /* default 0 [0 centavos] */
                }
            }
            if (inObject('start_time', array[i])) {
                if (array[i].start_time) {
                    parsedObj.start_time = tryParse(array[i].start_time, 'int', null); /* null para ser eliminado */
                }
            }
            if (inObject('end_time', array[i])) {
                if (parsedObj.daily_budget && parsedObj.daily_budget > 0) {
                    parsedObj.end_time = 0;
                } else {
                    if (array[i].end_time) {
                        parsedObj.end_time = tryParse(array[i].end_time, 'int', null); /* null para ser eliminado */
                    }
                }
            }
            if (inObject('redownload', array[i])) {
                if (array[i].redownload) {
                    parsedObj.redownload = tryParse(array[i].redownload, 'bool', false); /* null para ser eliminado */
                }
            }

            this.postArrObj.push(parsedObj);
        }

        /*validação do objeto parseado*/
        return this.validArrObj(this.postArrObj);
    };
    this.validArrObj = function(arrObj) {
        if (!(arrObj instanceof Object) || $.isEmptyObject(arrObj)) return false;
        if (!$.isArray(arrObj)) return false;
        if (arrObj.length < 1) return false;

        for (i = 0, len = arrObj.length; i < len; i++) {

            if (inObject('name', arrObj[i])) {
                if (arrObj[i].name === '') return false;
            }

            if (inObject('daily_budget', arrObj[i]) && inObject('lifetime_budget', arrObj[i])) {
                if (arrObj[i].daily_budget === 0 && arrObj[i].daily_budget === 0) return false;
            }

            if (inObject('start_time', arrObj[i])) {
                if (isNaN(arrObj[i].start_time)) return false;
            }

            if (inObject('end_time', arrObj[i])) {
                if (isNaN(arrObj[i].end_time)) return false;
            }

            /* quando for daily_budget especificar end_time=0 */
            if (inObject('daily_budget', arrObj[i]) && inObject('end_time', arrObj[i])) {
                if (arrObj[i].daily_budget > 0) {
                    arrObj[i].end_time = 0;
                }
            }

            /* quando for lifetime_budget é obrigatório especificar o end_time*/
            if (inObject('lifetime_budget', arrObj[i]) && inObject('end_time', arrObj[i])) {
                if (arrObj[i].lifetime_budget > 0 && arrObj[i].end_time < 1) {
                    return false;
                }
            }

            if (inObject('lifetime_budget', arrObj[i])) {
                if (!inObject('end_time', arrObj[i])) return false;
            }

        }
        return true;
    };
    this.fbCreate = function(token, accountId, adCampaignObj, callbackFunction) {
        try {
            if (!token || typeof token != 'string') throw 'invalid token';
            if (!accountId || isNaN(accountId)) throw 'invalid accountId';
            if (!(adCampaignObj instanceof Object) || $.isEmptyObject(adCampaignObj)) throw 'invalid adCampaignObj';
            if (!callbackFunction) throw 'invalid callbackFunction';

            var uri = this.uri + 'act_' + accountId + "/adcampaigns";

            /*incrementa o objeto de adCampaignObjetros para o post*/
            if ($.isArray(adCampaignObj)) {
                if (adCampaignObj.length > 0) {
                    for (var i = 0, len = adCampaignObj.length; i < len; i++) {
                        adCampaignObj[i].access_token = token;
                        adCampaignObj[i].callback = callbackFunction;

                        /*post*/
                        $.ajax({
                            type: 'POST',
                            url: uri,
                            data: adCampaignObj[i],
                            dataType: 'text',
                            cache: false,
                            crossDomain: true,
                            success: function(fbReturn) {
                                try {
                                    if (fbReturn && typeof fbReturn == 'string') {
                                        eval(fbReturn);
                                    } else {
                                        if (callbackFunction && typeof callbackFunction == 'string') {
                                            eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                                        } else {
                                            console.log('AdCampaign.fbCreate: ', e);
                                        }
                                    }
                                } catch (e) {
                                    console.log('AdCampaign.fbCreate: ', e);
                                }
                            },
                            error: function(jqXHR, textStatus, errorThrown) {
                                if (callbackFunction && typeof callbackFunction == 'string') {
                                    eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                                } else {
                                    console.log('AdCampaign.fbCreate: ', e);
                                }
                            }
                        });
                    }
                }
            } else {
                console.log('fbCreate adCampaignObj',adCampaignObj);
                adCampaignObj.access_token = token;
                adCampaignObj.callback = callbackFunction;

                /*post*/
                $.ajax({
                    type: 'POST',
                    url: uri,
                    data: adCampaignObj,
                    dataType: 'text',
                    cache: false,
                    crossDomain: true,
                    success: function(fbReturn) {
                        try {
                            if (fbReturn && typeof fbReturn == 'string') {
                                eval(fbReturn);
                            } else {
                                if (callbackFunction && typeof callbackFunction == 'string') {
                                    eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                                } else {
                                    console.log('AdCampaign.fbCreate: ', e);
                                }
                            }
                        } catch (e) {
                            console.log('AdCampaign.fbCreate: ', e);
                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        if (callbackFunction && typeof callbackFunction == 'string') {
                            eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                        } else {
                            console.log('AdCampaign.fbCreate: ', e);
                        }
                    }
                });
            }
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && typeof e == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e + '\'}});');
            } else {
                console.log('AdCampaign.fbCreate: ', e);
            }
        }
    };
    this.fbReadById = function(token, campaignId, fields, callbackFunction) {
        try {
            if (!token || typeof token != 'string') {
                $.error('Invalid token');
            }
            if (!campaignId || isNaN(campaignId)) {
                $.error('Invalid campaign id');
            }
            if (!callbackFunction) {
                $.error('Invalid callback function');
            };

            var uri = this.uri + campaignId + "/";
            var defaultFields = "id,name,account_id,campaign_status,start_time,end_time,updated_time,created_time,daily_budget,lifetime_budget,budget_remaining";
            var objPost = {};

            objPost.access_token = token;
            objPost.fields = ((!fields || typeof fields != 'string') ? defaultFields : fields);
            objPost.callback = callbackFunction;

            /*post*/
            $.ajax({
                type: 'GET',
                url: uri,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdCampaign.fbReadById: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('AdCampaign.fbReadById: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    var message = '';
                    if (jqXHR.hasOwnProperty('responseText')) {
                        try {
                            eval(jqXHR.responseText);
                        } catch (e) {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdCampaign.fbReadById: ', e);
                            }
                        }
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && e.hasOwnProperty('message') && typeof e.message == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e.message + '\'}});');
            } else {
                console.log('AdCampaign.fbReadById: ', e);
            }
        }
    };
    this.fbRead = function(token, accountId, fields, callbackFunction) {
        try {
            if (!token || typeof token != 'string') throw 'invalid token';
            if (!accountId || isNaN(accountId)) throw 'invalid accountId';
            if (!callbackFunction) throw 'invalid callbackFunction';

            var uri = this.uri + 'act_' + accountId + "/adcampaigns";
            var defaultFields = "id,name,account_id,campaign_status,start_time,end_time,updated_time,created_time,daily_budget,lifetime_budget,budget_remaining";
            var objPost = {};

            objPost.access_token = token;
            objPost.fields = ((!fields || typeof fields != 'string') ? defaultFields : fields);
            objPost.callback = callbackFunction;

            /*post*/
            $.ajax({
                type: 'GET',
                url: uri,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdCampaign.fbRead: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('AdCampaign.fbRead: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (callbackFunction && typeof callbackFunction == 'string') {
                        eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                    } else {
                        console.log('AdCampaign.fbRead: ', e);
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && typeof e == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e + '\'}});');
            } else {
                console.log('AdCampaign.fbRead: ', e);
            }
        }
    };
    this.fbReadStatsById = function(token, campaignId, startTime, endTime, callbackFunction) {
        try {
            if (!token || typeof token != 'string') {
                $.error('Invalid token');
            }
            if (!campaignId || isNaN(campaignId)) {
                $.error('Invalid campaign id');
            }
            if (!callbackFunction) {
                $.error('Invalid callback function');
            };

            var uri = this.uri + campaignId + "/stats/";

            var objPost = {};
            objPost.access_token = token;
            objPost.callback = callbackFunction;

            if (startTime && typeof startTime == 'string')
                objPost.start_time = startTime;

            if (endTime && typeof endTime == 'string')
                objPost.end_time = endTime;

            /*post*/
            $.ajax({
                type: 'GET',
                url: uri,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdCampaign.fbReadStatsById: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('AdCampaign.fbReadStatsById: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    var message = '';
                    if (jqXHR.hasOwnProperty('responseText')) {
                        try {
                            eval(jqXHR.responseText);
                        } catch (e) {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdCampaign.fbReadStatsById: ', e);
                            }
                        }
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && e.hasOwnProperty('message') && typeof e.message == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e.message + '\'}});');
            } else {
                console.log('AdCampaign.fbReadStatsById: ', e);
            }
        }
    };
    this.fbUpdate = function(token, campaignId, updateObject, callbackFunction) {
        // console.log('aaa', token, campaignId, updateObject, callbackFunction);
        try {
            if (!token || typeof token != 'string') {
                $.error('Invalid token');
            }
            if (!campaignId || isNaN(campaignId)) {
                $.error('Invalid campaign id');
            }
            if (!updateObject || !(typeof updateObject === 'object') || $.isEmptyObject(updateObject)) {
                $.error('Invalid update params');
            }
            if (!callbackFunction) {
                $.error('Invalid callback function');
            };

            var availableFiledsToUpdate = ['name', 'daily_budget', 'lifetime_budget', 'campaign_status', 'end_time', 'start_time'];
            var newUpdateObject = {};
            for (var i in updateObject) {
                for (var e in availableFiledsToUpdate) {
                    if (i != availableFiledsToUpdate[e])
                        continue;

                    newUpdateObject[i] = updateObject[i];
                }
            }

            if (!newUpdateObject || !(typeof newUpdateObject === 'object') || $.isEmptyObject(newUpdateObject)) {
                $.error('Invalid update params');
            }

            var uri = this.uri + campaignId;

            var objPost = {};
            objPost.access_token = token;
            objPost.callback = callbackFunction;
            for (var i in newUpdateObject) {
                objPost[i] = newUpdateObject[i];
            }

            /*post*/
            $.ajax({
                type: 'POST',
                url: uri,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn.replace(callbackFunction + '(', callbackFunction + '(' + campaignId + ','));
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '(' + campaignId + ',{\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdCampaign.fbUpdate: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('AdCampaign.fbUpdate: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    var message = '';
                    if (jqXHR.hasOwnProperty('responseText')) {
                        try {
                            eval(jqXHR.responseText.replace(callbackFunction + '(', callbackFunction + '(' + campaignId + ','));
                        } catch (e) {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '(' + campaignId + ',{\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdCampaign.fbUpdate: ', e);
                            }
                        }
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && e.hasOwnProperty('message') && typeof e.message == 'string') {
                eval(callbackFunction + '(' + campaignId + ',{\'error\':{\'message\':\'' + e.message + '\'}});');
            } else {
                console.log('AdCampaign.fbUpdate: ', e);
            }
        }
    };
    this.fbDelete = function(token, campaignId, callbackFunction) {
        try {
            if (!token || typeof token != 'string') {
                $.error('Invalid token');
            }
            if (!campaignId || isNaN(campaignId)) {
                $.error('Invalid campaign id');
            }
            if (!callbackFunction) {
                $.error('Invalid callback function');
            };

            var uri = this.uri + campaignId;

            var objPost = {};
            objPost.access_token = token;
            objPost.callback = callbackFunction;

            /*post*/
            $.ajax({
                type: 'DELETE',
                url: uri,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdCampaign.fbDelete: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('AdCampaign.fbDelete: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    var message = '';
                    if (jqXHR.hasOwnProperty('responseText')) {
                        try {
                            eval(jqXHR.responseText);
                        } catch (e) {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdCampaign.fbDelete: ', e);
                            }
                        }
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && e.hasOwnProperty('message') && typeof e.message == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e.message + '\'}});');
            } else {
                console.log('AdCampaign.fbDelete: ', e);
            }
        }
    };

    /* ações construtoras */
    var self = this; /* mágica da orientação a objetos do javascript */
    this.setArrObj(arrObj);
    this.setCredentials(objCredentials);
}

//  AD GROUP
// *  https://developers.facebook.com/docs/reference/ads-api/adgroup/
// *  https://developers.facebook.com/docs/reference/ads-api/reachestimate/
// *
// *  AdGroup.getReachEstimate() : efetua busca de publico alvo e média de bidding (cpa, cpm, ocpm)

function AdGroup() {
    this.uri = 'https://graph.facebook.com/';
    this.getReachEstimate = function(token, accountId, currency, locale, callbackFunction, targeting_spec) {
        try {
            if (!token || typeof token != 'string') throw 'invalid token';
            if (!accountId || isNaN(accountId)) throw 'invalid accountId';
            if (!currency || typeof currency != 'string') throw 'invalid currency';
            if (!locale || typeof locale != 'string') throw 'invalid locale';
            if (!callbackFunction) throw 'invalid callbackFunction';
            if (!targeting_spec instanceof Object || $.isEmptyObject(targeting_spec)) throw 'invalid targeting_spec';

            var uri = 'https://graph.facebook.com/act_' + accountId + '/reachestimate';
            var objPost = {};
            objPost.access_token = token;
            objPost.callback = callbackFunction;
            objPost.currency = currency; //BRL
            objPost.locale = locale; //pt_BR
            objPost.pretty = 0;
            objPost.targeting_spec = JSON.stringify(targeting_spec);

            /*post*/
            $.ajax({
                type: 'GET',
                url: uri,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdGroup.getReachEstimate: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('AdGroup.getReachEstimate: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (callbackFunction && typeof callbackFunction == 'string') {
                        eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                    } else {
                        console.log('AdGroup.getReachEstimate: ', e);
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && typeof e == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e + '\'}});');
            } else {
                console.log('AdGroup.getReachEstimate: ', e);
            }
        }
    };
    this.createAnAd = function(token, accountId, ad, callbackFunction) {
        try {
            if (!token || typeof token != 'string') throw 'invalid token';
            if (!accountId || isNaN(accountId)) throw 'invalid accountId';
            if (!ad instanceof Object || $.isEmptyObject(ad)) throw 'invalid ad';
            if (!callbackFunction) throw 'invalid callbackFunction';

            var objPost = {};
            var uri;

            for (var a in ad) {
                if (ad[a] == null || ad[a] == '')
                    continue;

                objPost[a] = ad[a];
            }

            objPost.access_token = token;
            objPost.callback = callbackFunction;

            if (objPost.hasOwnProperty('ad_id'))
                uri = this.uri + objPost.ad_id;
            else
                uri = this.uri + 'act_' + accountId + '/adgroups';

            console.log('uri', uri);
            console.log('objPost', objPost);

            $.ajax({
                type: 'POST',
                url: uri,
                data: objPost,
                dataType: 'text',
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdGroup.createAnAd: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('AdGroup.createAnAd: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (callbackFunction && typeof callbackFunction == 'string') {
                        eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                    } else {
                        console.log('AdGroup.createAnAd: ', e);
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && typeof e == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e + '\'}});');
            } else {
                console.log('AdGroup.createAnAd: ', e);
            }
        }
    };
    this.fbGetByCampaignId = function(token, campaignId, fields, includeDeleted, limit, callbackFunction) {
        try {
            if (!token || typeof token != 'string') {
                $.error('Invalid token');
            }
            if (!campaignId || isNaN(campaignId)) {
                $.error('Invalid campaign id');
            }
            if (!callbackFunction) {
                $.error('Invalid callback function');
            };

            var uri = this.uri + campaignId + "/adgroups/";
            var defaultFields = "id,campaign_id,account_id,name,adgroup_status,bid_type,disapprove_reason_descriptions,last_updated_by_app_id,view_tags,created_time,updated_time,bid_info,conversion_specs,tracking_specs,targeting,creative_ids,disapprove_reason_descriptions";
            var objPost = {};

            objPost.access_token = token;
            objPost.fields = ((!fields || typeof fields != 'string') ? defaultFields : fields);
            objPost.callback = callbackFunction;
            objPost.limit = (!limit || isNaN(limit) || parseInt(limit) <= 0) ? 500 : limit;
            objPost.include_deleted = includeDeleted == true ? 'true' : 'false';

            /*post*/
            $.ajax({
                type: 'GET',
                url: uri,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdGroup.fbGetByCampaignId: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('AdGroup.fbGetByCampaignId: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    var message = '';
                    if (jqXHR.hasOwnProperty('responseText')) {
                        try {
                            eval(jqXHR.responseText);
                        } catch (e) {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdGroup.fbGetByCampaignId: ', e);
                            }
                        }
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && e.hasOwnProperty('message') && typeof e.message == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e.message + '\'}});');
            } else {
                console.log('AdGroup.fbGetByCampaignId: ', e);
            }
        }
    };
    this.fbReadStatsByIds = function(token, accountId, adIds, startTime, endTime, limit, callbackFunction) {
        try {
            if (!token || typeof token != 'string') {
                $.error('Invalid token');
            }
            if (!accountId || isNaN(accountId)) {
                $.error('Invalid account id');
            }
            if (!adIds || !$.isArray(adIds) || adIds.length <= 0) {
                $.error('Invalid ad ids');
            }
            if (!callbackFunction) {
                $.error('Invalid callback function');
            };

            var uri = this.uri + 'act_' + accountId + "/adgroupstats/";

            var objPost = {};
            objPost.access_token = token;
            objPost.adgroup_ids = '[' + adIds.join(',') + ']'
            objPost.callback = callbackFunction;
            objPost.limit = (!limit || isNaN(limit) || parseInt(limit) <= 0) ? 500 : limit;

            if (startTime && typeof startTime == 'string')
                objPost.start_time = startTime;

            if (endTime && typeof endTime == 'string')
                objPost.end_time = endTime;

            /*post*/
            $.ajax({
                type: 'GET',
                url: uri,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdGroup.fbReadStatsByIds: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('AdGroup.fbReadStatsByIds: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    var message = '';
                    if (jqXHR.hasOwnProperty('responseText')) {
                        try {
                            eval(jqXHR.responseText);
                        } catch (e) {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdGroup.fbReadStatsByIds: ', e);
                            }
                        }
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && e.hasOwnProperty('message') && typeof e.message == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e.message + '\'}});');
            } else {
                console.log('AdGroup.fbReadStatsByIds: ', e);
            }
        }
    };
    this.fbUpdate = function(token, adId, updateObject, callbackFunction) {
        try {
            if (!token || typeof token != 'string') {
                $.error('Invalid token');
            }
            if (!adId || isNaN(adId)) {
                $.error('Invalid ad id');
            }
            if (!updateObject || !(typeof updateObject === 'object') || $.isEmptyObject(updateObject)) {
                $.error('Invalid update params');
            }
            if (!callbackFunction) {
                $.error('Invalid callback function');
            };

            var availableFiledsToUpdate = ['name', 'bid_type', 'bid_info', 'conversion_specs', 'creative', 'targeting', 'tracking_specs', 'view_tags', 'social_prefs', 'adgroup_status'];
            var newUpdateObject = {};
            for (var i in updateObject) {
                for (var e in availableFiledsToUpdate) {
                    if (i != availableFiledsToUpdate[e])
                        continue;

                    newUpdateObject[i] = (typeof updateObject[i] === 'object') ? JSON.stringify(updateObject[i]) : updateObject[i];
                }
            }

            if (!newUpdateObject || !(typeof newUpdateObject === 'object') || $.isEmptyObject(newUpdateObject)) {
                $.error('Invalid update params');
            }

            var uri = this.uri + adId;

            var objPost = {};
            objPost.access_token = token;
            objPost.callback = callbackFunction;
            for (var i in newUpdateObject) {
                objPost[i] = newUpdateObject[i];
            }

            /*post*/
            $.ajax({
                type: 'POST',
                url: uri,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn.replace(callbackFunction + '(', callbackFunction + '(' + adId + ','));
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '(' + adId + ',{\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdGroup.fbUpdate: error');
                            }
                        }
                    } catch (e) {
                        console.log('AdGroup.fbUpdate: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    var message = '';
                    if (jqXHR.hasOwnProperty('responseText')) {
                        try {
                            eval(jqXHR.responseText.replace(callbackFunction + '(', callbackFunction + '(' + adId + ','));
                        } catch (e) {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '(' + adId + ',{\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdGroup.fbUpdate: ', e);
                            }
                        }
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && e.hasOwnProperty('message') && typeof e.message == 'string') {
                eval(callbackFunction + '(' + adId + ',{\'error\':{\'message\':\'' + e.message + '\'}});');
            } else {
                console.log('AdGroup.fbUpdate: ', e);
            }
        }
    };
    this.fbDelete = function(token, adId, callbackFunction) {
        try {
            if (!token || typeof token != 'string') {
                $.error('Invalid token');
            }
            if (!adId || isNaN(adId)) {
                $.error('Invalid ad id');
            }
            if (!callbackFunction) {
                $.error('Invalid callback function');
            };

            var uri = this.uri + adId;

            var objPost = {};
            objPost.access_token = token;
            objPost.callback = callbackFunction;

            /*post*/
            $.ajax({
                type: 'DELETE',
                url: uri,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn.replace(callbackFunction + '(', callbackFunction + '(' + adId + ','));
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '(' + adId + ',{\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdGroup.fbDelete: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('AdGroup.fbDelete: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    var message = '';
                    if (jqXHR.hasOwnProperty('responseText')) {
                        try {
                            eval(jqXHR.responseText.replace(callbackFunction + '(', callbackFunction + '(' + adId + ','));
                        } catch (e) {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '(' + adId + ',{\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdGroup.fbDelete: ', e);
                            }
                        }
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && e.hasOwnProperty('message') && typeof e.message == 'string') {
                eval(callbackFunction + '(' + adId + ',{\'error\':{\'message\':\'' + e.message + '\'}});');
            } else {
                console.log('AdGroup.fbDelete: ', e);
            }
        }
    };
    this.fbPreview = function(token, adId, callbackFunction) {
        try {
            if (!token || typeof token != 'string') {
                $.error('Invalid token');
            }
            if (!adId || isNaN(adId)) {
                $.error('Invalid ad id');
            }
            if (!callbackFunction) {
                $.error('Invalid callback function');
            };

            var uri = this.uri + adId + '/previews';

            var objPost = {};
            objPost.access_token = token;
            objPost.callback = callbackFunction;

            /*post*/
            $.ajax({
                type: 'GET',
                url: uri,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn.replace(callbackFunction + '(', callbackFunction + '(' + adId + ','));
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '(' + adId + ',{\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdGroup.fbPreview: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('AdGroup.fbPreview: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    var message = '';
                    if (jqXHR.hasOwnProperty('responseText')) {
                        try {
                            eval(jqXHR.responseText.replace(callbackFunction + '(', callbackFunction + '(' + adId + ','));
                        } catch (e) {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '(' + adId + ',{\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdGroup.fbPreview: ', e);
                            }
                        }
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && e.hasOwnProperty('message') && typeof e.message == 'string') {
                eval(callbackFunction + '(' + adId + ',{\'error\':{\'message\':\'' + e.message + '\'}});');
            } else {
                console.log('AdGroup.fbPreview: ', e);
            }
        }
    };
}

//  AD CREATIVE
//  https://developers.facebook.com/docs/reference/ads-api/adcreative/
//  AdCreative.getCreative() : recupera as informações do criativo do anúncio

function AdCreative() {
    this.uri = 'https://graph.facebook.com/';
    this.getCreative = function(creativeId, token, fields, callbackFunction) {
        try {
            if (!creativeId || isNaN(creativeId)) throw 'invalid creativeId';
            if (!token || typeof token != 'string') throw 'invalid token';
            if (!callbackFunction) throw 'invalid callbackFunction';

            var uri = this.uri + creativeId;
            var objPost = {};

            if (fields && typeof fields === 'string')
                objPost.fields = (fields || 'story_id, type, object_id');

            objPost.access_token = token;
            objPost.callback = callbackFunction;

            $.ajax({
                type: 'GET',
                url: uri,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdCreative.AdObjectByUrl: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('AdCreative.AdObjectByUrl: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (callbackFunction && typeof callbackFunction == 'string') {
                        eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                    } else {
                        console.log('AdCreative.AdObjectByUrl: ', e);
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && typeof e == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e + '\'}});');
            } else {
                console.log('AdCreative.AdObjectByUrl: ', e);
            }
        }
    };
}

//  AD IMAGE
//  https://developers.facebook.com/docs/reference/ads-api/adimage/
//  https://graph.facebook.com/act_AccountID/adimages?hashes=["0d500843a1d4699a0b41e99f4137a5c3","012feg987e98g789f789e87976210983"]
//  AdImage.getImageByHash() : recupera as url das imagens da biblioteca criativa através dos seus respectivos hashes

function AdImage() {
    this.uri = 'https://graph.facebook.com/';
    this.getImageByHash = function(accountId, arrHashes, token, callbackFunction) {
        try {
            if (!accountId || isNaN(accountId)) throw 'invalid accountId';
            if (!arrHashes || (arrHashes instanceof Object && !$.isEmptyObject(arrHashes))) throw 'invalid arrHashes';
            if (!token || typeof token != 'string') throw 'invalid token';
            if (!callbackFunction) throw 'invalid callbackFunction';

            var uri = this.uri + 'act_' + accountId + '/adimages';
            var objPost = {};

            if ($.isArray(arrHashes)) {
                objPost.hashes = JSON.stringify(arrHashes);
            } else {
                objPost.hashes = JSON.stringify([arrHashes]);
            }

            objPost.access_token = token;
            objPost.callback = callbackFunction;

            $.ajax({
                type: 'GET',
                url: uri,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('AdImage.getImageByHash: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('AdImage.getImageByHash: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (callbackFunction && typeof callbackFunction == 'string') {
                        eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                    } else {
                        console.log('AdImage.getImageByHash: ', e);
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && typeof e == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e + '\'}});');
            } else {
                console.log('AdImage.getImageByHash: ', e);
            }
        }
    };
}

//  CONVERSION PIXELS
// *  https://developers.facebook.com/docs/reference/ads-api/offsite-pixels/
// 
// ConversionPixels.Create() : Cria o pixel;
// ConversionPixels.Get() : Recupera as informações do pixel;
// ConversionPixels.ReadByAdAccount() : Recupera todos os pixels a partir do AccountId
// ConversionPixels.Delete() : Apaga pixels a partir do AccountId

function ConversionPixels() {
    this.uri = 'https://graph.facebook.com/';
    this.Create = function(token, accountId, name, tag, callbackFunction) {
        try {
            if (!token || typeof token != 'string') throw 'invalid token';
            if (!accountId || isNaN(accountId)) throw 'invalid accountId';
            if (!name || typeof name != 'string') throw 'invalid name';
            if (!tag || typeof tag != 'string') throw 'invalid tag';
            if (!callbackFunction) throw 'invalid callbackFunction';

            var uri = this.uri + 'act_' + accountId + '/offsitepixels';
            var objPost = {};
            objPost.access_token = token;
            objPost.name = name;
            objPost.tag = tag;
            objPost.callback = callbackFunction;

            $.ajax({
                type: 'POST',
                url: uri,
                data: objPost,
                dataType: 'text',
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('ConversionPixels.Create: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('ConversionPixels.Create: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (callbackFunction && typeof callbackFunction == 'string') {
                        eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                    } else {
                        console.log('ConversionPixels.Create: ', e);
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && typeof e == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e + '\'}});');
            } else {
                console.log('ConversionPixels.Create: ', e);
            }
        }
    };
    this.Get = function(token, pixelId, callbackFunction) {
        try {
            if (!token || typeof token != 'string') throw 'invalid token';
            if (!pixelId || isNaN(pixelId)) throw 'invalid pixelId';
            if (!callbackFunction) throw 'invalid callbackFunction';

            var uri = this.uri + pixelId;
            var objPost = {};
            objPost.access_token = token;
            objPost.callback = callbackFunction;

            $.ajax({
                type: 'GET',
                url: uri,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('ConversionPixels.Get: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('ConversionPixels.Get: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (callbackFunction && typeof callbackFunction == 'string') {
                        eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                    } else {
                        console.log('ConversionPixels.Get: ', e);
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && typeof e == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e + '\'}});');
            } else {
                console.log('ConversionPixels.Get: ', e);
            }
        }
    };
    this.ReadByAdAccount = function(token, accountId, callbackFunction) {
        try {
            if (!token || typeof token != 'string') throw 'invalid token';
            if (!accountId || isNaN(accountId)) throw 'invalid accountId';
            if (!callbackFunction) throw 'invalid callbackFunction';

            var uri = this.uri + 'act_' + accountId + '/offsitepixels';
            var objPost = {};
            objPost.access_token = token;
            objPost.callback = callbackFunction;

            $.ajax({
                type: 'GET',
                url: uri,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('ConversionPixels.ReadByAdAccount: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('ConversionPixels.ReadByAdAccount: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (callbackFunction && typeof callbackFunction == 'string') {
                        eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                    } else {
                        console.log('ConversionPixels.ReadByAdAccount: ', e);
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && typeof e == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e + '\'}});');
            } else {
                console.log('ConversionPixels.ReadByAdAccount: ', e);
            }
        }
    };
    this.Delete = function(token, pixelId, callbackFunction) {
        try {
            if (!token || typeof token != 'string') throw 'invalid token';
            if (!pixelId || isNaN(pixelId)) throw 'invalid pixelId';
            if (!callbackFunction) throw 'invalid callbackFunction';

            var uri = this.uri + pixelId;
            var objPost = {};
            objPost.access_token = token;
            objPost.callback = callbackFunction;

            $.ajax({
                type: 'DELETE',
                url: uri,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('ConversionPixels.Delete: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('ConversionPixels.Delete: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (callbackFunction && typeof callbackFunction == 'string') {
                        eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                    } else {
                        console.log('ConversionPixels.Delete: ', e);
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && typeof e == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e + '\'}});');
            } else {
                console.log('ConversionPixels.Delete: ', e);
            }
        }
    };
}

//  Search
// * https://developers.facebook.com/docs/reference/api/search/
// 
// ConversionPixels.Create() : Cria o pixel;

function Search() {
    this.uri = 'https://graph.facebook.com/search';
    this.AdObjectByUrl = function(token, q, callbackFunction) {
        try {
            if (!token || typeof token != 'string') throw 'invalid token';
            if (!q || typeof q != 'string') throw 'invalid q';
            if (!callbackFunction) throw 'invalid callbackFunction';

            var uri = this.uri;
            var objPost = {};
            objPost.type = 'adobjectbyurl';
            objPost.q = q;
            objPost.access_token = token;
            objPost.callback = callbackFunction;

            $.ajax({
                type: 'GET',
                url: uri,
                data: objPost,
                dataType: 'text',
                cache: false,
                crossDomain: true,
                success: function(fbReturn) {
                    try {
                        if (fbReturn && typeof fbReturn == 'string') {
                            eval(fbReturn);
                        } else {
                            if (callbackFunction && typeof callbackFunction == 'string') {
                                eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                            } else {
                                console.log('Search.AdObjectByUrl: ', e);
                            }
                        }
                    } catch (e) {
                        console.log('Search.AdObjectByUrl: ', e);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (callbackFunction && typeof callbackFunction == 'string') {
                        eval(callbackFunction + '({\'error\':{\'message\':\'invalid Facebook response\'}});');
                    } else {
                        console.log('Search.AdObjectByUrl: ', e);
                    }
                }
            });
        } catch (e) {
            if (callbackFunction && typeof callbackFunction == 'string' && typeof e == 'string') {
                eval(callbackFunction + '({\'error\':{\'message\':\'' + e + '\'}});');
            } else {
                console.log('Search.AdObjectByUrl: ', e);
            }
        }
    };
}