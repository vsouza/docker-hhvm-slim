Notifications = {
    pagination: 5, // Pagination setting
    length: 0,
    unread: 0,
    getNotifications: function(markRead, orderBy) {
        orderBy = orderBy || null;
        var url = '/notifications';
        if (markRead) url += '/read';
        url += '/' + this.pagination + '/' + (this.length);
        log(url);
        var self = this;
        $.ajax({
            type: 'get',
            url: url,
            success: function(notifications) {
                try {
                    if (self.length == 0) handleHudNotifications(notifications);
                    handleNotitifications(notifications);
                    self.length += self.pagination;
                    self.unread = notifications.message;

                } catch (e) {
                    console.log('Notifications.getNotifications:' + e);
                }
            },
            error: function() {
                console.log('error loading notifications');
            }
        });
    },
};


function getNotifications() {
    Notifications.getNotifications();
}

function handleHudNotifications(notifications) {
    $("#global-unread").text(notifications.message);
    CreateClass.MyHandlebars(notifications, "wrapnotifications").simpleRender();
}

$(document).ready(function() {
    // DESCOMENTAR ESSA LINHA
    // getNotifications(); 
});