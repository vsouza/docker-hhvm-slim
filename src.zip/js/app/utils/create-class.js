////////////////////
// OBJECT FACTORY //
////////////////////

var CreateClass = {
    CheckIn: function() {
        return new CheckIn();
    },
    Regional: function() {
        var instance = {};
        if (!tbCookie.has("currentRegional")) {
            tbCookie.set("currentRegional", JSON.stringify(DEF_CONFIG.get('REGIONAL')));
            instance = new Regional(DEF_CONFIG.get('REGIONAL'));
        } else {
            instance = new Regional(JSON.parse(tbCookie.get("currentRegional")));
        }

        return instance;
    },
    FbUser: function(a) {
        return new FbUser(a);
    },
    AdAccount: function(a) {
        return new AdAccount(a);
    },
    AdCampaignGroup: function() {
        return new AdCampaignGroup();
    },
    AdCampaign: function(a, b) {
        return new AdCampaign(a, b);
    },
    MyHandlebars: function(a, b) {
        return new MyHandlebars(a, b);
    },
    FbPage: function() {
        return new FbPage();
    },
    AdGroup: function() {
        return new AdGroup();
    },
    AdCreative: function() {
        return new AdCreative();
    },
    AdImage: function() {
        return new AdImage();
    },
    ConversionPixels: function() {
        return new ConversionPixels();
    },
    Search: function() {
        return new Search();
    },
};
