module.exports = require("./moment-timezone");
module.exports.tz.add(require('./moment-timezone.json'));
