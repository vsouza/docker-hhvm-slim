// Generated on 2013-10-29 using generator-php 0.1.0
'use strict';

// # Folder Paths
// to match only one level down:
// 'test/spec/{,*/}*.js'
// to recursively match all subfolders:
// 'test/spec/**/*.js'

module.exports = function(grunt) {
    // load all grunt tasks
    require('matchdep').filterDev('grunt-*').forEach(grunt.loadNpmTasks);

    // configurable paths
    var yeomanConfig = {
        app: 'app',
        assets: 'assets',
        dist: 'public',
        views: 'app/Views',
        viewsbuild: 'build/Views'
    };

    grunt.initConfig({
        yeoman: yeomanConfig,

        // Develpment
        watch: {
            css: {
                files: ['<%= yeoman.assets %>/css/*.css'],
                options: {
                    livereload: true
                }
            },
            sass: {
                files: ['<%= yeoman.assets %>/scss/**/*.{scss,sass}'],
                tasks: ['sass:watch'],
                options: {
                    spawn: false
                }
            },
            php: {
                files: ['<%= yeoman.app %>/Views/**/*.php'],
                options: {
                    livereload: true
                }
            },
            js: {
                files: [
                    'js/**/*.js',
                ],
                // tasks: ['jshint']
            },
        },
        sass: {
            options: {
                sourceMap: true,
                sourceComments: false
            },
            watch: {
                files: {} // populated by sass watch event
            },
            dist: {
                files: {
                    '<%= yeoman.assets %>/css/website.css': '<%= yeoman.assets %>/scss/website.scss',
                    '<%= yeoman.assets %>/css/main.css': '<%= yeoman.assets %>/scss/main.scss',
                    '<%= yeoman.assets %>/css/goals.css': '<%= yeoman.assets %>/scss/goals.scss',
                    '<%= yeoman.assets %>/css/tests.css': '<%= yeoman.assets %>/scss/tests.scss',
                }
            },
        },
        jshint: {
            options: {
                jshintrc: '.jshintrc'
            },
            all: {
                src: [
                    'Gruntfile.js',
                    'js/app/**/*.js',
                ]
            }
        },

        // Build
        clean: {
            server: ['.tmp'],
            dist: {
                files: [{
                    dot: true,
                    src: [
                        '.tmp',
                        '<%= yeoman.dist %>/**/*',
                        '<%= yeoman.viewsbuild %>/**/*',
                        '!<%= yeoman.dist %>/.git*',
                        '!<%= yeoman.dist %>/.htaccess',
                        '!<%= yeoman.dist %>/index.php',
                    ]
                }]
            }
        },
        useminPrepare: {
            options: {
                dest: '<%= yeoman.dist %>'
            },
            html: '<%= yeoman.app %>/Views/**/*{.html,.php}'
        },
        copy: {
            assets: {
                files: [{
                    expand: true,
                    dot: true,
                    cwd: '<%= yeoman.assets %>',
                    dest: '<%= yeoman.dist %>/<%= yeoman.assets %>',
                    src: [
                        '*.{ico,png,txt}',
                        'img/**/*.{png,jpg,gif,webp,gif}',
                        'font/*',
                        '.htaccess',
                    ]
                }]
            },
            jslocale: {
                files: [{
                    expand: true,
                    dot: true,
                    cwd: 'js',
                    dest: '<%= yeoman.dist %>/js',
                    src: [
                        'locale/**/*',
                    ]
                }]
            },
            views: {
                files: [{
                    expand: true,
                    dot: true,
                    cwd: '<%= yeoman.views %>',
                    dest: '<%= yeoman.viewsbuild %>',
                    src: [
                        '**/*',
                        '!_build',
                    ]
                }]
            },
            favicon: {
                files: [{
                    expand: true,
                    dot: true,
                    cwd: '',
                    dest: '<%= yeoman.dist %>',
                    src: [
                        '*.ico',
                    ]
                }]
            },
        },
        rev: {
            dist: {
                files: {
                    src: [
                        '<%= yeoman.dist %>/js/**/*.js',
                        '!<%= yeoman.dist %>/js/locale/**/*.js',
                        '<%= yeoman.dist %>/<%= yeoman.assets %>/css/**/*.css',
                        '<%= yeoman.dist %>/<%= yeoman.assets %>/img/**/*.{png,jpg,jpeg,gif,webp}'
                    ]
                }
            }
        },
        usemin: {
            html: ['<%= yeoman.viewsbuild %>/**/*{.html,.php}', '<%= yeoman.dist %>/**/*{.html,.php}'],
            css: ['<%= yeoman.dist %>/<%= yeoman.assets %>/css/**/*.css'],
            js: ['<%= yeoman.dist %>/js/**/*.js'],
            options: {
                assetsDirs: [ // Matches relative paths from builded files
                    '<%= yeoman.dist %>', // /assets/css
                    '<%= yeoman.dist %>/<%= yeoman.assets %>/css', // ../img inside CSS
                    '<%= yeoman.dist %>/<%= yeoman.assets %>', // imgs inside JS
                    '<%= yeoman.dist %>/..' // /assets/img
                ],
                patterns: {
                  js: [
                      [/(img\/.*?\.(?:gif|jpeg|jpg|png|webp|svg))/gm, 'Updating JS to revved images']
                  ]
                }
            },
        },
        concurrent: {
            dist: [
                'sass:dist',
                'imagemin',
                'htmlmin'
            ],
        },
        imagemin: {
            dist: {
                files: [{
                    expand: true,
                    cwd: '<%= yeoman.assets %>/<%= yeoman.assets %>/img',
                    src: '**/*.{png,jpg,jpeg}',
                    dest: '<%= yeoman.dist %>/<%= yeoman.assets %>/img'
                }]
            }
        },
        htmlmin: {
            dist: {
                files: [{
                    expand: true,
                    cwd: '<%= yeoman.app %>',
                    src: '**/*.{html}',
                    dest: '<%= yeoman.dist %>'
                }]
            }
        },
        // cdn: {
        //     options: {
        //         cdn: 'http://cdn.cloudfront.net/container/',
        //         flatten: true,
        //         supportedTypes: { 'php': 'html' }
        //     },
        //     dist: {
        //         src: ['<%= yeoman.app %>/Views/_build/**/*.php'],
        //     }
        // },
    });

    // watch events
    grunt.event.on('watch', function(action, filepath, target) {
        if(target == "sass") {
            var files = {};
            var csspath = filepath.replace(/scss|sass/g, 'css');
            files[csspath] = filepath;
            grunt.config('sass.watch.files', files);
        }
        if(target == "js") {
            grunt.config('jshint.all.src', filepath);
        }
    });

    grunt.registerTask('build', [
        'clean:dist',
        'useminPrepare',
        'concurrent:dist',
        'concat',
        'cssmin',
        'uglify',
        'copy:assets',
        'copy:jslocale',
        'copy:views',
        'copy:favicon',
        'rev',
        'usemin'
    ]);

    grunt.registerTask('default', [
        'watch'
    ]);
};
